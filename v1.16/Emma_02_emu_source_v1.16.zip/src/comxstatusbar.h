#ifndef COMXSTATUSBAR_H
#define COMXSTATUSBAR_H

#define LED_SIZE_X 12
#define LED_SIZE_Y 7

class ComxStatusBar : public wxStatusBar
{
public:
	ComxStatusBar(wxWindow *parent);
	~ComxStatusBar();

	void initComxBar(bool expansionRomLoaded, int expansionTypeCard0);
	void updateLedStatus(int card, int i, bool status);
	void reDrawBar();

private:
	void displayText();
	void displayLeds();
	void deleteBitmaps();
	void updateStatusBarText();

	wxButton *ledBitmapPointers [4][2];
	wxBitmap *ledOffPointer;
	wxBitmap *ledOnPointer;

	bool expansionRomLoaded_;
	int expansionTypeCard0_;
	bool ledsDefined_;
};

#endif  //_comxstatusbar_H_