/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "main.h"
#include "comxstatusbar.h"

ComxStatusBar::ComxStatusBar(wxWindow *parent)
: wxStatusBar(parent, wxID_ANY, 0)
{
	ledOffPointer = new wxBitmap("images/comxledoff.png", wxBITMAP_TYPE_PNG);
	ledOnPointer = new wxBitmap("images/comxledon.png", wxBITMAP_TYPE_PNG);
	ledsDefined_ = false;
}

ComxStatusBar::~ComxStatusBar()
{
	delete ledOffPointer;
	delete ledOnPointer;
	deleteBitmaps();
}

void ComxStatusBar::initComxBar(bool expansionRomLoaded, int expansionTypeCard0)
{
	expansionRomLoaded_ = expansionRomLoaded;
	expansionTypeCard0_ = expansionTypeCard0;
	SetFieldsCount(5);
	displayLeds();
	displayText();
}

void ComxStatusBar::updateLedStatus(int card, int i, bool status)
{
	if (status)
	{
		ledBitmapPointers [card][i]->SetBitmap(*ledOnPointer);
	}
	else
	{
		ledBitmapPointers [card][i]->SetBitmap(*ledOffPointer);
	}
}

void ComxStatusBar::displayText()
{
	wxRect rect;
	this->GetFieldRect (1, rect);
	if (expansionRomLoaded_)
	{
		if (rect.GetWidth() < 80)
			SetStatusText("E-Box", 0);
		else
			SetStatusText("Expansion Box", 0);
	}
	else
	{
		if (expansionTypeCard0_ != COMXEMPTY)
		{
			if (rect.GetWidth() < 80)
				SetStatusText("E-Card", 0);
			else
				SetStatusText("Expansion Card", 0);
		}
	}
}

void ComxStatusBar::displayLeds()
{
	deleteBitmaps();

	wxRect rect;
	this->GetFieldRect (1, rect);

	for (int card = 0; card < 4; card++)
	{
		for (int i = 0; i < 2; i++)
		{
#if defined(__WXGTK__)
			ledBitmapPointers [card][i] = new wxButton(this, wxID_ANY, wxEmptyString, 
							         wxPoint((card+1)*(rect.GetWidth()+1)+i*14+16, 4), wxSize(-1, -1),
							         wxBORDER_NONE);  //Not tested, was: wxNO_BORDER | wxBU_EXACTFIT | wxBU_TOP);
#else
			ledBitmapPointers [card][i] = new wxButton(this, wxID_ANY, wxEmptyString, 
							         wxPoint((card+1)*(rect.GetWidth()+1)+i*14+16, 9), wxSize(LED_SIZE_X, LED_SIZE_Y),
							         wxBORDER_NONE);
#endif
			ledBitmapPointers [card][i]->SetBitmap(*ledOffPointer);
			if (p_Computer->getComxExpansionType(card) == COMXEMPTY)
				ledBitmapPointers[card][i]->Hide();
			if ((!expansionRomLoaded_) &&(card >0))
				ledBitmapPointers[card][i]->Hide();
		}
	}
	ledsDefined_ = true;
}

void ComxStatusBar::deleteBitmaps()
{
	if (!ledsDefined_)  return;
	for (int card = 0; card < 4; card++)
	{
		for (int i = 0; i < 2; i++)
		{
			delete ledBitmapPointers [card][i];
		}
	}
	ledsDefined_ = false;
}

void ComxStatusBar::reDrawBar()
{
	displayText();
	updateStatusBarText();
	displayLeds();
}

void ComxStatusBar::updateStatusBarText()
{
	wxString buf;

	wxRect rect;
	this->GetFieldRect (1, rect);

	for (int slot = 0; slot < 4; slot++)
	{
		if (!((slot > 0) && !expansionRomLoaded_))
		{
			switch(p_Computer->getComxExpansionType(slot))
			{
				case COMXRAM:
					if (rect.GetWidth() < 70)
						buf.Printf("%d:", slot+1);
					else
						if (rect.GetWidth() < 100)
							buf.Printf("%d:           32K", slot+1);
						else
							buf.Printf("%d:           Ram 32K", slot+1);
					SetStatusText(buf, slot+1);
				break;

				case COMXFLOP:
					if (rect.GetWidth() < 70)
						buf.Printf("%d:", slot+1);
					else
						buf.Printf("%d:           FDC", slot+1);
					SetStatusText(buf, slot+1);
				break;

				case COMXPRINTER:
					if (rect.GetWidth() < 70)
						buf.Printf("%d:", slot+1);
					else
						if (rect.GetWidth() < 90)
							buf.Printf("%d:           Pr", slot+1);
						else
							buf.Printf("%d:           Printer", slot+1);
					SetStatusText(buf, slot+1);
				break;

				case COMXRS232:
					if (rect.GetWidth() < 70)
						buf.Printf("%d:", slot+1);
					else
						if (rect.GetWidth() < 90)
							buf.Printf("%d:           232", slot+1);
						else
							buf.Printf("%d:           RS232", slot+1);
					SetStatusText(buf, slot+1);
				break;

				case COMXTHPRINTER:
					if (rect.GetWidth() < 70)
						buf.Printf("%d:", slot+1);
					else
						if (rect.GetWidth() < 90)
							buf.Printf("%d:           Th", slot+1);
						else
							if (rect.GetWidth() < 130)
								buf.Printf("%d:           Thermal", slot+1);
							else
								buf.Printf("%d:           Thermal Printer", slot+1);
					SetStatusText(buf, slot+1);
				break;

				case COMX80COLUMN:
					if (rect.GetWidth() < 70)
						buf.Printf("%d:", slot+1);
					else
						if (rect.GetWidth() < 90)
							buf.Printf("%d:           80", slot+1);
						else
							if (rect.GetWidth() < 110)
								buf.Printf("%d:           80 COL", slot+1);
							else
								buf.Printf("%d:           80 Column", slot+1);
					SetStatusText(buf, slot+1);
				break;

				case COMXJOY:
					if (rect.GetWidth() < 70)
						buf.Printf("%d:", slot+1);
					else
						if (rect.GetWidth() < 95)
							buf.Printf("%d:           Joy", slot+1);
						else
							if (rect.GetWidth() < 120)
								buf.Printf("%d:           JoyCard", slot+1);
							else
								buf.Printf("%d:           F&M JoyCard", slot+1);
					SetStatusText(buf, slot+1);
				break;
				
				case COMXEPROMBOARD:
					if (rect.GetWidth() < 70)
						buf.Printf("%d:", slot+1);
					else
						if (rect.GetWidth() < 95)
							buf.Printf("%d:           E-B", slot+1);
						else
							if (rect.GetWidth() < 120)
								buf.Printf("%d:           Eprom-B", slot+1);
							else
								if (rect.GetWidth() < 150)
									buf.Printf("%d:           Eprom Board", slot+1);
								else
									buf.Printf("%d:           F&M Eprom Board", slot+1);
					SetStatusText(buf, slot+1);
				break;

			}
		}
	}
}
