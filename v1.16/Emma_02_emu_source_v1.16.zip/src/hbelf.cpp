/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

/*
 *******************************************************************
 *** This software is copyright 2006 by Michael H Riley          ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "app_icon.xpm"
#endif

#include "main.h"

#include "hbelf.h"

ElfScreen::ElfScreen(wxWindow *parent, const wxSize& size)
: Panel(parent, size)
{
}

ElfScreen::~ElfScreen()
{
	delete mainBitmapPointer;
	delete upBitmapPointer;
	delete downBitmapPointer;
	delete pushUpBitmapPointer;
	delete pushDownBitmapPointer;

	delete runButtonPointer;
	delete mpButtonPointer;
	delete powerButtonPointer;
	delete loadButtonPointer;

	for (int i=0; i<8; i++)
	{
		delete dataSwitchPointer[i];
	}
	for (int i=0; i<4; i++)
	{
		delete efSwitchPointer[i];
		delete addressPointer[i];
	}
	for (int i=0; i<2; i++)
	{
		delete dataPointer[i];
	}
 	delete qLedPointer;
}

void ElfScreen::init()
{
	keyStart_ = 0;
	keyEnd_ = 0;
	lastKey_ = 0;
	forceUpperCase_ = p_Main->getCheckBox("UpperCaseElf");

	wxClientDC dc(this);
	wxString buttonText, switchNumber;

	wxBitmap *upBitmap;
	wxBitmap *downBitmap;

	upBitmap = new wxBitmap ("images/swup.png", wxBITMAP_TYPE_PNG);
	downBitmap = new wxBitmap ("images/swdown.png", wxBITMAP_TYPE_PNG);

	wxColour bkgrClr(0x31, 0x31, 0x30); 
	wxColour maskColour(255, 0, 255);

	maskUp = new wxMask (*upBitmap, maskColour);
	upBitmap->SetMask(maskUp);
	maskDown = new wxMask (*downBitmap, maskColour);
	downBitmap->SetMask(maskDown);

	upBitmapPointer = new wxBitmap(upBitmap->GetWidth(), upBitmap->GetHeight());  
	downBitmapPointer = new wxBitmap(downBitmap->GetWidth(), downBitmap->GetHeight());  

	wxMemoryDC memDC(*upBitmapPointer); 
	memDC.SetBackground(*wxTheBrushList->FindOrCreateBrush(bkgrClr)); 
	memDC.Clear(); 
	memDC.DrawBitmap(*upBitmap, 0, 0, true);
	memDC.SelectObject(wxNullBitmap); 

	memDC.SelectObject(*downBitmapPointer); 
	memDC.Clear(); 
	memDC.DrawBitmap(*downBitmap, 0, 0, true); 
	memDC.SelectObject(wxNullBitmap); 

	delete upBitmap;
	delete downBitmap;

	upBitmap = new wxBitmap("images/pushup.png", wxBITMAP_TYPE_PNG);
	downBitmap = new wxBitmap("images/pushdown.png", wxBITMAP_TYPE_PNG);

	maskUp = new wxMask (*upBitmap, maskColour);
	upBitmap->SetMask(maskUp);
	maskDown = new wxMask (*downBitmap, maskColour);
	downBitmap->SetMask(maskDown);

	pushUpBitmapPointer = new wxBitmap(upBitmap->GetWidth(), upBitmap->GetHeight());  
	pushDownBitmapPointer = new wxBitmap(downBitmap->GetWidth(), downBitmap->GetHeight());  

	memDC.SelectObject(*pushUpBitmapPointer); 
	memDC.Clear(); 
	memDC.DrawBitmap(*upBitmap, 0, 0, true);
	memDC.SelectObject(wxNullBitmap); 

	memDC.SelectObject(*pushDownBitmapPointer); 
	memDC.Clear(); 
	memDC.DrawBitmap(*downBitmap, 0, 0, true); 
	memDC.SelectObject(wxNullBitmap); 

	delete upBitmap;
	delete downBitmap;

	mainBitmapPointer = new wxBitmap("images/elf.png", wxBITMAP_TYPE_PNG);

	runButtonPointer = new wxButton(this, 1, wxEmptyString, wxPoint(190, 312), wxSize(25, 25), wxBORDER_NONE);
	runButtonPointer->SetBitmap(*downBitmapPointer);
	mpButtonPointer = new wxButton(this, 2, wxEmptyString, wxPoint(150, 312), wxSize(25, 25), wxBORDER_NONE);
	mpButtonPointer->SetBitmap(*downBitmapPointer);
	powerButtonPointer = new wxButton(this, 3, wxEmptyString, wxPoint(313, 312), wxSize(25, 25), wxBORDER_NONE);
	powerButtonPointer->SetBitmap(*downBitmapPointer);
	loadButtonPointer = new wxButton(this, 4, wxEmptyString, wxPoint(75, 312), wxSize(25, 25), wxBORDER_NONE);
	loadButtonPointer->SetBitmap(*downBitmapPointer);
	qLedPointer = new Led(dc, 324, 250, ELFLED);
	updateQLed_ = true;

	for (int i=0; i<8; i++)
	{
		switchNumber.Printf("%i", i);
		dataSwitchPointer[i] = new wxButton(this, i+10, switchNumber, wxPoint(18+30*(7-i), 362), wxSize(25, 25), wxBU_NOTEXT|wxBORDER_NONE);
		dataSwitchPointer[i]->SetBitmap(*downBitmapPointer);
	}
	for (int i=0; i<4; i++)
	{
		switchNumber.Printf("%i", i);
		efSwitchPointer[i] = new wxButton(this, i+20, switchNumber, wxPoint(138+30*(3-i), 422), wxSize(25, 25), wxBU_NOTEXT|wxBORDER_NONE);
		efSwitchPointer[i]->SetBitmap(*downBitmapPointer);
		addressPointer[i] = new Til311();
		addressPointer[i]->init(dc, 18+i*40, 226);
	}
	updateAddress_ = true;
	for (int i=0; i<2; i++)
	{
		dataPointer[i] = new Til311();
		dataPointer[i]->init(dc, 218+i*40, 226);
	}
	updateData_ = true;
	this->connectKeyEvent(this);
}

void ElfScreen::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxPaintDC dc(this);
	dc.DrawBitmap(*mainBitmapPointer, 0, 0);
	dc.DrawBitmap(*pushUpBitmapPointer, 33, 312);

	for (int i=0; i<4; i++)
	{
		addressPointer[i]->onPaint(dc);
	}
	for (int i=0; i<2; i++)
	{
		dataPointer[i]->onPaint(dc);
	}
	qLedPointer->onPaint(dc);
}

void ElfScreen::inUp()
{
	wxClientDC dc(this);
	dc.DrawBitmap(*pushUpBitmapPointer, 33, 312);
}

void ElfScreen::inDown()
{
	wxClientDC dc(this);
	dc.DrawBitmap(*pushDownBitmapPointer, 33, 312);
}

void ElfScreen::onButtonRelease(wxMouseEvent& event)
{
	p_Computer->onButtonRelease(event);
	event.Skip();
}

void ElfScreen::onButtonPress(wxMouseEvent& event)
{
	p_Computer->onButtonPress(event);
	event.Skip();
}

BEGIN_EVENT_TABLE(Elf, wxFrame)
	EVT_CLOSE (Elf::onClose)
	EVT_BUTTON(1, Elf::onRunButton)
	EVT_BUTTON(2, Elf::onMpButton)
	EVT_BUTTON(3, Elf::onPowerButton)
	EVT_BUTTON(4, Elf::onLoadButton)
	EVT_BUTTON(10, Elf::dataSwitch)
	EVT_BUTTON(11, Elf::dataSwitch)
	EVT_BUTTON(12, Elf::dataSwitch)
	EVT_BUTTON(13, Elf::dataSwitch)
	EVT_BUTTON(14, Elf::dataSwitch)
	EVT_BUTTON(15, Elf::dataSwitch)
	EVT_BUTTON(16, Elf::dataSwitch)
	EVT_BUTTON(17, Elf::dataSwitch)
	EVT_BUTTON(20, Elf::efSwitch)
	EVT_BUTTON(21, Elf::efSwitch)
	EVT_BUTTON(22, Elf::efSwitch)
	EVT_BUTTON(23, Elf::efSwitch)
END_EVENT_TABLE()

Elf::Elf(const wxString& title, const wxPoint& pos, const wxSize& size, double clock, ElfConfiguration conf)
: wxFrame((wxFrame *)NULL, -1, title, pos, size)
{
	elfClockSpeed_ = clock;
	elfConfiguration = conf;
	data_ = 0;
	lastAddress_ = 0;

	SetIcon(wxICON(app_icon));
	this->SetClientSize(size);

	elfScreenPointer = new ElfScreen(this, size);
	elfScreenPointer->init();

	threadPointer = new RunElf();
	if ( threadPointer->Create() != wxTHREAD_NO_ERROR )
	{
		p_Main->message("Can't create thread");
	}
	threadPointer->SetPriority(WXTHREAD_MAX_PRIORITY);
}

Elf::~Elf()
{
	if (elfConfiguration.useHexKeyboard && !hexKeypadClosed_)
	{
		p_Main->setKeypadPos(ELF, keypadPointer->GetPosition());
		keypadPointer->Destroy();
	}
	if (elfConfiguration.useLedModule && !ledModuleClosed_)
	{
		p_Main->setLedModulePos(ledModulePointer->GetPosition());
		ledModulePointer->Destroy();
	}
	if (elfConfiguration.usePixie)
	{
		p_Main->setPixiePos(ELF, pixiePointer->GetPosition());
		pixiePointer->Destroy();
	}
	if (elfConfiguration.useTMS9918)
	{
		p_Main->setTmsPos(ELF, tmsPointer->GetPosition());
		tmsPointer->Destroy();
	}
	if (elfConfiguration.use6845||elfConfiguration.useS100)
	{
		p_Main->set6845Pos(ELF, mc6845Pointer->GetPosition());
		mc6845Pointer->Destroy();
	}
	if (elfConfiguration.use6847)
	{
		p_Main->set6847Pos(ELF, mc6847Pointer->GetPosition());
		mc6847Pointer->Destroy();
	}
	if (elfConfiguration.use8275)
	{
		p_Main->set8275Pos(ELF, i8275Pointer->GetPosition());
		i8275Pointer->Destroy();
	}
	if (elfConfiguration.vtType != VTNONE)
	{
		p_Main->setVtPos(ELF, vtPointer->GetPosition());
		vtPointer->Destroy();
	}
	if (p_Main->getPrinterStatus())
	{
		p_Printer->closeFrames();
		delete p_Printer;
	}
	p_Main->setMainPos(ELF, GetPosition());

	delete elfScreenPointer;
}

void Elf::stopComputer()
{
	threadPointer->Delete();
}

void Elf::showModules(bool status)
{
	if (elfConfiguration.useHexKeyboard && !hexKeypadClosed_)
		keypadPointer->Show(status);
	if (elfConfiguration.useLedModule && !ledModuleClosed_)
		ledModulePointer->Show(status);
}

void Elf::onClose(wxCloseEvent&WXUNUSED(event) )
{
	threadPointer->Pause();
	p_Main->stopComputer();
}

bool Elf::keyDownPressed(int key)
{
	if (p_Main->checkFunctionKey(key))
		return true;
	onHexKeyDown(key);
	if (elfConfiguration.useKeyboard)
		keyboardUp();
	if (elfConfiguration.UsePS2)
	{
		keyDownPs2(key);
			return true;
	}
	return false;
}

bool Elf::keyUpReleased(int key)
{
	if (key == WXK_INSERT)
	{
		onInButtonRelease();
		return true;
	}
	onHexKeyUp(key);
	if (elfConfiguration.UsePS2)
	{
		keyUpPs2(key);
		return true;
	}
	return false;
}

void Elf::charEvent(int keycode)
{
	if (elfConfiguration.useKeyboard)
		charEventKeyboard(keycode);
}

void Elf::onButtonRelease(wxMouseEvent& event)
{
	onInButtonRelease();
	event.Skip();
}

void Elf::onButtonPress(wxMouseEvent& event)
{
	int x, y;
	event.GetPosition(&x, &y);

	if ((x >= 33) &&(x <= 63) &&(y >= 312) &&(y <= 342))
	{
		onInButtonPress(getData());
	}
	event.Skip();
}

void Elf::onInButtonPress()
{
	if (elfConfiguration.useHexKeyboard)
		onInButtonPress(switches_);
	else
		onInButtonPress(getData());
}

void Elf::onInButtonPress(Byte value)
{
	inPressed_ = true;
	if (cpuMode_ == LOAD)
	{
		dmaIn(value);
		showData(value);
	}
	else
	{
		efSwitchState_[3] = 1;
	}
	elfScreenPointer->inDown();
}

void Elf::onInButtonRelease()
{
	if (efSwitchState_[3] == 1)
	{
		inPressed_ = false;
		efSwitchState_[3] = 0;
	}
	elfScreenPointer->inUp();
}

void Elf::onHexKeyDown(int keycode)
{
	if (!elfConfiguration.useHexKeyboard)
		return;
	for (int i=0; i<16; i++)
	{
		if (keycode == hexKeyDefA_[i])
		{
			ef3State_ = 0;
			switches_ = ((switches_ << 4) & 0xf0) | i;
			keypadPointer->onNumberDown(i);
		}
	}
	for (int i=0; i<5; i++)
	{
		if (keycode == keyDefGameValueA_[i])
		{
			if (keyDefGameHexA_[i] == 16)
				onInButtonPress();
			else
			{

				ef3State_ = 0;
				switches_ = ((switches_ << 4) & 0xf0) | (keyDefGameHexA_[i]&0xf);
				keypadPointer->onNumberDown(keyDefGameHexA_[i]&0xf);
			}
		}
		if (keycode == keyDefGameValueB_[i])
		{
			if (keyDefGameHexB_[i] == 16)
				onInButtonPress();
			else
			{

				ef3State_ = 0;
				switches_ = ((switches_ << 4) & 0xf0) | (keyDefGameHexB_[i]&0xf);
				keypadPointer->onNumberDown(keyDefGameHexB_[i]&0xf);
			}
		}
	}
}

void Elf::onHexDown(int hex)
{
	ef3State_ = 0;
	switches_ = ((switches_ << 4) & 0xf0) | hex;
}

void Elf::onHexKeyUp(int keycode)
{
	if (!elfConfiguration.useHexKeyboard)
		return;
	for (int i=0; i<5; i++)
	{
		if (keyDefGameHexA_[i] == 16)
		{
			if (keycode == keyDefGameValueA_[i])
			{
				onInButtonRelease();
				return;
			}
		}
		if (keyDefGameHexB_[i] == 16)
		{
			if (keycode == keyDefGameValueB_[i])
			{
				onInButtonRelease();
				return;
			}
		}
	}
	ef3State_ = 1;
}

void Elf::configureComputer()
{
	int efPort; 
	wxString printBuffer;

	inType_[3] = ELFIN;
	outType_[3] = ELFOUT;

	p_Main->message("Configuring Elf");
	p_Main->message("	Output 4: display output, input 4: data input");
	if (elfConfiguration.useHexKeyboardEf3)
	{
		efPort = p_Main->getConfigItem("/Elf/HexEf", 3l);
		efType_[efPort] = ELFEF3;
		printBuffer.Printf("	EF %d: 0 when hex button pressed", efPort);
		p_Main->message(printBuffer);
	}
	if (elfConfiguration.useTape)
	{
		efPort = p_Main->getConfigItem("/Elf/TapeEf", 2l);
		efType_[efPort] = ELF2EF2;
		printBuffer.Printf("	EF %d: cassette in", efPort);
		p_Main->message(printBuffer);
	}
	if (efType_[4] == 0)
	{
		efType_[4] = ELFINEF;
		p_Main->message("	EF 4: 0 when in button pressed");
	}
	p_Main->message("");

	p_Main->getDefaultHexKeys("Elf", "A", hexKeyDefA_);
	p_Main->getDefaultGameKeys("Elf", "A", keyDefGameValueA_, keyDefGameHexA_);
	p_Main->getDefaultGameKeys("Elf", "B", keyDefGameValueB_, keyDefGameHexB_);

	if (p_Main->getConfigBool("/Elf/GameAuto", true))
	{
		p_Main->loadKeyDefinition(p_Main->getComboValue("MainRomElf"), p_Main->getComboValue("MainRom2Elf"), keyDefGameHexA_, keyDefGameHexB_);
		p_Main->storeDefaultGameKeys("Elf", "A", keyDefGameValueA_, keyDefGameHexA_);
 		p_Main->storeDefaultGameKeys("Elf", "B", keyDefGameValueB_, keyDefGameHexB_);
	}
	
	resetCpu();
}

void Elf::reDefineKeysA(int hexKeyDefA[], int keyDefGameValueA[], int keyDefGameHexA[])
{
	for (int i=0; i<16; i++)
	{
		hexKeyDefA_[i] = hexKeyDefA[i];
	}
	for (int i=0; i<5; i++)
	{
		keyDefGameValueA_[i] = keyDefGameValueA[i];
		keyDefGameHexA_[i] = keyDefGameHexA[i];
	}
}

void Elf::reDefineKeysB(int* WXUNUSED(hexKeyDefB[]), int keyDefGameValueB[], int keyDefGameHexB[])
{
	for (int i=0; i<5; i++)
	{
		keyDefGameValueB_[i] = keyDefGameValueB[i];
		keyDefGameHexB_[i] = keyDefGameHexB[i];
	}
}

void Elf::initComputer()
{
	Show(elfConfiguration.useElfControlWindows);
	runButtonState_ = 0;
	for (int i=0; i<8; i++)  dataSwitchState_[i]=0;
	for (int i=0; i<4; i++)  efSwitchState_[i]=0;
	inPressed_ = false;
	mpButtonState_ = 0;
	loadButtonState_ = 1;
	cassetteEf_ = 0;

	switches_ = 0;
	ef3State_ = 1;
	hexKeypadClosed_ = false;
	ledModuleClosed_ = false;
}

Byte Elf::ef(int flag)
{
	switch(efType_[flag])
	{
		case 0:
			return 1-efSwitchState_[flag-1];
		break;

		case PIXIEEF:
			return pixiePointer->efPixie();
		break;

		case KEYBRDEF:
			return efKeyboard();
		break;

		case PS2GPIOEF:
			return efPs2gpio();
		break;

		case PS2EF:
			return efPs2();
		break;

		case FDCEF:
			return ef1793();
		break;

		case VT100EF:
			return vtPointer->ef();
		break;

		case MC6847EF:
			return mc6845Pointer->ef6845();
		break;

		case I8275EF:
			return i8275Pointer->ef8275();
		break;

		case ELFINEF:
			return ef4();
		break;

		case VTINEF:
			if (inPressed_ == true)
				return 0;
			else
				return vtPointer->ef();
		break;

		case ELF2EF2:
			return cassetteEf_;
		break;

		case ELFEF3:
			return ef3State_;
		break;

		default:
			return 1;
	}
}

Byte Elf::ef4()
{
	if (inPressed_ == true)
		return 0;
	else
		return 1;
}

Byte Elf::in(Byte port, Word WXUNUSED(address))
{
	Byte ret;

	switch(inType_[port-1])
	{
		case 0:
			ret = 255;
		break;

		case PIXIEIN:
			ret = pixiePointer->inPixie();
		break;

		case I8275PREGREAD:
			ret = i8275Pointer->pRegRead();
		break;

		case I8275SREGREAD:
			ret = i8275Pointer->sRegRead();
		break;

		case KEYBRDIN:
			ret = inKeyboard();
		break;

		case PS2GPIOIN:
			ret = inPs2gpio();
		break;

		case PS2IN:
			ret = inPs2();
		break;

		case ELFIN:
			if (elfConfiguration.useHexKeyboard)
				ret = switches_;
			else
				ret = getData();
		break;

		case FDCIN:
			ret = in1793();
		break;

		case IDEIN:
			ret = inIde();
		break;

		case PORTEXTIN:
			ret = inPortExtender();
		break;

		case UARTIN:
			return vtPointer->uartIn();
		break;

		case UARTSTATUS:
			return vtPointer->uartStatus();
		break;

		default:
			ret = 255;
	}
	inValues_[port] = ret;
	return ret;
}

Byte Elf::getData()
{
	return(dataSwitchState_[7]?128:0) +(dataSwitchState_[6]?64:0) +(dataSwitchState_[5]?32:0) +(dataSwitchState_[4]?16:0) +(dataSwitchState_[3]?8:0) +(dataSwitchState_[2]?4:0) +(dataSwitchState_[1]?2:0) +(dataSwitchState_[0]?1:0);
}

void Elf::out(Byte port, Word WXUNUSED(address), Byte value)
{
	outValues_[port] = value;

	switch(outType_[port-1])
	{
		case 0:
			return;
		break;

		case TMSHIGHOUT:
			tmsPointer->modeHighOut(value);
		break;

		case TMSLOWOUT:
			tmsPointer->modeLowOut(value);
		break;

		case PIXIEOUT:
			pixiePointer->outPixie();
		break;

		case MC6847OUT:
			mc6847Pointer->outMc6847(value);
		break;

		case I8275PREGWRITE:
			i8275Pointer->pRegWrite(value);
		break;

		case I8275CREGWRITE:
			i8275Pointer->cRegWrite(value);
		break;

		case VT100OUT:
			vtPointer->out(value);
		break;

		case PRINTEROUT:
			p_Printer->printerOut(value);
		break;

		case LEDMODOUT:
			ledModulePointer->write(value);
		break;

		case PS2OUT:
			outPs2(value);
		break;

		case ELFOUT:
			showData(value);
		break;

		case FDCSELECTOUT:
			selectRegister1793(value);
		break;

		case FDCWRITEOUT:
			writeRegister1793(value);
		break;

		case IDESELECTOUT:
			selectIdeRegister(value);
		break;

		case IDEWRITEOUT:
			outIde(value);
		break;

		case PORTEXTSELECTOUT:
			selectPortExtender(value);
		break;

		case PORTEXTWRITEOUT:
			outPortExtender(value);
		break;

		case UARTOUT:
			return vtPointer->uartOut(value);
		break;

		case UARTCONTROL:
			return vtPointer->uartControl(value);
		break;
	}
}

void Elf::showData(Byte val)
{
	elfScreenPointer->showData(val);
}

void Elf::cycle(int type)
{
	switch(cycleType_[type])
	{
		case 0:
			return;
		break;

		case KEYBRDCYCLE:
			cycleKeyboard();
		break;

		case PS2GPIOCYCLE:
			cyclePs2gpio();
		break;

		case PS2CYCLE:
			cyclePs2();
		break;

		case PIXIECYCLE:
			pixiePointer->cyclePixie();
		break;

		case TMSCYCLE:
			tmsPointer->cycleTms();
		break;

		case MC6847CYCLE:
			mc6847Pointer->cycle6847();
		break;

		case MC6845BLINK:
			mc6845Pointer->blink6845();
		break;

		case MC6845CYCLE:
			mc6845Pointer->cycle6845();
		break;

		case I8275CYCLE:
			i8275Pointer->cycle8275();
		break;

		case VT100CYCLE:
			vtPointer->cycleVt();
		break;

		case FDCCYCLE:
			cycleFdc();
		break;

		case IDECYCLE:
			cycleIde();
		break;
	}
}

void Elf::autoBoot()
{
	elfScreenPointer->runUp();
	runButtonState_ = 1;
	setClear(runButtonState_);
	if (cpuMode_ == RESET)  
		elfScreenPointer->showAddress(0);
}

void Elf::switchQ(int value)
{
	elfScreenPointer->setQLed(value);
}

int Elf::getMpButtonState()
{
	return mpButtonState_;
}

void Elf::onRunButton(wxCommandEvent&WXUNUSED(event))
{
	onRun();
}

void Elf::onRun()
{
	if (runButtonState_)
	{
		elfScreenPointer->runDown();
		runButtonState_ = 0;
	}
	else
	{
		elfScreenPointer->runUp();
		runButtonState_ = 1;
		p_Main->startTime();
	}
	setClear(runButtonState_);
	p_Main->updateTitle();
	if (cpuMode_ == RESET)  	
		elfScreenPointer->showAddress(0);
}

void Elf::onMpButton(wxCommandEvent&WXUNUSED(event))
{
	if (mpButtonState_)
	{
		elfScreenPointer->mpDown();
		mpButtonState_ = 0;
	}
	else
	{
		elfScreenPointer->mpUp();
		mpButtonState_ = 1;
	}
}

void Elf::onLoadButton(wxCommandEvent&WXUNUSED(event))
{
	if (!loadButtonState_)
	{
		elfScreenPointer->loadDown();
		loadButtonState_ = 1;
	}
	else
	{
		elfScreenPointer->loadUp();
		loadButtonState_ = 0;
	}
	setWait(loadButtonState_);
	if (cpuMode_ == RESET)  
		elfScreenPointer->showAddress(0);
}

void Elf::onPowerButton(wxCommandEvent&WXUNUSED(event))
{
	elfScreenPointer->powerUp();
	threadPointer->Pause();
	p_Main->stopComputer();
}

void Elf::dataSwitch(wxCommandEvent&event)
{
	int i;

	i = event.GetId() - 10;

	if (dataSwitchState_[i])
	{
		elfScreenPointer->dataDown(i);
		dataSwitchState_[i] = 0;
	}
	else
	{
		elfScreenPointer->dataUp(i);
		dataSwitchState_[i] = 1;
	}
}

void Elf::efSwitch(wxCommandEvent&event)
{
	int i;

	i = event.GetId() - 20;

	if (efSwitchState_[i])
	{
		elfScreenPointer->efDown(i);
		efSwitchState_[i] = 0;
	}
	else
	{
		elfScreenPointer->efUp(i);
		efSwitchState_[i] = 1;
	}
    setEf(i+1, 1-efSwitchState_[i]);
}

void Elf::startComputer()
{
	startElfKeyFile("Elf");

	resetPressed_ = false;

	if (elfConfiguration.usePortExtender)
		configurePortExt(ELF);

	ramStart_ = p_Main->getStartRam("Elf", ELF);
	Word ramEnd = p_Main->getEndRam("Elf", ELF);
	ramMask_ = 0x100;
	while (ramMask_ < (ramEnd + 1 - ramStart_))
		ramMask_ *= 2;
	ramMask_ -= 1;

	defineMemoryType(ramStart_, ramEnd, RAM);

	for (int i=ramMask_ + 1 + ramStart_; i<0x10000; i+=(ramMask_+1))
		defineMemoryType(i, i+(ramEnd - ramStart_), MAPPEDRAM);

	if (elfConfiguration.usePager)
	{
		allocPagerMemory();
		definePortExtForPager();

		defineMemoryType(0, 65535, PAGER);
	}
	if (elfConfiguration.useEms)
	{
		allocEmsMemory();
		defineMemoryType(0x8000, 0xbfff, EMSMEMORY);
	}

	p_Main->enableDebugGuiMemory();
	readProgramCombo(p_Main->getRomDir(ELF, MAINROM), "MainRomElf", p_Main->getLoadromMode(ELF, 0), 0, NONAME);
	readProgramCombo(p_Main->getRomDir(ELF, MAINROM2), "MainRom2Elf", p_Main->getLoadromMode(ELF, 1), 0, NONAME);

	configureElfExtensions();
	if (elfConfiguration.autoBoot)
	{
		scratchpadRegister_[0]=p_Main->getBootAddress("Elf", ELF);
		autoBoot();
	}

	if (elfConfiguration.vtType != VTNONE)
		setEf(4,0);

	if (elfConfiguration.usePortExtender)
		p_Main->setGuiPortExtenderValue();

	p_Main->setSwName("");
	p_Main->updateTitle();
	address_ = 0;
	elfScreenPointer->showAddress(address_);

	cpuCycles_ = 0;
	p_Main->startTime();
	elfScreenPointer->setLedMs(elfConfiguration.ledTimeMs);

	threadPointer->Run();
}

Byte Elf::readMem(Word addr)
{
	address_ = addr;
	elfScreenPointer->showAddress(address_);

	switch (memoryType_[addr/256])
	{
		case EMSMEMORY:
			switch (emsMemoryType_[((addr & 0x3fff) |(emsPage_ << 14))/256])
			{
				case UNDEFINED:
					return 255;
				break;

				case ROM:
				case RAM:
					return emsRam_[(long) ((addr & 0x3fff) |(emsPage_ << 14))];
				break;

				default:
					return 255;
				break;
			}
		break;

		case UNDEFINED:
			return 255;
		break;

		case ROM:
			return mainMemory_[addr];
		break;

		case MAPPEDRAM:
		case RAM:
			addr = (addr & ramMask_) + ramStart_;
			return mainMemory_[addr];
		break;

		case MC6847RAM:
			return mc6847Pointer->read6847(addr);
		break;

		case MC6845RAM:
			return mc6845Pointer->read6845(addr & 0x7ff);
		break;

		case MC6845REGISTERS:
			return mc6845Pointer->readData6845(addr);
		break;

		case PAGER:
			switch (pagerMemoryType_[((getPager(addr>>12) << 12) |(addr &0xfff))/256])
			{
				case UNDEFINED:
					return 255;
				break;

				case ROM:
				case RAM:
					return mainMemory_[(getPager(addr>>12) << 12) |(addr &0xfff)];
				break;

				default:
					return 255;
				break;
			}
		break;

		default:
			return 255;
		break;
	}
}

void Elf::writeMem(Word addr, Byte value, bool writeRom)
{
	address_ = addr;
	elfScreenPointer->showAddress(address_);

	if (emsMemoryDefined_)
	{
		if (addr>=0xc000 && addr <=0xffff)
		{
			emsPage_ = value & 0x1f;
		}
	}

	switch (memoryType_[addr/256])
	{
		case EMSMEMORY:
			switch (emsMemoryType_[((addr & 0x3fff) |(emsPage_ << 14))/256])
			{
				case UNDEFINED:
				case ROM:
					if (writeRom)
						emsRam_[(long) ((addr & 0x3fff) |(emsPage_ << 14))] = value;
				break;

				case RAM:
					if (!getMpButtonState())
						emsRam_[(long) ((addr & 0x3fff) |(emsPage_ << 14))] = value;
				break;
			}
		break;

		case MC6847RAM:
			mc6847Pointer->write(addr, value);
			mainMemory_[addr] = value;
		break;

		case MC6845RAM:
			mc6845Pointer->write6845(addr & 0x7ff, value);
		break;

		case MC6845REGISTERS:
			mc6845Pointer->writeRegister6845(addr, value);
		break;

		case UNDEFINED:
		case ROM:
			if (writeRom)
				mainMemory_[addr]=value;
		break;

		case MAPPEDRAM:
		case RAM:
			if (!getMpButtonState())
			{
				addr = (addr & ramMask_) + ramStart_;
				mainMemory_[addr]=value;
			}
		break;

		case PAGER:
			switch (pagerMemoryType_[((getPager(addr>>12) << 12) |(addr &0xfff))/256])
			{
				case UNDEFINED:
				case ROM:
					if (writeRom)
						mainMemory_[(getPager(addr>>12) << 12) |(addr &0xfff)] = value;
				break;

				case RAM:
					if (!getMpButtonState())
						mainMemory_[(getPager(addr>>12) << 12) |(addr &0xfff)] = value;
				break;
			}
		break;

	}
}

void Elf::cpuInstruction()
{
	if (debugMode_)
		p_Main->updateWindow();
	if (cpuMode_ == RUN)
	{
		if (steps_ != 0)
		{
			cycle0_=0;
			machineCycle();
			if (cycle0_ == 0) machineCycle();
			if (cycle0_ == 0 && steps_ != 0)
			{
				cpuCycle();
				cpuCycles_ += 2;
			}
		}
		else
			soundCycle();

		playSaveLoad();
		checkElfFunction();
		if (resetPressed_)
		{
			resetCpu();
			if (elfConfiguration.use8275)
				i8275Pointer->cRegWrite(0x40);
			if (elfConfiguration.autoBoot)
			{
				scratchpadRegister_[0]=p_Main->getBootAddress("Elf", ELF);
				autoBoot();
			}
			resetPressed_ = false;
			p_Main->setSwName("");
			startElfKeyFile("Elf");
		}
		if (debugMode_)
			p_Main->cycleDebug();
	}
	else
	{
		machineCycle();
		machineCycle();
		cpuCycles_ = 0;
		p_Main->startTime();
		if (cpuMode_ == LOAD)
		{
			showData(readMem(address_));
			threadPointer->Sleep(1);
		}
	}
}

void Elf::configureElfExtensions()
{
	wxString fileName, fileName2;

	if (elfConfiguration.usePixie)
	{
		double zoom = p_Main->getZoom();
		double scale = p_Main->getScale();
		pixiePointer = new Pixie( "Elf - Pixie", p_Main->getPixiePos(ELF), wxSize(64*zoom*scale, 128*zoom), zoom, scale, ELF);
		p_Video = pixiePointer;
		pixiePointer->setZoom(zoom);
		pixiePointer->configurePixie();
		pixiePointer->initPixie();
		pixiePointer->Show(true);
	}

	if (elfConfiguration.use6845)
	{
		double zoom = p_Main->getZoom();
		mc6845Pointer = new MC6845( "Elf - MC6845", p_Main->get6845Pos(ELF), wxSize(64*8*zoom, 16*8*zoom), zoom, ELF, elfClockSpeed_, 8);
		p_Video = mc6845Pointer;
		mc6845Pointer->configure6845();
		mc6845Pointer->init6845();
		mc6845Pointer->Show(true);
	}

	if (elfConfiguration.useS100)
	{
		double zoom = p_Main->getZoom();
		mc6845Pointer = new MC6845( "Elf - Quest Super Video", p_Main->get6845Pos(ELF), wxSize(64*7*zoom, 16*9*zoom), zoom, ELF, elfClockSpeed_, 7);
		p_Video = mc6845Pointer;
		mc6845Pointer->configureSuperVideo();
		mc6845Pointer->init6845();
		mc6845Pointer->Show(true);
	}

	if (elfConfiguration.use6847)
	{
		double zoom = p_Main->getZoom();
		mc6847Pointer = new mc6847( "Elf - MC6847", p_Main->get6847Pos(ELF), wxSize(elfConfiguration.charLine*8*zoom, elfConfiguration.screenHeight6847*zoom), zoom, ELF, elfClockSpeed_);
		p_Video = mc6847Pointer;
		mc6847Pointer->configure();
		mc6847Pointer->Show(true);
	}

	if (elfConfiguration.use8275)
	{
		double zoom = p_Main->getZoom();
		i8275Pointer = new i8275( "Elf - Intel 8275", p_Main->get8275Pos(ELF), wxSize(80*8*zoom, 24*10*2*zoom), zoom, ELF, elfClockSpeed_);
		p_Video = i8275Pointer;
		i8275Pointer->configure8275();
		i8275Pointer->init8275();
		i8275Pointer->Show(true);
	}

	if (elfConfiguration.useTMS9918)
	{
		double zoom = p_Main->getZoom();
		tmsPointer = new Tms9918( "Elf - TMS 9918", p_Main->getTmsPos(ELF), wxSize(320*zoom,240*zoom), zoom, ELF, elfClockSpeed_);
		p_Video = tmsPointer;
		tmsPointer->configure();
		tmsPointer->Show(true);
	}

	if (elfConfiguration.fdcEnabled)
	{
		configure1793(1, 40, 18, 256, ELF);
		resetFdc();
	}

	if (elfConfiguration.ideEnabled)
	{
		fileName = p_Main->getIdeDir(ELF);
		fileName2 = fileName;

		fileName.operator += (p_Main->getTextValue("IdeFileElf"));
		fileName2.operator += ("disk2.ide");

		configureIde(fileName, fileName2);
	}

	if (p_Main->getPrinterStatus())
	{
		p_Printer = new Printer();
		p_Printer->configureElfPrinter();
		p_Printer->initElf(p_Printer, "Cosmac Elf");
	}

	if (elfConfiguration.useLedModule)
	{
		ledModulePointer = new LedModule("Led Module", p_Main->getLedModulePos(), wxSize(172, 116), ELF);
		ledModulePointer->configure();
		ledModulePointer->setLedMs(elfConfiguration.ledTimeMs);
		ledModulePointer->Show(elfConfiguration.useElfControlWindows);
	}

	if (elfConfiguration.vtType != VTNONE)
	{
		double zoom = p_Main->getZoomVt();
		vtPointer = new Vt100("Elf - VT 100", p_Main->getVtPos(ELF), wxSize(640*zoom, 400*zoom), zoom, ELF, elfClockSpeed_, elfConfiguration.vtType);
		p_Vt100 = vtPointer;
		vtPointer->configure(elfConfiguration.baudR, elfConfiguration.baudT);
		vtPointer->Show(true);
		vtPointer->drawScreen();
	}
	setQsound (p_Main->getChoiceSelection("QsoundElf"));

	if (elfConfiguration.useHexKeyboard)
	{
		keypadPointer = new Keypad("Keypad", p_Main->getKeypadPos(ELF), wxSize(172, 229), ELF);
		keypadPointer->setLedMs(elfConfiguration.ledTimeMs);
		keypadPointer->Show(elfConfiguration.useElfControlWindows);
		p_Main->message("Configuring Elf Keypad\n");
	}

	if (elfConfiguration.useKeyboard)
		configureKeyboard(ELF);

	if (elfConfiguration.UsePS2)
		configurePs2(elfConfiguration.ps2Interrupt);
}

void Elf::moveWindows()
{
	if (elfConfiguration.useHexKeyboard)
		keypadPointer->Move(p_Main->getKeypadPos(ELF));
	if (elfConfiguration.useLedModule)
		ledModulePointer->Move(p_Main->getLedModulePos());
	if (elfConfiguration.usePixie)
		pixiePointer->Move(p_Main->getPixiePos(ELF));
	if (elfConfiguration.useTMS9918)
		tmsPointer->Move(p_Main->getTmsPos(ELF));
	if (elfConfiguration.use6845||elfConfiguration.useS100)
		mc6845Pointer->Move(p_Main->get6845Pos(ELF));
	if (elfConfiguration.use6847)
		mc6847Pointer->Move(p_Main->get6847Pos(ELF));
	if (elfConfiguration.use8275)
		i8275Pointer->Move(p_Main->get8275Pos(ELF));
	if (elfConfiguration.vtType != VTNONE)
		vtPointer->Move(p_Main->getVtPos(ELF));
}

void Elf::updateTitle(wxString Title)
{
	if (elfConfiguration.usePixie)
		pixiePointer->SetTitle("Elf - Pixie"+Title);
	if (elfConfiguration.useTMS9918)
		tmsPointer->SetTitle("Elf - TMS 9918"+Title);
	if (elfConfiguration.use6845)
		mc6845Pointer->SetTitle("Elf - MC6845"+Title);
	if (elfConfiguration.useS100)
		mc6845Pointer->SetTitle("Elf - Quest Super Video"+Title);
	if (elfConfiguration.use6847)
		mc6847Pointer->SetTitle("Elf - MC6847"+Title);
	if (elfConfiguration.use8275)
		i8275Pointer->SetTitle("Elf - Intel 8275"+Title);
	if (elfConfiguration.vtType != VTNONE)
		vtPointer->SetTitle("Elf - VT 100"+Title);
	if (elfConfiguration.useLedModule)
		ledModulePointer->SetTitle("Led Module"+Title);
	if (elfConfiguration.useHexKeyboard)
		keypadPointer->SetTitle("Keypad"+Title);
}

void Elf::setForceUpperCase(bool status)
{
	if (elfConfiguration.vtType != VTNONE)
		vtPointer->setForceUCVt(status);
	if (elfConfiguration.useKeyboard)
		setForceUpperCaseKeyboard(status);
}

void Elf::onReset()
{
	resetPressed_ = true;
}

void Elf::sleepComputer(long ms)
{
	threadPointer->Sleep(ms);
}

Byte Elf::read8275CharRom(Word addr)
{
	if (elfConfiguration.use8275)
		return i8275Pointer->read8275CharRom(addr);
	else
		return 0;
}

void Elf::write8275CharRom(Word addr, Byte value)
{
	if (elfConfiguration.use8275)
		i8275Pointer->write8275CharRom(addr, value);
}
Byte Elf::read6845CharRom(Word addr)
{
	if (elfConfiguration.use6845||elfConfiguration.useS100)
		return mc6845Pointer->read6845CharRom(addr);
	else
		return 0;
}

void Elf::write6845CharRom(Word addr, Byte value)
{
	mc6845Pointer->write6845CharRom(addr, value);
}

Byte Elf::read6847CharRom(Word addr)
{
	if (elfConfiguration.use6847)
		return mc6847Pointer->read6847CharRom(addr);
	else
		return 0;
}

void Elf::write6847CharRom(Word addr, Byte value)
{
	if (elfConfiguration.use6847)
		mc6847Pointer->write6847CharRom(addr, value);
}

int Elf::readDirect6847(Word addr)
{
	if (elfConfiguration.use6847)
		return mc6847Pointer->readDirect6847(addr); 
	else
		return 0;
}

void Elf::writeDirect6847(Word addr, int value)
{
	if (elfConfiguration.use6847)
		mc6847Pointer->writeDirect6847(addr, value); 
}

Word Elf::get6847RamMask()
{
 	if (elfConfiguration.use6847)
		return mc6847Pointer->get6847RamMask();
	else
		return 0;
}

void Elf::ledTimeout()
{
	elfScreenPointer->ledTimeout();
	if (elfConfiguration.useHexKeyboard && !hexKeypadClosed_)
		keypadPointer->ledTimeout();
	if (elfConfiguration.useLedModule && !ledModuleClosed_)
		ledModulePointer->ledTimeout();
}

void Elf::setLedMs(long ms)
{
	elfScreenPointer->setLedMs(ms);
	if (elfConfiguration.useHexKeyboard && !hexKeypadClosed_)
		keypadPointer->setLedMs(ms);
	if (elfConfiguration.useLedModule && !ledModuleClosed_)
		ledModulePointer->setLedMs(ms);
}

Byte Elf::getKey(Byte vtOut)
{
	Byte tempVtOut = elfScreenPointer->getKey(vtOut);

	if (tempVtOut == vtOut)
	{
	if (elfConfiguration.useHexKeyboard && !hexKeypadClosed_)
			tempVtOut = keypadPointer->getKey(vtOut);
		if (tempVtOut == vtOut)
		{
			if (elfConfiguration.useLedModule && !ledModuleClosed_)
				tempVtOut = ledModulePointer->getKey(vtOut);
		}
	}
	return tempVtOut;
}

void Elf::activateMainWindow()
{
	bool maximize = IsMaximized();
	Iconize(false);
	Raise();
	Show(true);
	Maximize(maximize);
}

void *RunElf::Entry()
{
	while(!TestDestroy())
	{
		p_Computer->cpuInstruction();
	}
	return NULL;
}
