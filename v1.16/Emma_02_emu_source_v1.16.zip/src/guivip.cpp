/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guivip.h"
#include "pixie.h"

#include "psave.h"

BEGIN_EVENT_TABLE(GuiVip, GuiTMC2000)

	EVT_BUTTON(XRCID("RomButtonVip"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("RamSWButtonVip"), GuiVip::onRamSWVip)
	EVT_BUTTON(XRCID("Chip8SWButtonVip"), GuiMain::onChip8SW)
	EVT_BUTTON(XRCID("EjectChip8SWVip"), GuiMain::onEjectChip8SW)
	EVT_SPIN_UP(XRCID("ZoomSpinVip"), GuiMain::onZoomUp)
	EVT_SPIN_DOWN(XRCID("ZoomSpinVip"), GuiMain::onZoomDown)
	EVT_TEXT(XRCID("ZoomValueVip"), GuiMain::onZoomValue)
	EVT_BUTTON(XRCID("FullScreenF3Vip"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("CasButtonVip"), GuiMain::onCassette)
	EVT_BUTTON(XRCID("EjectCasVip"), GuiMain::onCassetteEject)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonVip"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Vip"), GuiMain::onScreenDump)
	EVT_BUTTON(XRCID("RealCasLoadVip"), GuiMain::onRealCas)
	EVT_BUTTON(XRCID("CasLoadVip"), GuiMain::onCassetteLoad)
	EVT_BUTTON(XRCID("CasSaveVip"), GuiMain::onCassetteSave)
	EVT_BUTTON(XRCID("CasStopVip"), GuiMain::onCassetteStop)
	EVT_CHECKBOX(XRCID("TurboVip"), GuiMain::onTurbo)
	EVT_TEXT(XRCID("TurboClockVip"), GuiMain::onTurboClock)
	EVT_CHECKBOX(XRCID("AutoCasLoadVip"), GuiMain::onAutoLoad)
	EVT_BUTTON(XRCID("SaveButtonVip"), GuiMain::onSaveButton)
	EVT_BUTTON(XRCID("LoadButtonVip"), GuiMain::onLoadButton)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeVip"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeVip"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("TempoVip"), GuiVip::onTempo)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("TempoVip"), GuiVip::onTempo)
	EVT_CHOICE(XRCID("SoundVip"), GuiVip::onSound)
	EVT_TEXT(XRCID("ClockVip"), GuiMain::onClock)
	EVT_BUTTON(XRCID("KeyMapVip"), Main::onHexKeyDef)
	EVT_CHECKBOX(XRCID("KeyboardVip"), GuiMain::onKeyboard)
	EVT_BUTTON(XRCID("ColoursVip"), Main::onColoursDef)
	EVT_TEXT(XRCID("PrintFileVip"), GuiMain::onPrintFileText)
	EVT_BUTTON(XRCID("PrintButtonVip"), GuiMain::onPrintButton)
	EVT_CHOICE(XRCID("PrintModeVip"), GuiMain::onPrintMode)
	EVT_BUTTON(XRCID("PrintFileButtonVip"), GuiMain::onPrintFile)
	EVT_COMMAND(wxID_ANY, OPEN_PRINTER_WINDOW, GuiMain::openPrinterFrame) 
	EVT_TEXT(XRCID("RamSWVip"), GuiVip::onRamSWText)
	EVT_TEXT(XRCID("BeepFrequencyVip"), GuiMain::onBeepFrequency)

END_EVENT_TABLE()

GuiVip::GuiVip(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiTMC2000(title, pos, size)
{
}

void GuiVip::readVipConfig()
{
	bool turbo, vp590, vp580, highRes, stereo, keyboard;
	selectedComputer_ = VIP;

	XRCCTRL(*this, "MainRomVip", wxComboBox)->SetValue(configPointer->Read("/Vip/VipMainRom", "vip.rom"));
	XRCCTRL(*this, "RamSWVip", wxComboBox)->SetValue(configPointer->Read("/Vip/VipRamSW", "chip8x.ram"));
	XRCCTRL(*this, "Chip8SWVip", wxTextCtrl)->SetValue(configPointer->Read("/Vip/VipChip8SW", "Blockout [Steve Houk].c8x"));
	wxString defaultZoom;
	defaultZoom.Printf("%2.2f", 2.0);
	conf[VIP].zoom_ = configPointer->Read("/Vip/Zoom", defaultZoom);
	XRCCTRL(*this, "ZoomValueVip", wxTextCtrl)->ChangeValue(conf[VIP].zoom_);
	wxString defaultScale;
	defaultScale.Printf("%i", 3);
	conf[VIP].xScale_ = configPointer->Read("/Vip/xScale", defaultScale);
	conf[VIP].romDir_[MAINROM] = configPointer->Read("/Vip/VipRomDir", dataDir_ + "Vip"  + pathSeparator_);
	conf[VIP].ramDir_ = configPointer->Read("/Vip/VipRamDir", dataDir_ + "Vip"  + pathSeparator_);
	conf[VIP].chip8SWDir_ = configPointer->Read("/Vip/Chip8SWDir", dataDir_ + "Chip-8"  + pathSeparator_ + "Chip-8X and Hybrids"  + pathSeparator_);

	configPointer->Read("/Vip/HighRes", &highRes, false);
	XRCCTRL(*this, "HighResVip", wxCheckBox)->SetValue(highRes);
	configPointer->Read("/Vip/VP590", &vp590, true);
	XRCCTRL(*this, "VP590", wxCheckBox)->SetValue(vp590);
	configPointer->Read("/Vip/VP580", &vp580, false);
	XRCCTRL(*this, "VP580", wxCheckBox)->SetValue(vp580);
	XRCCTRL(*this, "SoundVip", wxChoice)->SetSelection(configPointer->Read("/Vip/SoundVip", 1l));
	setSoundGui(XRCCTRL(*this, "SoundVip", wxChoice)->GetSelection());
	configPointer->Read("/Vip/Stereo", &stereo, true);
	XRCCTRL(*this, "StereoVip", wxCheckBox)->SetValue(stereo);
	configPointer->Read("/Vip/Keyboard", &keyboard, false);
	XRCCTRL(*this, "KeyboardVip", wxCheckBox)->SetValue(keyboard);

	XRCCTRL(*this, "WavFileVip", wxTextCtrl)->SetValue(configPointer->Read("/Vip/VipWavFile", ""));
	conf[VIP].wavFileDir_ = configPointer->Read("/Vip/WavFileDir", dataDir_ + "Vip" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileVip", wxComboBox)->SetValue(configPointer->Read("/Vip/VipScreenDumpFile", "screendump.png"));
	conf[VIP].screenDumpFileDir_ = configPointer->Read("/Vip/VipScreenDumpFileDir", dataDir_ + "Vip" + pathSeparator_);
	configPointer->Read("/Vip/VipTurbo", &turbo, true);
	XRCCTRL(*this, "TurboVip", wxCheckBox)->SetValue(turbo);
	turboGui("Vip");
	conf[VIP].turboClock_ = configPointer->Read("/Vip/VipTurboClock", "15");
	XRCCTRL(*this, "TurboClockVip", wxTextCtrl)->SetValue(conf[VIP].turboClock_);
	configPointer->Read("/Vip/VipAutoCasLoad", &conf[VIP].autoCassetteLoad_, true);
	XRCCTRL(*this, "AutoCasLoadVip", wxCheckBox)->SetValue(conf[VIP].autoCassetteLoad_);
	configPointer->Read("/Vip/RealCasLoad", &conf[VIP].realCassetteLoad_, false);
	setRealCas(VIP);
	configPointer->Read("/Vip/Printer", &conf[VIP].printerOn_, false);
	setPrinterState(VIP);

	conf[VIP].volume_ = configPointer->Read("/Vip/VipVolume", 25l);
	XRCCTRL(*this, "VolumeVip", wxSlider)->SetValue(conf[VIP].volume_);
	conf[VIP].tempo_ = configPointer->Read("/Vip/Tempo", 100l);
	XRCCTRL(*this, "TempoVip", wxSlider)->SetValue(conf[VIP].tempo_);
	XRCCTRL(*this, "RamVip", wxSpinCtrl)->SetValue(configPointer->Read("/Vip/VipRam", 4l));
	XRCCTRL(*this, "VP570", wxSpinCtrl)->SetValue(configPointer->Read("/Vip/VP570", 7l));

	XRCCTRL(*this, "PrintFileVip", wxTextCtrl)->SetValue(configPointer->Read("/Vip/PrintFile", "printerout.txt"));
	conf[VIP].printFileDir_ = configPointer->Read("/Vip/PrintFileDir", dataDir_ + "Vip" + pathSeparator_); 
	XRCCTRL(*this, "PrintModeVip", wxChoice)->SetSelection(configPointer->Read("/Vip/PrintMode", 1l));
	conf[VIP].printMode_ = configPointer->Read("/Vip/PrintMode", 1l);
	setPrintMode();

	conf[VIP].mainX_ = configPointer->Read("/Vip/VipX", mainWindowX_+windowInfo.mainwX);
	conf[VIP].mainY_ = configPointer->Read("/Vip/VipY", mainWindowY_);

	wxString defaultClock;
	defaultClock.Printf("%1.4f", 1.7609);
	conf[VIP].clock_ = configPointer->Read("/Vip/Clock", defaultClock);
	XRCCTRL(*this, "ClockVip", wxTextCtrl)->ChangeValue(conf[VIP].clock_);

	conf[VIP].beepFrequency_ = configPointer->Read("/Vip/BeepFrequency", 250);
	wxString beepFrequency;
	beepFrequency.Printf("%d", conf[VIP].beepFrequency_);
	XRCCTRL(*this, "BeepFrequencyVip", wxTextCtrl)->ChangeValue(beepFrequency);
}

void GuiVip::writeVipConfig()
{
	configPointer->Write("/Vip/VipMainRom", XRCCTRL(*this, "MainRomVip", wxComboBox)->GetValue());
	configPointer->Write("/Vip/VipRamSW", XRCCTRL(*this, "RamSWVip", wxComboBox)->GetValue());
	configPointer->Write("/Vip/VipChip8SW", XRCCTRL(*this, "Chip8SWVip", wxTextCtrl)->GetValue());
	configPointer->Write("/Vip/Zoom", conf[VIP].zoom_);
	configPointer->Write("/Vip/VipRomDir", conf[VIP].romDir_[MAINROM]);
	configPointer->Write("/Vip/VipRamDir", conf[VIP].ramDir_);
	configPointer->Write("/Vip/Chip8SWDir", conf[VIP].chip8SWDir_);

	configPointer->Write("/Vip/HighRes", XRCCTRL(*this, "HighResVip", wxCheckBox)->GetValue());
	configPointer->Write("/Vip/VP590", XRCCTRL(*this, "VP590", wxCheckBox)->GetValue());
	configPointer->Write("/Vip/VP580", XRCCTRL(*this, "VP580", wxCheckBox)->GetValue());
	configPointer->Write("/Vip/SoundVip", XRCCTRL(*this, "SoundVip", wxChoice)->GetSelection());
	configPointer->Write("/Vip/Stereo", XRCCTRL(*this, "StereoVip", wxCheckBox)->GetValue());
	configPointer->Write("/Vip/Keyboard", XRCCTRL(*this, "KeyboardVip", wxCheckBox)->GetValue());

	if (conf[VIP].mainX_ > 0)
		configPointer->Write("/Vip/VipX", conf[VIP].mainX_);
	if (conf[VIP].mainY_ > 0)
		configPointer->Write("/Vip/VipY", conf[VIP].mainY_);

	configPointer->Write("/Vip/VipWavFile", XRCCTRL(*this, "WavFileVip", wxTextCtrl)->GetValue());
	configPointer->Write("/Vip/WavFileDir", conf[VIP].wavFileDir_);
	configPointer->Write("/Vip/VipScreenDumpFile", XRCCTRL(*this, "ScreenDumpFileVip", wxComboBox)->GetValue());
	configPointer->Write("/Vip/VipScreenDumpFileDir", conf[VIP].screenDumpFileDir_);
	configPointer->Write("/Vip/VipTurbo", XRCCTRL(*this, "TurboVip", wxCheckBox)->GetValue());
	configPointer->Write("/Vip/VipTurboClock", conf[VIP].turboClock_);
	configPointer->Write("/Vip/VipAutoCasLoad", XRCCTRL(*this, "AutoCasLoadVip", wxCheckBox)->GetValue());
	configPointer->Write("/Vip/RealCasLoad", conf[VIP].realCassetteLoad_);
	configPointer->Write("/Vip/Printer", conf[VIP].printerOn_);
	configPointer->Write("/Vip/VipVolume", XRCCTRL(*this, "VolumeVip", wxSlider)->GetValue());
	configPointer->Write("/Vip/Tempo", XRCCTRL(*this, "TempoVip", wxSlider)->GetValue());
	configPointer->Write("/Vip/VipRam", XRCCTRL(*this, "RamVip", wxSpinCtrl)->GetValue());
	configPointer->Write("/Vip/VP570", XRCCTRL(*this, "VP570", wxSpinCtrl)->GetValue());

	configPointer->Write("/Vip/PrintFileDir", conf[VIP].printFileDir_);
	configPointer->Write("/Vip/PrintMode", conf[VIP].printMode_);
	configPointer->Write("/Vip/PrintFile", XRCCTRL(*this, "PrintFileVip", wxTextCtrl)->GetValue());
	configPointer->Write("/Vip/VipKeyFileDir", conf[VIP].keyFileDir_);
	configPointer->Write("/Vip/Clock", conf[VIP].clock_);
	configPointer->Write("/Vip/BeepFrequency", conf[VIP].beepFrequency_);
}

void GuiVip::onTempo(wxScrollEvent&event)
{
	conf[selectedComputer_].tempo_ = event.GetPosition();
	if (computerRunning_)
		p_Computer->setTempo(conf[selectedComputer_].tempo_);
}

void GuiVip::onSound(wxCommandEvent&event)
{
	setSoundGui(event.GetSelection());
}

void GuiVip::onRamSWVip(wxCommandEvent&event)
{
	onRamSW(event);
	XRCCTRL(*this,"HighResVip", wxCheckBox)->SetValue(XRCCTRL(*this,"RamSWVip", wxComboBox)->GetValue() == "chip10.hex");
}

void GuiVip::onRamSWText(wxCommandEvent& WXUNUSED(event) )
{
	XRCCTRL(*this,"HighResVip", wxCheckBox)->SetValue(XRCCTRL(*this,"RamSWVip", wxComboBox)->GetValue() == "chip10.hex");
}

void GuiVip::setSoundGui(int sound)
{
	conf[VIP].vipSound_ = sound;
	XRCCTRL(*this, "BeepFrequencyTextVip", wxStaticText)->Enable(conf[VIP].vipSound_ == VIP_BEEP);
	XRCCTRL(*this, "BeepFrequencyVip", wxTextCtrl)->Enable(conf[VIP].vipSound_ == VIP_BEEP);
	XRCCTRL(*this, "BeepFrequencyTextHzVip", wxStaticText)->Enable(conf[VIP].vipSound_ == VIP_BEEP);

	if (conf[VIP].vipSound_ == VIP_SUPER2 || conf[VIP].vipSound_ == VIP_SUPER4)
	{
		XRCCTRL(*this,"TempoTextVip", wxStaticText)->Enable(true);
		XRCCTRL(*this,"TempoVip", wxSlider)->Enable(true);
		XRCCTRL(*this,"StereoVip", wxCheckBox)->Enable(true);
	}
	else
	{
		XRCCTRL(*this,"TempoTextVip", wxStaticText)->Enable(false);
		XRCCTRL(*this,"TempoVip", wxSlider)->Enable(false);
		XRCCTRL(*this,"StereoVip", wxCheckBox)->Enable(false);
	}
}
