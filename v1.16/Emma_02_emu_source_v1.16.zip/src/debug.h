#ifndef DEBUG_H
#define DEBUG_H

#include "wx/listctrl.h"

#include "guicomx.h"

#define TREG_D 0
#define TREG_P 1
#define TREG_X 2
#define TREG_T 3
#define TREG_DF 4
#define TREG_Q 5
#define TREG_R0 6
#define TREG_R1 7
#define TREG_R2 8
#define TREG_R3 9
#define TREG_R4 10
#define TREG_R5 11
#define TREG_R6 12
#define TREG_R7 13
#define TREG_R8 14
#define TREG_R9 15
#define TREG_RA 16
#define TREG_RB 17
#define TREG_RC 18
#define TREG_RD 19
#define TREG_RE 20
#define TREG_RF 21
#define TREG_FAULT 22

#define CPU_MEMORY 0
#define CPU_TYPE 1
#define CDP_1870_P 2
#define CDP_1870_C 3
#define V_6845 4
#define V_6847 5
#define V_6847_RAM 6
#define TMS_MEMORY 7
#define VT_RAM 8
#define CDP_1864 9
#define I_8275 10

class DebugWindow : public GuiComx 
{
public:
	DebugWindow(const wxString& title, const wxPoint& pos, const wxSize& size);
	~DebugWindow();

	void readDebugConfig();
	void writeDebugConfig();

	void enableDebugGuiMemory();
	void setGuiPortExtenderValue();
	void enableDebugGui(bool status);
	void cycleDebug();
	void updateWindow(); 
	void resetDisplay();    
	void assemblerDisplay(wxString buffer);
	void disassemblerDisplay(wxString buffer);
	void debugTrace(wxString buffer);
	void onEnter(wxCommandEvent& event);
	void onDebugDis(wxCommandEvent&event);
	void setPauseState();
	void SetDebugMode();

	void onLog(wxCommandEvent&event);
	void onClear(wxCommandEvent&event);
	void onTrace(wxCommandEvent&event);
	void onTraceDma(wxCommandEvent&event);
	void onTraceInt(wxCommandEvent&event);
	void onTraceInp(wxCommandEvent&event);
	void onTraceOut(wxCommandEvent&event);

	void onShowD(wxCommandEvent&event);
	void onShowP(wxCommandEvent&event);
	void onShowX(wxCommandEvent&event);
	void onShowT(wxCommandEvent&event);
	void onShowFlag(wxCommandEvent&event);
	void onShowIo(wxCommandEvent&event);
	void onShowReg(wxCommandEvent&event);

	void onInt(wxCommandEvent&event);

	void onPauseButton(wxCommandEvent&event);
	void onStepButton(wxCommandEvent&event);
	void onRunButton(wxCommandEvent&event);
	void onRunAddress(wxCommandEvent&event);
	void onBreakPointAddress(wxCommandEvent&event);
	void onTregValue(wxCommandEvent&event);
	void onTrapValue(wxCommandEvent&event);

	void onBreakPointSet(wxCommandEvent&event);
	void onTregSet(wxCommandEvent&event);
	void onTrapSet(wxCommandEvent&event);

	void deleteBreakPoint(wxListEvent&event);
	void deleteTreg(wxListEvent&event);
	void deleteTrap(wxListEvent&event);

	void editBreakPoint(wxListEvent&event);
	void editTreg(wxListEvent&event);
	void editTrap(wxListEvent&event);

	void onTrapCommand(wxCommandEvent&event);

	void O1(wxCommandEvent&event);
	void O2(wxCommandEvent&event);
	void O3(wxCommandEvent&event);
	void O4(wxCommandEvent&event);
	void O5(wxCommandEvent&event);
	void O6(wxCommandEvent&event);
	void O7(wxCommandEvent&event);

	void D(wxCommandEvent&event);
	void P(wxCommandEvent&event);
	void X(wxCommandEvent&event);
	void T(wxCommandEvent&event);
	void DF(wxCommandEvent&event);
	void Q(wxCommandEvent&event);
	void IE(wxCommandEvent&event);

	void R0(wxCommandEvent&event);
	void R1(wxCommandEvent&event);
	void R2(wxCommandEvent&event);
	void R3(wxCommandEvent&event);
	void R4(wxCommandEvent&event);
	void R5(wxCommandEvent&event);
	void R6(wxCommandEvent&event);
	void R7(wxCommandEvent&event);
	void R8(wxCommandEvent&event);
	void R9(wxCommandEvent&event);
	void RA(wxCommandEvent&event);
	void RB(wxCommandEvent&event);
	void RC(wxCommandEvent&event);
	void RD(wxCommandEvent&event);
	void RE(wxCommandEvent&event);
	void RF(wxCommandEvent&event);

	void onDebugDisplayPage(wxCommandEvent&event); 
	void onDebugDisplayPageSpinUp(wxSpinEvent&event); 
	void debugDisplayPageSpinUp(); 
	void onDebugDisplayPageSpinDown(wxSpinEvent&event); 
	void DebugDisplayPage(); 
	void ShowCharacters(Word address, int y);
	void DebugDisplayMap();
	void DebugDisplay();
	void onDebugMemType(wxCommandEvent&event);
	void onDebugExpansionSlot(wxSpinEvent&event);
	void onDebugExpansionRam(wxSpinEvent&event);
	void onDebugExpansionEprom(wxSpinEvent&event);
	void onDebugEmsPage(wxSpinEvent&event);
	void onDebugPager(wxSpinEvent&event);
	void onDebugPortExtender(wxSpinEvent&event);
	void onDebugSaveDump(wxCommandEvent&event);
	void onDebugCopy(wxCommandEvent&event);
	void onDebugCopyStart(wxCommandEvent&event);
	void onDebugCopyEnd(wxCommandEvent&event);
	void onDebugCopyTo(wxCommandEvent&event);
	void onDebugAssemblerAddress(wxCommandEvent&event);
	void onDebugDisStart(wxCommandEvent&event);
	void onDebugDisEnd(wxCommandEvent&event);
	void onDebugDisLog(wxCommandEvent&event);

	void onEditMemory(wxCommandEvent&event);
	void setMemoryType(int id, int setType);
	void memoryDisplay();
	Word getAddressMask();
	void DebugDisplay1870VideoRam();
	void DebugDisplay1864ColorRam();
	void DebugDisplay8275CharRom();
	void DebugDisplay6845CharRom();
	void DebugDisplay6847CharRom();
	void DebugDisplay6847VideoRam();
	void DebugDisplayTmsRam();
	void DebugDisplayVtRam();

	void onProtectedMode(wxCommandEvent& event);

	Byte debugReadMem(Word address);
	void debugWriteMem(Word address, Byte value);
	void setSwName(wxString swName);
	void updateTitle();
	void updateDebugMenu(bool debugMode);
	void onDebugMode(wxCommandEvent& event);
	void onF1();

protected:
	void trace();

	wxTextCtrl *assemblerWindowPointer;
	wxTextCtrl *disassemblerWindowPointer;
	wxTextCtrl *traceWindowPointer;
	wxTextCtrl *inputWindowPointer;
	wxListCtrl *breakPointWindowPointer;
	wxListCtrl *tregWindowPointer;
	wxListCtrl *trapWindowPointer;
	wxTextCtrl *registerTextPointer[16];
	wxTextCtrl *outTextPointer[8];
	wxTextCtrl *inTextPointer[8];
	wxTextCtrl *efTextPointer[5];
	wxTextCtrl *dfTextPointer;
	wxTextCtrl *qTextPointer;
	wxTextCtrl *ieTextPointer;
	wxTextCtrl *dTextPointer;
	wxTextCtrl *pTextPointer;
	wxTextCtrl *xTextPointer;
	wxTextCtrl *tTextPointer;

	bool traceInt_;
	bitset<8> traceInp_;
	bitset<8> traceOut_;
	bool traceDma_;
	bool trace_;
	bool xmlLoaded_;

private:
	wxString extractWord(wxString *buffer); 
	void addBreakPoint(); 
	void addTrap(); 
	void addTreg(); 
	void disassemble(Word start, Word end);
	int assemble(wxString *buffer, Byte* b1, Byte* b2, Byte* b3);
	Word getRegisterNumber(wxString buffer);
	int getRegister(wxString buffer); 

	Word breakPoints_[64];
	int numberOfBreakPoints_;

	Byte traps_[64][4];
	int numberOfTraps_;

	Word tregs_[64][2];
	int numberOfTregs_;

	Word lastR_[16];
	Byte lastD_;
	Byte lastP_;
	Byte lastX;
	Byte lastT_;
	Byte lastDf_;
	Byte lastQ_;
	Byte lastIe_;
	Byte lastEf1_;
	Byte lastEf2_;
	Byte lastEf3_;
	Byte lastEf4_;
	Word lastOut_[8];
	Byte lastIn_[8];

	long debugAddress_;
	bool protectedMode_;
	bool traceRegisters_;
	bool traceFlags_;
	bool traceIo_;
	bool traceD_;
	bool traceP_;
	bool traceX_;
	bool traceT_;
	bool performStep_;
	int memoryDisplay_;
	Byte portExtender_;
	wxString debugDir_;

	wxBitmap pauseOnBitmap;
	wxBitmap pauseOffBitmap;
	wxString swName_;

	DECLARE_EVENT_TABLE()
};

#endif  // DEBUG_H