#ifndef COSMICOS_H
#define COSMICOS_H

#include "til313.h"
#include "cosmicoshex.h"
#include "led.h"
#include "cdp1802.h"
#include "pixie.h"
#include "keyboard.h"
#include "keypad.h"
#include "vt100.h"
#include "printer.h"
#include "elfconfiguration.h"

class RunCosmicos : public wxThread
{
public:
	RunCosmicos() {};
	virtual void *Entry();
};

class CosmicosScreen : public Panel
{
public:
	CosmicosScreen(wxWindow *parent, const wxSize& size);
	~CosmicosScreen();

	void init();
	void onPaint(wxPaintEvent&event);

private:
};

class Cosmicos : public wxFrame, public Cdp1802
{
public:
	Cosmicos(const wxString& title, const wxPoint& pos, const wxSize& size, double clock, ElfConfiguration conf);
	Cosmicos() {};
	~Cosmicos();

	void onClose(wxCloseEvent&WXUNUSED(event));
	bool keyDownPressed(int keycode);
	bool keyUpReleased(int keycode);
	void onButtonRelease(wxCommandEvent& event);
	void onButtonPress(wxCommandEvent& event);

	void onSingleStep(wxCommandEvent&WXUNUSED(event));
	void onPause(wxCommandEvent&WXUNUSED(event));
	void onResetButton(wxCommandEvent&WXUNUSED(event));
	void onRunButton(wxCommandEvent& event);
	void onLoadButton(wxCommandEvent& event);
	void onClearButton(wxCommandEvent& event);
	void onMpButton(wxCommandEvent& event);
	void onRamButton(wxCommandEvent& event);
	Byte getData();

	void dataButton(wxCommandEvent& event);

	void onRun();
	void autoBoot();
	Byte inPressed();
	void onInButtonPress(Byte value);
	void onInButtonRelease();
	void onInButtonPress();
	void onHexKeyDown(int keycode);
	void onHexKeyUp(int keycode);

	void configureComputer();
	void reDefineKeysA(int *, int *, int *);
	void reDefineKeysB(int *, int *, int *);
	void initComputer();
	Byte ef(int flag);
	Byte in(Byte port, Word address);
	void out(Byte port, Word address, Byte value);
	void switchQ(int value);
	void showData(Byte value);
	void cycle(int type);

	void onPowerButton(wxCommandEvent& event);

	void startComputer();
	void stopComputer();
	Byte readMem(Word addr);
	void writeMem(Word addr, Byte value, bool writeRom);
	void cpuInstruction();
	void configureElfExtensions();
	void moveWindows();
	void updateTitle(wxString Title);
	void setForceUpperCase(bool status);
	void onReset();
	void checkCosmicosFunction();

	void removeCosmicosHex();
	void showModules(bool useHex);
	void setCosmicosClockSpeed(double clock) {cosmicosClockSpeed_ = clock;};
	void saveRam();
	void loadRam();
	void ledTimeout();
	void setLedMs(long ms);
	Byte getKey(Byte vtOut);
	void activateMainWindow();

private:
	RunCosmicos *threadPointer;
	class CosmicosScreen *cosmicosScreenPointer;

	Pixie *pixiePointer;
	Vt100 *vtPointer;

	Cosmicoshex *p_Cosmicoshex;
	Keypad *keypadPointer;

	ElfConfiguration cosmicosConfiguration;

	int qState_;
	Byte switches_;
	Byte data_;
	Byte lastMode_;
	char singleStep_;
	char state_;

	int hexKeyDefA_[16];
	int keyDefGameHexA_[5];
	int keyDefGameValueA_[5];
	int keyDefGameHexB_[5];
	int keyDefGameValueB_[5];

	double cosmicosClockSpeed_;
	Word lastAddress_;

	int bootstrap_;
	int runButtonState_;
	bool inPressed_;
	int loadButtonState_;
	int mpButtonState_;
	int ramButtonState_;
	int dataSwitchState_[8];
	int segNumber_;

	Word mainRamAddress_;

	int cycleValue_;
	int cycleSize_;
	bool pixieOn_;

	DECLARE_EVENT_TABLE()
};

#endif  // COSMICOS_H
