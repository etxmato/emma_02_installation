
#include "serial.h" 

DWORD dwError;

CSerialComm::CSerialComm()
{


}

CSerialComm::~CSerialComm()
{

    CloseHandle(m_hCom);
}

BOOL CSerialComm::OpenSerialPort(LPCSTR portName)
{

  m_hCom = CreateFileA (portName ,// Pointer to the name of the port
                      GENERIC_READ | GENERIC_WRITE,
                                    // Access (read/write) mode
                      0,            // Share mode
                      NULL,         // Pointer to the security attribute
                      OPEN_EXISTING,// How to open the serial port
                      0,            // Port attributes
                      NULL);        // Handle to port with attribute
                                    // to copy

  // if fail to open the port, return FALSE.
  if ( m_hCom == INVALID_HANDLE_VALUE ) 
    // Could not open the port.
      return FALSE;


  PortDCB.DCBlength = sizeof (DCB);     

// Get the default port setting information.
	GetCommState (m_hCom, &PortDCB);

// Change the DCB structure settings.
    PortDCB.BaudRate = 57600;              // Current baud 
    PortDCB.fBinary = TRUE;               // Binary mode; no EOF check 
	PortDCB.fParity = FALSE;               // Enable parity checking. 
    PortDCB.fOutxCtsFlow = FALSE;         // No CTS output flow control 
    PortDCB.fOutxDsrFlow = FALSE;         // No DSR output flow control 
	PortDCB.fDtrControl = DTR_CONTROL_DISABLE; 
                                        // DTR flow control type 
  PortDCB.fDsrSensitivity = FALSE;      // DSR sensitivity 
  PortDCB.fTXContinueOnXoff = TRUE;     // XOFF continues Tx 
  PortDCB.fOutX = FALSE;                // No XON/XOFF out flow control 
  PortDCB.fInX = FALSE;                 // No XON/XOFF in flow control 
  PortDCB.fErrorChar = FALSE;           // Disable error replacement. 
  PortDCB.fNull = FALSE;                // Disable null stripping. 
  PortDCB.fRtsControl = RTS_CONTROL_DISABLE; 
                                        // RTS flow control 
  PortDCB.fAbortOnError = FALSE;        // Do not abort reads/writes on 
                                        // error.
    PortDCB.ByteSize = 8;                 // Number of bits/bytes, 4-8 
	PortDCB.Parity = NOPARITY;            // 0-4=no,odd,even,mark,space 
    PortDCB.StopBits = ONESTOPBIT;        // 0,1,2 = 1, 1.5, 2 

  unsigned long inBuff = 65000;
  unsigned long outBuff = 65000;
  SetupComm(m_hCom,inBuff,outBuff);


  // Configure the port according to the specifications of the DCB 
  // structure.
  SetCommState(m_hCom,&PortDCB);

  return true;

}

BOOL CSerialComm::Write(char *buffer, unsigned int ByteCount)
{
    DWORD dummy;
    if(buffer == NULL)
       return FALSE;
    
    
        WriteFile(  m_hCom, 
                    buffer, 
                    (DWORD)ByteCount, 
                    &dummy, 
                    0 
                 ); 

return true;

}

BOOL CSerialComm::Read(char *buffer, unsigned int ByteCount)
{

    DWORD dummy;
    if((ByteCount==0) || (buffer == NULL))
        return FALSE;


    if(!ReadFile(m_hCom,buffer,(DWORD)ByteCount,&dummy,NULL))
        return FALSE;

    return TRUE;

}

BOOL CSerialComm::CloseSerialPort()
{


    if(CloseHandle(m_hCom)) return TRUE ;
    else return FALSE;

}