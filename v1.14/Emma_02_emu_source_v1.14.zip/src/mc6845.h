#ifndef MC6845_H
#define MC6845_H

#include "video.h"

class CharacterList6845
{
public:
	wxCoord x;
	wxCoord y;
	CharacterList6845 *nextCharacter;
};

class MC6845Screen : public wxWindow
{
public:
	MC6845Screen(wxWindow *parent, const wxSize& size, double zoom, int computerType);
	~MC6845Screen() {};

	void onPaint(wxPaintEvent&event);
	void onChar(wxKeyEvent&event);
	void onKeyDown(wxKeyEvent&event);
	void onKeyUp(wxKeyEvent&event);

	void blit(wxCoord xdest, wxCoord ydest, wxCoord width, wxCoord height, wxDC *source, wxCoord xsrc, wxCoord ysrc);
	void drawBackground(wxColour clr, int width, int height, wxCoord offsetX, wxCoord offsetY);
	void drawRectangle(wxColour clr, int x, int y, wxCoord width, wxCoord height);
	void setZoom(double zoom);

private:
	double zoom_;
	int computerType_;

	DECLARE_EVENT_TABLE()
};

class MC6845 : public Video
{
public:

	MC6845(const wxString& title, const wxPoint& pos, const wxSize& size, double zoom, int computerType, double clock, int charW);
	~MC6845();

	void onClose(wxCloseEvent&event );
	void setReBlit();

	void setZoom(double zoom);
	void configure6845();
	void configureSuperVideo();
	void init6845();
	Byte ef6845();
	void cycle6845();
	void blink6845();

	void onF3();
	void onF5();

	void writeRegister6845(Word addr, Byte value);
	Byte readData6845(Word addr);
	void writeData6845(Byte value);
	Byte read6845(Word addr);
	void write6845(Word addr, Byte value);
	Byte read6845CharRom(Word addr);
	void write6845CharRom(Word addr, Byte value);
	void copyScreen();
	void drawScreen6845();
	void draw6845(Word addr, Byte value);
	void drawCharacter6845(int x, int y, Byte value);
	void drawCursor6845(Word addr, bool status);
	void setInterlace(bool status);
	bool readCharRomFile(wxString romDir, wxString FileRef);
	void changeSize();
	bool isFullScreenSet() {return fullScreenSet_;};

private:
	void setFullScreen();
	void drawBackground();

	Byte mc6845ram_[2048];
	Byte mc6845CharRom_[2048];

	wxBitmap *screenCopyPointer;
	CharacterList6845 *characterListPointer6845;
    class MC6845Screen *mc6845ScreenPointer;
	Word mc6845RamStart_;
	Word mc6845RamEnd_;
	Word mc6845AddressRegister_;
	Word mc6845DataRegister_;

	wxMemoryDC dcMemory;

	int computerType_;
	wxString elfTypeStr_;
	double clock_;

	int cycleValue6845_; 
	int cycleSize6845_;
	int nonDisplay6845_;
	int blinkValue6845_;
	int blinkSize6845_;

	double zoom_;
   bool zoomFraction_;
	double restoreZoomAfterFullScreen_;
	wxCoord offsetX_;
	wxCoord offsetY_;
	bool fullScreenSet_;
	bool updateCharacter_;
	bool newBackGround_;
	bool f3Pressed_;
	wxSize windowSize_;

	int Nht_;
	int charLine_;
	int Nvt_;
	int Nadj_;
	int rows_;
	bool interlace_;
	bool interlaceOR_;
	int videoM_;
	Byte register_[32];
	int registerIndex_;
	int startAddress_;
	int cursorAddress_;
	int cursorStartLine_;
	int cursorEndLine_;
	int scanLine_;
	bool cursorOn_;
	bool cursorBlink_;
	bool cursorBlinkOn_;
	int blink_;
	int cursorBlinkTime_;
	int updateCharacter6845_;

	int charW_;

	DECLARE_EVENT_TABLE()
};

#endif  // MC6845_H