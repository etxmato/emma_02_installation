/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guistudio2.h"
#include "pixie.h"

BEGIN_EVENT_TABLE(GuiStudio2, GuiVip)

	EVT_BUTTON(XRCID("RomButtonStudio2"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("CartRomButtonStudio2"), GuiMain::onCartRom)
	EVT_SPINCTRL(XRCID("ZoomStudio2"), GuiMain::onZoom)
	EVT_BUTTON(XRCID("FullScreenF3Studio2"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonStudio2"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Studio2"), GuiMain::onScreenDump)
	EVT_TEXT(XRCID("ClockStudio2"), GuiMain::onClock)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeStudio2"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeStudio2"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("KeyMapStudio2"), Main::onHexKeyDef)

	EVT_BUTTON(XRCID("RomButtonVisicom"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("CartRomButtonVisicom"), GuiMain::onCartRom)
	EVT_SPINCTRL(XRCID("ZoomVisicom"), GuiMain::onZoom)
	EVT_BUTTON(XRCID("FullScreenF3Visicom"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonVisicom"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Visicom"), GuiMain::onScreenDump)
	EVT_TEXT(XRCID("ClockVisicom"), GuiMain::onClock)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeVisicom"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeVisicom"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("KeyMapVisicom"), Main::onHexKeyDef)
	EVT_BUTTON(XRCID("ColoursVisicom"), Main::onColoursDef)

	EVT_BUTTON(XRCID("RomButtonVictory"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("CartRomButtonVictory"), GuiMain::onCartRom)
	EVT_SPINCTRL(XRCID("ZoomVictory"), GuiMain::onZoom)
	EVT_BUTTON(XRCID("FullScreenF3Victory"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonVictory"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Victory"), GuiMain::onScreenDump)
	EVT_TEXT(XRCID("ClockVictory"), GuiMain::onClock)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeVictory"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeVictory"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("KeyMapVictory"), Main::onHexKeyDef)
	EVT_BUTTON(XRCID("ColoursVictory"), Main::onColoursDef)

END_EVENT_TABLE()

GuiStudio2::GuiStudio2(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiVip(title, pos, size)
{
}

void GuiStudio2::readStudioConfig()
{
	selectedComputer_ = STUDIO;

	XRCCTRL(*this, "MainRomStudio2", wxComboBox)->SetValue(configPointer->Read("/Studio2/Studio2MainRom", "studio2.rom"));
	XRCCTRL(*this, "CartRomStudio2", wxComboBox)->SetValue(configPointer->Read("/Studio2/Studio2CartRom", ""));
	XRCCTRL(*this, "ZoomStudio2", wxSpinCtrl)->SetValue(configPointer->Read("/Studio2/Studio2Zoom", 2l));
	conf[STUDIO].romDir_[MAINROM] = configPointer->Read("/Studio2/Studio2RomDir", dataDir_ + "Studio2"  + pathSeparator_);
	conf[STUDIO].romDir_[CARTROM] = configPointer->Read("/Studio2/Studio2CartDir", dataDir_ + "Studio2" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileStudio2", wxComboBox)->SetValue(configPointer->Read("/Studio2/Studio2ScreenDumpFile", "screendump.bmp"));
	conf[STUDIO].screenDumpFileDir_ = configPointer->Read("/Studio2/Studio2ScreenDumpFileDir", dataDir_ + "Studio2" + pathSeparator_);

	conf[STUDIO].mainX_ = configPointer->Read("/Studio2/StudioX", mainWindowX_+windowInfo.mainwX);
	conf[STUDIO].mainY_ = configPointer->Read("/Studio2/StudioY", mainWindowY_);

	wxString defaultClock;
	defaultClock.Printf("%1.2f", 1.76);
	conf[STUDIO].clock_ = configPointer->Read("/Studio2/Clock", defaultClock);
	XRCCTRL(*this, "ClockStudio2", wxTextCtrl)->ChangeValue(conf[STUDIO].clock_);

	conf[STUDIO].volume_ = configPointer->Read("/Studio2/Volume", 25l);
	XRCCTRL(*this, "VolumeStudio2", wxSlider)->SetValue(conf[STUDIO].volume_);
	conf[STUDIO].realCassetteLoad_ = false;
}

void GuiStudio2::writeStudioConfig()
{
	configPointer->Write("/Studio2/Studio2MainRom", XRCCTRL(*this, "MainRomStudio2", wxComboBox)->GetValue());
	configPointer->Write("/Studio2/Studio2CartRom", XRCCTRL(*this, "CartRomStudio2", wxComboBox)->GetValue());
	configPointer->Write("/Studio2/Studio2Zoom", XRCCTRL(*this, "ZoomStudio2", wxSpinCtrl)->GetValue());
	configPointer->Write("/Studio2/Studio2RomDir", conf[STUDIO].romDir_[MAINROM]);
	configPointer->Write("/Studio2/Studio2CartDir", conf[STUDIO].romDir_[CARTROM]);
	configPointer->Write("/Studio2/Studio2ScreenDumpFile", XRCCTRL(*this, "ScreenDumpFileStudio2", wxComboBox)->GetValue());
	configPointer->Write("/Studio2/Studio2ScreenDumpFileDir", conf[STUDIO].screenDumpFileDir_);

	if (conf[STUDIO].mainX_ > 0)
		configPointer->Write("/Studio2/StudioX", conf[STUDIO].mainX_);
	if (conf[STUDIO].mainY_ > 0)
		configPointer->Write("/Studio2/StudioY", conf[STUDIO].mainY_);

	configPointer->Write("/Studio2/Clock", conf[STUDIO].clock_);

	configPointer->Write("/Studio2/Volume", XRCCTRL(*this, "VolumeStudio2", wxSlider)->GetValue());
}

void GuiStudio2::readVisicomConfig()
{
	selectedComputer_ = VISICOM;

	XRCCTRL(*this, "MainRomVisicom", wxComboBox)->SetValue(configPointer->Read("/Visicom/MainRom", "visicom.rom"));
	XRCCTRL(*this, "CartRomVisicom", wxComboBox)->SetValue(configPointer->Read("/Visicom/CartRom", ""));
	XRCCTRL(*this, "ZoomVisicom", wxSpinCtrl)->SetValue(configPointer->Read("/Visicom/Zoom", 2l));
	conf[VISICOM].romDir_[MAINROM] = configPointer->Read("/Visicom/RomDir", dataDir_ + "Visicom"  + pathSeparator_);
	conf[VISICOM].romDir_[CARTROM] = configPointer->Read("/Visicom/CartDir", dataDir_ + "Visicom" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileVisicom", wxComboBox)->SetValue(configPointer->Read("/Visicom/ScreenDumpFile", "screendump.bmp"));
	conf[VISICOM].screenDumpFileDir_ = configPointer->Read("/Visicom/ScreenDumpFileDir", dataDir_ + "Visicom" + pathSeparator_);

	conf[VISICOM].mainX_ = configPointer->Read("/Visicom/X", mainWindowX_+windowInfo.mainwX);
	conf[VISICOM].mainY_ = configPointer->Read("/Visicom/Y", mainWindowY_);

	wxString defaultClock;
	defaultClock.Printf("%1.2f", 1.76);
	conf[VISICOM].clock_ = configPointer->Read("/Visicom/Clock", defaultClock);
	XRCCTRL(*this, "ClockVisicom", wxTextCtrl)->ChangeValue(conf[VISICOM].clock_);

	conf[VISICOM].volume_ = configPointer->Read("/Visicom/Volume", 25l);
	XRCCTRL(*this, "VolumeVisicom", wxSlider)->SetValue(conf[VISICOM].volume_);
	conf[VISICOM].realCassetteLoad_ = false;
}

void GuiStudio2::writeVisicomConfig()
{
	configPointer->Write("/Visicom/MainRom", XRCCTRL(*this, "MainRomVisicom", wxComboBox)->GetValue());
	configPointer->Write("/Visicom/CartRom", XRCCTRL(*this, "CartRomVisicom", wxComboBox)->GetValue());
	configPointer->Write("/Visicom/Zoom", XRCCTRL(*this, "ZoomVisicom", wxSpinCtrl)->GetValue());
	configPointer->Write("/Visicom/RomDir", conf[VISICOM].romDir_[MAINROM]);
	configPointer->Write("/Visicom/CartDir", conf[VISICOM].romDir_[CARTROM]);
	configPointer->Write("/Visicom/ScreenDumpFile", XRCCTRL(*this, "ScreenDumpFileVisicom", wxComboBox)->GetValue());
	configPointer->Write("/Visicom/ScreenDumpFileDir", conf[VISICOM].screenDumpFileDir_);

	if (conf[VISICOM].mainX_ > 0)
		configPointer->Write("/Visicom/X", conf[VISICOM].mainX_);
	if (conf[VISICOM].mainY_ > 0)
		configPointer->Write("/Visicom/Y", conf[VISICOM].mainY_);

	configPointer->Write("/Visicom/Clock", conf[VISICOM].clock_);

	configPointer->Write("/Visicom/Volume", XRCCTRL(*this, "VolumeVisicom", wxSlider)->GetValue());
}

void GuiStudio2::readVictoryConfig()
{
	selectedComputer_ = VICTORY;

	XRCCTRL(*this, "MainRomVictory", wxComboBox)->SetValue(configPointer->Read("/Victory/MainRom", "victory.rom"));
	XRCCTRL(*this, "CartRomVictory", wxComboBox)->SetValue(configPointer->Read("/Victory/CartRom", ""));
	XRCCTRL(*this, "ZoomVictory", wxSpinCtrl)->SetValue(configPointer->Read("/Victory/Zoom", 2l));
	conf[VICTORY].romDir_[MAINROM] = configPointer->Read("/Victory/RomDir", dataDir_ + "Victory"  + pathSeparator_);
	conf[VICTORY].romDir_[CARTROM] = configPointer->Read("/Victory/CartDir", dataDir_ + "Victory" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileVictory", wxComboBox)->SetValue(configPointer->Read("/Victory/ScreenDumpFile", "screendump.bmp"));
	conf[VICTORY].screenDumpFileDir_ = configPointer->Read("/Victory/ScreenDumpFileDir", dataDir_ + "Victory" + pathSeparator_);

	conf[VICTORY].mainX_ = configPointer->Read("/Victory/X", mainWindowX_+windowInfo.mainwX);
	conf[VICTORY].mainY_ = configPointer->Read("/Victory/Y", mainWindowY_);

	wxString defaultClock;
	defaultClock.Printf("%1.2f", 1.76);
	conf[VICTORY].clock_ = configPointer->Read("/Victory/Clock", defaultClock);
	XRCCTRL(*this, "ClockVictory", wxTextCtrl)->ChangeValue(conf[VICTORY].clock_);

	conf[VICTORY].volume_ = configPointer->Read("/Victory/Volume", 25l);
	XRCCTRL(*this, "VolumeVictory", wxSlider)->SetValue(conf[VICTORY].volume_);
	conf[VICTORY].realCassetteLoad_ = false;
}

void GuiStudio2::writeVictoryConfig()
{
	configPointer->Write("/Victory/MainRom", XRCCTRL(*this, "MainRomVictory", wxComboBox)->GetValue());
	configPointer->Write("/Victory/CartRom", XRCCTRL(*this, "CartRomVictory", wxComboBox)->GetValue());
	configPointer->Write("/Victory/Zoom", XRCCTRL(*this, "ZoomVictory", wxSpinCtrl)->GetValue());
	configPointer->Write("/Victory/RomDir", conf[VICTORY].romDir_[MAINROM]);
	configPointer->Write("/Victory/CartDir", conf[VICTORY].romDir_[CARTROM]);
	configPointer->Write("/Victory/ScreenDumpFile", XRCCTRL(*this, "ScreenDumpFileVictory", wxComboBox)->GetValue());
	configPointer->Write("/Victory/ScreenDumpFileDir", conf[VICTORY].screenDumpFileDir_);

	if (conf[VICTORY].mainX_ > 0)
		configPointer->Write("/Victory/X", conf[VICTORY].mainX_);
	if (conf[VICTORY].mainY_ > 0)
		configPointer->Write("/Victory/Y", conf[VICTORY].mainY_);

	configPointer->Write("/Victory/Clock", conf[VICTORY].clock_);

	configPointer->Write("/Victory/Volume", XRCCTRL(*this, "VolumeVictory", wxSlider)->GetValue());
}