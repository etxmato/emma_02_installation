#ifndef TELMAC1800_H
#define TELMAC1800_H

#include "cdp1802.h"
#include "pixie.h"

class RunTMC1800 : public wxThread
{
public:
	RunTMC1800() {};
	virtual void *Entry();
};

class Tmc1800 : public Cdp1802, public Pixie
{
public:
	Tmc1800(const wxString& title, const wxPoint& pos, const wxSize& size, double zoom, int computerType);
	~Tmc1800();

	void configureComputer();
	void reDefineKeysA(int *, int *, int *);
	void reDefineKeysB(int *, int *, int *);
	void initComputer();
	void keyDown(int keycode);
	void keyUp(int keycode);

	void onRun();

	Byte ef(int flag);
	Byte ef3();
	Byte in(Byte port, Word address);
	void out(Byte port, Word address, Byte value);
	void outTMC1800(Byte value);
	void cycle(int type);

	void startComputer();
	void stopComputer();
	Byte readMem(Word addr);
	void writeMem(Word addr, Byte value, bool writeRom);
	void cpuInstruction();
	void onReset();
	void checkTMC1800Function();

private:
	RunTMC1800 *threadPointer;

	Byte telmac1800KeyPort_;
	Byte telmac1800KeyState_[64];
	bool resetPressed_;
	int cPressed;
	bool runPressed_;
	Word addressLatch_;
	Word ramMask_;

	int hexKeyDefA_[64];
	int keyDefGameHexA_[5];
	int keyDefGameValueA_[5];
	int keyDefGameHexB_[5];
	int keyDefGameValueB_[5];
};

#endif  // TELMAC1800_H
