/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "app_icon.xpm"
//#include "elf2k_icon.xpm"
#endif

#include "main.h"

#include "elf2kswitch.h"

BEGIN_EVENT_TABLE(Elf2Kswitch, wxFrame)
	EVT_CLOSE (Elf2Kswitch::onClose)
	EVT_PAINT(Elf2Kswitch::onPaint)
	EVT_CHAR(Elf2Kswitch::onChar)
	EVT_KEY_DOWN(Elf2Kswitch::onKeyDown)
	EVT_KEY_UP(Elf2Kswitch::onKeyUp)
	EVT_LEFT_DOWN(Elf2Kswitch::onButtonPress)
	EVT_LEFT_UP(Elf2Kswitch::onButtonRelease)
	EVT_BUTTON(1, Elf2Kswitch::onRunButton)
	EVT_BUTTON(2, Elf2Kswitch::onMpButton)
	EVT_BUTTON(4, Elf2Kswitch::onLoadButton)
	EVT_BUTTON(10, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(11, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(12, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(13, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(14, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(15, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(16, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(17, Elf2Kswitch::dataSwitch)
END_EVENT_TABLE()

Elf2Kswitch::Elf2Kswitch(const wxString& title, const wxPoint& pos, const wxSize& size)
: wxFrame((wxFrame *)NULL, -1, title, pos, size)
{
	wxBitmap *upBitmap;
	wxBitmap *downBitmap;

	wxClientDC dc(this);

	wxString switchNumber;

	SetIcon(wxICON(app_icon));
//	SetIcon(wxICON(elf2k_icon));
	this->SetClientSize(size);

	elfBitmapPointer = new wxBitmap("images/elf2kswitches.png", wxBITMAP_TYPE_PNG);

	upBitmap = new wxBitmap ("images/swup.png", wxBITMAP_TYPE_PNG);
	downBitmap = new wxBitmap ("images/swdown.png", wxBITMAP_TYPE_PNG);

	wxColour bkgrClr(255, 255, 255); 
	wxColour maskColour(255, 0, 255);

	maskUp = new wxMask (*upBitmap, maskColour);
	upBitmap->SetMask(maskUp);
	maskDown = new wxMask (*downBitmap, maskColour);
	downBitmap->SetMask(maskDown);

	upBitmapPointer = new wxBitmap(upBitmap->GetWidth(), upBitmap->GetHeight());  
	downBitmapPointer = new wxBitmap(downBitmap->GetWidth(), downBitmap->GetHeight());  

	wxMemoryDC memDC(*upBitmapPointer); 
	memDC.SetBackground(*wxTheBrushList->FindOrCreateBrush(bkgrClr)); 
	memDC.Clear(); 
	memDC.DrawBitmap(*upBitmap, 0, 0, true);
	memDC.SelectObject(wxNullBitmap); 

	memDC.SelectObject(*downBitmapPointer); 
	memDC.Clear(); 
	memDC.DrawBitmap(*downBitmap, 0, 0, true); 
	memDC.SelectObject(wxNullBitmap); 

	delete upBitmap;
	delete downBitmap;

	upBitmap = new wxBitmap("images/pushup.png", wxBITMAP_TYPE_PNG);
	downBitmap = new wxBitmap("images/pushdown.png", wxBITMAP_TYPE_PNG);

	maskUp = new wxMask (*upBitmap, maskColour);
	upBitmap->SetMask(maskUp);
	maskDown = new wxMask (*downBitmap, maskColour);
	downBitmap->SetMask(maskDown);

	pushUpBitmapPointer = new wxBitmap(upBitmap->GetWidth(), upBitmap->GetHeight());  
	pushDownBitmapPointer = new wxBitmap(downBitmap->GetWidth(), downBitmap->GetHeight());  

	memDC.SelectObject(*pushUpBitmapPointer); 
	memDC.Clear(); 
	memDC.DrawBitmap(*upBitmap, 0, 0, true);
	memDC.SelectObject(wxNullBitmap); 

	memDC.SelectObject(*pushDownBitmapPointer); 
	memDC.Clear(); 
	memDC.DrawBitmap(*downBitmap, 0, 0, true); 
	memDC.SelectObject(wxNullBitmap); 

	delete upBitmap;
	delete downBitmap;

	runButtonPointer = new wxButton(this, 1, wxEmptyString, wxPoint(380, 31), wxSize(25, 25), wxBORDER_NONE);
	runButtonPointer->SetBitmap(*downBitmapPointer);
	mpButtonPointer = new wxButton(this, 2, wxEmptyString, wxPoint(332, 31), wxSize(25, 25), wxBORDER_NONE);
	mpButtonPointer->SetBitmap(*downBitmapPointer);
	loadButtonPointer = new wxButton(this, 4, wxEmptyString, wxPoint(93, 31), wxSize(25, 25), wxBORDER_NONE);
	loadButtonPointer->SetBitmap(*downBitmapPointer);

	for (int i=0; i<8; i++)
	{
		switchNumber.Printf("%i", i);
		dataSwitchPointer[i] = new wxButton(this, i+10, switchNumber, wxPoint(45+48*(7-i), 111), wxSize(25, 25), wxBU_NOTEXT|wxBORDER_NONE);
		dataSwitchPointer[i]->SetBitmap(*downBitmapPointer);
	}
}

Elf2Kswitch::~Elf2Kswitch()
{
	p_Main->setElf2KswitchPos(GetPosition());

	delete elfBitmapPointer;
	delete upBitmapPointer;
	delete downBitmapPointer;

	delete runButtonPointer;
	delete mpButtonPointer;
	delete loadButtonPointer;
//	delete inButtonPointer;
	delete pushUpBitmapPointer;
	delete pushDownBitmapPointer;

	for (int i=0; i<8; i++)
	{
		delete dataSwitchPointer[i];
	}
}

void Elf2Kswitch::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxPaintDC dc(this);
	dc.DrawBitmap(*elfBitmapPointer, 0, 0);
	dc.DrawBitmap(*pushUpBitmapPointer, 45, 31);
}

void Elf2Kswitch::onClose(wxCloseEvent&WXUNUSED(event) )
{
	p_Computer->removeElf2KSwitch();
	Destroy();
}

void Elf2Kswitch::onKeyDown(wxKeyEvent& event)
{
	if (!p_Computer->keyDownPressed(event.GetKeyCode()))
		event.Skip();
}

void Elf2Kswitch::onKeyUp(wxKeyEvent& event)
{
	if (!p_Computer->keyUpReleased(event.GetKeyCode()))
		event.Skip();
}

void Elf2Kswitch::onChar(wxKeyEvent& event)
{
	p_Computer->charEvent(event.GetKeyCode());
}

void Elf2Kswitch::onButtonRelease(wxMouseEvent& event)
{
	p_Computer->onInButtonRelease();
	event.Skip();
}

void Elf2Kswitch::onButtonPress(wxMouseEvent& event)
{
	int x, y;
	event.GetPosition(&x, &y);

	if ((x >= 45) &&(x <= 75) &&(y >= 31) &&(y <= 61))
	{
		p_Computer->onInButtonPress(p_Computer->getData());
	}
	event.Skip();
}

void Elf2Kswitch::onLoadButton(wxCommandEvent&WXUNUSED(event))
{
	p_Computer->onLoadButton();
}

void Elf2Kswitch::onMpButton(wxCommandEvent&WXUNUSED(event))
{
	p_Computer->onMpButton();
}

void Elf2Kswitch::onRunButton(wxCommandEvent&WXUNUSED(event))
{
	p_Computer->onRun();
}

void Elf2Kswitch::setRunButtonUp(int up)
{
	if (up == 1)
		runButtonPointer->SetBitmap(*upBitmapPointer);
	else
		runButtonPointer->SetBitmap(*downBitmapPointer);
}

void Elf2Kswitch::setInButtonUp(bool up)
{
	wxClientDC dc(this);
	if (up)
		dc.DrawBitmap(*pushUpBitmapPointer, 45, 31);
	else
		dc.DrawBitmap(*pushDownBitmapPointer, 45, 31);
}

void Elf2Kswitch::setLoadButtonUp(int up)
{
	if (up)
		loadButtonPointer->SetBitmap(*upBitmapPointer);
	else
		loadButtonPointer->SetBitmap(*downBitmapPointer);
}

void Elf2Kswitch::setMpButtonUp(int up)
{
	if (up)
		mpButtonPointer->SetBitmap(*upBitmapPointer);
	else
		mpButtonPointer->SetBitmap(*downBitmapPointer);
}

void Elf2Kswitch::setDataSwitchUp(int number, int up)
{
	if (up)
		dataSwitchPointer[number]->SetBitmap(*upBitmapPointer);
	else
		dataSwitchPointer[number]->SetBitmap(*downBitmapPointer);
}

void Elf2Kswitch::dataSwitch(wxCommandEvent&event)
{
	int i;

	i = event.GetId() - 10;

	p_Computer->dataSwitch(i);
}
