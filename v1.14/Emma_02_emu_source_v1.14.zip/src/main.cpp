/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#define MAIN

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/stdpaths.h"
#include "wx/fs_inet.h"
#include "wx/filesys.h"
#include "wx/url.h"
#include "wx/dir.h"
#include "wx/fs_zip.h"
#include "wx/sysopt.h" 

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "app_icon.xpm"
#endif

#include "main.h"
#include "ports.h"
#include "psave.h"
#include "datadir.h"
#include "printer.h"
#include "about.h"

//For memory leak debugging, uncomment next line
//#include <vld.h>

#define VU_RED 60
#define VU_MAX 100
#define VU_HI 10

DEFINE_EVENT_TYPE(OPEN_COMX_PRINTER_WINDOW)
DEFINE_EVENT_TYPE(OPEN_PRINTER_WINDOW)
DEFINE_EVENT_TYPE( wxEVT_ERROR_MSG )

BEGIN_EVENT_TABLE(Main, DebugWindow)

	EVT_CLOSE(Main::onClose)

	EVT_MENU(XRCID(GUIQUIT), Main::onQuit)
	EVT_MENU(XRCID(GUIABOUT), Main::onAbout)
	EVT_MENU(XRCID("MI_DataDir"), Main::onDataDir)
	EVT_MENU(XRCID("MI_Home"), Main::onHome)
	EVT_MENU(XRCID("MI_UpdateCheck"), Main::onUpdateCheck)
	EVT_MENU(XRCID("MI_UpdateEmma"), Main::onUpdateEmma)
	EVT_MENU(XRCID(GUIHELP), Main::onHelp)
	EVT_MENU(XRCID(GUISAVECONFIG), Main::onSaveConfig)
	EVT_MENU(XRCID(GUISAVEONEXIT), Main::onSaveOnExit)
	EVT_MENU(XRCID(GUIDEFAULTWINDOWPOS), Main::onDefaultWindowPosition)
	EVT_MENU(XRCID(GUIDEFAULT), Main::onDefaultSettings)
	EVT_MENU(XRCID("Flat"), Main::onFlat)
	EVT_MENU(XRCID("Crisp"), Main::onCrisp)
	EVT_MENU(XRCID("Default"), Main::onDefault)
	EVT_MENU(XRCID("TV Speaker"), Main::onTvSpeaker)
	EVT_MENU(XRCID("Handheld"), Main::onHandheld)

	EVT_BUTTON(XRCID("StartButtonComx"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonElf"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonElfII"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonSuperElf"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonElf2K"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonCosmicos"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonStudio2"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonVisicom"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonVictory"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonVip"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonCidelsa"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonTmc600"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonTMC1800"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonTMC2000"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonNano"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonPecom"), Main::onStart)
	EVT_BUTTON(XRCID("StartButtonEti"), Main::onStart)

	EVT_CHOICEBOOK_PAGE_CHANGED(XRCID("StudioChoiceBook"), Main::onStudioChoiceBook)
	EVT_CHOICEBOOK_PAGE_CHANGED(XRCID("TelmacChoiceBook"), Main::onTelmacChoiceBook)
	EVT_CHOICEBOOK_PAGE_CHANGED(XRCID("CosmacChoiceBook"), Main::onCosmacChoiceBook)
	EVT_TIMER(902, Main::vuTimeout)

	EVT_ERROR_MSG(wxID_ANY, Main::errorMessageEvent)

END_EVENT_TABLE()

IMPLEMENT_APP(Emu1802)

WindowInfo getWinSizeInfo()
{
	int major, minor;

	WindowInfo returnValue;

	wxOperatingSystemId operatingSystemId;
	operatingSystemId = wxGetOsVersion(&major, &minor);

	if (operatingSystemId == wxOS_UNIX_LINUX)
	{
		returnValue.xBorder = 6;
		returnValue.yBorder = 27;
		returnValue.xBorder2 = 6;
		returnValue.yBorder2 = 54;
		returnValue.mainwY = 457;
		returnValue.mainwX = 535;
		returnValue.xPrint = 11;
	}
	else
	{
		if (major == 6) 
		{
			if (minor == 0) // Vista
			{
				returnValue.xBorder2 = 16;
				returnValue.yBorder2 = 36;
				returnValue.mainwY = 491;
			}
			else // 7
			{
				returnValue.xBorder2 = 16;
				returnValue.yBorder2 = 36;
				returnValue.mainwY = 493;
			}

		}
		else
		{
			if (minor == 1) // XP
			{
				returnValue.xBorder2 = 8;
				returnValue.yBorder2 = 36;
				returnValue.mainwY = 489;
			}
			else // 2000
			{
				returnValue.xBorder2 = 8;
				returnValue.yBorder2 = 36;
				returnValue.mainwY = 489;
			}
		}
		returnValue.xPrint = 21;
		returnValue.xBorder = 0;
		returnValue.yBorder = 0;
		returnValue.mainwX = 550;
	}


	return returnValue;
}

bool Emu1802::OnInit()
{
	wxInitAllImageHandlers();
    wxFileSystem::AddHandler(new wxZipFSHandler);
	wxXmlResource::Get()->InitAllHandlers();
	wxXmlResource::Get()->Load("main.xrc");

    SetVendorName("Marcel van Tongeren");
    SetAppName("Emma 02"); 

	wxConfigBase *configPointer = wxConfigBase::Get();
	configPointer->SetRecordDefaults();

	PrintDataPointer = new wxPrintData;
	PrintDataPointer->SetPaperId(wxPAPER_A4);

	p_PageSetupData = new wxPageSetupDialogData;
	(*p_PageSetupData) = *PrintDataPointer;
	p_PageSetupData->SetMarginTopLeft(wxPoint(9, 9));
	p_PageSetupData->SetMarginBottomRight(wxPoint(9, 9));

	int mainWindowX = configPointer->Read("/Xpos", 30);
	int mainWindowY = configPointer->Read("/Ypos", 30);

	WindowInfo windowInfo = getWinSizeInfo();

	p_Main = new Main("Emma 02", wxPoint(mainWindowX, mainWindowY), wxSize(windowInfo.mainwX, windowInfo.mainwY));

	configPointer->Write("/Version", EMMA_VERSION);

	bool checkForUpdate;
	configPointer->Read("/CheckForUpdate", &checkForUpdate, true);

	if (checkForUpdate)
	{
		if (p_Main->updateEmma())
  			return false;
	}

	p_Main->Show(true);
	return true;
}

int Emu1802::OnExit()
{
	delete wxConfigBase::Set((wxConfigBase *) NULL);
	delete PrintDataPointer;
	delete p_PageSetupData;
	return 0;
}

Main::Main(const wxString& title, const wxPoint& pos, const wxSize& size)
: DebugWindow(title, pos, size)
{
	windowInfo = getWinSizeInfo();
	xmlLoaded_ = false;
	SetIcon(wxICON(app_icon));

	SetMenuBar(wxXmlResource::Get()->LoadMenuBar("Main_Menu"));
	wxXmlResource::Get()->LoadPanel(this, "Main_GUI");

	xmlLoaded_ = true;
	computerRunning_ = false;
	runningComputer_ = NO_COMPUTER;

	workingDir_ = wxGetCwd();	wxStandardPaths stPath;
	dataDir_ = configPointer->Read("/DataDir", stPath.GetUserDataDir() + pathSeparator_);

	wxFileName applicationFile = wxFileName::wxFileName(workingDir_, "", wxPATH_NATIVE);
	pathSeparator_ = applicationFile.GetPathSeparator(wxPATH_NATIVE);
	applicationDirectory_ = applicationFile.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);

	wxString helpFile = applicationDirectory_ + "Emma 02.htb";

 	if (!help_.Initialize(helpFile))
	{
		(void)wxMessageBox( "Failed adding book " + helpFile + "\n",
							"Emma 02", wxICON_ERROR | wxOK );
	}

	this->Connect(XRCID(GUICOMPUTERNOTEBOOK), wxEVT_COMMAND_NOTEBOOK_PAGE_CHANGED, wxNotebookEventHandler(Main::onComputer) );
	wxFont smallFont(6, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
	XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetFont(smallFont);
	wxFont defaultFont(8, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
	XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetFont(defaultFont);

	wxString text;
	for (int i=0; i<16; i++)
	{
		text.Printf("R%d",i);
		registerTextPointer[i] = XRCCTRL(*this,text, wxTextCtrl);
	}
	for (int i=1; i<8; i++)
	{
		text.Printf("I%d",i);
		inTextPointer[i] = XRCCTRL(*this,text, wxTextCtrl);
		text.Printf("O%d",i);
		outTextPointer[i] = XRCCTRL(*this,text, wxTextCtrl);
	}
	for (int i=1; i<5; i++)
	{
		text.Printf("EF%d",i);
		efTextPointer[i] = XRCCTRL(*this,text, wxTextCtrl);
	}
	dfTextPointer = XRCCTRL(*this,"DF", wxTextCtrl);
	qTextPointer = XRCCTRL(*this,"Q", wxTextCtrl);
	ieTextPointer = XRCCTRL(*this,"IE", wxTextCtrl);
	dTextPointer = XRCCTRL(*this,"D", wxTextCtrl);
	pTextPointer = XRCCTRL(*this,"P", wxTextCtrl);
	xTextPointer = XRCCTRL(*this,"X", wxTextCtrl);
	tTextPointer = XRCCTRL(*this,"T", wxTextCtrl);

	assemblerWindowPointer = XRCCTRL(*this,"AssemblerWindow", wxTextCtrl);
	disassemblerWindowPointer = XRCCTRL(*this,"DisassemblerWindow", wxTextCtrl);
	traceWindowPointer = XRCCTRL(*this,"TraceWindow", wxTextCtrl);
	inputWindowPointer = XRCCTRL(*this,"InputWindow", wxTextCtrl);
	breakPointWindowPointer = XRCCTRL(*this,"BreakPointWindow", wxListCtrl);
	tregWindowPointer = XRCCTRL(*this,"TregWindow", wxListCtrl);
	trapWindowPointer = XRCCTRL(*this,"TrapWindow", wxListCtrl);

	readConfig();

	oldGauge_ = 1;
	vuPointer = new wxTimer(this, 902);
	ReparentAllStaticBoxItemsInWindow( XRCCTRL(*this,"COMX-35", wxPanel));
	ReparentAllStaticBoxItemsInWindow( XRCCTRL(*this,"Pecom", wxPanel));
}

Main::~Main()
{
	delete vuPointer;
	if (configPointer == NULL || !saveOnExit_)
		return;

	this->GetPosition(&mainWindowX_, &mainWindowY_);
	writeConfig();
}

void Main::writeConfig()
{
	wxMenuBar *menubarPointer = GetMenuBar();

	if (mainWindowX_ > 0)
		configPointer->Write("/Xpos", mainWindowX_);
	if (mainWindowY_ > 0)
		configPointer->Write("/Ypos", mainWindowY_);

	configPointer->Write("/SelectedNotebook", XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->GetSelection());
	configPointer->Write("StudioChoiceBook", XRCCTRL(*this, "StudioChoiceBook", wxChoicebook)->GetSelection());
	configPointer->Write("TelmacChoiceBook", XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->GetSelection());
	configPointer->Write("DebuggerChoiceBook", XRCCTRL(*this, "DebuggerChoiceBook", wxChoicebook)->GetSelection());
	configPointer->Write("CosmacChoiceBook", XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->GetSelection());

	if (menubarPointer->IsChecked(XRCID("Flat")))
		configPointer->Write("Equalization", "Flat");
	if (menubarPointer->IsChecked(XRCID("Crisp")))
		configPointer->Write("Equalization", "Crisp");
	if (menubarPointer->IsChecked(XRCID("Default")))
		configPointer->Write("Equalization", "Default");
	if (menubarPointer->IsChecked(XRCID("TV Speaker")))
		configPointer->Write("Equalization", "TV Speaker");
	if (menubarPointer->IsChecked(XRCID("Handheld")))
		configPointer->Write("Equalization", "Handheld");

	configPointer->Write("/DataDir", dataDir_);
	configPointer->Write("/SaveOnExit", saveOnExit_);
	configPointer->Write("/CheckForUpdate", checkForUpdate_);
	configPointer->Write("/FullScreenFloat", fullScreenFloat_);
	configPointer->Write("/PsaveVolume", psaveData_[0]);
	configPointer->Write("/PsaveBitRate", psaveData_[1]);
	configPointer->Write("/PsaveBitsPerSample", psaveData_[2]);
	configPointer->Write("/ConversionTypeWav", psaveData_[3]);
	configPointer->Write("/TapeChannel", psaveData_[4]);
	configPointer->Write("/Playback", psaveData_[5]);
	configPointer->Write("/ReversedPolarity", psaveData_[6]);
	configPointer->Write("/ConversionType", psaveData_[7]);

	writeDebugConfig();
	writeComxConfig();
	writeElfConfig(ELF, "Elf");
	writeElfConfig(ELFII, "ElfII");
	writeElfConfig(SUPERELF, "SuperElf");
	writeElf2KConfig();
	writeCosmicosConfig();
	writeStudioConfig();
	writeVisicomConfig();
	writeVictoryConfig();
	writeVipConfig();
	writeCidelsaConfig();
	writeTelmacConfig();
	writeTMC2000Config();
	writeTMC1800Config();
	writeNanoConfig();
	writePecomConfig();
	writeEtiConfig();
}

void Main::readConfig()
{
	wxMenuBar *menubarPointer = GetMenuBar();
	Byte brightness [8] = { 0, 28, 77, 105, 150, 194, 227, 0xff };

	mainWindowX_ = configPointer->Read("/Xpos", 30);
	mainWindowY_ = configPointer->Read("/Ypos", 30);

	wxString colour[66];

	for (int i=0; i<8; i++)
	{
		colour[i*8].Printf("#%02X%02X%02X", (brightness[i]^0xff)&0xff, (brightness[i]^0xff)&0xff, (brightness[i]^0xff)&0xff);
		colour[i*8+1].Printf("#%02X%02X%02X", 0, brightness[i], 0);
		colour[i*8+2].Printf("#%02X%02X%02X", 0, 0, brightness[i]);
		colour[i*8+3].Printf("#%02X%02X%02X", 0, brightness[i], brightness[i]);
		colour[i*8+4].Printf("#%02X%02X%02X", brightness[i], 0, 0);
		colour[i*8+5].Printf("#%02X%02X%02X", brightness[i], brightness[i], 0);
		colour[i*8+6].Printf("#%02X%02X%02X", brightness[i], 0, brightness[i]);
		colour[i*8+7].Printf("#%02X%02X%02X", brightness[i], brightness[i], brightness[i]);
	}
	colour[64] = "#00ff00";	// foreground i8275
	colour[65] = "#004000";	// background i8275
	setScreenInfo(COMX, 0, 66, colour);
	setComputerInfo(COMX, "Comx", "COMX-35", "comx");

	setScreenInfo(CIDELSA, 56, 64, colour);
	setComputerInfo(CIDELSA, "Cidelsa", "Cidelsa", "");

	setScreenInfo(TMC600, 56, 64, colour);
	setComputerInfo(TMC600, "Tmc600", "Telmac 600", "tmc600");

	setScreenInfo(PECOM, 56, 64, colour);
	setComputerInfo(PECOM, "Pecom", "Pecom 64", "pecom");

	colour[0] = "#ffffff";	// foreground pixie
	colour[1] = "#000000";	// background pixie
	colour[2] = "#00ff00";	// foreground i8275
	colour[3] = "#004000";	// background i8275
	colour[4] = "#00ff00";	// highlight i8275
	setScreenInfo(ELF2K, 0, 5, colour);
	setComputerInfo(ELF2K, "Elf2K", "Elf 2000", "");

	setScreenInfo(COSMICOS, 0, 5, colour);
	setComputerInfo(COSMICOS, "Cosmicos", "Cosmicos", "");

	colour[5] = "#000000";	// background mc6847
	colour[6] = "#00ff00";	// text green
	colour[7] = "#ffc418";	// text orange
	colour[8] = "#00ff00";	// graphic Green
	colour[9] = "#ffff00";	// graphic Yellow 
	colour[10] = "#0000ff";	// graphic Blue
	colour[11] = "#ff0000";	// graphic Red
	colour[12] = "#ffffff";	// graphic Buff
	colour[13] = "#00ffff";	// graphic Cyan
	colour[14] = "#ff00ff";	// graphic Magenta
	colour[15] = "#ffc418";	// graphic Orange
	colour[16] = "#000000";
	colour[17] = "#000000";
	colour[18] = "#007f00";
	colour[19] = "#00ff00";
	colour[20] = "#00003f";
	colour[21] = "#0000ff";
	colour[22] = "#3f0000";
	colour[23] = "#007f7f";
	colour[24] = "#7f0000";
	colour[25] = "#ff0000";
	colour[26] = "#7f7f00";
	colour[27] = "#ffff00";
	colour[28] = "#003f00";
	colour[29] = "#7f007f";
	colour[30] = "#7f7f7f";
	colour[31] = "#ffffff";
	setScreenInfo(ELF, 0, 32, colour);
	setComputerInfo(ELF, "Elf", "Cosmac Elf", "");

	setScreenInfo(ELFII, 0, 32, colour);
	setComputerInfo(ELFII, "ElfII", "Netronics Elf II", "super");

	setScreenInfo(SUPERELF, 0, 32, colour);
	setComputerInfo(SUPERELF, "SuperElf", "Quest Super Elf", "super");

	setScreenInfo(STUDIO, 0, 2, colour);
	setComputerInfo(STUDIO, "Studio2", "Studio II", "");

	setScreenInfo(NANO, 0, 2, colour);
	setComputerInfo(NANO, "Nano", "Telmac Nano", "");

	setScreenInfo(TMC1800, 0, 2, colour);
	setComputerInfo(TMC1800, "TMC1800", "Telmac 1800", "");

	colour[0] = "#004000";
	colour[1] = "#70d0ff";
	colour[2] = "#d0ff70";
	colour[3] = "#ff7070";
	setScreenInfo(VISICOM, 0, 4, colour);
	setComputerInfo(VISICOM, "Visicom", "Visicom COM-100", "");

	colour[0] = "#141414";
	colour[1] = "#ff0000";
	colour[2] = "#0000ff";
	colour[3] = "#ff00ff";
	colour[4] = "#00ff00";
	colour[5] = "#ffff00";
	colour[6] = "#00ffff";
	colour[7] = "#ffffff";
	colour[8] = "#000080";
	colour[9] = "#000000";
	colour[10] = "#008000";
	colour[11] = "#800000";
	setScreenInfo(VIP, 0, 12, colour);
	setComputerInfo(VIP, "Vip", "Cosmac VIP", "");

	setScreenInfo(ETI, 0, 12, colour);
	setComputerInfo(ETI, "Eti", "ETI 660", "");

	colour[0] = "#ffffff";
	colour[1] = "#ff00ff";
	colour[2] = "#00ffff";
	colour[3] = "#0000ff";
	colour[4] = "#ffff00";
	colour[5] = "#ff0000";
	colour[6] = "#00ff00";
	colour[7] = "#141414";
	setScreenInfo(TMC2000, 0, 12, colour);
	setComputerInfo(TMC2000, "TMC2000", "Telmac 2000", "");

	colour[0] = "#ffffff";
	colour[1] = "#ff40ff";
	colour[2] = "#40ffff";
	colour[3] = "#4040ff";
	colour[4] = "#ffff40";
	colour[5] = "#ff4040";
	colour[6] = "#40ff40";
	colour[7] = "#141414";
	colour[8] = "#d0a0ff";
	colour[9] = "#a0a0a0";
	colour[10] = "#a0ffa0";
	colour[11] = "#d0a0a0";
	setScreenInfo(VICTORY, 0, 12, colour);
	setComputerInfo(VICTORY, "Victory", "Victory MPT-02", "");

	readDebugConfig();
	readComxConfig();
	readElfConfig(ELF, "Elf");
	readElfConfig(ELFII, "ElfII");
	readElfConfig(SUPERELF, "SuperElf");
	readElf2KConfig();
	readCosmicosConfig();
	readVipConfig();
	readStudioConfig();
	readVisicomConfig();
	readVictoryConfig();
	readCidelsaConfig();
	readTelmacConfig();
	readTMC1800Config();
	readTMC2000Config();
	readNanoConfig();
	readPecomConfig();
	readEtiConfig();

	configPointer->Read("/SaveOnExit", &saveOnExit_, true);
	menubarPointer->Check(XRCID(GUISAVEONEXIT), saveOnExit_);
	configPointer->Read("/CheckForUpdate", &checkForUpdate_, true);
	menubarPointer->Check(XRCID("MI_UpdateCheck"), checkForUpdate_);
	configPointer->Read("/FullScreenFloat", &fullScreenFloat_, true);
	menubarPointer->Check(XRCID("MI_FullScreenFloat"), fullScreenFloat_);
	menubarPointer->Check(XRCID(configPointer->Read("Equalization", "TV Speaker")), true);

	if (configPointer->Read("Equalization") == "Flat")
	{
		bass_ = 1;
		treble_ = 0;
	}

	if (configPointer->Read("Equalization") == "Crisp")
	{
		bass_ = 1;
		treble_ = 5;
	}

	if (configPointer->Read("Equalization") == "Default")
	{
		bass_ = 16;
		treble_ = -8;
	}

	if (configPointer->Read("Equalization") == "TV Speaker")
	{
		bass_ = 180;
		treble_ = -8;
	}

	if (configPointer->Read("Equalization") == "Handheld")
	{
		bass_ = 2000;
		treble_ = -47;
	}

	XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(COMXTAB);
	XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(MESSAGETAB);

	XRCCTRL(*this, "StudioChoiceBook", wxChoicebook)->SetSelection(configPointer->Read("StudioChoiceBook", 0l));
	XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetSelection(configPointer->Read("CosmacChoiceBook", 0l));
//***	XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetSelection(configPointer->Read("CosmacChoiceBook", 5l));
	XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->SetSelection(configPointer->Read("TelmacChoiceBook", 0l));
	XRCCTRL(*this, "DebuggerChoiceBook", wxChoicebook)->SetSelection(configPointer->Read("DebuggerChoiceBook", 0l));

	XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(configPointer->Read("SelectedNotebook", 0l));
//***	XRCCTRL(*this, GUICOMPUTERNOTEBOOK), wxNotebook)->SetSelection(configPointer->Read("SelectedNotebook", 1l));

	psaveData_[0] = configPointer->Read("/PsaveVolume", 15l);
	psaveData_[1] = configPointer->Read("/PsaveBitRate", 1l);
	psaveData_[2] = configPointer->Read("/PsaveBitsPerSample", 1l);
	psaveData_[3] = configPointer->Read("/ConversionTypeWav", 0l);
	psaveData_[4] = configPointer->Read("/TapeChannel", 0l);
	psaveData_[5] = configPointer->Read("/Playback", 0l);
	psaveData_[6] = configPointer->Read("/ReversedPolarity", 0l);
	psaveData_[7] = configPointer->Read("/ConversionType", 1l);
}

void Main::onHelp(wxCommandEvent& WXUNUSED(event))
{
	help_.DisplayContents();
}

wxString Main::downloadString(wxString url)
{
	wxFileSystem fs; 
	wxFSFile *file= fs.OpenFile(url); 
	wxString returnString = "";

	if (file)   
	{ 
		wxInputStream *in_stream = file->GetStream(); 
		if (in_stream)
		{
			unsigned char buffer[400]; 
			in_stream->Read(buffer, 400); 
			int i=0;
			while (buffer[i] != 0 && i<400)
			{
				returnString.operator += (buffer[i]);
				i++;
			}
		}
		delete file;
	}
	return returnString;
}

bool Main::updateEmma()
{
	wxFileSystem::AddHandler(new wxInternetFSHandler); 
	wxString version = configPointer->Read("/Version", EMMA_VERSION);

	wxString latestVersion = downloadString("http://emma02download.hobby-site.com/Emma_02_version.txt");
	if (latestVersion == "")
		return false;

	int urlStart=latestVersion.Find("HREF=");
	if (urlStart != wxNOT_FOUND)
	{	
		urlStart+=6;
		latestVersion = latestVersion.Mid(urlStart);
		int urlEnd=latestVersion.Find((char)34);
		latestVersion = latestVersion.Mid(0, urlEnd);
		latestVersion = downloadString(latestVersion);
	}

	if (latestVersion == version || latestVersion == "")
		return false;

	int answer = wxMessageBox( "Emma 02 V"+latestVersion+" is available, download now?\n",
							   "Emma 02", wxICON_QUESTION  | wxYES_DEFAULT | wxYES_NO);

	if (answer == wxYES)
	{
		::wxLaunchDefaultBrowser("http://www.emma02.hobby-site.com/ccount/click.php?id=1");
		return true;
	}
	else
		return false;
}

void Main::onQuit(wxCommandEvent&WXUNUSED(event))
{
	stopComputer();
	Destroy();
}

void Main::onSaveOnExit(wxCommandEvent&event)
{
	saveOnExit_ = event.IsChecked();
}

void Main::onSaveConfig(wxCommandEvent&WXUNUSED(event))
{
	writeConfig();
}

void Main::onClose(wxCloseEvent&WXUNUSED(event))
{
	stopComputer();
	Destroy();
}

void Main::onAbout(wxCommandEvent&WXUNUSED(event))
{
	MyAboutDialog MyAboutDialog(this);
 	MyAboutDialog.ShowModal();
}

void Main::onDataDir(wxCommandEvent&WXUNUSED(event))
{
	DatadirDialog dataDialog(this);
 	dataDialog.ShowModal();
}

void Main::onHome(wxCommandEvent&WXUNUSED(event))
{
	::wxLaunchDefaultBrowser("http://www.emma02.hobby-site.com/");
}

void Main::onUpdateCheck(wxCommandEvent&event)
{
	checkForUpdate_ = event.IsChecked();
}

void Main::onUpdateEmma(wxCommandEvent&WXUNUSED(event))
{
	updateEmma();
}

void Main::onDefaultSettings(wxCommandEvent&WXUNUSED(event))
{
	setDefaultSettings();
}

void Main::setDefaultSettings()
{
	for (int i=0; i<5; i++)
	{
		delete baudTextT[i];
		delete baudChoiceT[i];
		delete baudTextR[i];
		delete baudChoiceR[i];
	}
	configPointer->DeleteAll();
	readConfig();
}

void Main::onFlat(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 1;
	treble_ = 0;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onCrisp(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 1;
	treble_ = 5;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onDefault(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 16;
	treble_ = -8;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onTvSpeaker(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 180;
	treble_ = -8;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onHandheld(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 2000;
	treble_ = -47;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onDefaultWindowPosition(wxCommandEvent&WXUNUSED(event))
{
	mainWindowX_ = 30;
	mainWindowY_ = 30;
	conf[COMX].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[COMX].mainY_ = mainWindowY_;
	conf[CIDELSA].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[CIDELSA].mainY_ = mainWindowY_;
	conf[TMC600].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[TMC600].mainY_ = mainWindowY_;
	conf[VIP].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[VIP].mainY_ = mainWindowY_;
	conf[TMC1800].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[TMC1800].mainY_ = mainWindowY_;
	conf[TMC2000].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[TMC2000].mainY_ = mainWindowY_;
	conf[ETI].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[ETI].mainY_ = mainWindowY_;
	conf[NANO].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[NANO].mainY_ = mainWindowY_;
	conf[PECOM].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[PECOM].mainY_ = mainWindowY_;
	conf[STUDIO].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[STUDIO].mainY_ = mainWindowY_;
	conf[VISICOM].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[VISICOM].mainY_ = mainWindowY_;
	conf[VICTORY].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[VICTORY].mainY_ = mainWindowY_;

	for (int i=0; i<5; i++)
	{
		conf[i].pixieX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].pixieY_ = mainWindowY_;
		conf[i].tmsX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].tmsY_ = mainWindowY_;
		conf[i].mc6845X_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].mc6845Y_ = mainWindowY_;
		conf[i].mc6847X_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].mc6847Y_ = mainWindowY_;
		conf[i].i8275X_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].i8275Y_ = mainWindowY_;
		conf[i].vtX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].vtY_ = mainWindowY_;

		conf[i].mainX_ = mainWindowX_;
		conf[i].mainY_ = mainWindowY_+windowInfo.mainwY+windowInfo.yBorder;
	}

	conf[ELF2K].keypadX_ = mainWindowX_+507+windowInfo.xBorder2;
	conf[ELF2K].keypadY_ = mainWindowY_+478+windowInfo.yBorder2;
	conf[COSMICOS].keypadX_ = mainWindowX_+333+windowInfo.xBorder2;
	conf[COSMICOS].keypadY_ = mainWindowY_+windowInfo.mainwY+windowInfo.yBorder;
	conf[ELF].keypadX_ = mainWindowX_+346+windowInfo.xBorder2;
	conf[ELF].keypadY_ = mainWindowY_+windowInfo.mainwY+windowInfo.yBorder;
	ledModuleX_ = mainWindowX_+346+windowInfo.xBorder2;
	ledModuleY_ = mainWindowY_+windowInfo.mainwY+229+windowInfo.yBorder2;
	switchX_ = mainWindowX_+507+windowInfo.xBorder2;
	switchY_ = mainWindowY_+478+windowInfo.yBorder2;

	this->Move(mainWindowX_, mainWindowY_);
	switch (runningComputer_)
	{
		case COMX:
			p_Comx->Move(conf[COMX].mainX_, conf[COMX].mainY_);
		break;

		case CIDELSA:
			p_Cidelsa->Move(conf[CIDELSA].mainX_, conf[CIDELSA].mainY_);
		break;

		case TMC600:
			p_Tmc600->Move(conf[TMC600].mainX_, conf[TMC600].mainY_);
		break;

		case TMC2000:
			p_Tmc2000->Move(conf[TMC2000].mainX_, conf[TMC2000].mainY_);
		break;

		case TMC1800:
			p_Tmc1800->Move(conf[TMC1800].mainX_, conf[TMC1800].mainY_);
		break;

		case ETI:
			p_Eti->Move(conf[ETI].mainX_, conf[ETI].mainY_);
		break;

		case NANO:
			p_Nano->Move(conf[NANO].mainX_, conf[NANO].mainY_);
		break;

		case PECOM:
			p_Pecom->Move(conf[PECOM].mainX_, conf[PECOM].mainY_);
		break;

		case STUDIO:
			p_Studio2->Move(conf[STUDIO].mainX_, conf[STUDIO].mainY_);
		break;

		case VISICOM:
			p_Visicom->Move(conf[VISICOM].mainX_, conf[VISICOM].mainY_);
		break;

		case VICTORY:
			p_Victory->Move(conf[VICTORY].mainX_, conf[VICTORY].mainY_);
		break;

		case VIP:
			p_Vip->Move(conf[VIP].mainX_, conf[VIP].mainY_);
		break;

		case ELF2K:
			p_Elf2K->moveWindows();
			p_Elf2K->Move(conf[ELF2K].mainX_, conf[ELF2K].mainY_);
		break;

		case COSMICOS:
			p_Cosmicos->moveWindows();
			p_Cosmicos->Move(conf[COSMICOS].mainX_, conf[COSMICOS].mainY_);
		break;

		case ELF:
			p_Elf->moveWindows();
			p_Elf->Move(conf[ELF].mainX_, conf[ELF].mainY_);
		break;

		case ELFII:
			p_Elf2->moveWindows();
			p_Elf2->Move(conf[ELFII].mainX_, conf[ELFII].mainY_);
		break;

		case SUPERELF:
			p_Super->moveWindows();
			p_Super->Move(conf[SUPERELF].mainX_, conf[SUPERELF].mainY_);
		break;
	}
}

void Main::onStart(wxCommandEvent&WXUNUSED(event))
{
	int zoom;
	int comxy;
	int stereo = 1;
	int toneChannels = 1;

	emuClosing_ = false;
	if (computerRunning_)
	{
		p_Computer->onReset();
		return;
	}

	p_Video = NULL;
	p_Vt100 = NULL;

	runningComputer_ = selectedComputer_;
	wxSetWorkingDirectory(workingDir_);
	setClock(runningComputer_);
	zoom = getSpinValue("Zoom"+computerInfo[runningComputer_].gui);
	vuPointer->Start(100, wxTIMER_CONTINUOUS);

	switch (runningComputer_)
	{
		case COMX:
			p_Main->setComxExpLedOn (false);
			if (getChoiceSelection("VidModeComx") == PAL)
				comxy = 216;
			else
				comxy = 192;
			p_Comx = new Comx(computerInfo[COMX].name, wxPoint(conf[COMX].mainX_, conf[COMX].mainY_), wxSize(240 * zoom, comxy * zoom), zoom, COMX, conf[COMX].clockSpeed_);
			p_Video = p_Comx;
			p_Computer = p_Comx;
		break;

		case ELF:
			p_Elf = new Elf(computerInfo[ELF].name, wxPoint(conf[ELF].mainX_, conf[ELF].mainY_), wxSize(346, 464), conf[ELF].clockSpeed_, elfConfiguration[ELF]);
			p_Computer = p_Elf;
		break;

		case ELFII:
			p_Elf2 = new Elf2(computerInfo[ELFII].name, wxPoint(conf[ELFII].mainX_, conf[ELFII].mainY_), wxSize(534, 386), conf[ELFII].clockSpeed_, elfConfiguration[ELFII]);
			p_Computer = p_Elf2;
		break;

		case SUPERELF:
			p_Super = new Super(computerInfo[SUPERELF].name, wxPoint(conf[SUPERELF].mainX_, conf[SUPERELF].mainY_), wxSize(534, 386), selectedComputer_, conf[SUPERELF].clockSpeed_, elfConfiguration[SUPERELF]);
			p_Computer = p_Super;
		break;

		case ELF2K:
			p_Elf2K = new Elf2K(computerInfo[ELF2K].name, wxPoint(conf[ELF2K].mainX_, conf[ELF2K].mainY_), wxSize(507, 459), conf[ELF2K].clockSpeed_, elfConfiguration[ELF2K]);
			p_Computer = p_Elf2K;
		break;

		case COSMICOS:
			p_Cosmicos = new Cosmicos(computerInfo[COSMICOS].name, wxPoint(conf[COSMICOS].mainX_, conf[COSMICOS].mainY_), wxSize(333, 160), conf[COSMICOS].clockSpeed_, elfConfiguration[COSMICOS]);
			p_Computer = p_Cosmicos;
		break;

		case STUDIO:
			p_Studio2 = new Studio2(computerInfo[STUDIO].name, wxPoint(conf[STUDIO].mainX_, conf[STUDIO].mainY_), wxSize(192*zoom, 128*zoom), zoom, STUDIO);
			p_Video = p_Studio2;
			p_Computer = p_Studio2;
		break;

		case VISICOM:
			p_Visicom = new Visicom(computerInfo[VISICOM].name, wxPoint(conf[VISICOM].mainX_, conf[VISICOM].mainY_), wxSize(192*zoom, 128*zoom), zoom, VISICOM);
			p_Video = p_Visicom;
			p_Computer = p_Visicom;
		break;

		case VICTORY:
			p_Victory = new Victory(computerInfo[VICTORY].name, wxPoint(conf[VICTORY].mainX_, conf[VICTORY].mainY_), wxSize(192*zoom, 192*zoom), zoom, VICTORY);
			p_Video = p_Victory;
			p_Computer = p_Victory;
		break;

		case VIP:
			p_Vip = new Vip(computerInfo[VIP].name, wxPoint(conf[VIP].mainX_, conf[VIP].mainY_), wxSize(192*zoom, 128*zoom), zoom, VIP, conf[VIP].clockSpeed_, conf[VIP].tempo_);
			p_Video = p_Vip;
			p_Computer = p_Vip;
			if (XRCCTRL(*this, "StereoVip", wxCheckBox)->GetValue())
				stereo = 2;
			if (conf[VIP].vipSound_ == VIP_SUPER2)
				toneChannels = 2;
			if (conf[VIP].vipSound_ == VIP_SUPER4)
				toneChannels = 4;
		break;

		case TMC1800:
			p_Tmc1800 = new Tmc1800(computerInfo[TMC1800].name, wxPoint(conf[TMC1800].mainX_, conf[TMC1800].mainY_), wxSize(192*zoom, 128*zoom), zoom, TMC1800);
			p_Video = p_Tmc1800;
			p_Computer = p_Tmc1800;
		break;

		case TMC2000:
			p_Tmc2000 = new Tmc2000(computerInfo[TMC2000].name, wxPoint(conf[TMC2000].mainX_, conf[TMC2000].mainY_), wxSize(192*zoom, 192*zoom), zoom, TMC2000);
			p_Video = p_Tmc2000;
			p_Computer = p_Tmc2000;
		break;

		case ETI:
			p_Eti = new Eti(computerInfo[ETI].name, wxPoint(conf[ETI].mainX_, conf[ETI].mainY_), wxSize(192*zoom, 192*zoom), zoom, ETI);
			p_Video = p_Eti;
			p_Computer = p_Eti;
		break;

		case NANO:
			p_Nano = new Nano(computerInfo[NANO].name, wxPoint(conf[NANO].mainX_, conf[NANO].mainY_), wxSize(192*zoom, 192*zoom), zoom, NANO);
			p_Video = p_Nano;
			p_Computer = p_Nano;
		break;

		case CIDELSA:
			p_Cidelsa = new Cidelsa(computerInfo[CIDELSA].name, wxPoint(conf[CIDELSA].mainX_, conf[CIDELSA].mainY_), wxSize(200*zoom, 240*zoom), zoom, CIDELSA, conf[CIDELSA].clockSpeed_);
			p_Video = p_Cidelsa;
			p_Computer = p_Cidelsa;
		break;

		case TMC600:
			p_Tmc600 = new Tmc600(computerInfo[TMC600].name, wxPoint(conf[TMC600].mainX_, conf[TMC600].mainY_), wxSize(240*zoom, 216*zoom), zoom, TMC600, conf[TMC600].clockSpeed_);
			p_Video = p_Tmc600;
			p_Computer = p_Tmc600;
		break;

		case PECOM:
			p_Pecom = new Pecom(computerInfo[PECOM].name, wxPoint(conf[PECOM].mainX_, conf[PECOM].mainY_), wxSize(240*zoom, 216*zoom), zoom, PECOM, conf[PECOM].clockSpeed_);
			p_Video = p_Pecom;
			p_Computer = p_Pecom;
		break;
	}
	enableGui(false);
	computerRunning_ = true;
	p_Computer->initCpu(selectedComputer_);
	p_Computer->configureComputer();
 	p_Computer->initSound(conf[runningComputer_].clockSpeed_, runningComputer_, conf[runningComputer_].volume_, bass_, treble_, toneChannels, stereo, conf[runningComputer_].realCassetteLoad_);
	p_Computer->initComputer();
	p_Computer->startComputer();
}

void Main::stopComputer()
{
	vuPointer->Stop();
	if (emuClosing_)  return;
	emuClosing_ = true;
	switch (runningComputer_)
	{
		case COMX:
			setComxStatusLedOn (false);
			vuSet("Vu"+computerInfo[runningComputer_].gui, 0);
		break;
		case ELF:
		case ELFII:
		case SUPERELF:
			enableMemAccessGui(false);
			vuSet("Vu"+computerInfo[runningComputer_].gui, 0);
		break;
		case VIP:
		case COSMICOS: 
		case TMC600:
		case TMC1800:
		case TMC2000:
		case NANO:
		case PECOM:
		case ETI:
			vuSet("Vu"+computerInfo[runningComputer_].gui, 0);
		break;
		case NO_COMPUTER:
			return;
		break;
	}
	p_Computer->stopComputer();
	p_Computer->showTime();
	delete p_Computer;
	p_Computer = NULL;
	p_Video = NULL;
	p_Vt100 = NULL;
	computerRunning_ = false;
	enableGui(true);
	runningComputer_ = NO_COMPUTER;
}

void Main::onComputer(wxNotebookEvent&event)
{
	switch(event.GetSelection())
	{
		case COMXTAB:
			selectedComputer_ = COMX;
		break;

		case ELFTAB:
			selectedComputer_ = elfChoice_;
		break;

		case STUDIOTAB:
			selectedComputer_ = studioChoice_;
		break;

		case CIDELSATAB:
			selectedComputer_ = CIDELSA;
		break;

		case TELMACTAB:
			selectedComputer_ = telmacChoice_;
		break;

		case PECOMTAB:
			selectedComputer_ = PECOM;
		break;

		case ETITAB:
			selectedComputer_ = ETI;
		break;

		case DEBUGGERTAB:
			selectedComputer_ = DEBUGGER;
		break;

		case MESSAGETAB:
			selectedComputer_ = MESSAGE;
		break;
	}
	enableElfConfig(selectedComputer_ < 3);
}

void Main::onStudioChoiceBook(wxChoicebookEvent&event)
{
	switch(event.GetSelection())
	{
		case 0:
			studioChoice_ = STUDIO;
		break;

		case 1:
			studioChoice_ = VISICOM;
		break;

		case 2:
			studioChoice_ = VICTORY;
		break;
	}
	selectedComputer_ = studioChoice_;
}

void Main::onTelmacChoiceBook(wxChoicebookEvent&event)
{
	switch(event.GetSelection())
	{
		case 0:
			telmacChoice_ = TMC600;
		break;

		case 1:
			telmacChoice_ = TMC1800;
		break;

		case 2:
			telmacChoice_ = TMC2000;
		break;

		case 3:
			telmacChoice_ = NANO;
		break;
	}
	selectedComputer_ = telmacChoice_;
}

void Main::onCosmacChoiceBook(wxChoicebookEvent&event)
{
	switch(event.GetSelection())
	{
		case 0:
			elfChoice_ = ELF2K;
		break;

		case 1:
			elfChoice_ = VIP;
		break;

		case 2:
			elfChoice_ = COSMICOS; 
		break;

		case 3:
			elfChoice_ = ELF; 
		break;

		case 4:
			elfChoice_ = ELFII;
		break;

		case 5:
			elfChoice_ = SUPERELF;
		break;
	}
	selectedComputer_ = elfChoice_;
	enableElfConfig(selectedComputer_ < 3);
}

void Main::enableElfConfig(bool status)
{
	wxMenuBar *menubarPointer = GetMenuBar();

	menubarPointer->Enable(XRCID("MI_GameMode"), status);
	menubarPointer->Enable(XRCID("MI_GiantBoard"), status);
	menubarPointer->Enable(XRCID("MI_QuestLoader"), status);
	menubarPointer->Enable(XRCID("MI_SuperBasic"), status);
	menubarPointer->Enable(XRCID("MI_SuperBasicSerial"), status);
	menubarPointer->Enable(XRCID("MI_RcaBasic"), status);
	menubarPointer->Enable(XRCID("MI_RcaBasicSerial"), status);
	menubarPointer->Enable(XRCID("MI_RcaBasicPixie"), status);
	menubarPointer->Enable(XRCID("MI_RcaBasicElfOsInstall"), status);
	menubarPointer->Enable(XRCID("MI_Music"), status);
	menubarPointer->Enable(XRCID("MI_SuperGoldMonitor"), status);
	menubarPointer->Enable(XRCID("MI_MonitorBasic"), status);
	menubarPointer->Enable(XRCID("MI_FigForth"), status);
	menubarPointer->Enable(XRCID("MI_TinyBasicPixie"), status);
	menubarPointer->Enable(XRCID("MI_TinyBasicSerial"), status);
	menubarPointer->Enable(XRCID("MI_TinyBasic6847"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsInstallConfig"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsConfig"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsInstallConfig25"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsConfig25"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoInstallConfigPixie"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoConfigPixie"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoInstallConfig6845"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoConfig6845"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoInstallConfig6847"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoConfig6847"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoInstallConfigTms"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoConfigTms"), status);
}

void Main::enableGui(bool status)
{
	wxMenuBar *menubarPointer = GetMenuBar();

	menubarPointer->Enable(XRCID(GUIDEFAULT), status);

	if (runningComputer_ == COMX)
	{
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"EpromComx", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomComx", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ExpRomComx", wxComboBox)->Enable(status);
		XRCCTRL(*this,"ExpRomButtonComx", wxButton)->Enable(status);
		XRCCTRL(*this, "Cart1RomComx", wxComboBox)->Enable(status);
		XRCCTRL(*this, "Cart1RomButtonComx", wxButton)->Enable(status);
		if (expansionRomLoaded_)
		{
			XRCCTRL(*this,"Cart2RomComx", wxComboBox)->Enable(status);
			XRCCTRL(*this,"Cart2RomButtonComx", wxButton)->Enable(status);
			XRCCTRL(*this,"Cart3RomComx", wxComboBox)->Enable(status);
			XRCCTRL(*this,"Cart3RomButtonComx", wxButton)->Enable(status);
			XRCCTRL(*this,"Cart4RomComx", wxComboBox)->Enable(status);
			XRCCTRL(*this,"Cart4RomButtonComx", wxButton)->Enable(status);
		}
		XRCCTRL(*this,"VidModeComx", wxChoice)->Enable(status);
		XRCCTRL(*this,"VidModeTextComx", wxStaticText)->Enable(status);
		XRCCTRL(*this,"PrintButtonComx", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Comx", wxButton)->Enable(!status);
		XRCCTRL(*this,"FullScreenF3Comx", wxButton)->Enable(!status);
		XRCCTRL(*this,"ExpRamComx", wxCheckBox)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
		enableDiskRomGui(diskRomLoaded_);
		enableComxGui(status);
	}
	if (runningComputer_ == CIDELSA)
	{
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomCidelsa", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ScreenDumpF5Cidelsa", wxButton)->Enable(!status);
		XRCCTRL(*this,"FullScreenF3Cidelsa", wxButton)->Enable(!status);
	}
	if (runningComputer_ == TMC600)
	{
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"PrintButtonTmc600", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Tmc600", wxButton)->Enable(!status);
		XRCCTRL(*this,"FullScreenF3Tmc600", wxButton)->Enable(!status);
		XRCCTRL(*this,"MainRomTmc600", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ExpRomTmc600", wxComboBox)->Enable(status);
		XRCCTRL(*this,"ExpRomButtonTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"CharRomTmc600", wxComboBox)->Enable(status);
		XRCCTRL(*this,"CharRomButtonTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"RamTmc600", wxChoice)->Enable(status);
		XRCCTRL(*this,"RamTextTmc600", wxStaticText)->Enable(status);
		if (status == true)
		{
			XRCCTRL(*this,"AdiInputText", wxStaticText)->Enable(!status);
			XRCCTRL(*this,"AdiChannel", wxSpinCtrl)->Enable(!status);
			XRCCTRL(*this,"AdiVolt", wxSpinCtrl)->Enable(!status);
			XRCCTRL(*this,"AdiVoltText", wxStaticText)->Enable(!status);
			XRCCTRL(*this,"AdsInputText", wxStaticText)->Enable(!status);
			XRCCTRL(*this,"AdsChannel", wxSpinCtrl)->Enable(!status);
			XRCCTRL(*this,"AdsVolt", wxSpinCtrl)->Enable(!status);
			XRCCTRL(*this,"AdsVoltText", wxStaticText)->Enable(!status);
		}
		XRCCTRL(*this,"RealTimeClockTmc600", wxCheckBox)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == PECOM)
	{
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"PrintButtonPecom", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Pecom", wxButton)->Enable(!status);
		XRCCTRL(*this,"FullScreenF3Pecom", wxButton)->Enable(!status);
		XRCCTRL(*this,"MainRomPecom", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonPecom", wxButton)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == VIP)
	{
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
//		XRCCTRL(*this,"KeyMapVip", wxButton)->Enable(status&!getCheckBox("KeyboardVip"));
		XRCCTRL(*this,"HighResVip", wxCheckBox)->Enable(status);
		XRCCTRL(*this,"MainRomVip", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonVip", wxButton)->Enable(status);
		XRCCTRL(*this,"RamSWVip", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RamSWButtonVip", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWVip", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"Chip8SWButtonVip", wxButton)->Enable(status);
		XRCCTRL(*this,"EjectChip8SWVip", wxButton)->Enable(status);
		XRCCTRL(*this,"VP580",wxCheckBox)->Enable(status);
		XRCCTRL(*this,"VP590",wxCheckBox)->Enable(status);
		XRCCTRL(*this,"KeyboardVip",wxCheckBox)->Enable(status);
		XRCCTRL(*this,"SoundVip",wxChoice)->Enable(status);
		XRCCTRL(*this,"StereoVip",wxCheckBox)->Enable(status);
		XRCCTRL(*this,"FullScreenF3Vip", wxButton)->Enable(!status);
		XRCCTRL(*this,"RamVip", wxSpinCtrl)->Enable(status);
		XRCCTRL(*this,"RamTextVip", wxStaticText)->Enable(status);
		XRCCTRL(*this,"RamKbVip", wxStaticText)->Enable(status);
		XRCCTRL(*this,"VP570", wxSpinCtrl)->Enable(status);
		XRCCTRL(*this,"VP570Text", wxStaticText)->Enable(status);
		XRCCTRL(*this,"RamKbVip", wxStaticText)->Enable(status);
		if (!status)
		{
			XRCCTRL(*this,"PrintButtonVip", wxBitmapButton)->Enable(conf[VIP].printerOn_);
			XRCCTRL(*this,"PrintButtonVip", wxBitmapButton)->SetToolTip("Open printer window (F4)");
		}
		else
		{
			XRCCTRL(*this,"PrintButtonVip", wxBitmapButton)->Enable(true);
			if (conf[VIP].printerOn_)
				XRCCTRL(*this,"PrintButtonVip", wxBitmapButton)->SetToolTip("Disable printer support");
			else
				XRCCTRL(*this,"PrintButtonVip", wxBitmapButton)->SetToolTip("Enable printer support");
		}
		XRCCTRL(*this,"ScreenDumpF5Vip", wxButton)->Enable(!status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == STUDIO)
	{
//		XRCCTRL(*this,"KeyMapStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomStudio2", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"CartRomStudio2", wxComboBox)->Enable(status);
		XRCCTRL(*this,"CartRomButtonStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3Studio2", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Studio2", wxButton)->Enable(!status);
	}
	if (runningComputer_ == VISICOM)
	{
//		XRCCTRL(*this,"KeyMapVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomVisicom", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"CartRomVisicom", wxComboBox)->Enable(status);
		XRCCTRL(*this,"CartRomButtonVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3Visicom", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Visicom", wxButton)->Enable(!status);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
	}
	if (runningComputer_ == VICTORY)
	{
//		XRCCTRL(*this,"KeyMapVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomVictory", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"CartRomVictory", wxComboBox)->Enable(status);
		XRCCTRL(*this,"CartRomButtonVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3Victory", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Victory", wxButton)->Enable(!status);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
	}
	if (runningComputer_ == TMC2000)
	{
//		XRCCTRL(*this,"KeyMapTMC2000", wxButton)->Enable(status&!getCheckBox("KeyboardTMC2000"));
		XRCCTRL(*this,"MainRomTMC2000", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"RamSWTMC2000", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RamSWButtonTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWTMC2000", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"EjectChip8SWTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWButtonTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3TMC2000", wxButton)->Enable(!status);
		XRCCTRL(*this,"RamTMC2000", wxChoice)->Enable(status);
		XRCCTRL(*this,"RamTextTMC2000", wxStaticText)->Enable(status);
		XRCCTRL(*this,"ScreenDumpF5TMC2000", wxButton)->Enable(!status);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == TMC1800)
	{
//		XRCCTRL(*this,"KeyMapTMC1800", wxButton)->Enable(status&!getCheckBox("KeyboardTMC1800"));
		XRCCTRL(*this,"MainRomTMC1800", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"RamSWTMC1800", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RamSWButtonTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWTMC1800", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"EjectChip8SWTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWButtonTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3TMC1800", wxButton)->Enable(!status);
		XRCCTRL(*this,"RamTMC1800", wxChoice)->Enable(status);
		XRCCTRL(*this,"RamTextTMC1800", wxStaticText)->Enable(status);
		XRCCTRL(*this,"ScreenDumpF5TMC1800", wxButton)->Enable(!status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == ETI)
	{
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
//		XRCCTRL(*this,"KeyMapEti", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomEti", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonEti", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWEti", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"EjectChip8SWEti", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWButtonEti", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3Eti", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Eti", wxButton)->Enable(!status);
		XRCCTRL(*this,"RamEti", wxChoice)->Enable(status);
		XRCCTRL(*this,"RamTextEti", wxStaticText)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == NANO)
	{
//		XRCCTRL(*this,"KeyMapNano", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomNano", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonNano", wxButton)->Enable(status);
		XRCCTRL(*this,"RamSWNano", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RamSWButtonNano", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWNano", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"EjectChip8SWNano", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWButtonNano", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3Nano", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Nano", wxButton)->Enable(!status);
		XRCCTRL(*this,"SoundNano", wxChoice)->Enable(status);
		XRCCTRL(*this,"SoundTextNano", wxStaticText)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}

	if (runningComputer_ == ELF || runningComputer_ == ELFII || runningComputer_ == SUPERELF)
	{
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		wxString elfTypeStr;
		switch (runningComputer_)
		{
			case ELF:
				XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
				XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
				XRCCTRL(*this, "ShowAddressElf", wxTextCtrl)->Enable(status&elfConfiguration[ELF].useElfControlWindows);
				XRCCTRL(*this,"AddressText1Elf",wxStaticText)->Enable(status&elfConfiguration[ELF].useElfControlWindows);
				XRCCTRL(*this,"AddressText2Elf",wxStaticText)->Enable(status&elfConfiguration[ELF].useElfControlWindows);
				XRCCTRL(*this,"UseLedModule", wxCheckBox)->Enable(status);
				elfTypeStr = "Elf";
			break;
			case ELFII:
				XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
				XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
				elfTypeStr = "ElfII";
			break;
			case SUPERELF:
				XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
				XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
				XRCCTRL(*this, "ShowAddressSuperElf", wxTextCtrl)->Enable(status&elfConfiguration[SUPERELF].useElfControlWindows);
				XRCCTRL(*this,"AddressText1SuperElf",wxStaticText)->Enable(status&elfConfiguration[SUPERELF].useElfControlWindows);
				XRCCTRL(*this,"AddressText2SuperElf",wxStaticText)->Enable(status&elfConfiguration[SUPERELF].useElfControlWindows);
				elfTypeStr = "SuperElf";
			break;
		}
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
		enableElfConfig(status);
		XRCCTRL(*this,"Tape"+elfTypeStr, wxCheckBox)->Enable(status);
		XRCCTRL(*this,"MainRom"+elfTypeStr, wxComboBox)->Enable(status);
		XRCCTRL(*this,"MainRom2"+elfTypeStr, wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButton"+elfTypeStr, wxButton)->Enable(status);
		XRCCTRL(*this,"Rom1"+elfTypeStr, wxButton)->Enable(status);
		XRCCTRL(*this,"RomButton2"+elfTypeStr, wxButton)->Enable(status);
		XRCCTRL(*this,"Rom2"+elfTypeStr, wxButton)->Enable(status);
		XRCCTRL(*this,"DP_Button"+elfTypeStr, wxButton)->Enable(status);
//		XRCCTRL(*this,"KeyMap"+elfTypeStr, wxButton)->Enable(status&elfConfiguration[runningComputer_].useHexKeyboard);
		if (elfConfiguration[runningComputer_].ideEnabled)
		{
			XRCCTRL(*this,"IDE_Button"+elfTypeStr, wxButton)->Enable(status);
			XRCCTRL(*this,"IdeFile"+elfTypeStr, wxTextCtrl)->Enable(status);
			XRCCTRL(*this,"Eject_IDE"+elfTypeStr, wxButton)->Enable(status);
		}
		XRCCTRL(*this,"AutoBoot"+elfTypeStr, wxCheckBox)->Enable(status);
		XRCCTRL(*this,"BootAddress"+elfTypeStr, wxTextCtrl)->Enable(status);
		if (!status)
		{
			XRCCTRL(*this,"PrintButton"+elfTypeStr, wxBitmapButton)->Enable(conf[runningComputer_].printerOn_);
			XRCCTRL(*this,"PrintButton"+elfTypeStr, wxBitmapButton)->SetToolTip("Open printer window (F4)");
		}
		else
		{
			XRCCTRL(*this,"PrintButton"+elfTypeStr, wxBitmapButton)->Enable(true);
			if (conf[runningComputer_].printerOn_)
				XRCCTRL(*this,"PrintButton"+elfTypeStr, wxBitmapButton)->SetToolTip("Disable printer support");
			else
				XRCCTRL(*this,"PrintButton"+elfTypeStr, wxBitmapButton)->SetToolTip("Enable printer support");
		}
		XRCCTRL(*this,"CpuMode"+elfTypeStr, wxCheckBox)->Enable(status);
		XRCCTRL(*this,"Memory"+elfTypeStr, wxChoice)->Enable(status);
		XRCCTRL(*this,"MemoryText"+elfTypeStr,wxStaticText)->Enable(status);
		if (elfConfiguration[runningComputer_].usePager)
			XRCCTRL(*this,"PortExt"+elfTypeStr, wxCheckBox)->Enable(false);
		else
			XRCCTRL(*this,"PortExt"+elfTypeStr, wxCheckBox)->Enable(status);

		if (elfConfiguration[runningComputer_].usePager || elfConfiguration[runningComputer_].useEms)
		{
			XRCCTRL(*this, "StartRamText"+computerInfo[runningComputer_].gui, wxStaticText)->Enable(false);
			XRCCTRL(*this, "StartRam"+computerInfo[runningComputer_].gui, wxTextCtrl)->Enable(false);
			XRCCTRL(*this, "EndRamText"+computerInfo[runningComputer_].gui, wxStaticText)->Enable(false);
			XRCCTRL(*this, "EndRam"+computerInfo[runningComputer_].gui, wxTextCtrl)->Enable(false);
		}
		else
		{
			XRCCTRL(*this, "StartRamText"+computerInfo[runningComputer_].gui, wxStaticText)->Enable(status);
			XRCCTRL(*this, "StartRam"+computerInfo[runningComputer_].gui, wxTextCtrl)->Enable(status);
			XRCCTRL(*this, "EndRamText"+computerInfo[runningComputer_].gui, wxStaticText)->Enable(status);
			XRCCTRL(*this, "EndRam"+computerInfo[runningComputer_].gui, wxTextCtrl)->Enable(status);
		}
		XRCCTRL(*this,"VTType"+elfTypeStr,wxChoice)->Enable(status);
		if (XRCCTRL(*this,"VTType"+elfTypeStr,wxChoice)->GetSelection() != VTNONE)
		{
			if (elfConfiguration[runningComputer_].useUart)
			{
				baudTextR[runningComputer_]->Enable(status);
				baudChoiceR[runningComputer_]->Enable(status);
			}
			baudTextT[runningComputer_]->Enable(status);
			baudChoiceT[runningComputer_]->Enable(status);
			XRCCTRL(*this,"SerialLog"+elfTypeStr, wxCheckBox)->Enable(status);
			XRCCTRL(*this,"VtSetup"+elfTypeStr, wxButton)->Enable(status);
			XRCCTRL(*this, "Uart"+elfTypeStr, wxCheckBox)->Enable(status);
			XRCCTRL(*this,"VTText"+elfTypeStr,wxStaticText)->Enable(status);
		}
		XRCCTRL(*this,"VideoType"+elfTypeStr,wxChoice)->Enable(status);
		XRCCTRL(*this,"VideoTypeText"+elfTypeStr,wxStaticText)->Enable(status);
		XRCCTRL(*this,"DiskType"+elfTypeStr,wxChoice)->Enable(status);
//		XRCCTRL(*this,"DiskTypeText"+elfTypeStr,wxStaticText)->Enable(status);
		XRCCTRL(*this,"Keyboard"+elfTypeStr,wxChoice)->Enable(status);
		XRCCTRL(*this,"KeyboardText"+elfTypeStr,wxStaticText)->Enable(status);
		XRCCTRL(*this,"CharRomButton"+elfTypeStr, wxButton)->Enable(status&(elfConfiguration[runningComputer_].use6847||elfConfiguration[runningComputer_].use8275||elfConfiguration[runningComputer_].use6845||elfConfiguration[runningComputer_].useS100));
		XRCCTRL(*this,"VtCharRomButton"+elfTypeStr, wxButton)->Enable(status&(elfConfiguration[runningComputer_].vtType != VTNONE));
		XRCCTRL(*this,"VtCharRom"+elfTypeStr, wxComboBox)->Enable(elfConfiguration[runningComputer_].vtType != VTNONE);
		XRCCTRL(*this,"CharRom"+elfTypeStr, wxComboBox)->Enable(status&(elfConfiguration[runningComputer_].use6847||elfConfiguration[runningComputer_].use8275||elfConfiguration[runningComputer_].use6845||elfConfiguration[runningComputer_].useS100));
		XRCCTRL(*this,"FullScreenF3"+elfTypeStr, wxButton)->Enable(!status&(elfConfiguration[runningComputer_].usePixie||elfConfiguration[runningComputer_].useTMS9918||elfConfiguration[runningComputer_].use6847||elfConfiguration[runningComputer_].use6845||elfConfiguration[runningComputer_].use8275||elfConfiguration[runningComputer_].useS100||(elfConfiguration[runningComputer_].vtType != VTNONE)));
		XRCCTRL(*this,"ScreenDumpF5"+elfTypeStr, wxButton)->Enable(!status&(elfConfiguration[runningComputer_].usePixie||elfConfiguration[runningComputer_].useTMS9918||elfConfiguration[runningComputer_].use6847||elfConfiguration[runningComputer_].use6845||elfConfiguration[runningComputer_].use8275||elfConfiguration[runningComputer_].useS100||(elfConfiguration[runningComputer_].vtType != VTNONE)));
		enableMemAccessGui(!status);
	}
	if (runningComputer_ == ELF2K)
	{
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomElf2K", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"IDE_ButtonElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"IdeFileElf2K", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"Eject_IDEElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"Elf2KCpuMode",wxCheckBox)->Enable(status);
		XRCCTRL(*this,"Elf2KShowAddress",wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"Elf2KAddressText1",wxStaticText)->Enable(status);
		XRCCTRL(*this,"Elf2KAddressText2",wxStaticText)->Enable(status);
		XRCCTRL(*this,"DP_ButtonElf2K", wxButton)->Enable(status);
//		XRCCTRL(*this,"KeyMapElf2K", wxButton)->Enable(status&elfConfiguration[ELF2K].useHexKeyboardEf3);
		enableMemAccessGui(!status);
		if (!elfConfiguration[ELF2K].use8275)
		{
			XRCCTRL(*this, "VTTypeElf2K", wxChoice)->Enable(status);
			if (XRCCTRL(*this,"VTTypeElf2K",wxChoice)->GetSelection() != VTNONE)
			{
				if (elfConfiguration[ELF2K].useUart)
				{
					baudTextR[ELF2K]->Enable(status);
					baudChoiceR[ELF2K]->Enable(status);
				}
				baudTextT[ELF2K]->Enable(status);
				baudChoiceT[ELF2K]->Enable(status);
				XRCCTRL(*this, "VTTextElf2K", wxStaticText)->Enable(status);
				XRCCTRL(*this,"VtSetupElf2K", wxButton)->Enable(status);
				XRCCTRL(*this,"SerialLogElf2K", wxCheckBox)->Enable(status);
				XRCCTRL(*this,"UartElf2K", wxCheckBox)->Enable(status);
			}
		}
		XRCCTRL(*this,"Elf2KVideoType",wxChoice)->Enable(status);
		XRCCTRL(*this,"Elf2KVideoType_Text",wxStaticText)->Enable(status);
		XRCCTRL(*this,"Elf2KKeyboard",wxChoice)->Enable(status);
		XRCCTRL(*this,"Elf2KKeyboard_Text",wxStaticText)->Enable(status);
		XRCCTRL(*this,"CharRomButtonElf2K", wxButton)->Enable(status&elfConfiguration[ELF2K].use8275);
		XRCCTRL(*this,"VtCharRomButtonElf2K", wxButton)->Enable(status&(elfConfiguration[ELF2K].vtType != VTNONE));
		XRCCTRL(*this,"VtCharRomElf2K", wxComboBox)->Enable(status&(elfConfiguration[ELF2K].vtType != VTNONE));
		XRCCTRL(*this,"CharRomElf2K", wxComboBox)->Enable(status&elfConfiguration[ELF2K].use8275);
		XRCCTRL(*this,"FullScreenF3Elf2K", wxButton)->Enable(!status&(elfConfiguration[ELF2K].usePixie||elfConfiguration[ELF2K].use8275||(elfConfiguration[ELF2K].vtType != VTNONE)));
		XRCCTRL(*this,"ScreenDumpF5Elf2K", wxButton)->Enable(!status&(elfConfiguration[ELF2K].usePixie||elfConfiguration[ELF2K].use8275||(elfConfiguration[ELF2K].vtType != VTNONE)));
		XRCCTRL(*this,"Elf2KRtc", wxCheckBox)->Enable(status);
	}
	if (runningComputer_ == COSMICOS)
	{
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomCosmicos", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"CpuModeCosmicos",wxCheckBox)->Enable(status);
//		XRCCTRL(*this,"DP_ButtonCosmicos", wxButton)->Enable(status);
//		XRCCTRL(*this,"KeyMapCosmicos", wxButton)->Enable(status&elfConfiguration[COSMICOS].useHexKeyboardEf3);
		XRCCTRL(*this,"RamCosmicos", wxSpinCtrl)->Enable(status);
		XRCCTRL(*this,"RamTextCosmicos", wxStaticText)->Enable(status);
		XRCCTRL(*this,"RamKbCosmicos", wxStaticText)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
		enableMemAccessGui(!status);

		XRCCTRL(*this, "VTTypeCosmicos", wxChoice)->Enable(status);
		if (XRCCTRL(*this,"VTTypeCosmicos",wxChoice)->GetSelection() != VTNONE)
		{
			if (elfConfiguration[COSMICOS].useUart)
			{
				baudTextR[COSMICOS]->Enable(status);
				baudChoiceR[COSMICOS]->Enable(status);
			}
			baudTextT[COSMICOS]->Enable(status);
			baudChoiceT[COSMICOS]->Enable(status);
			XRCCTRL(*this, "VTTextCosmicos", wxStaticText)->Enable(status);
			XRCCTRL(*this,"SerialLogCosmicos", wxCheckBox)->Enable(status);
			XRCCTRL(*this,"VtSetupCosmicos", wxButton)->Enable(status);
			XRCCTRL(*this,"EfCosmicos", wxCheckBox)->Enable(status);
		}

		XRCCTRL(*this,"VideoTypeCosmicos",wxChoice)->Enable(status);
		XRCCTRL(*this,"VideoType_TextCosmicos",wxStaticText)->Enable(status);
		XRCCTRL(*this,"KeyboardCosmicos",wxChoice)->Enable(status);
		XRCCTRL(*this,"Keyboard_TextCosmicos",wxStaticText)->Enable(status);
		XRCCTRL(*this,"VtCharRomButtonCosmicos", wxButton)->Enable(status&(elfConfiguration[COSMICOS].vtType != VTNONE));
		XRCCTRL(*this,"VtCharRomCosmicos", wxComboBox)->Enable(status&(elfConfiguration[COSMICOS].vtType != VTNONE));
		XRCCTRL(*this,"FullScreenF3Cosmicos", wxButton)->Enable(!status&(elfConfiguration[COSMICOS].usePixie||(elfConfiguration[COSMICOS].vtType != VTNONE)));
		XRCCTRL(*this,"ScreenDumpF5Cosmicos", wxButton)->Enable(!status&(elfConfiguration[COSMICOS].usePixie||(elfConfiguration[COSMICOS].vtType != VTNONE)));
	}
	enableDebugGui(!status);
	enableStartButtonGui(status);
}

void Main::message(wxString buffer)
{
	XRCCTRL(*this,"Message_Window",wxTextCtrl)->AppendText(buffer);
	XRCCTRL(*this,"Message_Window",wxTextCtrl)->AppendText("\n");
}

void Main::messageInt(int value)
{
	wxString buffer;

	buffer.Printf("%d", value);
	XRCCTRL(*this,"Message_Window",wxTextCtrl)->AppendText(buffer);
	XRCCTRL(*this,"Message_Window",wxTextCtrl)->AppendText("\n");
}

void Main::messageHex(int value)
{
	wxString buffer;

	buffer.Printf("%04X", value);
	XRCCTRL(*this,"Message_Window",wxTextCtrl)->AppendText(buffer);
	XRCCTRL(*this,"Message_Window",wxTextCtrl)->AppendText("\n");
}

wxString Main::getApplicationDir()
{
	return applicationDirectory_;
}

wxChar Main::getPathSep()
{
	return pathSeparator_;
}

int Main::setFdcStepRate(int rate)
{
	switch(rate)
	{
		case 0: return conf[runningComputer_].fdcCpms_ * 6;
		case 1: return conf[runningComputer_].fdcCpms_ * 12;
		case 2: return conf[runningComputer_].fdcCpms_ * 20;
		case 3: return conf[runningComputer_].fdcCpms_ * 30;
	}
	return conf[runningComputer_].fdcCpms_ * 12;
}

int Main::getPsaveData(int item)
{
	return psaveData_[item];
}

void Main::setPsaveData(int item, int data)
{
	psaveData_[item] = data;
	if (computerRunning_)
		p_Computer->setPsaveSettings();
}

void Main::vuTimeout(wxTimerEvent&WXUNUSED(event))
{
	switch (runningComputer_)
	{
		case COMX:
		case VIP: 
		case COSMICOS: 
		case ELF: 
		case ELFII:
		case SUPERELF:
		case TMC600:
		case TMC1800:
		case TMC2000:
		case PECOM:
		case ETI:
		case NANO:
			vuSet("Vu"+computerInfo[runningComputer_].gui, p_Computer->getGaugeValue());
		break;
	}
}

void Main::vuSet(wxString item, int gaugeValue)
{
	if (gaugeValue == oldGauge_)
		return;

	oldGauge_ = gaugeValue;

	wxBitmap vu(100, VU_HI, 24);
	wxMemoryDC dcVu;

	dcVu.SelectObject(vu);
	dcVu.SetPen(wxPen(wxColour(0, 0xc0, 0)));
	dcVu.SetBrush(wxBrush(wxColour(0, 0xc0, 0)));

	int gaugeGreen = gaugeValue / 100;
	if (gaugeGreen > VU_RED)  gaugeGreen = VU_RED;
	dcVu.DrawRectangle(0, 0, gaugeGreen, VU_HI);

	if (gaugeGreen < VU_RED)
	{
		dcVu.SetPen(wxPen(wxColour(0, 0x22, 0)));
		dcVu.SetBrush(wxBrush(wxColour(0, 0x22, 0)));
		dcVu.DrawRectangle(gaugeGreen, 0, VU_RED-gaugeGreen, VU_HI);
	}

	dcVu.SetPen(wxPen(wxColour(0xc0, 0, 0)));
	dcVu.SetBrush(wxBrush(wxColour(0xc0, 0, 0)));

	int gaugeRed = gaugeValue / 100;
	if (gaugeRed > VU_MAX)  gaugeRed = VU_MAX;
	if (gaugeRed < VU_RED)  gaugeRed = VU_RED;
	dcVu.DrawRectangle(VU_RED, 0, gaugeRed-VU_RED, VU_HI);

	if (gaugeRed < VU_MAX)
	{
		dcVu.SetPen(wxPen(wxColour(0x22, 0, 0)));
		dcVu.SetBrush(wxBrush(wxColour(0x22, 0, 0)));
		dcVu.DrawRectangle(gaugeRed, 0, VU_MAX-gaugeRed, VU_HI);
	}
	dcVu.SelectObject(wxNullBitmap);
	XRCCTRL(*this, item, wxStaticBitmap)->SetBitmap(vu);
}

void Main::errorMessageEvent(wxErrorMsgEvent&event)
{
    wxString message = event.GetMsg();
	(void)wxMessageBox( message,
					    "Emma 02", wxICON_ERROR | wxOK );
}

void Main::errorMessage(wxString msg)
{
    wxErrorMsgEvent event( wxEVT_ERROR_MSG, GetId() );
    event.SetEventObject( p_Main );
    event.SetMsg( msg );
	GetEventHandler()->AddPendingEvent( event );
}

wxErrorMsgEvent::wxErrorMsgEvent( wxEventType commandType, int id )
: wxNotifyEvent( commandType, id )
{
    message = "";
}

void Main::ReparentAllStaticBoxItemsInWindow(wxWindow *window)
{
  std::vector<wxWindow*> staticboxes;
  GetAllWindowChildrenOfClass(window, CLASSINFO(wxStaticBox), staticboxes);
  for(size_t i=0; i < staticboxes.size(); i++)
  {
    wxStaticBox *staticbox=(wxStaticBox*)staticboxes[i];
    ReparentStaticBoxItems(staticbox);
  }
}

void Main::GetAllWindowChildrenOfClass(wxWindow *window, const wxClassInfo *classinfo, std::vector<wxWindow*> &items)
{
  if(window->IsKindOf(classinfo))
  {
    items.push_back(window);
  }
  const wxWindowList& children=window->GetChildren();
  size_t numchildren=children.GetCount();
  for(size_t i=0; i < numchildren; i++)
  {
    wxWindow *child=(wxWindow*)children[i];
    if(!child->IsTopLevel())
    {
      GetAllWindowChildrenOfClass(child, classinfo, items);
    }
  }
}

void Main::ReparentStaticBoxItems(wxStaticBox *staticbox)
{
#ifdef __WXMSW__
  wxSizer *sizer=staticbox->GetContainingSizer();
  ReparentStaticBoxItems2(staticbox, sizer);
#endif
}

void Main::ReparentStaticBoxItems2(wxStaticBox *staticbox, wxSizer *sizer)
{
  wxWindow *staticboxparent=staticbox->GetParent();
  size_t numitems=sizer->GetItemCount();
  for(size_t i=0; i < numitems; i++)
  {
    wxSizerItem *item=sizer->GetItem(i);
    if(item->IsWindow())
    {
      wxWindow *window=item->GetWindow();
      if(window->GetParent() == staticboxparent)
      {
        window->Reparent(staticbox);       
      }
    }
    else if(item->IsSizer())
    {
      wxSizer *childsizer=item->GetSizer();
      ReparentStaticBoxItems2(staticbox, childsizer);
    }
  }
}

void Main::loadKeyDefinition(wxString findFile1, wxString findFile2, int hexKeysA[], int hexKeysB[])
{
	wxTextFile keyDefinitionFile;
	wxString gameName;

	bool valid1 = true;
	bool valid2 = true;
	if (findFile1 == "")
		valid1 = false;
	if (findFile2 == "")
		valid2 = false;
	if (keyDefinitionFile.Open(dataDir_ + "keydefinition.txt"))
	{
		for (gameName=keyDefinitionFile.GetFirstLine(); !keyDefinitionFile.Eof(); gameName=keyDefinitionFile.GetNextLine())
		{
			if (((gameName == findFile1) && valid1) || ((gameName == findFile2) && valid2))
			{
				if (keyDefinitionFile.Eof())
					return;
				wxString HexKeyValues=keyDefinitionFile.GetNextLine();
				if (HexKeyValues.BeforeFirst(':') != "Hex_keys")
					return;
				HexKeyValues = HexKeyValues.AfterFirst(':');

				wxString nextValue = HexKeyValues.BeforeFirst(',');
				long value;
				int i=0;
				while (nextValue.ToLong(&value, 16) && i<10)
				{
					if (value <17)
					{
						if (i < 5)
							hexKeysA[i] = value;
						else
							hexKeysB[i-5] = value;
					}
					i++;
					HexKeyValues = HexKeyValues.AfterFirst(',');
					nextValue = HexKeyValues.BeforeFirst(',');
				}
/*				if (keyDefinitionFile.Eof())
					return;
				wxString PCKeyValues=keyDefinitionFile.GetNextLine();
				if (PCKeyValues.BeforeFirst(':') != "PC_keys")
					return;
				PCKeyValues = PCKeyValues.AfterFirst(':');

				nextValue = PCKeyValues.BeforeFirst(',');
				i=0;
				while (nextValue.ToLong(&value, 10) && i<10)
				{
					if (i < 5)
						pcKeysA[i] = value;
					else
						pcKeysB[i-5] = value;
					i++;
					PCKeyValues = PCKeyValues.AfterFirst(',');
					nextValue = PCKeyValues.BeforeFirst(',');
				}
				return;*/
			}
		}
	}
}

void Main::getDefaultGameKeys(wxString computerStr, wxString player, int keysValue[], int keysHex[])
{
	if (player == "A")
	{
		keysValue[HEX_UP] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Up", WXK_UP);
		keysValue[HEX_LEFT] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Left", WXK_LEFT);
		keysValue[HEX_RIGHT] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Right", WXK_RIGHT);
		keysValue[HEX_DOWN] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Down", WXK_DOWN);
		keysValue[HEX_FIRE] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Fire", WXK_SPACE);

		keysHex[HEX_UP] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Up", 2);
		keysHex[HEX_LEFT] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Left", 4);
		keysHex[HEX_RIGHT] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Right", 6);
		keysHex[HEX_DOWN] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Down", 8);
		keysHex[HEX_FIRE] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Fire", 5);
	}
	else
	{
		keysValue[HEX_UP] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Up", WXK_NUMPAD_UP);
		keysValue[HEX_LEFT] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Left", WXK_NUMPAD_LEFT);
		keysValue[HEX_RIGHT] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Right", WXK_NUMPAD_RIGHT);
		keysValue[HEX_DOWN] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Down", WXK_NUMPAD_DOWN);
		keysValue[HEX_FIRE] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Fire", WXK_NUMPAD_ENTER );

		keysHex[HEX_UP] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Up", 0xc);
		keysHex[HEX_LEFT] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Left", 7);
		keysHex[HEX_RIGHT] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Right", 9);
		keysHex[HEX_DOWN] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Down", 0xd);
		keysHex[HEX_FIRE] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Fire", 0l);
	}

}

void Main::storeDefaultGameKeys(wxString computerStr, wxString player, int keysValue[], int keysHex[])
{
	configPointer->Write(computerStr+"/KeyGameValue"+player+"Up", keysValue[HEX_UP]);
	configPointer->Write(computerStr+"/KeyGameValue"+player+"Left", keysValue[HEX_LEFT]);
	configPointer->Write(computerStr+"/KeyGameValue"+player+"Right", keysValue[HEX_RIGHT]);
	configPointer->Write(computerStr+"/KeyGameValue"+player+"Down", keysValue[HEX_DOWN]);
	configPointer->Write(computerStr+"/KeyGameValue"+player+"Fire", keysValue[HEX_FIRE]);

	configPointer->Write(computerStr+"/KeyGameHex"+player+"Up", keysHex[HEX_UP]);
	configPointer->Write(computerStr+"/KeyGameHex"+player+"Left", keysHex[HEX_LEFT]);
	configPointer->Write(computerStr+"/KeyGameHex"+player+"Right", keysHex[HEX_RIGHT]);
	configPointer->Write(computerStr+"/KeyGameHex"+player+"Down", keysHex[HEX_DOWN]);
	configPointer->Write(computerStr+"/KeyGameHex"+player+"Fire", keysHex[HEX_FIRE]);
}

void Main::getDefaultHexKeys(wxString computerStr, wxString player, int keysHex[])
{
	if (player == "A")
	{
		keysHex[0] = configPointer->Read(computerStr+"/HexKeyA0", 48);
		keysHex[1] = configPointer->Read(computerStr+"/HexKeyA1", 49);
		keysHex[2] = configPointer->Read(computerStr+"/HexKeyA2", 50);
		keysHex[3] = configPointer->Read(computerStr+"/HexKeyA3", 51);
		keysHex[4] = configPointer->Read(computerStr+"/HexKeyA4", 52);
		keysHex[5] = configPointer->Read(computerStr+"/HexKeyA5", 53);
		keysHex[6] = configPointer->Read(computerStr+"/HexKeyA6", 54);
		keysHex[7] = configPointer->Read(computerStr+"/HexKeyA7", 55);
		keysHex[8] = configPointer->Read(computerStr+"/HexKeyA8", 56);
		keysHex[9] = configPointer->Read(computerStr+"/HexKeyA9", 57);
		keysHex[10] = configPointer->Read(computerStr+"/HexKeyAA", 65);
		keysHex[11] = configPointer->Read(computerStr+"/HexKeyAB", 66);
		keysHex[12] = configPointer->Read(computerStr+"/HexKeyAC", 67);
		keysHex[13] = configPointer->Read(computerStr+"/HexKeyAD", 68);
		keysHex[14] = configPointer->Read(computerStr+"/HexKeyAE", 69);
		keysHex[15] = configPointer->Read(computerStr+"/HexKeyAF", 70);
	}
	else
	{
		keysHex[0] = configPointer->Read(computerStr+"/HexKeyB0", WXK_NUMPAD0);
		keysHex[1] = configPointer->Read(computerStr+"/HexKeyB1", WXK_NUMPAD1);
		keysHex[2] = configPointer->Read(computerStr+"/HexKeyB2", WXK_NUMPAD2);
		keysHex[3] = configPointer->Read(computerStr+"/HexKeyB3", WXK_NUMPAD3);
		keysHex[4] = configPointer->Read(computerStr+"/HexKeyB4", WXK_NUMPAD4);
		keysHex[5] = configPointer->Read(computerStr+"/HexKeyB5", WXK_NUMPAD5);
		keysHex[6] = configPointer->Read(computerStr+"/HexKeyB6", WXK_NUMPAD6);
		keysHex[7] = configPointer->Read(computerStr+"/HexKeyB7", WXK_NUMPAD7);
		keysHex[8] = configPointer->Read(computerStr+"/HexKeyB8", WXK_NUMPAD8);
		keysHex[9] = configPointer->Read(computerStr+"/HexKeyB9", WXK_NUMPAD9);
		keysHex[10] = configPointer->Read(computerStr+"/HexKeyBA", WXK_HOME);
		keysHex[11] = configPointer->Read(computerStr+"/HexKeyBB", WXK_END);
		keysHex[12] = configPointer->Read(computerStr+"/HexKeyBC", WXK_PAGEUP);
		keysHex[13] = configPointer->Read(computerStr+"/HexKeyBD", WXK_PAGEDOWN);
		keysHex[14] = configPointer->Read(computerStr+"/HexKeyBE", WXK_NUMPAD_DIVIDE);
		keysHex[15] = configPointer->Read(computerStr+"/HexKeyBF", WXK_NUMPAD_MULTIPLY);
	}
}

