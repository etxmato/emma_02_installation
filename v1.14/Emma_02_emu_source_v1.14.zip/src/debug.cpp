/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

/*
 *******************************************************************
 *** This software is copyright 2006 by Michael H Riley          ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/textfile.h"
#include "wx/tglbtn.h"
#include "wx/listbox.h"

#include "main.h"
#include "debug.h"
#include "elfconfiguration.h"
#include "breakpoints.h"

int opCode[] =
{
	0x74, 0x7c, 0xf4, 0xfc, 0xf2, 0xfa, // A
	0x34, 0x35, 0x36, 0x37, 0x33, 0x3c, 0x3d, 0x3e, 0x3f, 0x3b, 0x39, 0x3a, 0x31, 0x30, 0x32, // B
	0x20, 0x71, // D
	0x90, 0x80, // G
	0x00, 0x10, 0x69, 0x60, // I
	0xc3, 0xcb, 0xc9, 0xca, 0xc1, 0xc0, 0xc2, 0x40, 0xf8, 0x00, 0xf0, 0x72, 0xcf, 0xcc, 0xc8, 0xc7, 0xc5, 0xc6, 0xcd, 0xce, // L
	0x79, // M
	0x38, 0xc8, 0xc4, // N
	0xf1, 0xf9, 0x61, // O
	0xb0, 0xa0, // P
	0x7a, 0x70, // R
	0x78, 0xf5, 0x75, 0x7d, 0xfd, 0xd0, 0x7b, 0xe0, 0xfe, 0x7e, 0xf6, 0x76, 0x38, 0xf7, 0x77, 0x7f, 0xff, 0x50, 0x73, // S
	0xf3, 0xfb // X
};

int numberOfBytes[] =
{
	1, 2, 1, 2, 1, 2,
	2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
	1, 1,
	1, 1,
	1, 1, 2, 1,
	3, 3, 3, 3, 3, 3, 3 , 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 , 1,
	1,
	1, 1, 1,
	1, 2, 2,
	1, 1,
	1, 1,
	1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1,
	1, 2
};

bool useRegister[] =
{
	false, false, false, false, false, false,
	false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
	true, false,
	true, true,
	false, true, false, false,
	false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, false, false, false, false,
	false,
	false, false, false,
	false, false, false,
	true, true,
	false, false,
	false, false, false, false, false, true, false, true, false, false, false, false, false, false, false, false, false, true, false,
	false, false,
};

BEGIN_EVENT_TABLE(DebugWindow, GuiComx)

	EVT_CHECKBOX(XRCID("DebugMode"), Main::onDebugMode)
	EVT_TEXT_ENTER(XRCID("InputWindow"), DebugWindow::onEnter)

	EVT_BUTTON(XRCID("TraceLog"), DebugWindow::onLog)
	EVT_TOGGLEBUTTON(XRCID("TraceButton"), DebugWindow::onTrace)
	EVT_TOGGLEBUTTON(XRCID("DmaButton"), DebugWindow::onTraceDma)
	EVT_TOGGLEBUTTON(XRCID("IntButton"), DebugWindow::onTraceInt)
	EVT_LISTBOX(XRCID("InpList"), DebugWindow::onTraceInp)
	EVT_LISTBOX(XRCID("OutList"), DebugWindow::onTraceOut)

	EVT_TOGGLEBUTTON(XRCID("DButton"), DebugWindow::onShowD)
	EVT_TOGGLEBUTTON(XRCID("PButton"), DebugWindow::onShowP)
	EVT_TOGGLEBUTTON(XRCID("XButton"), DebugWindow::onShowX)
	EVT_TOGGLEBUTTON(XRCID("TButton"), DebugWindow::onShowT)
	EVT_TOGGLEBUTTON(XRCID("FlagButton"), DebugWindow::onShowFlag)
	EVT_TOGGLEBUTTON(XRCID("IoButton"), DebugWindow::onShowIo)
	EVT_TOGGLEBUTTON(XRCID("RegisterButton"), DebugWindow::onShowReg)

	EVT_BUTTON(XRCID("DebugInterrupt"), DebugWindow::onInt)

	EVT_BUTTON(XRCID("DebugPauseButton"), DebugWindow::onPauseButton)
	EVT_BUTTON(XRCID("DebugStepButton"), DebugWindow::onStepButton)
	EVT_BUTTON(XRCID("DebugRunButton"), DebugWindow::onRunButton)
	EVT_TEXT(XRCID("DebugRunAddress"), DebugWindow::onRunAddress)
	EVT_TEXT(XRCID("BreakPointAddress"), DebugWindow::onBreakPointAddress)
	EVT_TEXT(XRCID("TregValue"), DebugWindow::onTregValue)
	EVT_TEXT(XRCID("TrapValue"), DebugWindow::onTrapValue)

	EVT_BUTTON(XRCID("BreakPointSet"), DebugWindow::onBreakPointSet)
	EVT_BUTTON(XRCID("TregSet"), DebugWindow::onTregSet)
	EVT_CHOICE(XRCID("TrapCommand"), DebugWindow::onTrapCommand)
	EVT_BUTTON(XRCID("TrapSet"), DebugWindow::onTrapSet)

	EVT_LIST_DELETE_ITEM(XRCID("BreakPointWindow"), DebugWindow::deleteBreakPoint)
	EVT_LIST_DELETE_ITEM(XRCID("TregWindow"), DebugWindow::deleteTreg)
	EVT_LIST_DELETE_ITEM(XRCID("TrapWindow"), DebugWindow::deleteTrap)
	EVT_LIST_END_LABEL_EDIT(XRCID("BreakPointWindow"), DebugWindow::editBreakPoint)
	EVT_LIST_END_LABEL_EDIT(XRCID("TregWindow"), DebugWindow::editTreg)
	EVT_LIST_END_LABEL_EDIT(XRCID("TrapWindow"), DebugWindow::editTrap)

	EVT_TEXT_ENTER(XRCID("O1"), DebugWindow::O1)
	EVT_TEXT_ENTER(XRCID("O2"), DebugWindow::O2)
	EVT_TEXT_ENTER(XRCID("O3"), DebugWindow::O3)
	EVT_TEXT_ENTER(XRCID("O4"), DebugWindow::O4)
	EVT_TEXT_ENTER(XRCID("O5"), DebugWindow::O5)
	EVT_TEXT_ENTER(XRCID("O6"), DebugWindow::O6)
	EVT_TEXT_ENTER(XRCID("O7"), DebugWindow::O7)

	EVT_TEXT_ENTER(XRCID("D"), DebugWindow::D)
	EVT_TEXT_ENTER(XRCID("P"), DebugWindow::P)
	EVT_TEXT_ENTER(XRCID("X"), DebugWindow::X)
	EVT_TEXT_ENTER(XRCID("T"), DebugWindow::T)
	EVT_TEXT_ENTER(XRCID("DF"), DebugWindow::DF)
	EVT_TEXT_ENTER(XRCID("Q"), DebugWindow::Q)
	EVT_TEXT_ENTER(XRCID("IE"), DebugWindow::IE)

	EVT_TEXT_ENTER(XRCID("R0"), DebugWindow::R0)
	EVT_TEXT_ENTER(XRCID("R1"), DebugWindow::R1)
	EVT_TEXT_ENTER(XRCID("R2"), DebugWindow::R2)
	EVT_TEXT_ENTER(XRCID("R3"), DebugWindow::R3)
	EVT_TEXT_ENTER(XRCID("R4"), DebugWindow::R4)
	EVT_TEXT_ENTER(XRCID("R5"), DebugWindow::R5)
	EVT_TEXT_ENTER(XRCID("R6"), DebugWindow::R6)
	EVT_TEXT_ENTER(XRCID("R7"), DebugWindow::R7)
	EVT_TEXT_ENTER(XRCID("R8"), DebugWindow::R8)
	EVT_TEXT_ENTER(XRCID("R9"), DebugWindow::R9)
	EVT_TEXT_ENTER(XRCID("R10"), DebugWindow::RA)
	EVT_TEXT_ENTER(XRCID("R11"), DebugWindow::RB)
	EVT_TEXT_ENTER(XRCID("R12"), DebugWindow::RC)
	EVT_TEXT_ENTER(XRCID("R13"), DebugWindow::RD)
	EVT_TEXT_ENTER(XRCID("R14"), DebugWindow::RE)
	EVT_TEXT_ENTER(XRCID("R15"), DebugWindow::RF)

	EVT_TEXT(XRCID("DebugDisplayPage"), DebugWindow::onDebugDisplayPage)
	EVT_TEXT_ENTER(XRCID("DebugDisplayPage"), DebugWindow::onDebugDisplayPage)
	EVT_SPIN_UP(XRCID("DebugDisplayPageSpin"), DebugWindow::onDebugDisplayPageSpinUp)
	EVT_SPIN_DOWN(XRCID("DebugDisplayPageSpin"), DebugWindow::onDebugDisplayPageSpinDown)
	EVT_CHOICE(XRCID("DebugMemType"), DebugWindow::onDebugMemType)
	EVT_SPINCTRL(XRCID("DebugExpansionSlot"), DebugWindow::onDebugExpansionSlot)
	EVT_SPINCTRL(XRCID("DebugExpansionRam"), DebugWindow::onDebugExpansionRam)
	EVT_SPINCTRL(XRCID("DebugExpansionEprom"), DebugWindow::onDebugExpansionEprom)
	EVT_SPINCTRL(XRCID("DebugEmsPage"), DebugWindow::onDebugEmsPage)
	EVT_SPINCTRL(XRCID("DebugPager"), DebugWindow::onDebugPager)
	EVT_SPINCTRL(XRCID("DebugPortExtender"), DebugWindow::onDebugPortExtender)
	EVT_BUTTON(XRCID("DebugSave"), DebugWindow::onDebugSaveDump)
	EVT_BUTTON(XRCID("DebugCopy"), DebugWindow::onDebugCopy)
	EVT_BUTTON(XRCID("DebugDis"), DebugWindow::onDebugDis)
	EVT_BUTTON(XRCID("DebugDisLog"), DebugWindow::onDebugDisLog)
	EVT_TEXT(XRCID("DebugDisStart"), DebugWindow::onDebugDisStart)
	EVT_TEXT(XRCID("DebugDisEnd"), DebugWindow::onDebugDisEnd)
	EVT_TEXT(XRCID("DebugAssemblerAddress"), DebugWindow::onDebugAssemblerAddress)
	EVT_TEXT(XRCID("DebugCopyStart"), DebugWindow::onDebugCopyStart)
	EVT_TEXT(XRCID("DebugCopyEnd"), DebugWindow::onDebugCopyEnd)
	EVT_TEXT(XRCID("DebugCopyTo"), DebugWindow::onDebugCopyTo)

	EVT_TEXT(wxXmlResource::GetXRCID("MEM00", 0x1000), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM01", 0x1001), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM02", 0x1002), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM03", 0x1003), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM04", 0x1004), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM05", 0x1005), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM06", 0x1006), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM07", 0x1007), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM08", 0x1008), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM09", 0x1009), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM0A", 0x100A), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM0B", 0x100B), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM0C", 0x100C), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM0D", 0x100D), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM0E", 0x100E), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM0F", 0x100F), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEM10", 0x1010), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM11", 0x1011), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM12", 0x1012), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM13", 0x1013), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM14", 0x1014), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM15", 0x1015), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM16", 0x1016), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM17", 0x1017), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM18", 0x1018), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM19", 0x1019), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM1A", 0x101A), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM1B", 0x101B), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM1C", 0x101C), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM1D", 0x101D), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM1E", 0x101E), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM1F", 0x101F), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEM20", 0x1020), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM21", 0x1021), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM22", 0x1022), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM23", 0x1023), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM24", 0x1024), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM25", 0x1025), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM26", 0x1026), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM27", 0x1027), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM28", 0x1028), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM29", 0x1029), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM2A", 0x102A), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM2B", 0x102B), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM2C", 0x102C), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM2D", 0x102D), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM2E", 0x102E), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM2F", 0x102F), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEM30", 0x1030), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM31", 0x1031), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM32", 0x1032), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM33", 0x1033), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM34", 0x1034), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM35", 0x1035), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM36", 0x1036), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM37", 0x1037), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM38", 0x1038), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM39", 0x1039), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM3A", 0x103A), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM3B", 0x103B), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM3C", 0x103C), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM3D", 0x103D), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM3E", 0x103E), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM3F", 0x103F), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEM40", 0x1040), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM41", 0x1041), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM42", 0x1042), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM43", 0x1043), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM44", 0x1044), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM45", 0x1045), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM46", 0x1046), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM47", 0x1047), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM48", 0x1048), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM49", 0x1049), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM4A", 0x104A), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM4B", 0x104B), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM4C", 0x104C), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM4D", 0x104D), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM4E", 0x104E), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM4F", 0x104F), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEM50", 0x1050), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM51", 0x1051), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM52", 0x1052), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM53", 0x1053), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM54", 0x1054), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM55", 0x1055), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM56", 0x1056), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM57", 0x1057), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM58", 0x1058), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM59", 0x1059), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM5A", 0x105A), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM5B", 0x105B), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM5C", 0x105C), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM5D", 0x105D), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM5E", 0x105E), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM5F", 0x105F), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEM60", 0x1060), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM61", 0x1061), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM62", 0x1062), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM63", 0x1063), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM64", 0x1064), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM65", 0x1065), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM66", 0x1066), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM67", 0x1067), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM68", 0x1068), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM69", 0x1069), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM6A", 0x106A), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM6B", 0x106B), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM6C", 0x106C), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM6D", 0x106D), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM6E", 0x106E), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM6F", 0x106F), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEM70", 0x1070), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM71", 0x1071), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM72", 0x1072), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM73", 0x1073), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM74", 0x1074), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM75", 0x1075), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM76", 0x1076), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM77", 0x1077), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM78", 0x1078), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM79", 0x1079), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM7A", 0x107A), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM7B", 0x107B), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM7C", 0x107C), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM7D", 0x107D), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM7E", 0x107E), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM7F", 0x107F), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEM80", 0x1080), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM81", 0x1081), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM82", 0x1082), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM83", 0x1083), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM84", 0x1084), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM85", 0x1085), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM86", 0x1086), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM87", 0x1087), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM88", 0x1088), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM89", 0x1089), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM8A", 0x108A), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM8B", 0x108B), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM8C", 0x108C), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM8D", 0x108D), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM8E", 0x108E), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM8F", 0x108F), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEM90", 0x1090), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM91", 0x1091), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM92", 0x1092), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM93", 0x1093), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM94", 0x1094), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM95", 0x1095), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM96", 0x1096), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM97", 0x1097), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM98", 0x1098), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM99", 0x1099), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM9A", 0x109A), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM9B", 0x109B), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM9C", 0x109C), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM9D", 0x109D), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM9E", 0x109E), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEM9F", 0x109F), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEMA0", 0x10A0), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMA1", 0x10A1), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMA2", 0x10A2), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMA3", 0x10A3), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMA4", 0x10A4), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMA5", 0x10A5), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMA6", 0x10A6), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMA7", 0x10A7), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMA8", 0x10A8), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMA9", 0x10A9), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMAA", 0x10AA), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMAB", 0x10AB), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMAC", 0x10AC), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMAD", 0x10AD), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMAE", 0x10AE), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMAF", 0x10AF), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEMB0", 0x10B0), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMB1", 0x10B1), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMB2", 0x10B2), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMB3", 0x10B3), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMB4", 0x10B4), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMB5", 0x10B5), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMB6", 0x10B6), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMB7", 0x10B7), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMB8", 0x10B8), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMB9", 0x10B9), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMBA", 0x10BA), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMBB", 0x10BB), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMBC", 0x10BC), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMBD", 0x10BD), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMBE", 0x10BE), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMBF", 0x10BF), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEMC0", 0x10C0), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMC1", 0x10C1), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMC2", 0x10C2), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMC3", 0x10C3), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMC4", 0x10C4), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMC5", 0x10C5), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMC6", 0x10C6), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMC7", 0x10C7), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMC8", 0x10C8), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMC9", 0x10C9), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMCA", 0x10CA), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMCB", 0x10CB), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMCC", 0x10CC), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMCD", 0x10CD), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMCE", 0x10CE), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMCF", 0x10CF), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEMD0", 0x10D0), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMD1", 0x10D1), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMD2", 0x10D2), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMD3", 0x10D3), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMD4", 0x10D4), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMD5", 0x10D5), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMD6", 0x10D6), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMD7", 0x10D7), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMD8", 0x10D8), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMD9", 0x10D9), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMDA", 0x10DA), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMDB", 0x10DB), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMDC", 0x10DC), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMDD", 0x10DD), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMDE", 0x10DE), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMDF", 0x10DF), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEME0", 0x10E0), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEME1", 0x10E1), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEME2", 0x10E2), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEME3", 0x10E3), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEME4", 0x10E4), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEME5", 0x10E5), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEME6", 0x10E6), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEME7", 0x10E7), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEME8", 0x10E8), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEME9", 0x10E9), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMEA", 0x10EA), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMEB", 0x10EB), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMEC", 0x10EC), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMED", 0x10ED), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMEE", 0x10EE), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMEF", 0x10EF), DebugWindow::onEditMemory)

	EVT_TEXT(wxXmlResource::GetXRCID("MEMF0", 0x10F0), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMF1", 0x10F1), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMF2", 0x10F2), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMF3", 0x10F3), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMF4", 0x10F4), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMF5", 0x10F5), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMF6", 0x10F6), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMF7", 0x10F7), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMF8", 0x10F8), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMF9", 0x10F9), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMFA", 0x10FA), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMFB", 0x10FB), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMFC", 0x10FC), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMFD", 0x10FD), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMFE", 0x10FE), DebugWindow::onEditMemory)
	EVT_TEXT(wxXmlResource::GetXRCID("MEMFF", 0x10FF), DebugWindow::onEditMemory)

	EVT_CHECKBOX(XRCID(GUIPROTECTEDMODE), DebugWindow::onProtectedMode)

END_EVENT_TABLE()

DebugWindow::DebugWindow(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiComx(title, pos, size)
{
	numberOfBreakPoints_ = 0;
	numberOfTraps_ = 0;
	numberOfTregs_ = 0;
	debugMode_ = false;
	protectedMode_ = true;
	traceDma_ = false;
	traceInt_ = false;
	traceRegisters_ = false;
	traceFlags_ = false;
	traceD_ = false;
	traceP_ = false;
	traceX_ = false;
	traceT_ = false;
	traceIo_ = false;
	trace_ = false;
	performStep_ = false;
	memoryDisplay_ = CPU_MEMORY;
	debugAddress_ = 0;
	portExtender_ = 1;
	swName_ = "";

	pauseOnBitmap = wxBitmap("images/pause_on.png", wxBITMAP_TYPE_PNG);
	pauseOffBitmap = wxBitmap("images/pause_off.png", wxBITMAP_TYPE_PNG);

}

DebugWindow::~DebugWindow()
{
}

void DebugWindow::readDebugConfig()
{
	debugDir_ = configPointer->Read("/DebugDir", dataDir_);
#ifdef WIN32
	XRCCTRL(*this,"BreakPointWindow", wxListCtrl)->SetColumnWidth(-1, 43);
	XRCCTRL(*this,"TregWindow", wxListCtrl)->SetColumnWidth(-1, 53);
	XRCCTRL(*this,"TrapWindow", wxListCtrl)->SetColumnWidth(-1, 61);
#endif
}

void DebugWindow::writeDebugConfig()
{
	configPointer->Write("/DebugDir", debugDir_);
}

void DebugWindow::enableDebugGuiMemory ()
{
	switch (runningComputer_)
	{
		case COMX:
			XRCCTRL(*this, "DebugExpansionSlot", wxSpinCtrl)->SetValue(4);
			XRCCTRL(*this, "DebugExpansionRam", wxSpinCtrl)->SetValue(0);
			XRCCTRL(*this, "DebugExpansionEprom", wxSpinCtrl)->SetValue(0);
			XRCCTRL(*this, "DebugExpansionSlotText", wxStaticText)->Enable(p_Comx->checkExpansionRomLoaded());
			XRCCTRL(*this, "DebugExpansionSlot", wxSpinCtrl)->Enable(p_Comx->checkExpansionRomLoaded());
			XRCCTRL(*this, "DebugExpansionRamText", wxStaticText)->Enable(p_Comx->isRamCardActive());
			XRCCTRL(*this, "DebugExpansionEpromText", wxStaticText)->Enable(p_Comx->isEpromBoardLoaded());
			XRCCTRL(*this, "DebugExpansionRam", wxSpinCtrl)->Enable(p_Comx->isRamCardActive());
			XRCCTRL(*this, "DebugExpansionEprom", wxSpinCtrl)->Enable(p_Comx->isEpromBoardLoaded());
		break;

		case ELF:
		case ELFII:
		case SUPERELF:
			XRCCTRL(*this, "DebugEmsPageText", wxStaticText)->Enable(elfConfiguration[runningComputer_].useEms);
			XRCCTRL(*this, "DebugEmsPage", wxSpinCtrl)->Enable(elfConfiguration[runningComputer_].useEms);
			XRCCTRL(*this, "DebugPagerText", wxStaticText)->Enable(elfConfiguration[runningComputer_].usePager);
			XRCCTRL(*this, "DebugPager", wxSpinCtrl)->Enable(elfConfiguration[runningComputer_].usePager);
			XRCCTRL(*this, "DebugPortExtender", wxSpinCtrl)->Enable(elfConfiguration[runningComputer_].usePager);
			XRCCTRL(*this, "DebugPortExtender", wxSpinCtrl)->SetValue(portExtender_);
		break;
	}
}

void DebugWindow::setGuiPortExtenderValue()
{
	XRCCTRL(*this, "DebugPager", wxSpinCtrl)->SetValue(p_Computer->getPager(portExtender_));
}

void DebugWindow::enableDebugGui(bool status)
{
	wxString text;

	XRCCTRL(*this,"RegisterButton", wxToggleButton)->Enable(status);
	for (int i=0; i<16; i++)
	{
		text.Printf("R%d",i);
		registerTextPointer[i]->Enable(status&&!protectedMode_);
		text.Printf("R%dText",i);
		XRCCTRL(*this,text, wxStaticText)->Enable(status&&traceRegisters_);
	}
	XRCCTRL(*this,"IoButton", wxToggleButton)->Enable(status);
	for (int i=1; i<8; i++)
	{
		text.Printf("I%dText",i);
		XRCCTRL(*this,text, wxStaticText)->Enable(status&&traceIo_);
		text.Printf("O%d",i);
		outTextPointer[i]->Enable(status&&!protectedMode_);
		text.Printf("O%dText",i);
		XRCCTRL(*this,text, wxStaticText)->Enable(status&&traceIo_);
	}
	XRCCTRL(*this,"FlagButton", wxToggleButton)->Enable(status);
	for (int i=1; i<5; i++)
	{
		text.Printf("EF%dText",i);
		XRCCTRL(*this,text, wxStaticText)->Enable(status&&traceFlags_);
	}
	dfTextPointer->Enable(status&&!protectedMode_);
	XRCCTRL(*this,"DFText", wxStaticText)->Enable(status&&traceFlags_);
	qTextPointer->Enable(status&&!protectedMode_);
	XRCCTRL(*this,"QText", wxStaticText)->Enable(status&&traceFlags_);
	ieTextPointer->Enable(status&&!protectedMode_);
	XRCCTRL(*this,"IEText", wxStaticText)->Enable(status&&traceFlags_);
	dTextPointer->Enable(status&&!protectedMode_);
	XRCCTRL(*this,"DButton", wxToggleButton)->Enable(status);
	pTextPointer->Enable(status&&!protectedMode_);
	XRCCTRL(*this,"PButton", wxToggleButton)->Enable(status);
	xTextPointer->Enable(status&&!protectedMode_);
	XRCCTRL(*this,"XButton", wxToggleButton)->Enable(status);
	tTextPointer->Enable(status&&!protectedMode_);
	XRCCTRL(*this,"TButton", wxToggleButton)->Enable(status);
	XRCCTRL(*this,"InputWindow", wxTextCtrl)->Enable(status);
	XRCCTRL(*this,"ProtectedMode", wxCheckBox)->Enable(status);
	XRCCTRL(*this,"DebugRunButton", wxButton)->Enable(status);
	XRCCTRL(*this,"DebugInterrupt", wxButton)->Enable(status);
	XRCCTRL(*this,"DebugDis", wxButton)->Enable(status);
	XRCCTRL(*this,"DebugDisLog", wxButton)->Enable(status);
	XRCCTRL(*this,"DebugCopy", wxButton)->Enable(status);
	XRCCTRL(*this, "DebugSave", wxButton)->Enable(status);
	XRCCTRL(*this,"DebugPauseButton", wxBitmapButton)->Enable(status);
	XRCCTRL(*this,"DebugStepButton", wxBitmapButton)->Enable(status);

	if (computerRunning_)
		setPauseState();
	else
		XRCCTRL(*this, "DebugPauseButton", wxBitmapButton)->SetBitmapLabel(pauseOffBitmap);

	XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->Enable(memoryDisplay_ != CPU_TYPE);

	if (!status)
	{
		XRCCTRL(*this, "DebugPortExtender", wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, "DebugPager", wxSpinCtrl)->SetValue(0);
		XRCCTRL(*this, "DebugExpansionSlotText", wxStaticText)->Enable(false);
		XRCCTRL(*this, "DebugExpansionSlot", wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, "DebugExpansionRamText", wxStaticText)->Enable(false);
		XRCCTRL(*this, "DebugExpansionRam", wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, "DebugExpansionEpromText", wxStaticText)->Enable(false);
		XRCCTRL(*this, "DebugExpansionEprom", wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, "DebugEmsPageText", wxStaticText)->Enable(false);
		XRCCTRL(*this, "DebugEmsPage", wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, "DebugPagerText", wxStaticText)->Enable(false);
		XRCCTRL(*this, "DebugPager", wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, "DebugSave", wxButton)->Enable(false);
	}
}

void DebugWindow::cycleDebug()
{
	wxString printBuffer, printBuffer2;

	Byte programCounter = p_Computer->getProgramCounter();
	Word programCounterAddress = p_Computer->getScratchpadRegister(programCounter);

	if (p_Computer->getSteps() != 0 && numberOfBreakPoints_ > 0)
	{
		for (int i=0; i<numberOfBreakPoints_; i++)
		{
			if (breakPoints_[i] == programCounterAddress)
			{
				p_Computer->setSteps(0);
				debugTrace("Hit Breakpoint");
				setPauseState();
			}
		}
	}
	if (p_Computer->getSteps() != 0 && numberOfTraps_ > 0)
	{
		for (int i=0; i<numberOfTraps_; i++)
		{
			if ((traps_[i][0] == 1 && traps_[i][1] == p_Computer->readMem(programCounterAddress)) ||
				(traps_[i][0] == 2 && traps_[i][1] == p_Computer->readMem(programCounterAddress) &&
									 traps_[i][2] == p_Computer->readMem(programCounterAddress+1)) ||
				(traps_[i][0] == 3 && traps_[i][1] == p_Computer->readMem(programCounterAddress) &&
						             traps_[i][2] == p_Computer->readMem(programCounterAddress+1) &&
								     traps_[i][3] == p_Computer->readMem(programCounterAddress+2)))
			{
				p_Computer->setSteps(0);
				debugTrace("Instruction Trap");
				setPauseState();
			}
		}
	}
	if (p_Computer->getSteps() != 0 && numberOfTregs_ > 0)
	{
		int j = -1;
		printBuffer2 = "Register Trap: ";
		for (int i=0; i<numberOfTregs_; i++)
		{
			if (tregs_[i][0] == TREG_D && tregs_[i][1] == p_Computer->getAccumulator())
			{
				printBuffer.Printf("D=%02X", p_Computer->getAccumulator());
				j = i;
			}
			if (tregs_[i][0] == TREG_DF && tregs_[i][1] == p_Computer->getDataFlag())
			{
				printBuffer.Printf("DF=%X", p_Computer->getDataFlag());
				j = i;
			}
			if (tregs_[i][0] == TREG_P && tregs_[i][1] == programCounter)
			{
				printBuffer.Printf("P=%X", programCounter);
				j = i;
			}
			if (tregs_[i][0] == TREG_X && tregs_[i][1] == p_Computer->getDataPointer())
			{
				printBuffer.Printf("X=%X", p_Computer->getDataPointer());
				j = i;
			}
			if (tregs_[i][0] == TREG_T && tregs_[i][1] == p_Computer->getRegisterT())
			{
				printBuffer.Printf("X=%02X",p_Computer->getRegisterT());
				j = i;
			}
			if (tregs_[i][0] == TREG_Q && tregs_[i][1] == p_Computer->getFlipFlopQ())
			{
				printBuffer.Printf("Q=%X", p_Computer->getFlipFlopQ());
				j = i;
			}
			if (tregs_[i][0] >= TREG_R0 && tregs_[i][0] <= TREG_RF &&
				tregs_[i][1] == p_Computer->getScratchpadRegister(tregs_[i][0]-TREG_R0))
			{
				printBuffer.Printf("R%X=%02X",tregs_[i][0]-TREG_R0,tregs_[i][1]);
				j = i;
			}
		}
		if (j >= 0)
		{
			p_Computer->setSteps(0);
			printBuffer2.operator += (printBuffer);
			debugTrace(printBuffer2);
			setPauseState();
		}
	}

	if (p_Computer->getSteps() > 0)
	{
		p_Computer->setSteps(p_Computer->getSteps()-1);

		if (p_Computer->getSteps() == 0)
			setPauseState();
	}

	if (performStep_)
	{
		wxString stepsStr = XRCCTRL(*this,"NumberOfSteps",wxTextCtrl)->GetValue();
		long steps;
		if (!stepsStr.ToLong(&steps))
			steps = 1;
		p_Computer->setSteps(steps);
		performStep_ = false;
		setPauseState();
	}
}

void DebugWindow::resetDisplay()
{
	for (int i=0; i<16; i++) lastR_[i] = p_Computer->getScratchpadRegister(i)+1;
	for (int i=1; i<8; i++) lastOut_[i] = p_Computer->getOutValue(i) + 1;
	for (int i=1; i<8; i++) lastIn_[i] = p_Computer->getInValue(i) + 1;
	lastD_ = p_Computer->getAccumulator() + 1;
	lastP_ = p_Computer->getProgramCounter() + 1;
	lastX = p_Computer->getDataPointer() + 1;
	lastT_ = p_Computer->getRegisterT() + 1;
	lastDf_ = p_Computer->getDataFlag() ^ 1;
	lastQ_ = p_Computer->getFlipFlopQ() ^ 1;
	lastIe_ = p_Computer->getInterruptEnable() ^ 1;
	Byte cpuFlag = p_Computer->getEfFlags();
	lastEf1_ = (cpuFlag & 1) ^ 0x1;
	lastEf2_ = (cpuFlag & 2) ^ 0x2;
	lastEf3_ = (cpuFlag & 4) ^ 0x4;
	lastEf4_ = (cpuFlag & 8) ^ 0x8;
}

void DebugWindow::updateWindow()
{
	wxString buffer;
	Word scratchpadRegister;
	Byte cpucpuRegister;
	Byte cpuFlag;

#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
#endif
	if (traceRegisters_)
	{
		for (int i=0; i<16; i++)
		{
			scratchpadRegister = p_Computer->getScratchpadRegister(i);
			if (scratchpadRegister != lastR_[i])
			{
				buffer.Printf("%04X", scratchpadRegister);
				registerTextPointer[i]->ChangeValue(buffer);
				lastR_[i] = scratchpadRegister;
			}
		}
	}
	if (traceIo_)
	{
		for (int i=1; i<8; i++)
		{
			if (p_Computer->getOutValue(i) != lastOut_[i])
			{
				switch (runningComputer_)
				{
					case COMX:
					case CIDELSA:
					case PECOM:
						if (i>3)
							buffer.Printf("%04X",p_Computer->getOutValue(i));
						else
							buffer.Printf("%02X",p_Computer->getOutValue(i));
					break;

					case TMC600:
						if (i==5 && (p_Computer->getOutValue(7) != 0x20) && (p_Computer->getOutValue(7) != 0x30))
							buffer.Printf("%04X",p_Computer->getOutValue(i));
						else
							buffer.Printf("%02X",p_Computer->getOutValue(i));
					break;

					default:
						buffer.Printf("%02X",p_Computer->getOutValue(i));
					break;
				}
				outTextPointer[i]->ChangeValue(buffer);
				lastOut_[i] = p_Computer->getOutValue(i);
			}
			if (p_Computer->getInValue(i) != lastIn_[i])
			{
				buffer.Printf("%02X",p_Computer->getInValue(i));
				inTextPointer[i]->ChangeValue(buffer);
				lastIn_[i] = p_Computer->getInValue(i);
			}
  		}
	}

	if (traceD_)
	{
		cpucpuRegister = p_Computer->getAccumulator();
	 	if (cpucpuRegister != lastD_)
		{
			buffer.Printf("%02X", cpucpuRegister);
			dTextPointer->ChangeValue(buffer);
			lastD_ = cpucpuRegister;
		}
	}
	if (traceP_)
	{
		cpucpuRegister = p_Computer->getProgramCounter();
		if (cpucpuRegister != lastP_)
		{
			buffer.Printf("%02X", cpucpuRegister);
			pTextPointer->ChangeValue(buffer);
			lastP_ = cpucpuRegister;
		}
	}
	if (traceX_)
	{
		cpucpuRegister = p_Computer->getDataPointer();
		if (cpucpuRegister != lastX)
		{
			buffer.Printf("%02X", cpucpuRegister);
			xTextPointer->ChangeValue(buffer);
			lastX = cpucpuRegister;
		}
	}
	if (traceT_)
	{
		cpucpuRegister = p_Computer->getRegisterT();
		if (cpucpuRegister != lastT_)
		{
			buffer.Printf("%02X", cpucpuRegister);
			tTextPointer->ChangeValue(buffer);
			lastT_ = cpucpuRegister;
  		}
	}

	if (traceFlags_)
	{
		cpuFlag = p_Computer->getDataFlag();
		if (cpuFlag != lastDf_)
		{
			buffer.Printf("%01X", cpuFlag);
			dfTextPointer->ChangeValue(buffer);
			lastDf_ = cpuFlag;
		}
		cpuFlag = p_Computer->getFlipFlopQ();
		if (cpuFlag != lastQ_)
		{
			buffer.Printf("%01X", cpuFlag);
			qTextPointer->ChangeValue(buffer);
			lastQ_ = cpuFlag;
		}
		cpuFlag = p_Computer->getInterruptEnable();
		if (cpuFlag != lastIe_)
		{
			buffer.Printf("%01X", cpuFlag);
			ieTextPointer->ChangeValue(buffer);
  			lastIe_ = cpuFlag;
 		}
		cpuFlag = p_Computer->getEfFlags();
 		if ((cpuFlag & 1) != lastEf1_)
		{
			buffer.Printf("%01X", cpuFlag & 1);
			efTextPointer[1]->ChangeValue(buffer);
			lastEf1_ = cpuFlag & 1;
		}
		if ((cpuFlag & 2) != lastEf2_)
		{
			buffer.Printf("%01X", (cpuFlag >> 1) & 1);
			efTextPointer[2]->ChangeValue(buffer);
 			lastEf2_ = cpuFlag & 2;
		}
		if ((cpuFlag & 4) != lastEf3_)
		{
			buffer.Printf("%01X", (cpuFlag >> 2) & 1);
			efTextPointer[3]->ChangeValue(buffer);
 			lastEf3_ = cpuFlag & 4;
		}
		if ((cpuFlag & 8) != lastEf4_)
		{
			buffer.Printf("%01X", (cpuFlag >> 3) & 1);
			efTextPointer[4]->ChangeValue(buffer);
			lastEf4_ = cpuFlag & 8;
		}
	}
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#endif
}

void DebugWindow::debugTrace(wxString buffer)
{
	if (!debugMode_)  return;
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
#endif
	traceWindowPointer->AppendText(buffer);
	traceWindowPointer->AppendText("\n");
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#endif
}

void DebugWindow::assemblerDisplay(wxString buffer)
{
	assemblerWindowPointer->AppendText(buffer);
	assemblerWindowPointer->AppendText("\n");
}

void DebugWindow::disassemblerDisplay(wxString buffer)
{
	disassemblerWindowPointer->AppendText(buffer);
	disassemblerWindowPointer->AppendText("\n");
}

void DebugWindow::deleteBreakPoint(wxListEvent&event)
{
	long selectedItem = event.GetIndex();

	if (selectedItem > -1)
	{
		for (int i=selectedItem; i<numberOfBreakPoints_-1; i++)
			breakPoints_[i] = breakPoints_[i+1];
		numberOfBreakPoints_--;
		SetDebugMode();
	}
}

void DebugWindow::deleteTrap(wxListEvent&event)
{
	long selectedItem = event.GetIndex();

	if (selectedItem > -1)
	{
		for (int j=selectedItem; j<numberOfTraps_-1; j++)
		{
			traps_[j][0] = traps_[j+1][0];
			traps_[j][1] = traps_[j+1][1];
			traps_[j][2] = traps_[j+1][2];
			traps_[j][3] = traps_[j+1][3];
		}
		numberOfTraps_--;
		SetDebugMode();
	}
}

void DebugWindow::deleteTreg(wxListEvent&event)
{
	long selectedItem = event.GetIndex();

	if (selectedItem > -1)
	{
		for (int j=selectedItem; j<numberOfTregs_-1; j++)
		{
			tregs_[j][0] = tregs_[j+1][0];
			tregs_[j][1] = tregs_[j+1][1];
		}
		numberOfTregs_--;
		SetDebugMode();
	}
}

void DebugWindow::editBreakPoint(wxListEvent&event)
{
	wxString bpStr = event.GetText();
	long selectedItem = event.GetIndex();

	if (bpStr == "")
	{
		breakPointWindowPointer->DeleteItem(selectedItem);
		event.Veto();
		return;
	}

	wxString strValue = extractWord (&bpStr);
	long value;

	if (!strValue.ToLong(&value, 16))
	{
		(void)wxMessageBox( "Please specify value in hexadecimal\n",
									"Emma 02", wxICON_ERROR | wxOK );
		event.Veto();
		return;
	}

	if (value > 0xffff)
	{
		(void)wxMessageBox( "Please specify value of 16 bit max\n",
									"Emma 02", wxICON_ERROR | wxOK );
		event.Veto();
		return;
	}

	breakPoints_[selectedItem] = value;
}

void DebugWindow::editTreg(wxListEvent&event)
{
	wxString tregStr = event.GetText();
	long selectedItem = event.GetIndex();

	if (tregStr == "")
	{
		tregWindowPointer->DeleteItem(selectedItem);
		event.Veto();
		return;
	}

	wxString registerStr = extractWord (&tregStr);
	int registerValue = getRegister (registerStr);

	if (registerValue != TREG_FAULT)
	{
		wxString strValue = extractWord (&tregStr);
		long value;

		if (!strValue.ToLong(&value, 16))
		{
			(void)wxMessageBox( "Please specify value in hexadecimal\n",
										"Emma 02", wxICON_ERROR | wxOK );
			event.Veto();
			return;
		}

		if ((registerValue >= TREG_R0) && (registerValue <= TREG_RF))
		{
			if (value > 0xffff)
			{
				(void)wxMessageBox( "Please specify value of 16 bit max\n",
											"Emma 02", wxICON_ERROR | wxOK );
				event.Veto();
				return;
			}
		}
		else
		{
			if (registerValue <= TREG_T)
			{
				if (value > 0xff)
				{
					(void)wxMessageBox( "Please specify value of 8 bit max\n",
												"Emma 02", wxICON_ERROR | wxOK );
					event.Veto();
					return;
				}
			}
			else
			{
				if (value > 1)
				{
					(void)wxMessageBox( "Please specify value of 0 or 1\n",
												"Emma 02", wxICON_ERROR | wxOK );
					event.Veto();
					return;
				}
			}
		}

		tregs_[selectedItem][0] = registerValue;
		tregs_[selectedItem][1] = value;
	}
	else
	{
		(void)wxMessageBox( "Please specify R0 to RF, D, P, X, T, DF or Q\n",
									"Emma 02", wxICON_ERROR | wxOK );
		event.Veto();
		return;
	}
}

void DebugWindow::editTrap(wxListEvent&event)
{
	wxString trapStr = event.GetText();
	long selectedItem = event.GetIndex();

	if (trapStr == "")
	{
		trapWindowPointer->DeleteItem(selectedItem);
		event.Veto();
		return;
	}

	Word count;
	Byte b1, b2, b3;

	count = assemble(&trapStr, &b1, &b2, &b3);
	if (count > 0)
	{
		traps_[selectedItem][0] = count;
		traps_[selectedItem][1] = b1;
		traps_[selectedItem][2] = b2;
		traps_[selectedItem][3] = b3;
	}
	else
	{
		(void)wxMessageBox( "Unrecognized command format\n",
									"Emma 02", wxICON_ERROR | wxOK );
		event.Veto();
		return;
	}
}

void DebugWindow::addBreakPoint()
{
	wxString printBuffer;

	printBuffer.Printf("%04X", breakPoints_[numberOfBreakPoints_]);
	breakPointWindowPointer->InsertItem(numberOfBreakPoints_, printBuffer);
	numberOfBreakPoints_++;
}

void DebugWindow::addTrap()
{
	wxString printBuffer;

	int i = numberOfTraps_;
	printBuffer = "";

	int n = traps_[i][1] & 0xf;
	int inst = traps_[i][1] >> 4;
	switch(inst)
	{
		case 0x0:
			switch(n)
			{
				case 0x0:
					printBuffer.operator += ("IDL");
				break;

				default:
					printBuffer.Printf("LDN  R%X",n);
				break;
			}
		break;

		case 0x1:
			printBuffer.Printf("INC  R%X",n);
		break;

		case 0x2:
			printBuffer.Printf("DEC  R%X",n);
		break;

		case 0x3:
			switch(n)
			{
				case 0x0:
					printBuffer.Printf("BR   %02X", traps_[i][2]);
				break;
				case 0x1:
					printBuffer.Printf("BQ   %02X", traps_[i][2]);
				break;
				case 0x2:
					printBuffer.Printf("BZ   %02X", traps_[i][2]);
				break;
				case 0x3:
					printBuffer.Printf("BDF  %02X", traps_[i][2]);
				break;
				case 0x4:
					printBuffer.Printf("B1   %02X", traps_[i][2]);
				break;
				case 0x5:
					printBuffer.Printf("B2   %02X", traps_[i][2]);
				break;
				case 0x6:
					printBuffer.Printf("B3   %02X", traps_[i][2]);
				break;
				case 0x7:
					printBuffer.Printf("B4   %02X", traps_[i][2]);
				break;
				case 0x8:
					printBuffer.operator += ("SKP"); break;
				case 0x9:
					printBuffer.Printf("BNQ  %02X", traps_[i][2]);
				break;
				case 0xa:
					printBuffer.Printf("BNZ  %02X", traps_[i][2]);
				break;
				case 0xb:
					printBuffer.Printf("BNF  %02X", traps_[i][2]);
				break;
				case 0xc:
					printBuffer.Printf("BN1  %02X", traps_[i][2]);
				break;
				case 0xd:
					printBuffer.Printf("BN2  %02X", traps_[i][2]);
				break;
				case 0xe:
					printBuffer.Printf("BN3  %02X", traps_[i][2]);
				break;
				case 0xf:
					printBuffer.Printf("BN4  %02X", traps_[i][2]);
				break;
			}
		break;

		case 0x4:
			printBuffer.Printf("LDA  R%X",n);
		break;

		case 0x5:
			printBuffer.Printf("STR  R%X",n);
		break;

		case 0x6:
			switch(n)
			{
				case 0x0:
					printBuffer.operator += ("IRX");
				break;
				case 0x1:
				case 0x2:
				case 0x3:
				case 0x4:
				case 0x5:
				case 0x6:
				case 0x7:
					printBuffer.Printf("OUT  %X",n);
				break;
				case 0x9:
				case 0xa:
				case 0xb:
				case 0xc:
				case 0xd:
				case 0xe:
				case 0xf:
					printBuffer.Printf("INP  %X",n-8);
				break;
			}
		break;
		case 0x7:
			switch(n)
			{
				case 0x0:
					printBuffer.operator += ("RET");
				break;
				case 0x1:
					printBuffer.operator += ("DIS");
				break;
				case 0x2:
					printBuffer.operator += ("LDXA");
				break;
				case 0x3:
					printBuffer.operator += ("STXD");
				break;
				case 0x4:
					printBuffer.operator += ("ADC");
				break;
				case 0x5:
					printBuffer.operator += ("SDB");
				break;
				case 0x6:
					printBuffer.operator += ("SHRC");
				break;
				case 0x7:
					printBuffer.operator += ("SMB");
				break;
				case 0x8:
					printBuffer.operator += ("SAV");
				break;
				case 0x9:
					printBuffer.operator += ("MARK");
				break;
				case 0xa:
					printBuffer.operator += ("REQ");
				break;
				case 0xb:
					printBuffer.operator += ("SEQ");
				break;
				case 0xe:
					printBuffer.operator += ("SHLC");
				break;
				case 0xc:
					printBuffer.Printf("ADCI %02X", traps_[i][2]);
				break;
				case 0xd:
					printBuffer.Printf("SDBI %02X", traps_[i][2]);
				break;
				case 0xf:
					printBuffer.Printf("SMBI %02X", traps_[i][2]);
				break;
			}
		break;
		case 0x8:
			printBuffer.Printf("GLO  R%X",n);
		break;
		case 0x9:
			printBuffer.Printf("GHI  R%X",n);
		break;
		case 0xa:
			printBuffer.Printf("PLO  R%X",n);
		break;
		case 0xb:
			printBuffer.Printf("PHI  R%X",n);
		break;
		case 0xc:
			switch(n)
			{
				case 0x0:
					printBuffer.Printf("LBR  %04X", traps_[i][2]<<8|traps_[i][3]);
				break;
				case 0x1:
					printBuffer.Printf("LBQ  %04X", traps_[i][2]<<8|traps_[i][3]);
				break;
				case 0x2:
					printBuffer.Printf("LBZ  %04X", traps_[i][2]<<8|traps_[i][3]);
				break;
				case 0x3:
					printBuffer.Printf("LBDF %04X", traps_[i][2]<<8|traps_[i][3]);
				break;
				case 0x4:
					printBuffer.operator += ("NOP");
				break;
				case 0x5:
					printBuffer.operator += ("LSNQ");
				break;
				case 0x6:
					printBuffer.operator += ("LSNZ");
				break;
				case 0x7:
					printBuffer.operator += ("LSNF");
				break;
				case 0x8:
					printBuffer.operator += ("LSKP");
				break;
				case 0x9:
					printBuffer.Printf("LBNQ %04X", traps_[i][2]<<8|traps_[i][3]);
				break;
				case 0xa:
					printBuffer.Printf("LBNZ %04X", traps_[i][2]<<8|traps_[i][3]);
				break;
				case 0xb:
					printBuffer.Printf("LBNF %04X", traps_[i][2]<<8|traps_[i][3]);
				break;
				case 0xc:
					printBuffer.operator += ("LSIE");
				break;
				case 0xd:
					printBuffer.operator += ("LSQ");
				break;
				case 0xe:
					printBuffer.operator += ("LSZ");
				break;
				case 0xf:
					printBuffer.operator += ("LSDF");
				break;
			}
		break;
		case 0xd:
			printBuffer.Printf("SEP  R%X",n);
		break;
		case 0xe:
			printBuffer.Printf("SEX  R%X",n);
		break;
		case 0xf:
			switch(n)
			{
				case 0x0:
					printBuffer.operator += ("LDX");
				break;
				case 0x1:
					printBuffer.operator += ("OR");
				break;
				case 0x2:
					printBuffer.operator += ("AND");
				break;
				case 0x3:
					printBuffer.operator += ("XOR");
				break;
				case 0x4:
					printBuffer.operator += ("ADD");
				break;
				case 0x5:
					printBuffer.operator += ("SD");
				break;
				case 0x6:
					printBuffer.operator += ("SHR");
				break;
				case 0x7:
					printBuffer.operator += ("SM");
				break;
				case 0x8:
					printBuffer.Printf("LDI  %02X", traps_[i][2]);
				break;
				case 0x9:
					printBuffer.Printf("ORI  %02X", traps_[i][2]);
				break;
				case 0xa:
					printBuffer.Printf("ANI  %02X", traps_[i][2]);
				break;
				case 0xb:
					printBuffer.Printf("XRI  %02X", traps_[i][2]);
				break;
				case 0xc:
					printBuffer.Printf("ADI  %02X", traps_[i][2]);
				break;
				case 0xd:
					printBuffer.Printf("SDI  %02X", traps_[i][2]);
				break;
				case 0xe:
					printBuffer.operator += ("SHL");
				break;
				case 0xf:
					printBuffer.Printf("SMI  %02X", traps_[i][2]);
				break;
			}
		break;
	}
	trapWindowPointer->InsertItem(i, printBuffer);
	numberOfTraps_++;
}

void DebugWindow::addTreg()
{
	wxString printBuffer;

	switch(tregs_[numberOfTregs_][0])
	{
		case TREG_R0: case TREG_R1: case TREG_R2: case TREG_R3: case TREG_R4: case TREG_R5: case TREG_R6: case TREG_R7: case TREG_R8: case TREG_R9:
		case TREG_RA: case TREG_RB: case TREG_RC: case TREG_RD: case TREG_RE: case TREG_RF:
			printBuffer.Printf("R%X %04X", tregs_[numberOfTregs_][0] - TREG_R0, tregs_[numberOfTregs_][1]);
		break;

		case TREG_D: printBuffer.Printf("D  %02X", tregs_[numberOfTregs_][1]);
		break;

		case TREG_DF: printBuffer.Printf("DF %X", (tregs_[numberOfTregs_][1])?1:0);
		break;

		case TREG_Q: printBuffer.Printf("Q  %X", (tregs_[numberOfTregs_][1])?1:0);
		break;

		case TREG_P: printBuffer.Printf("P  %X", tregs_[numberOfTregs_][1]);
		break;

		case TREG_X: printBuffer.Printf("X  %X", tregs_[numberOfTregs_][1]);
		break;

		case TREG_T: printBuffer.Printf("T  %02X", tregs_[numberOfTregs_][1]);
		break;
	}
	tregWindowPointer->InsertItem(numberOfTregs_, printBuffer);
	numberOfTregs_++;
}

wxString DebugWindow::extractWord(wxString *buffer)
{
	int end;
	wxString ret;

	buffer->Trim(false);

	end = buffer->Find(' ');
	if (end == -1)
	{
		ret = *buffer;
		*buffer = "";
		return ret;
	}

	ret = buffer->Mid(0, end);
	*buffer = buffer->Mid(end, buffer->Len()-end);
	return ret;
}

void DebugWindow::disassemble(Word start, Word end)
{
	wxString printBuffer, printBuffer2, printBuffer3;
	int i,n;

	while(start <= end)
	{
		i = p_Computer->readMem(start);
		printBuffer.Printf("%04X: %02X ", start, i);
		printBuffer2 = "";
		n = i & 0xf;
		i >>= 4;
		start++;
		switch(i)
		{
			case 0x0:
				switch(n)
				{
					case 0x0:
						printBuffer2.operator += ("IDL");
					break;

					default:
						printBuffer2.Printf("LDN  R%X",n);
					break;
				}
			break;

			case 0x1:
				printBuffer2.Printf("INC  R%X",n);
			break;

			case 0x2:
				printBuffer2.Printf("DEC  R%X",n);
			break;

			case 0x3:
				switch(n)
				{
					case 0x0:
						printBuffer2.Printf("BR   %02X", p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ", p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0x1:
						printBuffer2.Printf("BQ   %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0x2:
						printBuffer2.Printf("BZ   %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0x3:
						printBuffer2.Printf("BDF  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0x4:
						printBuffer2.Printf("B1   %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0x5:
						printBuffer2.Printf("B2   %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0x6:
						printBuffer2.Printf("B3   %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0x7:
						printBuffer2.Printf("B4   %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0x8:
						printBuffer2.operator += ("SKP"); break;
					case 0x9:
						printBuffer2.Printf("BNQ  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xa:
						printBuffer2.Printf("BNZ  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xb:
						printBuffer2.Printf("BNF  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xc:
						printBuffer2.Printf("BN1  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xd:
						printBuffer2.Printf("BN2  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xe:
						printBuffer2.Printf("BN3  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xf:
						printBuffer2.Printf("BN4  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
				}
			break;

			case 0x4:
				printBuffer2.Printf("LDA  R%X",n);
			break;

			case 0x5:
				printBuffer2.Printf("STR  R%X",n);
			break;

			case 0x6:
				switch(n)
				{
					case 0x0:
						printBuffer2.operator += ("IRX");
					break;
					case 0x1:
					case 0x2:
					case 0x3:
					case 0x4:
					case 0x5:
					case 0x6:
					case 0x7:
						printBuffer2.Printf("OUT  %X",n);
					break;
					case 0x9:
					case 0xa:
					case 0xb:
					case 0xc:
					case 0xd:
					case 0xe:
					case 0xf:
						printBuffer2.Printf("INP  %X",n-8);
					break;
				}
			break;
			case 0x7:
				switch(n)
				{
					case 0x0:
						printBuffer2.operator += ("RET");
					break;
					case 0x1:
						printBuffer2.operator += ("DIS");
					break;
					case 0x2:
						printBuffer2.operator += ("LDXA");
					break;
					case 0x3:
						printBuffer2.operator += ("STXD");
					break;
					case 0x4:
						printBuffer2.operator += ("ADC");
					break;
					case 0x5:
						printBuffer2.operator += ("SDB");
					break;
					case 0x6:
						printBuffer2.operator += ("SHRC");
					break;
					case 0x7:
						printBuffer2.operator += ("SMB");
					break;
					case 0x8:
						printBuffer2.operator += ("SAV");
					break;
					case 0x9:
						printBuffer2.operator += ("MARK");
					break;
					case 0xa:
						printBuffer2.operator += ("REQ");
					break;
					case 0xb:
						printBuffer2.operator += ("SEQ");
					break;
					case 0xe:
						printBuffer2.operator += ("SHLC");
					break;
					case 0xc:
						printBuffer2.Printf("ADCI %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xd:
						printBuffer2.Printf("SDBI %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xf:
						printBuffer2.Printf("SMBI %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
				}
			break;
			case 0x8:
				printBuffer2.Printf("GLO  R%X",n);
			break;
			case 0x9:
				printBuffer2.Printf("GHI  R%X",n);
			break;
			case 0xa:
				printBuffer2.Printf("PLO  R%X",n);
			break;
			case 0xb:
				printBuffer2.Printf("PHI  R%X",n);
			break;
			case 0xc:
				switch(n)
				{
					case 0x0:
						printBuffer2.Printf("LBR  %04X",p_Computer->readMem(start)<<8|p_Computer->readMem(start+1));
						printBuffer3.Printf("%02X %02X ",p_Computer->readMem(start),p_Computer->readMem(start+1));
						printBuffer.operator += (printBuffer3);
						start+=2;
					break;
					case 0x1:
						printBuffer2.Printf("LBQ  %04X",p_Computer->readMem(start)<<8|p_Computer->readMem(start+1));
						printBuffer3.Printf("%02X %02X ",p_Computer->readMem(start),p_Computer->readMem(start+1));
						printBuffer.operator += (printBuffer3);
						start+=2;
					break;
					case 0x2:
						printBuffer2.Printf("LBZ  %04X",p_Computer->readMem(start)<<8|p_Computer->readMem(start+1));
						printBuffer3.Printf("%02X %02X ",p_Computer->readMem(start),p_Computer->readMem(start+1));
						printBuffer.operator += (printBuffer3);
						start+=2;
					break;
					case 0x3:
						printBuffer2.Printf("LBDF %04X",p_Computer->readMem(start)<<8|p_Computer->readMem(start+1));
						printBuffer3.Printf("%02X %02X ",p_Computer->readMem(start),p_Computer->readMem(start+1));
						printBuffer.operator += (printBuffer3);
						start+=2;
					break;
					case 0x4:
						printBuffer2.operator += ("NOP");
					break;
					case 0x5:
						printBuffer2.operator += ("LSNQ");
					break;
					case 0x6:
						printBuffer2.operator += ("LSNZ");
					break;
					case 0x7:
						printBuffer2.operator += ("LSNF");
					break;
					case 0x8:
						printBuffer2.operator += ("LSKP");
					break;
					case 0x9:
						printBuffer2.Printf("LBNQ %04X",p_Computer->readMem(start)<<8|p_Computer->readMem(start+1));
						printBuffer3.Printf("%02X %02X ",p_Computer->readMem(start),p_Computer->readMem(start+1));
						printBuffer.operator += (printBuffer3);
						start+=2;
					break;
					case 0xa:
						printBuffer2.Printf("LBNZ %04X",p_Computer->readMem(start)<<8|p_Computer->readMem(start+1));
						printBuffer3.Printf("%02X %02X ",p_Computer->readMem(start),p_Computer->readMem(start+1));
						printBuffer.operator += (printBuffer3);
						start+=2;
					break;
					case 0xb:printBuffer2.Printf("LBNF %04X",p_Computer->readMem(start)<<8|p_Computer->readMem(start+1));
						printBuffer3.Printf("%02X %02X ",p_Computer->readMem(start),p_Computer->readMem(start+1));
						printBuffer.operator += (printBuffer3);
						start+=2;
					break;
					case 0xc:
						printBuffer2.operator += ("LSIE");
					break;
					case 0xd:
						printBuffer2.operator += ("LSQ");
					break;
					case 0xe:
						printBuffer2.operator += ("LSZ");
					break;
					case 0xf:
						printBuffer2.operator += ("LSDF");
					break;
				}
			break;
			case 0xd:
				printBuffer2.Printf("SEP  R%X",n);
			break;
			case 0xe:
				printBuffer2.Printf("SEX  R%X",n);
			break;
			case 0xf:
				switch(n)
				{
					case 0x0:
						printBuffer2.operator += ("LDX");
					break;
					case 0x1:
						printBuffer2.operator += ("OR");
					break;
					case 0x2:
						printBuffer2.operator += ("AND");
					break;
					case 0x3:
						printBuffer2.operator += ("XOR");
					break;
					case 0x4:
						printBuffer2.operator += ("ADD");
					break;
					case 0x5:
						printBuffer2.operator += ("SD");
					break;
					case 0x6:
						printBuffer2.operator += ("SHR");
					break;
					case 0x7:
						printBuffer2.operator += ("SM");
					break;
					case 0x8:
						printBuffer2.Printf("LDI  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0x9:
						printBuffer2.Printf("ORI  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xa:printBuffer2.Printf("ANI  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xb:printBuffer2.Printf("XRI  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xc:printBuffer2.Printf("ADI  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xd:printBuffer2.Printf("SDI  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
					case 0xe:printBuffer2.operator += ("SHL"); break;
					case 0xf:printBuffer2.Printf("SMI  %02X",p_Computer->readMem(start++));
						printBuffer3.Printf("%02X ",p_Computer->readMem(start-1));
						printBuffer.operator += (printBuffer3);
					break;
				}
			break;
		}
		while(printBuffer.Len() < 18) printBuffer.operator += (" ");
		printBuffer.operator += (printBuffer2);
		disassemblerDisplay(printBuffer);
	}
}

int DebugWindow::assemble(wxString *buffer, Byte* b1, Byte* b2, Byte* b3)
{
	wxString command, value, cpuRegister;
	long v;

	command = extractWord(buffer);

	if (command == "ADC") { *b1 = 0x74; return 1; }
	if (command == "ADCI")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x7c;
		*b2 = v & 0xff;
		return 2;
	}
	if (command == "ADD") { *b1 = 0xf4; return 1; }
	if (command == "ADI")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xfc;
		*b2 = v & 0xff; return 2;
	}
	if (command == "AND") { *b1 = 0xf2; return 1; }
	if (command == "ANI")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xfa;
		*b2 = v & 0xff; return 2;
	}
	if (command == "B1")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x34;
		*b2 = v & 0xff; return 2;
	}
	if (command == "B2")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x35;
		*b2 = v & 0xff; return 2;
	}
	if (command == "B3")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x36;
		*b2 = v & 0xff; return 2;
	}
	if (command == "B4")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x37;
		*b2 = v & 0xff; return 2;
	}
	if (command == "BDF")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x33;
		*b2 = v & 0xff; return 2;
	}
	if (command == "BN1")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x3c;
		*b2 = v & 0xff; return 2;
	}
	if (command == "BN2")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x3d;
		*b2 = v & 0xff; return 2;
	}
	if (command == "BN3")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x3e;
		*b2 = v & 0xff; return 2;
	}
	if (command == "BN4")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x3f;
		*b2 = v & 0xff; return 2;
	}
	if (command == "BNF")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x3b;
		*b2 = v & 0xff; return 2;
	}
	if (command == "BNQ")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x39;
		*b2 = v & 0xff; return 2;
	}
	if (command == "BNZ")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x3a;
		*b2 = v & 0xff; return 2;
	}
	if (command == "BQ")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x31;
		*b2 = v & 0xff; return 2;
	}
	if (command == "BR")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x30;
		*b2 = v & 0xff; return 2;
	}
	if (command == "BZ")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x32;
		*b2 = v & 0xff; return 2;
	}
	if (command == "DEC")
	{
		cpuRegister = extractWord(buffer);
		*b1 = 0x20 | getRegisterNumber(cpuRegister);
		return 1;
	}
	if (command == "DIS") { *b1 = 0x71; return 1; }
	if (command == "GHI")
	{
		cpuRegister = extractWord(buffer);
		*b1 = 0x90 | getRegisterNumber(cpuRegister); return 1;
	}
	if (command == "GLO")
	{
		cpuRegister = extractWord(buffer);
		*b1 = 0x80 | getRegisterNumber(cpuRegister); return 1;
	}
	if (command == "IDL") { *b1 = 0x00; return 1; }
	if (command == "INC")
	{
		cpuRegister = extractWord(buffer);
		*b1 = 0x10 | getRegisterNumber(cpuRegister); return 1;
	}
	if (command == "INP")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x60;
		*b1 |= (v & 0x7)+8; return 1;
	}
	if (command == "IRX") { *b1 = 0x60; return 1; }
	if (command == "LBDF")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xc3;
		*b2 = v >> 8;
		*b3 = v & 0xff; return 3;
	}
	if (command == "LBNF")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xcb;
		*b2 = v >> 8;
		*b3 = v & 0xff; return 3;
	}
	if (command == "LBNQ")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xc9;
		*b2 = v >> 8;
		*b3 = v & 0xff; return 3;
	}
	if (command == "LBNZ")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xca;
		*b2 = v >> 8;
		*b3 = v & 0xff; return 3;
	}
	if (command == "LBQ")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xc1;
		*b2 = v >> 8;
		*b3 = v & 0xff; return 3;
	}
	if (command == "LBR")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xc0;
		*b2 = v >> 8;
		*b3 = v & 0xff; return 3;
	}
	if (command == "LBZ")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xc2;
		*b2 = v >> 8;
		*b3 = v & 0xff; return 3;
	}
	if (command == "LDA")
	{
		cpuRegister = extractWord(buffer);
		*b1 = 0x40 | getRegisterNumber(cpuRegister); return 1;
	}
	if (command == "LDI")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xf8;
		*b2 = v & 0xff; return 2;
	}
	if (command == "LDN")
	{
		cpuRegister = extractWord(buffer);
		*b1 = 0x00 | getRegisterNumber(cpuRegister); return 1;
	}
	if (command == "LDX") { *b1 = 0xf0; return 1; }
	if (command == "LDXA") { *b1 = 0x72; return 1; }
	if (command == "LSDF") { *b1 = 0xcf; return 1; }
	if (command == "LSIE") { *b1 = 0xcc; return 1; }
	if (command == "LSKP") { *b1 = 0xc8; return 1; }
	if (command == "LSNF") { *b1 = 0xc7; return 1; }
	if (command == "LSNQ") { *b1 = 0xc5; return 1; }
	if (command == "LSNZ") { *b1 = 0xc6; return 1; }
	if (command == "LSQ") { *b1 = 0xcd; return 1; }
	if (command == "LSZ") { *b1 = 0xce; return 1; }
	if (command == "MARK") { *b1 = 0x79; return 1; }
	if (command == "NBR") { *b1 = 0x38; return 1; }
	if (command == "NLBR") { *b1 = 0xc8; return 1; }
	if (command == "NOP") { *b1 = 0xc4; return 1; }
	if (command == "OR") { *b1 = 0xf1; return 1; }
	if (command == "ORI")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xf9;
		*b2 = v & 0xff; return 2;
	}
	if (command == "OUT")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x60;
		*b1 |= (v & 0x7); return 1;
	}
	if (command == "PHI")
	{
		cpuRegister = extractWord(buffer);
		*b1 = 0xb0 | getRegisterNumber(cpuRegister); return 1;
	}
	if (command == "PLO")
	{
		cpuRegister = extractWord(buffer);
		*b1 = 0xa0 | getRegisterNumber(cpuRegister); return 1;
	}
	if (command == "REQ") { *b1 = 0x7a; return 1; }
	if (command == "RET") { *b1 = 0x70; return 1; }
	if (command == "SAV") { *b1 = 0x78; return 1; }
	if (command == "SD") { *b1 = 0xf5; return 1; }
	if (command == "SDB") { *b1 = 0x75; return 1; }
	if (command == "SDBI")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x7d;
		*b2 = v & 0xff; return 2;
	}
	if (command == "SDI")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xfd;
		*b2 = v & 0xff; return 2;
	}
	if (command == "SEP")
	{
		cpuRegister = extractWord(buffer);
		*b1 = 0xd0 | getRegisterNumber(cpuRegister); return 1;
	}
	if (command == "SEQ") { *b1 = 0x7b; return 1; }
	if (command == "SEX")
	{
		cpuRegister = extractWord(buffer);
		*b1 = 0xe0 | getRegisterNumber(cpuRegister); return 1;
	}
	if (command == "SHL") { *b1 = 0xfe; return 1; }
	if (command == "SHLC") { *b1 = 0x7e; return 1; }
	if (command == "SHR") { *b1 = 0xf6; return 1; }
	if (command == "SHRC") { *b1 = 0x76; return 1; }
	if (command == "SKP") { *b1 = 0x38; return 1; }
	if (command == "SM") { *b1 = 0xf7; return 1; }
	if (command == "SMB") { *b1 = 0x77; return 1; }
	if (command == "SMBI")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0x7f;
		*b2 = v & 0xff; return 2;
	}
	if (command == "SMI")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xff;
		*b2 = v & 0xff; return 2;
	}
	if (command == "STR")
	{
		cpuRegister = extractWord(buffer);
		*b1 = 0x50 | getRegisterNumber(cpuRegister); return 1;
	}
	if (command == "STXD") { *b1 = 0x73; return 1; }
	if (command == "XOR") { *b1 = 0xf3; return 1; }
	if (command == "XRI")
	{
		value = extractWord(buffer);
		value.ToLong(&v, 16);
		*b1 = 0xfb;
		*b2 = v & 0xff; return 2;
	}
	return 0;
}

Word DebugWindow::getRegisterNumber(wxString buffer)
{
	if (buffer == "R0") return 0;
	if (buffer == "R1") return 1;
	if (buffer == "R2") return 2;
	if (buffer == "R3") return 3;
	if (buffer == "R4") return 4;
	if (buffer == "R5") return 5;
	if (buffer == "R6") return 6;
	if (buffer == "R7") return 7;
	if (buffer == "R8") return 8;
	if (buffer == "R9") return 9;
	if (buffer == "RA") return 10;
	if (buffer == "RB") return 11;
	if (buffer == "RC") return 12;
	if (buffer == "RD") return 13;
	if (buffer == "RE") return 14;
	if (buffer == "RF") return 15;
	return 0;
}

int DebugWindow::getRegister(wxString buffer)
{
	if (buffer == "D")  return TREG_D;
	if (buffer == "DF")  return TREG_DF;
	if (buffer == "P")  return TREG_P;
	if (buffer == "X")  return TREG_X;
	if (buffer == "T")  return TREG_T;
	if (buffer == "Q")  return TREG_Q;
	if (buffer == "R0")  return TREG_R0;
	if (buffer == "R1")  return TREG_R1;
	if (buffer == "R2")  return TREG_R2;
	if (buffer == "R3")  return TREG_R3;
	if (buffer == "R4")  return TREG_R4;
	if (buffer == "R5")  return TREG_R5;
	if (buffer == "R6")  return TREG_R6;
	if (buffer == "R7")  return TREG_R7;
	if (buffer == "R8")  return TREG_R8;
	if (buffer == "R9")  return TREG_R9;
	if (buffer == "RA")  return TREG_RA;
	if (buffer == "RB")  return TREG_RB;
	if (buffer == "RC")  return TREG_RC;
	if (buffer == "RD")  return TREG_RD;
	if (buffer == "RE")  return TREG_RE;
	if (buffer == "RF")  return TREG_RF;
	return TREG_FAULT;
}

void DebugWindow::onEnter(wxCommandEvent&WXUNUSED(event))
{
	wxString debugIn, address, mnemonic;
	Byte b1,b2,b3;
	int count;

	debugIn = inputWindowPointer->GetValue();
	debugIn.MakeUpper();
	mnemonic = debugIn;

	count = assemble(&debugIn, &b1, &b2, &b3);

    if (count > 0)
	{
		address.Printf("%04X: ", (unsigned int)debugAddress_);
		assemblerDisplay(address+mnemonic);
		p_Computer->writeMem(debugAddress_++, b1, true);
		if (count > 1) p_Computer->writeMem(debugAddress_++, b2, true);
		if (count > 2) p_Computer->writeMem(debugAddress_++, b3, true);

		address.Printf("%04X", (unsigned int)debugAddress_);
		XRCCTRL(*this,"DebugAssemblerAddress",wxTextCtrl)->SetValue(address);

		inputWindowPointer->Clear();
	}
	else
		assemblerDisplay("1802 Instruction not recognized");
}

void DebugWindow::onDebugDis(wxCommandEvent&WXUNUSED(event))
{
	long start = get16BitValue("DebugDisStart");
	if (start == -1)  return;

	long end = get16BitValue("DebugDisEnd");
	if (end == -1)  return;

	disassemble(start, end);
}

void DebugWindow::onDebugSaveDump(wxCommandEvent&WXUNUSED(event))
{
	int num = 0;
	long addr;
	Byte value;
	wxFile outputFile;
	wxTextFile outputTextFile;
	wxString fileName, memoryStr, number, strValue, line;

	switch (memoryDisplay_)
	{
		case CPU_MEMORY:
			memoryStr = "CPU Memory";
			fileName = "memorydump";
		break;

		case CDP_1870_C:
			memoryStr = "CDP 1870 Character Ram";
			fileName = "cdp1870charramdump";
		break;

		case CDP_1870_P:
			memoryStr = "CDP 1870 Page Ram";
			fileName = "cdp1870pageramdump";
		break;

		case TMS_MEMORY:
			memoryStr = "TMS video Ram";
			fileName = "tmsramdump";
		break;

		case VT_RAM:
			memoryStr = "VT video Ram";
			fileName = "vtramdump";
		break;

		case CDP_1864:
			memoryStr = "CDP 1864 Color Ram";
			fileName = "cdp1864colorramdump";
		break;

		case V_6845:
			memoryStr = "MC6845 Char Rom";
			fileName = "mc6845charromdump";
		break;

		case V_6847:
			memoryStr = "MC6847 Char Rom";
			fileName = "mc6847charromdump";
		break;

		case V_6847_RAM:
			memoryStr = "MC6847 video Ram";
			fileName = "mc6847ramdump";
		break;

		case I_8275:
			memoryStr = "Intel 8275 Char Rom";
			fileName = "i8275charromdump";
		break;
	}

	fileName = wxFileSelector( "Select the " + memoryStr + " dump file to save",
                               debugDir_, fileName,
                               "bin|txt",
                               wxString::Format
                              (
                                   "Binary File (*.bin)|*.bin|Text File (*.txt)|*.txt"
                               ),
                               wxFD_SAVE|wxFD_CHANGE_DIR,
                               this
                              );

	if (!fileName || fileName.empty())
		return;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	wxString name = FullPath.GetName();
	wxString path = FullPath.GetPath();
	wxString ext = FullPath.GetExt();

	while(wxFile::Exists(fileName))
	{
		num++;
		number.Printf("%d", num);
		fileName = path + pathSeparator_ + name + "." + number + "." + ext;
	}

	if (ext == "bin")
	{
		outputFile.Create(fileName);
		for (long address = 0; address <= getAddressMask(); address++)
		{
			value = debugReadMem(address);
			outputFile.Write(&value, 1);
		}
		outputFile.Close();
	}
	else
	{
		outputTextFile.Create(fileName);
		addr = 0;
		while(addr <= getAddressMask())
		{
			line.Printf("%04X:", (unsigned int)addr);
			for (int i=0; i<16; i++)
			{
				strValue.Printf(" %02X", debugReadMem(addr+i));
				line = line + strValue;
			}

			outputTextFile.AddLine(line);
			addr += 16;
		}
		outputTextFile.Write();
		outputTextFile.Close();
	}
}

void DebugWindow::onPauseButton(wxCommandEvent&WXUNUSED(event))
{
	if (p_Computer->getSteps() < 0)
		p_Computer->setSteps(0);
	else
		p_Computer->setSteps(-1);
	setPauseState();
}

void DebugWindow::setPauseState()
{
	if (p_Computer->getSteps() == 0)
	{
		XRCCTRL(*this, "DebugPauseButton", wxBitmapButton)->SetBitmapLabel(pauseOnBitmap);
		XRCCTRL(*this,"DebugStepButton", wxBitmapButton)->Enable(true);
	}
	else
	{
		if (p_Computer->getSteps() > 0)
		{
			XRCCTRL(*this, "DebugPauseButton", wxBitmapButton)->SetBitmapLabel(pauseOffBitmap);
			XRCCTRL(*this,"DebugStepButton", wxBitmapButton)->Enable(true);
		}
		else
		{
			XRCCTRL(*this, "DebugPauseButton", wxBitmapButton)->SetBitmapLabel(pauseOffBitmap);
			XRCCTRL(*this,"DebugStepButton", wxBitmapButton)->Enable(false);
		}
	}
	updateTitle();
}

void DebugWindow::onStepButton(wxCommandEvent&WXUNUSED(event))
{
	performStep_ = true;
}

void DebugWindow::onRunButton(wxCommandEvent&WXUNUSED(event))
{
	p_Computer->setSteps(-1);
	setPauseState();

	long runAddress = get16BitValue("DebugRunAddress");
	if (runAddress == -1)  return;

	p_Computer->setScratchpadRegister(p_Computer->getProgramCounter(), runAddress);
}

void DebugWindow::onRunAddress(wxCommandEvent&WXUNUSED(event))
{
	get16BitValue("DebugRunAddress");
}

void DebugWindow::onBreakPointAddress(wxCommandEvent&WXUNUSED(event))
{
	get16BitValue("BreakPointAddress");
}

void DebugWindow::onTregValue(wxCommandEvent&WXUNUSED(event))
{
	get16BitValue("TregValue");
}

void DebugWindow::onTrapValue(wxCommandEvent&WXUNUSED(event))
{
	get16BitValue("TrapValue");
}

void DebugWindow::SetDebugMode()
{
	if (trace_ || (traceInp_ != 0) || (traceOut_ != 0) || traceDma_ || traceInt_ || traceRegisters_ || traceFlags_ || traceIo_ || traceD_ || traceP_ || traceX_ || traceT_ || (numberOfBreakPoints_ > 0) || (numberOfTraps_ > 0) || (numberOfTregs_ > 0))
		updateDebugMenu(true);
	else
		updateDebugMenu(false);
}

void DebugWindow::onLog(wxCommandEvent& WXUNUSED(event))
{
//	wxSetWorkingDirectory (workingDir_);
	int num = 0;
	wxString fileName, number;

	fileName = wxFileSelector( "Select the log file to save",
                               debugDir_, "trace.log",
                               "log",
                               wxString::Format
                              (
                                   "Dump File (*.log)|*.log|All files (%s)|%s",
                                   wxFileSelectorDefaultWildcardStr,
                                   wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_SAVE|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );

	if (!fileName || fileName.empty())
		return;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	wxString name = FullPath.GetName();
	wxString path = FullPath.GetPath();
	wxString ext = FullPath.GetExt();

	while(wxFile::Exists(fileName))
	{
		num++;
		number.Printf("%d", num);
		fileName = path + pathSeparator_ + name + "." + number + "." + ext;
	}
	traceWindowPointer->SaveFile(fileName);
}

void DebugWindow::onDebugDisLog(wxCommandEvent& WXUNUSED(event))
{
//	wxSetWorkingDirectory (workingDir_);
	int num = 0;
	wxString fileName, number;

	fileName = wxFileSelector( "Select the log file to save",
                               debugDir_, "disassembler.log",
                               "log",
                               wxString::Format
                              (
                                   "Dump File (*.log)|*.log|All files (%s)|%s",
                                   wxFileSelectorDefaultWildcardStr,
                                   wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_SAVE|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );

	if (!fileName || fileName.empty())
		return;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	wxString name = FullPath.GetName();
	wxString path = FullPath.GetPath();
	wxString ext = FullPath.GetExt();

	while(wxFile::Exists(fileName))
	{
		num++;
		number.Printf("%d", num);
		fileName = path + pathSeparator_ + name + "." + number + "." + ext;
	}
	disassemblerWindowPointer->SaveFile(fileName);
}

void DebugWindow::onClear(wxCommandEvent& WXUNUSED(event))
{
	traceWindowPointer->Clear();
}

void DebugWindow::onTrace(wxCommandEvent& WXUNUSED(event))
{
	trace_ = !trace_;
	if (computerRunning_)
	{
		p_Computer->setTraceStatus(trace_);
		enableDebugGui(true);
	}
	SetDebugMode();
}

void DebugWindow::onTraceDma(wxCommandEvent& WXUNUSED(event))
{
	traceDma_ = !traceDma_;
	if (computerRunning_)
	{
		p_Computer->setDmaTraceStatus(traceDma_);
		enableDebugGui(true);
	}
	SetDebugMode();
}

void DebugWindow::onTraceInt(wxCommandEvent& WXUNUSED(event))
{
	traceInt_ = !traceInt_;
	if (computerRunning_)
	{
		p_Computer->setIntTraceStatus(traceInt_);
		enableDebugGui(true);
	}
	SetDebugMode();
}

void DebugWindow::onTraceInp(wxCommandEvent& WXUNUSED(event))
{
	for (int i=1; i<8; i++)
	{
		traceInp_[i] = XRCCTRL(*this,"InpList", wxListBox)->IsSelected(i-1);
	}

	if (computerRunning_)
	{
		p_Computer->setInpTraceStatus(traceInp_);
		enableDebugGui(true);
	}
	SetDebugMode();
}

void DebugWindow::onTraceOut(wxCommandEvent& WXUNUSED(event))
{
	for (int i=1; i<8; i++)
	{
		traceOut_[i] = XRCCTRL(*this,"OutList", wxListBox)->IsSelected(i-1);
	}

	if (computerRunning_)
	{
		p_Computer->setOutTraceStatus(traceOut_);
		enableDebugGui(true);
	}
	SetDebugMode();
}

void DebugWindow::onShowD(wxCommandEvent& WXUNUSED(event))
{
	traceD_ = !traceD_;
	enableDebugGui(true);
	SetDebugMode();
	resetDisplay();
}

void DebugWindow::onShowP(wxCommandEvent& WXUNUSED(event))
{
	traceP_ = !traceP_;
	enableDebugGui(true);
	SetDebugMode();
	resetDisplay();
}

void DebugWindow::onShowX(wxCommandEvent& WXUNUSED(event))
{
	traceX_ = !traceX_;
	enableDebugGui(true);
	SetDebugMode();
	resetDisplay();
}

void DebugWindow::onShowT(wxCommandEvent& WXUNUSED(event))
{
	traceT_ = !traceT_;
	enableDebugGui(true);
	SetDebugMode();
	resetDisplay();
}

void DebugWindow::onShowFlag(wxCommandEvent& WXUNUSED(event))
{
	traceFlags_ = !traceFlags_;
	enableDebugGui(true);
	SetDebugMode();
	resetDisplay();
}

void DebugWindow::onShowIo(wxCommandEvent& WXUNUSED(event))
{
	traceIo_ = !traceIo_;
	enableDebugGui(true);
	SetDebugMode();
	resetDisplay();
}

void DebugWindow::onShowReg(wxCommandEvent& WXUNUSED(event))
{
	traceRegisters_ = !traceRegisters_;
	enableDebugGui(true);
	SetDebugMode();
	resetDisplay();
}

void DebugWindow::onInt(wxCommandEvent& WXUNUSED(event))
{
	p_Computer->interrupt();
}

void DebugWindow::onBreakPointSet(wxCommandEvent&WXUNUSED(event))
{
	if (numberOfBreakPoints_ == 64)
	{
		(void)wxMessageBox( "Maximum number of Break Points set\n",
									"Emma 02", wxICON_ERROR | wxOK );
		return;
	}

	long breakPointAddress = get16BitValue("BreakPointAddress");
	if (breakPointAddress == -1)
	{
		(void)wxMessageBox( "No Break Point value specified\n",
									"Emma 02", wxICON_ERROR | wxOK );
		return;
	}

	breakPoints_[numberOfBreakPoints_] = breakPointAddress;
	addBreakPoint();
	SetDebugMode();
}

void DebugWindow::onTregSet(wxCommandEvent&WXUNUSED(event))
{
	wxString printBuffer, strValue;

	char reg = XRCCTRL(*this,"TregRegister",wxChoice)->GetCurrentSelection();

	if ((reg >= TREG_D) && (reg <= TREG_RF))
	{
		long tregValue = get16BitValue("TregValue");;
		if (tregValue == -1)
		{
			(void)wxMessageBox( "No Register Value value specified\n",
										"Emma 02", wxICON_ERROR | wxOK );
			return;
		}

		if (numberOfTregs_ == 64)
		{
			(void)wxMessageBox( "Maximum number of Register Traps set\n",
										"Emma 02", wxICON_ERROR | wxOK );
			return;
		}

		if ((reg >= TREG_R0) && (reg <= TREG_RF))
		{
			if (tregValue > 0xffff)
			{
				(void)wxMessageBox( "Please specify value of 16 bit max\n",
											"Emma 02", wxICON_ERROR | wxOK );
				return;
			}
		}
		else
		{
			if (reg <= TREG_T)
			{
				if (tregValue > 0xff)
				{
					(void)wxMessageBox( "Please specify value of 8 bit max\n",
												"Emma 02", wxICON_ERROR | wxOK );
					return;
				}
			}
			else
			{
				if (tregValue > 1)
				{
					(void)wxMessageBox( "Please specify value of 0 or 1\n",
												"Emma 02", wxICON_ERROR | wxOK );
					return;
				}
			}
		}

		tregs_[numberOfTregs_][0] = reg;
		tregs_[numberOfTregs_][1] = tregValue;
		addTreg();
		SetDebugMode();
	}
	else
	{
		(void)wxMessageBox( "No register specified\n",
									"Emma 02", wxICON_ERROR | wxOK );
	}

}

void DebugWindow::onTrapCommand(wxCommandEvent&event)
{
	int command = event.GetSelection();

	XRCCTRL(*this, "TrapValue", wxTextCtrl)->Enable(numberOfBytes[command] > 1);
	XRCCTRL(*this, "TrapRegister", wxChoice)->Enable(useRegister[command]);
}

void DebugWindow::onTrapSet(wxCommandEvent&WXUNUSED(event))
{
	if (numberOfTraps_ == 64)
	{
		(void)wxMessageBox( "Maximum number of Command Traps set\n",
									"Emma 02", wxICON_ERROR | wxOK );
		return;
	}

	int command = XRCCTRL(*this,"TrapCommand",wxChoice)->GetCurrentSelection();
	wxString strValue = XRCCTRL(*this,"TrapValue",wxTextCtrl)->GetValue();
	long trapValue;

	if ((command >= 0) && (command <= 80))
	{
		traps_[numberOfTraps_][0] = numberOfBytes[command];
		traps_[numberOfTraps_][1] = opCode[command];
		if (useRegister[command])
		{
			int registerValue = XRCCTRL(*this,"TrapRegister",wxChoice)->GetCurrentSelection();
			if ((registerValue >= 0) && (registerValue <= 0xf))
			{
				traps_[numberOfTraps_][1] |= registerValue;
			}
			else
			{
				(void)wxMessageBox( "Please specify Register\n",
											"Emma 02", wxICON_ERROR | wxOK );
				return;
			}
		}
		if ((opCode[command] == 0x61) || (opCode[command] == 0x69))
		{
			if (!strValue.ToLong(&trapValue))
			{
				(void)wxMessageBox( "Please specify value 1 to 7\n",
											"Emma 02", wxICON_ERROR | wxOK );
				return;
			}
			traps_[numberOfTraps_][0] = 1;
			if ((trapValue >= 1) && (trapValue <= 7))
			{
				traps_[numberOfTraps_][1] = traps_[numberOfTraps_][1] + trapValue - 1;
			}
			else
			{
				(void)wxMessageBox( "Please specify value 1 to 7\n",
											"Emma 02", wxICON_ERROR | wxOK );
				return;
			}
		}
		if (traps_[numberOfTraps_][0] == 2)
		{
			if (!strValue.ToLong(&trapValue, 16))
			{
				(void)wxMessageBox( "Please specify value in hexadecimal\n",
											"Emma 02", wxICON_ERROR | wxOK );
				return;
			}
			if (trapValue > 0xff)
			{
				(void)wxMessageBox( "Please specify value of 8 bit max\n",
											"Emma 02", wxICON_ERROR | wxOK );
				return;
			}
			else
			{
				traps_[numberOfTraps_][2] = trapValue;
			}
		}
		if (traps_[numberOfTraps_][0] == 3)
		{
			if (!strValue.ToLong(&trapValue, 16))
			{
				(void)wxMessageBox( "Please specify value in hexadecimal\n",
											"Emma 02", wxICON_ERROR | wxOK );
				return;
			}
			if (trapValue > 0xffff)
			{
				(void)wxMessageBox( "Please specify value of 16 bit max\n",
											"Emma 02", wxICON_ERROR | wxOK );
				return;
			}
			else
			{
				traps_[numberOfTraps_][2] = (trapValue >> 8) & 0xff;
				traps_[numberOfTraps_][3] = trapValue & 0xff;
			}
		}
	}
	else
	{
		(void)wxMessageBox( "No command specified\n",
									"Emma 02", wxICON_ERROR | wxOK );
		return;
	}
	addTrap();
	SetDebugMode();
}

void DebugWindow::D(wxCommandEvent&WXUNUSED(event))
{
	long value = get8BitValue("D");
	if (value == -1)  return;

	p_Computer->setAccumulator(value);
}

void DebugWindow::P(wxCommandEvent&WXUNUSED(event))
{
	long value = get8BitValue("P");
	if (value == -1)  return;


	p_Computer->setProgramCounter(value);
}

void DebugWindow::X(wxCommandEvent&WXUNUSED(event))
{
	long value = get8BitValue("X");
	if (value == -1)  return;

	p_Computer->setDataPointer(value);
}

void DebugWindow::T(wxCommandEvent&WXUNUSED(event))
{
	long value = get8BitValue("T");
	if (value == -1)  return;

	p_Computer->setRegisterT(value);
}

void DebugWindow::DF(wxCommandEvent&WXUNUSED(event))
{
	long value = getBitValue("DF");
	if (value == -1)  return;

	p_Computer->setDataFlag(value);
}

void DebugWindow::Q(wxCommandEvent&WXUNUSED(event))
{
	long value = getBitValue("Q");
	if (value == -1)  return;

	p_Computer->setFlipFlopQ(value);
}

void DebugWindow::IE(wxCommandEvent&WXUNUSED(event))
{
	long value = getBitValue("IE");
	if (value == -1)  return;

	p_Computer->setInterruptEnable(value);
}

void DebugWindow::R0(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R0");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(0, value);
}

void DebugWindow::R1(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R1");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(1, value);
}

void DebugWindow::R2(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R2");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(2, value);
}

void DebugWindow::R3(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R3");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(3, value);
}

void DebugWindow::R4(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R4");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(4, value);
}

void DebugWindow::R5(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R5");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(5, value);
}

void DebugWindow::R6(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R6");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(6, value);
}

void DebugWindow::R7(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R7");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(7, value);
}

void DebugWindow::R8(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R8");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(8, value);
}

void DebugWindow::R9(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R9");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(9, value);
}

void DebugWindow::RA(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R10");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(10, value);
}

void DebugWindow::RB(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R11");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(11, value);
}

void DebugWindow::RC(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R12");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(12, value);
}

void DebugWindow::RD(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R13");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(13, value);
}

void DebugWindow::RE(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R14");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(14, value);
}

void DebugWindow::RF(wxCommandEvent&WXUNUSED(event))
{
	long value = get16BitValue("R15");
	if (value == -1)  return;

	p_Computer->setScratchpadRegister(15, value);
}

void DebugWindow::O1(wxCommandEvent&WXUNUSED(event))
{
	long value = get8BitValue("O1");
	if (value == -1)  return;

	p_Computer->out(1, 0, value);
}

void DebugWindow::O2(wxCommandEvent&WXUNUSED(event))
{
	long value = get8BitValue("O2");
	if (value == -1)  return;

	p_Computer->out(2, 0, value);
}

void DebugWindow::O3(wxCommandEvent&WXUNUSED(event))
{
	long value = get8BitValue("O3");
	if (value == -1)  return;

	p_Computer->out(3, 0, value);
}

void DebugWindow::O4(wxCommandEvent&WXUNUSED(event))
{
	long value;

	if (runningComputer_ == COMX || runningComputer_ == CIDELSA || runningComputer_ ==  TMC600 || runningComputer_ == PECOM)
	{
		value = get16BitValue("O4");
		if (value == -1)  return;
		p_Computer->out(4, value, 0);
	}
	else
	{
		value = get8BitValue("O4");
		if (value == -1)  return;
		p_Computer->out(4, 0, value);
	}
}

void DebugWindow::O5(wxCommandEvent&WXUNUSED(event))
{
	long value;

	if (runningComputer_ == COMX || runningComputer_ == CIDELSA || runningComputer_ ==  TMC600 || runningComputer_ == PECOM)
	{
		value = get16BitValue("O5");
		if (value == -1)  return;
		p_Computer->out(5, value, 0);
	}
	else
	{
		value = get8BitValue("O5");
		if (value == -1)  return;
		p_Computer->out(5, 0, value);
	}
}

void DebugWindow::O6(wxCommandEvent&WXUNUSED(event))
{
	long value;

	if (runningComputer_ == COMX || runningComputer_ == CIDELSA || runningComputer_ ==  TMC600 || runningComputer_ == PECOM)
	{
		value = get16BitValue("O6");
		if (value == -1)  return;
		p_Computer->out(6, value, 0);
	}
	else
	{
		value = get8BitValue("O6");
		if (value == -1)  return;
		p_Computer->out(6, 0, value);
	}
}

void DebugWindow::O7(wxCommandEvent&WXUNUSED(event))
{
	long value;

	if (runningComputer_ == COMX || runningComputer_ == CIDELSA || runningComputer_ ==  TMC600 || runningComputer_ == PECOM)
	{
		value = get16BitValue("O7");
		if (value == -1)  return;
		p_Computer->out(7, value, 0);
	}
	else
	{
		value = get8BitValue("O7");
		if (value == -1)  return;
		p_Computer->out(7, 0, value);
	}
}

void DebugWindow::onProtectedMode(wxCommandEvent&event)
{
	protectedMode_ = event.IsChecked();
	enableDebugGui(true);
}


void DebugWindow::onDebugDisplayPageSpinUp(wxSpinEvent&WXUNUSED(event))
{
	long address = get16BitValue("DebugDisplayPage");
	if (address == -1)  return;

	address += 0x100;
	Word ramMask = getAddressMask();

	if (memoryDisplay_ == V_6847_RAM)
	{
		while (address >= ((ramMask+1)*2)) 
			address -=  ((ramMask + 1)*2);
	}
	else
	{
		while (address > ramMask)  
			address -=  (ramMask + 1);
	}

	wxString addressStr;
	addressStr.Printf("%04X", (unsigned int)address);
	XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->SetValue(addressStr);

	memoryDisplay();
}

void DebugWindow::onDebugDisplayPageSpinDown(wxSpinEvent&WXUNUSED(event))
{
	long address = get16BitValue("DebugDisplayPage");
	if (address == -1)  return;

	address -= 0x100;
	Word ramMask = getAddressMask();

	if (memoryDisplay_ == V_6847_RAM)
	{
		while (address < 0)  
			address +=  ((ramMask + 1)*2);
	}
	else
	{
		while (address < 0)  
			address +=  (ramMask + 1);
	}

	wxString addressStr;
	addressStr.Printf("%04X", (unsigned int)address);
	XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->SetValue(addressStr);

	memoryDisplay();
}

void DebugWindow::onDebugDisplayPage(wxCommandEvent&WXUNUSED(event))
{
	memoryDisplay();
}

void DebugWindow::DebugDisplayPage()
{
	if (!computerRunning_)
	{
		if (xmlLoaded_)
			XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("No emulation running");
		return;
	}

	long start = get16BitValue("DebugDisplayPage");
	if (start == -1)  return;

	Word ramMask = getAddressMask();
	while (start > ramMask)  
		start -=  (ramMask + 1);

	XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("");

	switch (runningComputer_)
	{
		case COMX:
			XRCCTRL(*this, "DebugExpansionSlot", wxSpinCtrl)->SetValue(p_Comx->getComxExpansionSlot()+1);
			XRCCTRL(*this, "DebugExpansionRam", wxSpinCtrl)->SetValue(p_Comx->getComxExpansionRamBank());
			XRCCTRL(*this, "DebugExpansionEprom", wxSpinCtrl)->SetValue(p_Comx->getComxExpansionEpromBank());
		break;

		case ELF:
		case ELFII:
		case SUPERELF:
			if (elfConfiguration[runningComputer_].useEms)
			{
				if ((start > 0x7f00) && (start < 0xc000))
				{
					XRCCTRL(*this, "DebugEmsPage", wxSpinCtrl)->SetValue(p_Computer->getEmsPage());
				}
			}
		break;
	}

	wxString idReference, value;

	for (int x=0; x<16; x++)
	{
		idReference.Printf("TOP_HEADER%01X", x);
		value.Printf("  %01X", (unsigned int)(start+x)&0xf);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);
	}
	for (int y=0; y<16; y++)
	{
		idReference.Printf("MEM_HEADER%01X", y);
		XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(*wxBLACK);
		switch (p_Computer->getMemoryType(start/256))
		{
			case COMXEXPBOX:
				XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(wxColour(0x80, 0x80, 0xff));
			break;

			case EMSMEMORY:
				XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(wxColour(0xc8, 0xb4, 0x3e));
			break;

			case PAGER:
				if (((start>>12)&0xf) == portExtender_)
					XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(wxColour(0xa9, 0x3e, 0xac));
			break;
		}

		value.Printf("%04X", (unsigned int)start);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);

		ShowCharacters(start, y);
		for (int x=0; x<16; x++)
		{
			idReference.Printf("MEM%01X%01X", y, x);
			value.Printf("%02X", p_Computer->readMem(start));

			XRCCTRL(*this, idReference, wxTextCtrl)->SetForegroundColour(*wxBLACK);
			if (p_Computer->getMemoryType(start/256) == COMXEXPBOX)
			{
					if (p_Computer->getExpansionMemoryType(p_Comx->getComxExpansionSlot(), (start&0x1fff)/256) == RAMBANK)
						XRCCTRL(*this, idReference, wxTextCtrl)->SetForegroundColour(wxColour(0x45, 0xac, 0x22));
					if (p_Computer->getExpansionMemoryType(p_Comx->getComxExpansionSlot(), (start&0x1fff)/256) == EPROMBANK)
						XRCCTRL(*this, idReference, wxTextCtrl)->SetForegroundColour(wxColour(0x80, 0x00, 0x40));
			}

			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue("");
			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue(value);

			start++;
			while (start > ramMask)  
				start -=  (ramMask + 1);
		}
	}
}

void DebugWindow::ShowCharacters(Word address, int y)
{
	wxString idReference;
	idReference.Printf("CHAR%01X", y);

	wxBitmap line(128, 16, 24);
	wxMemoryDC dcLine, dcChar;

	int t;
	char bits [9];

	dcLine.SelectObject(line);
#if defined(__WXGTK__)
	dcLine.SetPen(wxPen(wxColour(0xfb, 0xf8, 0xf1)));
	dcLine.SetBrush(wxBrush(wxColour(0xfb, 0xf8, 0xf1)));
#else
	dcLine.SetPen(*wxWHITE_PEN);
	dcLine.SetBrush(*wxWHITE_BRUSH);
#endif
	dcLine.DrawRectangle(0, 0, 128, 16);

	wxFont exactFont(8, wxFONTFAMILY_TELETYPE, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);

	for (int j=0; j<16; j++)
	{
		if ((runningComputer_ == COMX) || (runningComputer_ == TMC600) || (runningComputer_ == PECOM))
		{
			for (int i=0; i<9; i++)
			{
				if (runningComputer_ == COMX)
					t = p_Comx->readCramDirect((debugReadMem(address+j)&0x7f)*16+i);
				else if (runningComputer_ == TMC600)
					t = p_Tmc600->readCramDirect((debugReadMem(address+j)&0xff)*16+i);
				else
					t = p_Pecom->readCramDirect((debugReadMem(address+j)&0x7f)*16+i);
				bits[i] = (t & 0x1) << 5;
				bits[i] |= (t & 0x2) << 3;
				bits[i] |= (t & 0x4) << 1;
				bits[i] |= (t & 0x8) >> 1;
				bits[i] |= (t & 0x10) >> 3;
				bits[i] |= (t & 0x20) >> 5;
			}
			wxBitmap character(bits, 6, 9, 1);
			dcChar.SelectObject(character);
			dcLine.Blit(j*8+1, 5, 6, 9, &dcChar, 0, 0, wxAND);
			dcChar.SelectObject(wxNullBitmap);
		}
		else
		{
			wxString character;
			character.Printf("%C", debugReadMem(address+j)&0x7f);
			dcLine.SetFont(exactFont);
			dcLine.DrawText(character, j*8, 0);
		}
	}

	dcLine.SelectObject(wxNullBitmap);
	XRCCTRL(*this, idReference, wxStaticBitmap)->SetForegroundColour(*wxBLACK);
	XRCCTRL(*this, idReference, wxStaticBitmap)->SetBitmap(line);
}

void DebugWindow::DebugDisplayMap()
{
	if (!computerRunning_)
	{
		if (xmlLoaded_)
			XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("No emulation running");
		return;
	}

	wxString idReference, idReference2, value;
	bool textGreen, textOrange;

	XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("");

	switch (runningComputer_)
	{
		case COMX:
			XRCCTRL(*this, "DebugExpansionSlot", wxSpinCtrl)->SetValue(p_Comx->getComxExpansionSlot()+1);
			XRCCTRL(*this, "DebugExpansionRam", wxSpinCtrl)->SetValue(p_Comx->getComxExpansionRamBank());
			XRCCTRL(*this, "DebugExpansionEprom", wxSpinCtrl)->SetValue(p_Comx->getComxExpansionEpromBank());
		break;

		case ELF:
		case ELFII:
		case SUPERELF:
			if (elfConfiguration[runningComputer_].useEms)
				XRCCTRL(*this, "DebugEmsPage", wxSpinCtrl)->SetValue(p_Computer->getEmsPage());
		break;
	}

	for (int x=0; x<16; x++)
	{
		idReference.Printf("TOP_HEADER%01X", x);
		value.Printf("  %01X", x);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);
	}
	for (int y=0; y<16; y++)
	{
		idReference.Printf("MEM_HEADER%01X", y);
		value.Printf("%04X", y*4096);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);
		XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(*wxBLACK);

		for (int x=0; x<16; x++)
		{
			textGreen = false;
			textOrange = false;
			switch (p_Computer->getMemoryType((y<<4)+x))
			{
				case UNDEFINED:
					value.Printf (" ");
				break;

				case RAM:
					value.Printf (".");
				break;

				case MAPPEDRAM:
					value.Printf ("M.");
				break;

				case VP570RAM:
					value.Printf ("E.");
				break;

				case COLOURRAM:
					value.Printf ("C.");
				break;

				case COMXEXPROM:
				case ROM:
					value.Printf ("R");
				break;

				case CARTRIDGEROM:
				case CRAM1870:
					value.Printf ("CR");
				break;

				case PRAM1870:
					value.Printf ("PR");
				break;

				case COMXEXPBOX:
					XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(wxColour(0x80, 0x80, 0xff));
					switch (p_Computer->getExpansionMemoryType(p_Comx->getComxExpansionSlot(), (y&1)*16+x))
					{
						case MC6845RAM:
							value.Printf ("M5");
						break;

						case MC6845REGISTERS:
							value.Printf ("MR");
						break;

						case RAMBANK:
							textGreen = true;
							switch (p_Computer->getBankMemoryType(XRCCTRL(*this, "DebugExpansionRam", wxSpinCtrl)->GetValue(), (y&1)*16+x))
							{
								case RAM:
									value.Printf (".");
								break;

								case ROM:
									value.Printf ("R");
								break;

								case UNDEFINED:
									value.Printf (" ");
								break;

								default:
									value.Printf ("xx");
								break;
							}
						break;

						case EPROMBANK:
							textOrange = true;
							switch (p_Computer->getEpromBankMemoryType(XRCCTRL(*this, "DebugExpansionEprom", wxSpinCtrl)->GetValue(), (y&1)*16+x))
							{
								case RAM:
									value.Printf (".");
								break;

								case ROM:
									value.Printf ("R");
								break;

								case UNDEFINED:
									value.Printf (" ");
								break;

								default:
									value.Printf ("xx");
								break;
							}
						break;

						case RAM:
							value.Printf (".");
						break;

						case ROM:
							value.Printf ("R");
						break;

						case UNDEFINED:
							value.Printf (" ");
						break;

						default:
							value.Printf ("xx");
						break;
					}
				break;

				case COPYFLOPROM:
					value.Printf ("CF");
				break;

				case COPYCOMXEXPROM:
					value.Printf ("CE");
				break;

				case EMSMEMORY:
					XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(wxColour(0xc8, 0xb4, 0x3e));

					switch (p_Computer->getEmsMemoryType((y&3)*16+x))
					{
						case RAM:
							value.Printf (".");
						break;

						case ROM:
							value.Printf ("R");
						break;

						case UNDEFINED:
							value.Printf (" ");
						break;

						default:
							value.Printf ("xx");
						break;
					}
				break;

				case PAGER:
					if (y == portExtender_)
						XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(wxColour(0xa9, 0x3e, 0xac));
					switch (p_Computer->getPagerMemoryType(y*16+x))
					{
						case RAM:
							value.Printf (".");
						break;

						case ROM:
							value.Printf ("R");
						break;

						case UNDEFINED:
							value.Printf (" ");
						break;

						default:
							value.Printf ("xx");
						break;
					}
				break;

				case MC6847RAM:
					value.Printf ("M7");
				break;

				case MC6845RAM:
					value.Printf ("M5");
				break;

				case MC6845REGISTERS:
					value.Printf ("MR");
				break;

				default:
					value.Printf ("xx");
				break;
			}
			idReference2.Printf("MEM%01X%01X", y, x);
			XRCCTRL(*this, idReference2, wxTextCtrl)->ChangeValue("");
			XRCCTRL(*this, idReference2, wxTextCtrl)->ChangeValue(value);
			if (textGreen)
				XRCCTRL(*this, idReference2, wxTextCtrl)->SetForegroundColour(wxColour(0x45, 0xac, 0x22));
			else
			{
				if (textOrange)
					XRCCTRL(*this, idReference2, wxTextCtrl)->SetForegroundColour(wxColour(0x80, 0x00, 0x40));
				else
					XRCCTRL(*this, idReference2, wxTextCtrl)->SetForegroundColour(*wxBLACK);
			}
		}

		idReference.Printf("CHAR%01X", y);
		wxBitmap line(128, 16, 24);
		wxMemoryDC dcLine;

		dcLine.SelectObject(line);
#if defined(__WXGTK__)
	dcLine.SetPen(wxPen(wxColour(0xfb, 0xf8, 0xf1)));
	dcLine.SetBrush(wxBrush(wxColour(0xfb, 0xf8, 0xf1)));
#else
	dcLine.SetPen(*wxWHITE_PEN);
	dcLine.SetBrush(*wxWHITE_BRUSH);
#endif
		dcLine.DrawRectangle(0, 0, 128, 16);

		dcLine.SelectObject(wxNullBitmap);
		XRCCTRL(*this, idReference, wxStaticBitmap)->SetBitmap(line);
	}
}

void DebugWindow::DebugDisplay1870VideoRam()
{
	if (!(runningComputer_ == COMX || runningComputer_ == CIDELSA || runningComputer_ ==  TMC600 || runningComputer_ == PECOM))
	{
		if (xmlLoaded_)
			XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("CDP 1870 not running");
		return;
	}

	long start = get16BitValue("DebugDisplayPage");
	if (start == -1)  return;

	wxString idReference, value;

	Word ramMask = getAddressMask();
	while (start > ramMask)  
		start -=  (ramMask + 1);

	XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("");

	value.Printf("%04X", (unsigned int)start);
	XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->ChangeValue(value);

	for (int x=0; x<16; x++)
	{
		idReference.Printf("TOP_HEADER%01X", x);
		value.Printf("  %01X", (unsigned int)(start+x)&0xf);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);
	}
	for (int y=0; y<16; y++)
	{
		idReference.Printf("MEM_HEADER%01X", y);
		XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(*wxBLACK);

		value.Printf("%04X", (unsigned int)start);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);

		ShowCharacters(start, y);
		for (int x=0; x<16; x++)
		{
			idReference.Printf("MEM%01X%01X", y, x);
			value.Printf("%02X", debugReadMem(start));

			XRCCTRL(*this, idReference, wxTextCtrl)->SetForegroundColour(*wxBLACK);

			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue("");
			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue(value);

			start++;
			while (start > ramMask)  
			start -=  (ramMask + 1);
		}
	}
}

void DebugWindow::DebugDisplay1864ColorRam()
{
	if (!(runningComputer_ == TMC2000 || runningComputer_ == VIP || runningComputer_ ==  ETI))
	{
		if (xmlLoaded_)
			XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("1864 Color RAM not used");
		return;
	}

	long start = get16BitValue("DebugDisplayPage");
	if (start == -1)  return;

	wxString idReference, value;

	Word ramMask = getAddressMask();
	while (start > ramMask)  
		start -=  (ramMask + 1);

	XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("");

	value.Printf("%04X", (unsigned int)start);
	XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->ChangeValue(value);

	for (int x=0; x<16; x++)
	{
		idReference.Printf("TOP_HEADER%01X", x);
		value.Printf("  %01X", (unsigned int)((start+x)&0xf));
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);
	}
	for (int y=0; y<16; y++)
	{
		idReference.Printf("MEM_HEADER%01X", y);
		XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(*wxBLACK);

		value.Printf("%04X", (unsigned int)start);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);

		ShowCharacters(start, y);
		for (int x=0; x<16; x++)
		{
			idReference.Printf("MEM%01X%01X", y, x);
			value.Printf("%02X", debugReadMem(start));

			XRCCTRL(*this, idReference, wxTextCtrl)->SetForegroundColour(*wxBLACK);

			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue("");
			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue(value);

			start++;
			while (start > ramMask)  
			start -=  (ramMask + 1);
		}
	}
}

void DebugWindow::DebugDisplay6845CharRom()
{
	switch (runningComputer_)
	{
		case COMX:
		break;

		case ELF:
		case ELFII:
		case SUPERELF:
			if (!(elfConfiguration[runningComputer_].use6845 || elfConfiguration[runningComputer_].useS100))  
			{
				XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("MC6845 not running");
				return;
			}
		break;

		default:
			if (xmlLoaded_)
				XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("MC6845 not running");
			return;
		break;
	}

	long start = get16BitValue("DebugDisplayPage");
	if (start == -1)  return;

	wxString idReference, value;

	Word ramMask = getAddressMask();
	while (start > ramMask)  
		start -=  (ramMask + 1);

	XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("");

	value.Printf("%04X", (unsigned int)start);
	XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->ChangeValue(value);

	for (int x=0; x<16; x++)
	{
		idReference.Printf("TOP_HEADER%01X", x);
		value.Printf("  %01X", (unsigned int)((start+x)&0xf));
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);
	}
	for (int y=0; y<16; y++)
	{
		idReference.Printf("MEM_HEADER%01X", y);
		XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(*wxBLACK);

		value.Printf("%04X", (unsigned int)start);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);

		ShowCharacters(start, y);
		for (int x=0; x<16; x++)
		{
			idReference.Printf("MEM%01X%01X", y, x);
			value.Printf("%02X", debugReadMem(start));

			XRCCTRL(*this, idReference, wxTextCtrl)->SetForegroundColour(*wxBLACK);

			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue("");
			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue(value);

			start++;
			while (start > ramMask)  
			start -=  (ramMask + 1);
		}
	}
}

void DebugWindow::DebugDisplay8275CharRom()
{
	switch (runningComputer_)
	{
		case ELF:
		case ELFII:
		case SUPERELF:
		case ELF2K:
			if (!elfConfiguration[runningComputer_].use8275)  
			{
				XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("Intel 8275 not running");
				return;
			}
		break;

		default:
			XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("Intel 8275 not running");
			return;
		break;
	}

	long start = get16BitValue("DebugDisplayPage");
	if (start == -1)  return;

	wxString idReference, value;

	Word ramMask = getAddressMask();
	while (start > ramMask)  
		start -=  (ramMask + 1);

	XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("");

	value.Printf("%04X", (unsigned int)start);
	XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->ChangeValue(value);

	for (int x=0; x<16; x++)
	{
		idReference.Printf("TOP_HEADER%01X", x);
		value.Printf("  %01X", (unsigned int)((start+x)&0xf));
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);
	}
	for (int y=0; y<16; y++)
	{
		idReference.Printf("MEM_HEADER%01X", y);
		XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(*wxBLACK);

		value.Printf("%04X", (unsigned int)start);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);

		ShowCharacters(start, y);
		for (int x=0; x<16; x++)
		{
			idReference.Printf("MEM%01X%01X", y, x);
			value.Printf("%02X", debugReadMem(start));

			XRCCTRL(*this, idReference, wxTextCtrl)->SetForegroundColour(*wxBLACK);

			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue("");
			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue(value);

			start++;
			while (start > ramMask)  
			start -=  (ramMask + 1);
		}
	}
}

void DebugWindow::DebugDisplay6847CharRom()
{
	switch (runningComputer_)
	{
		case ELF:
		case ELFII:
		case SUPERELF:
			if (!elfConfiguration[runningComputer_].use6847)
			{
				XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("MC6847 not running");
				return;
			}
		break;

		default:
			if (xmlLoaded_)
				XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("MC6847 not running");
			return;
		break;
	}

	long start = get16BitValue("DebugDisplayPage");
	if (start == -1)  return;

	wxString idReference, value;

	Word ramMask = getAddressMask();
	while (start > ramMask)  
		start -=  (ramMask + 1);

	if (start < 0x200)
		XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("Showing: Internal Rom");
	else
		XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("Showing: External Rom");

	value.Printf("%04X", (unsigned int)start);
	XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->ChangeValue(value);

	for (int x=0; x<16; x++)
	{
		idReference.Printf("TOP_HEADER%01X", x);
		value.Printf("  %01X", (unsigned int)((start+x)&0xf));
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);
	}
	for (int y=0; y<16; y++)
	{
		idReference.Printf("MEM_HEADER%01X", y);
		XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(*wxBLACK);

		value.Printf("%04X", (unsigned int)start);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);

		ShowCharacters(start, y);
		for (int x=0; x<16; x++)
		{
			idReference.Printf("MEM%01X%01X", y, x);
			value.Printf("%02X", debugReadMem(start));

			XRCCTRL(*this, idReference, wxTextCtrl)->SetForegroundColour(*wxBLACK);

			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue("");
			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue(value);

			start++;
			while (start > ramMask)  
			start -=  (ramMask + 1);
		}
	}
}

void DebugWindow::DebugDisplay6847VideoRam()
{
	switch (runningComputer_)
	{
		case ELF:
		case ELFII:
		case SUPERELF:
			if (!elfConfiguration[runningComputer_].use6847)
			{
				XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("MC6847 not running");
				return;
			}
		break;

		default:
			if (xmlLoaded_)
				XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("MC6847 not running");
			return;
		break;
	}

	long start = get16BitValue("DebugDisplayPage");
	if (start == -1)  return;

	wxString idReference, value;

	Word ramMask = getAddressMask();
	while (start >= ((ramMask+1)*2)) 
		start -=  ((ramMask+1)*2);

	if (start <= ramMask)
		XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("Showing: Bit 0 to 7");
	else
		XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("Showing: Bit 8 to 11");

	value.Printf("%04X", (unsigned int)start);
	XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->ChangeValue(value);

	for (int x=0; x<16; x++)
	{
		idReference.Printf("TOP_HEADER%01X", x);
		value.Printf("  %01X", (unsigned int)((start+x)&0xf));
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);
	}
	for (int y=0; y<16; y++)
	{
		idReference.Printf("MEM_HEADER%01X", y);
		XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(*wxBLACK);

		value.Printf("%04X", (unsigned int)start);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);

		ShowCharacters(start, y);
		for (int x=0; x<16; x++)
		{
			idReference.Printf("MEM%01X%01X", y, x);
			if (start <= ramMask)
				value.Printf("%02X", debugReadMem(start));
			else
				value.Printf("%01X", debugReadMem(start));

			XRCCTRL(*this, idReference, wxTextCtrl)->SetForegroundColour(*wxBLACK);

			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue("");
			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue(value);

			start++;
			while (start >= ((ramMask+1)*2))  
				start -=  ((ramMask+1)*2);
		}
	}
}

void DebugWindow::DebugDisplayTmsRam()
{
	switch (runningComputer_)
	{
		case ELF:
		case ELFII:
		case SUPERELF:
			if (!elfConfiguration[runningComputer_].useTMS9918)
			{
				XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("TMS 9918 not running");
				return;
			}
		break;

		default:
			if (xmlLoaded_)
				XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("TMS 9918 not running");
			return;
		break;
	}

	long start = get16BitValue("DebugDisplayPage");
	if (start == -1)  return;

	wxString idReference, value;

	Word ramMask = getAddressMask();
	while (start > ramMask)  
		start -=  (ramMask + 1);

	XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("");

	value.Printf("%04X", (unsigned int)start);
	XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->ChangeValue(value);

	for (int x=0; x<16; x++)
	{
		idReference.Printf("TOP_HEADER%01X", x);
		value.Printf("  %01X", (unsigned int)((start+x)&0xf));
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);
	}
	for (int y=0; y<16; y++)
	{
		idReference.Printf("MEM_HEADER%01X", y);
		XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(*wxBLACK);

		value.Printf("%04X", (unsigned int)start);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);

		ShowCharacters(start, y);
		for (int x=0; x<16; x++)
		{
			idReference.Printf("MEM%01X%01X", y, x);

			switch(runningComputer_)
			{
				case ELF:
					value.Printf("%02X", p_Elf->getTmsMemory(start));
				break;

				case ELFII:
					value.Printf("%02X", p_Elf2->getTmsMemory(start));
				break;

				case SUPERELF:
					value.Printf("%02X", p_Super->getTmsMemory(start));
				break;
			}

			XRCCTRL(*this, idReference, wxTextCtrl)->SetForegroundColour(*wxBLACK);

			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue("");
			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue(value);

			start++;
			while (start > ramMask)  
			start -=  (ramMask + 1);
		}
	}
}

void DebugWindow::DebugDisplayVtRam()
{
	switch (runningComputer_)
	{
		case ELF:
		case ELFII:
		case ELF2K:
		case COSMICOS:
		case SUPERELF:
			if (!elfConfiguration[runningComputer_].vtType != VTNONE)
			{
				XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("VT not running");
				return;
			}
		break;

		default:
			if (xmlLoaded_)
				XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("VT not running");
			return;
		break;
	}

	long start = get16BitValue("DebugDisplayPage");
	if (start == -1)  return;

	wxString idReference, value;

	Word ramMask = getAddressMask();
	while (start > ramMask)  
		start -=  (ramMask + 1);

	XRCCTRL(*this, "MEM_Message", wxStaticText)->SetLabel("");

	value.Printf("%04X", (unsigned int)start);
	XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->ChangeValue(value);

	for (int x=0; x<16; x++)
	{
		idReference.Printf("TOP_HEADER%01X", x);
		value.Printf("  %01X", (unsigned int)((start+x)&0xf));
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);
	}
	for (int y=0; y<16; y++)
	{
		idReference.Printf("MEM_HEADER%01X", y);
		XRCCTRL(*this, idReference, wxStaticText)->SetForegroundColour(*wxBLACK);

		value.Printf("%04X", (unsigned int)start);
		XRCCTRL(*this, idReference, wxStaticText)->SetLabel(value);

		ShowCharacters(start, y);
		for (int x=0; x<16; x++)
		{
			idReference.Printf("MEM%01X%01X", y, x);

			value.Printf("%02X", p_Vt100->getVtMemory(start));

			XRCCTRL(*this, idReference, wxTextCtrl)->SetForegroundColour(*wxBLACK);

			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue("");
			XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue(value);

			start++;
			while (start > ramMask)  
			start -=  (ramMask + 1);
		}
	}
}

void DebugWindow::onEditMemory(wxCommandEvent&event)
{
	long address, value;
	wxString addressStr, strValue;

	if (!computerRunning_)
	{
		(void)wxMessageBox( "Memory edit not possible as no machine is running\n",
									"Emma 02", wxICON_ERROR | wxOK );
		return;
	}

	int id = event.GetId() - 0x1000;
	wxString idReference;
	idReference.Printf("MEM%02X", id);

	switch (memoryDisplay_)
	{
		case CPU_TYPE:
			strValue = XRCCTRL(*this, idReference, wxTextCtrl)->GetValue();
			strValue.MakeUpper();
			if (strValue != " ")
			{
				strValue.Trim(false);
				strValue.Trim(true);
			}

			if (strValue == "R")
				setMemoryType(id, ROM);
			else if (strValue == ".")
				setMemoryType(id, RAM);
			else if (strValue == "M.")
				setMemoryType(id, MAPPEDRAM);
			else if (strValue == "E.")
				setMemoryType(id, VP570RAM);
			else if (strValue == "C.")
				setMemoryType(id, COLOURRAM);
			else if (strValue == " ")
				setMemoryType(id, UNDEFINED);
			else if (strValue == "")
				setMemoryType(id, UNDEFINED);
			else if (strValue == "CR")
				setMemoryType(id, CRAM1870);
			else if (strValue == "PR")
				setMemoryType(id, PRAM1870);
			else if (strValue == "M7")
				setMemoryType(id, MC6847RAM);
			else if (strValue == "M5")
				setMemoryType(id, MC6845RAM);
			else if (strValue == "MR")
				setMemoryType(id, MC6845REGISTERS);
			else if (strValue == "CF")
				setMemoryType(id, COPYFLOPROM);
			else if (strValue == "CE")
				setMemoryType(id, COPYCOMXEXPROM);
			else if (strValue == "P")
				setMemoryType(id, UNDEFINED);
			else if (strValue == "C")
				setMemoryType(id, UNDEFINED);
			else if (strValue == "E")
				setMemoryType(id, UNDEFINED);
			else if (strValue == "M")
				setMemoryType(id, UNDEFINED);
			else
			{
				(void)wxMessageBox( 	"Please use one of the following codes:\n"
										"space = UNDEFINED\n"
										". = RAM\n"
										"R = ROM\n"
										"M. = Mapped RAM\n"
										"E. = VP570 Expansion RAM\n"
										"PR = 1870 Page RAM\n"
										"CR = 1870 Character RAM\n"
										"M7 = MC6847 Video RAM\n"
										"M5 = MC6845 Video RAM\n"
										"MR = MC6845 Register\n"
										"CE = COMX Expansion ROM copy\n"
										"CF = COMX Floppy disk ROM copy\n"
										"C. = Victory or Vip Colour RAM access\n"
										"\nNote: some options are only allowed\n"
										"in specific cases.\n",
											"Emma 02", wxICON_ERROR | wxOK );
				return;
			}

			addressStr.Printf("%04X", id*256);
			XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->ChangeValue(addressStr);
		break;

		case CPU_MEMORY:
		case CDP_1870_C:
		case CDP_1870_P:
		case TMS_MEMORY:
		case VT_RAM:
		case CDP_1864:
		case V_6845:
		case I_8275:
		case V_6847:
		case V_6847_RAM:
			address = get16BitValue("DebugDisplayPage");
			if (address == -1)  return;

			value = get8BitValue(idReference);
			if (value == -1)  return;

			address += id;
			debugWriteMem(address, value);

			ShowCharacters(address-(id&0xf), (int)(id/16));
		break;
	}
}

void DebugWindow::setMemoryType(int id, int setType)
{
	switch (runningComputer_)
	{
		case COMX:
			if ((setType == RAM) || (setType == ROM) || (setType == UNDEFINED) || (setType == CRAM1870) || (setType == PRAM1870)|| (setType == COMXEXPBOX) || (setType == MC6845RAM) || (setType == MC6845REGISTERS) || (setType == COPYFLOPROM) || (setType == COPYCOMXEXPROM))
			{
				if (((setType == MC6845RAM) || (setType == MC6845REGISTERS)) && !p_Comx->isColumnRomLoaded())
				{
					(void)wxMessageBox( "No 80 column card configured\n",
												"Emma 02", wxICON_ERROR | wxOK );
					return;
				}
				if (p_Computer->getMemoryType(id) == COMXEXPBOX)
				{
					if (p_Computer->getExpansionMemoryType(XRCCTRL(*this, "DebugExpansionSlot", wxSpinCtrl)->GetValue()-1, id&0x1f) == RAMBANK)
					{
						if ((setType == RAM) || (setType == ROM) || (setType == UNDEFINED))
							p_Computer->defineBankMemoryType(XRCCTRL(*this, "DebugExpansionRam", wxSpinCtrl)->GetValue(), (id&0x1f)*256, setType);
						else
						{
							(void)wxMessageBox( "Only RAM (.), ROM (R) or UNDEFINED (space) allowed in 32K RAM Card\n",
														"Emma 02", wxICON_ERROR | wxOK );
						}
					}
					else
					{
						if (p_Computer->getExpansionMemoryType(XRCCTRL(*this, "DebugExpansionSlot", wxSpinCtrl)->GetValue()-1, id&0x1f) == EPROMBANK)
						{
							if ((setType == RAM) || (setType == ROM) || (setType == UNDEFINED))
								p_Computer->defineEpromBankMemoryType(XRCCTRL(*this, "DebugExpansionEprom", wxSpinCtrl)->GetValue(), (id&0x1f)*256, setType);
							else
							{
								(void)wxMessageBox( "Only RAM (.), ROM (R) or UNDEFINED (space) allowed in 32K RAM Card\n",
															"Emma 02", wxICON_ERROR | wxOK );
							}
						}
						else
						{
							if ((setType == RAM) || (setType == ROM) || (setType == UNDEFINED) || (setType == MC6845RAM) || (setType == MC6845REGISTERS))
								p_Computer->defineExpansionMemoryType(p_Comx->getComxExpansionSlot(), (id&0x1f)*256, setType);
							else
							{
								(void)wxMessageBox( "Only RAM (.), ROM (R), MC6845 (MR/M5) or UNDEFINED (space) allowed in COMX Expansion Slot\n",
															"Emma 02", wxICON_ERROR | wxOK );
							}
						}
					}
				}
				else
					p_Computer->defineMemoryType(id*256, setType);
			}
			else
			{
				(void)wxMessageBox( "Only RAM (.), ROM (R), CDP1870 (PR/CR), MC6845 (MR/M5), ROM Copy (CF/CE) or UNDEFINED (space) allowed in COMX emulation\n",
											"Emma 02", wxICON_ERROR | wxOK );
			}
		break;

		case ELF:
		case ELFII:
		case SUPERELF:
			if ((setType == RAM) || (setType == ROM) || (setType == UNDEFINED) || (setType == MC6847RAM) || (setType == MC6845RAM) || (setType == MC6845REGISTERS) )
			{
				if (!(elfConfiguration[runningComputer_].use6845 || elfConfiguration[runningComputer_].useS100) && ((setType == MC6845RAM) || (setType == MC6845REGISTERS)))
				{
					(void)wxMessageBox( "No MC6845 configured\n",
												"Emma 02", wxICON_ERROR | wxOK );
					return;
				}
				if (!elfConfiguration[runningComputer_].use6847 && (setType == MC6847RAM))
				{
					(void)wxMessageBox( "No MC6847 configured\n",
												"Emma 02", wxICON_ERROR | wxOK );
					return;
				}
				if (p_Computer->getMemoryType(id) == EMSMEMORY)
				{
					if ((setType == RAM) || (setType == ROM) || (setType == UNDEFINED))
						p_Computer->defineEmsMemoryType((id&0x3f)*256, setType);
					else
					{
						(void)wxMessageBox( "Only RAM (.), ROM (R), or UNDEFINED (space) allowed in EMS Memory bank\n",
													"Emma 02", wxICON_ERROR | wxOK );
					}
				}
				else if (p_Computer->getMemoryType(id) == PAGER)
				{
					if ((setType == RAM) || (setType == ROM) || (setType == UNDEFINED))
						p_Computer->definePagerMemoryType(id*256, setType);
					else
					{
						(void)wxMessageBox( "Only RAM (.), ROM (R), or UNDEFINED (space) allowed in Pager Memory\n",
													"Emma 02", wxICON_ERROR | wxOK );
					}
				}
				else
					p_Computer->defineMemoryType(id*256, setType);
			}
			else
			{
				(void)wxMessageBox( "Only RAM (.), ROM (R), MC6845 (M5/MR), MC6847 (M7) or UNDEFINED (space) allowed in Elf emulation\n",
											"Emma 02", wxICON_ERROR | wxOK );
			}
		break;

		case CIDELSA:
		case TMC600:
		case PECOM:
			if ((setType == RAM) || (setType == ROM) || (setType == UNDEFINED) || (setType == CRAM1870)|| (setType == PRAM1870))
				p_Computer->defineMemoryType(id*256, setType);
			else
			{
				(void)wxMessageBox( "Only RAM (.), ROM (R), CDP1870 (PR/CR) or UNDEFINED (space) allowed in "+computerInfo[runningComputer_].name+" emulation\n",
											"Emma 02", wxICON_ERROR | wxOK );
			}
		break;

		case VIP:
			if ((setType == RAM) || (setType == ROM) || (setType == COLOURRAM) || (setType == UNDEFINED) || (setType == MAPPEDRAM) || (setType == VP570RAM))
				p_Computer->defineMemoryType(id*256, setType);
			else
			{
				(void)wxMessageBox( "Only RAM (.), ROM (R), Mapped RAM (M.), Colour RAM (C.), VP570 Expansion RAM (VP) or UNDEFINED (space) allowed in Cosmac VIP emulation\n",
											"Emma 02", wxICON_ERROR | wxOK );
			}
		break;

		case ELF2K:
		case TMC2000:
		case TMC1800:
		case NANO:
		case ETI:
			if ((setType == RAM) || (setType == ROM) || (setType == UNDEFINED))
				p_Computer->defineMemoryType(id*256, setType);
			else
			{
				(void)wxMessageBox( "Only RAM (.), ROM (R), or UNDEFINED (space) allowed in "+computerInfo[runningComputer_].name+" emulation\n",
											"Emma 02", wxICON_ERROR | wxOK );
			}
		break;

		case COSMICOS:
			if ((setType == MAPPEDRAM) || (setType == RAM) || (setType == ROM) || (setType == UNDEFINED))
				p_Computer->defineMemoryType(id*256, setType);
			else
			{
				(void)wxMessageBox( "Only RAM (.), ROM (R), Main RAM (M.) or UNDEFINED (space) allowed in "+computerInfo[runningComputer_].name+" emulation\n",
											"Emma 02", wxICON_ERROR | wxOK );
			}
		break;

		case VICTORY:
			if (setType == CRAM1870)
				setType = CARTRIDGEROM;
			if ((setType == RAM) || (setType == MAPPEDRAM) || (setType == COLOURRAM) || (setType == ROM) || (setType == CARTRIDGEROM) || (setType == UNDEFINED))
				p_Computer->defineMemoryType(id*256, setType);
			else
			{
				(void)wxMessageBox( "Only RAM (.), Mapped RAM (M.), Colour RAM (C.), ROM (R), Cartridge ROM (CR) or UNDEFINED (space) allowed in "+computerInfo[runningComputer_].name+" emulation\n",
											"Emma 02", wxICON_ERROR | wxOK );
			}
		break;

		case VISICOM:
		case STUDIO:
			if (setType == CRAM1870)
				setType = CARTRIDGEROM;
			if ((setType == RAM) || (setType == MAPPEDRAM) || (setType == ROM) || (setType == CARTRIDGEROM) || (setType == UNDEFINED))
				p_Computer->defineMemoryType(id*256, setType);
			else
			{
				(void)wxMessageBox( "Only RAM (.), Mapped RAM (M.), ROM (R), Cartridge ROM (CR) or UNDEFINED (space) allowed in "+computerInfo[runningComputer_].name+" emulation\n",
											"Emma 02", wxICON_ERROR | wxOK );
			}
		break;
	}
}


void DebugWindow::memoryDisplay()
{
	switch (memoryDisplay_)
	{
		case CPU_MEMORY:
			DebugDisplayPage();
		break;

		case CPU_TYPE:
			DebugDisplayMap();
		break;

		case CDP_1870_C:
			DebugDisplay1870VideoRam();
		break;

		case CDP_1870_P:
			DebugDisplay1870VideoRam();
		break;

		case TMS_MEMORY:
			DebugDisplayTmsRam();
		break;

		case VT_RAM:
			DebugDisplayVtRam();
		break;

		case CDP_1864:
			DebugDisplay1864ColorRam();
		break;

		case I_8275:
			DebugDisplay8275CharRom();
		break;

		case V_6845:
			DebugDisplay6845CharRom();
		break;

		case V_6847:
			DebugDisplay6847CharRom();
		break;

		case V_6847_RAM:
			DebugDisplay6847VideoRam();
		break;
	}
}

Word DebugWindow::getAddressMask()
{
	switch (memoryDisplay_)
	{
		case CPU_MEMORY:
			return 0xffff;
		break;

		case CPU_TYPE:
			return 0xffff;
		break;

		case CDP_1870_C:
			switch (runningComputer_)
			{
				case COMX:
					return p_Comx->getCharacterMemoryMask();
				break;
				case CIDELSA:
					return p_Cidelsa->getCharacterMemoryMask();
				break;
				case TMC600:
					return p_Tmc600->getCharacterMemoryMask();
				break;
				case PECOM:
					return p_Pecom->getCharacterMemoryMask();
				break;
				default:
					return 0x7ff;
				break;
			}
		break;

		case CDP_1870_P:
			switch (runningComputer_)
			{
				case COMX:
					return p_Comx->getPageMemoryMask();
				break;
				case CIDELSA:
					return p_Cidelsa->getPageMemoryMask();
				break;
				case TMC600:
					return p_Tmc600->getPageMemoryMask();
				break;
				case PECOM:
					return p_Pecom->getPageMemoryMask();
				break;
				default:
					return 0x3ff;
				break;
			}
		break;

		case TMS_MEMORY:
			return 0x3fff;
		break;

		case CDP_1864:
			switch (runningComputer_)
			{
				case ETI:
				case VIP:
					return 0xff;
				break;
				default:
					return 0x3ff;
				break;
			}
		break;

		case I_8275:
			return 0x1fff;
		break;

		case VT_RAM:
		case V_6845:
		case V_6847:
			return 0x7ff;
		break;

		case V_6847_RAM:
			switch(runningComputer_)
			{
				case ELF:
					return p_Elf->get6847RamMask();
				break;

				case ELFII:
					return p_Elf2->get6847RamMask();
				break;

				case SUPERELF:
					return p_Super->get6847RamMask();
				break;

				default:
					return 0;
				break;
			}
		break;

		default:
			return 0xffff;
		break;
	}
}

void DebugWindow::onDebugMemType(wxCommandEvent&event)
{
	memoryDisplay_ = event.GetSelection();

	memoryDisplay();

	XRCCTRL(*this, "DebugDisplayPage", wxTextCtrl)->Enable(memoryDisplay_ != CPU_TYPE);
	XRCCTRL(*this, "DebugDisplayPageSpin", wxSpinButton)->Enable(memoryDisplay_ != CPU_TYPE);
	XRCCTRL(*this, "DebugSave", wxButton)->Enable(memoryDisplay_ != CPU_TYPE);
	XRCCTRL(*this, "DebugCopy", wxButton)->Enable(memoryDisplay_ != CPU_TYPE);
}

void DebugWindow::onDebugExpansionSlot(wxSpinEvent&event)
{
	int pos = event.GetPosition();
	int slot = 1 << pos;

	XRCCTRL(*this, "DebugExpansionRam", wxSpinCtrl)->SetValue(0);
	XRCCTRL(*this, "DebugExpansionEprom", wxSpinCtrl)->SetValue(0);
	p_Comx->out(1, 0, slot);

	memoryDisplay();
}

void DebugWindow::onDebugExpansionRam(wxSpinEvent&event)
{
	int pos = event.GetPosition();
	int bank = pos << 5;

	int slot = p_Computer->getOutValue(1) & 0x1f;
	slot = bank | slot;
	p_Comx->out(1, 0, slot);

	memoryDisplay();
}

void DebugWindow::onDebugExpansionEprom(wxSpinEvent&event)
{
	int pos = event.GetPosition();
	int bank = pos << 5;

	int slot = p_Computer->getOutValue(1) & 0x1f;
	slot = bank | slot;
	p_Comx->out(1, 0, slot);

	memoryDisplay();
}

void DebugWindow::onDebugEmsPage(wxSpinEvent&event)
{
	int page = event.GetPosition();

	p_Computer->setEmsPage(page);

	memoryDisplay();
}

void DebugWindow::onDebugPager(wxSpinEvent&event)
{
	int page = event.GetPosition();

	long address = get16BitValue("DebugDisplayPage");
	if (address == -1)  return;

	int selectOutput = getConfigItem(computerInfo[runningComputer_].gui+"/PortExtenderSelectOutput", 5l);
	int writeOutput = getConfigItem(computerInfo[runningComputer_].gui+"PortExtenderWriteOutput", 6l);

	p_Computer->out(selectOutput, 0, portExtender_);
	p_Computer->out(writeOutput, 0, page);

	memoryDisplay();
}

void DebugWindow::onDebugPortExtender(wxSpinEvent&event)
{
	portExtender_ = event.GetPosition();
	XRCCTRL(*this, "DebugPager", wxSpinCtrl)->SetValue(p_Computer->getPager(portExtender_));
	memoryDisplay();
}

void DebugWindow::onDebugCopy(wxCommandEvent&WXUNUSED(event))
{
	long start = get16BitValue("DebugCopyStart");
	if (start == -1)  return;

	if (start > getAddressMask())
	{
		(void)wxMessageBox( "Please specify a start value within specified memory\n",
									"Emma 02", wxICON_ERROR | wxOK );
		return;
	}

	long end = get16BitValue("DebugCopyEnd");
	if (end == -1)  return;

	if (end > getAddressMask())
	{
		(void)wxMessageBox( "Please specify a end value within specified memory\n",
									"Emma 02", wxICON_ERROR | wxOK );
		return;
	}

	long destination = get16BitValue("DebugCopyTo");
	if (destination == -1)  return;

	if (destination > getAddressMask())
	{
		(void)wxMessageBox( "Please specify a destination value within specified memory\n",
									"Emma 02", wxICON_ERROR | wxOK );
		return;
	}

	while(start <= end)
	{
		debugWriteMem(destination++, debugReadMem(start++));
	}
}

void DebugWindow::onDebugCopyStart(wxCommandEvent&WXUNUSED(event))
{
	get16BitValue("DebugCopyStart");
}

void DebugWindow::onDebugCopyEnd(wxCommandEvent&WXUNUSED(event))
{
	get16BitValue("DebugCopyEnd");
}

void DebugWindow::onDebugCopyTo(wxCommandEvent&WXUNUSED(event))
{
	get16BitValue("DebugCopyTo");
}

void DebugWindow::onDebugAssemblerAddress(wxCommandEvent&WXUNUSED(event))
{
	long address = get16BitValue("DebugAssemblerAddress");
	if (address == -1)  return;

	debugAddress_ =	address;
}

void DebugWindow::onDebugDisStart(wxCommandEvent&WXUNUSED(event))
{
	get16BitValue("DebugDisStart");
}

void DebugWindow::onDebugDisEnd(wxCommandEvent&WXUNUSED(event))
{
	get16BitValue("DebugDisEnd");
}


Byte DebugWindow::debugReadMem(Word address)
{
	switch (memoryDisplay_)
	{
		case CPU_MEMORY:
			return p_Computer->readMem(address);
		break;

		case CDP_1870_C:
			switch (runningComputer_)
			{
				case COMX:
					return p_Comx->readCramDirect(address);
				break;
				case CIDELSA:
					return p_Cidelsa->readCramDirect(address);
				break;
				case TMC600:
					return p_Tmc600->readCramDirect(address);
				break;
				case PECOM:
					return p_Pecom->readCramDirect(address);
				break;
				default:
					return 0;
				break;
			}
		break;

		case CDP_1870_P:
			switch (runningComputer_)
			{
				case COMX:
					return p_Comx->readPramDirect(address);
				break;
				case CIDELSA:
					return p_Cidelsa->readPramDirect(address);
				break;
				case TMC600:
					return p_Tmc600->readPramDirect(address);
				break;
				case PECOM:
					return p_Pecom->readPramDirect(address);
				break;
				default:
					return 0;
				break;
			}
		break;

		case TMS_MEMORY:
			switch(runningComputer_)
			{
				case ELF:
					return p_Elf->getTmsMemory(address);
				break;

				case ELFII:
					return p_Elf2->getTmsMemory(address);
				break;

				case SUPERELF:
					return p_Super->getTmsMemory(address);
				break;

				default:
					return 0;
				break;
			}
		break;

		case VT_RAM:
			if ((computerRunning_ && (p_Vt100 != NULL)))
				return p_Vt100->getVtMemory(address);
			else
				return 0;
		break;

		case CDP_1864:
			switch(runningComputer_)
			{
				case TMC600:
					return p_Tmc2000->read1864ColorDirect(address);
				break;
				case ETI:
					return p_Eti->read1864ColorDirect(address);
				break;
				case VIP:
					return p_Vip->read1864ColorDirect(address);
				break;
				default:
					return 0;
				break;
			}
		break;

		case I_8275:
			switch(runningComputer_)
			{
				case ELF:
					return p_Elf->read8275CharRom(address);
				break;

				case ELFII:
					return p_Elf2->read8275CharRom(address);
				break;

				case SUPERELF:
					return p_Super->read8275CharRom(address);
				break;

				case ELF2K:
					return p_Elf2K->read8275CharRom(address);
				break;

				default:
					return 0;
				break;
			}
		break;

		case V_6845:
			switch(runningComputer_)
			{
				case COMX:
					return p_Comx->read6845CharRom(address);
				break;

				case ELF:
					return p_Elf->read6845CharRom(address);
				break;

				case ELFII:
					return p_Elf2->read6845CharRom(address);
				break;

				case SUPERELF:
					return p_Super->read6845CharRom(address);
				break;

				default:
					return 0;
				break;
			}
		break;

		case V_6847:
			switch(runningComputer_)
			{
				case ELF:
					return p_Elf->read6847CharRom(address);
				break;

				case ELFII:
					return p_Elf2->read6847CharRom(address);
				break;

				case SUPERELF:
					return p_Super->read6847CharRom(address);
				break;

				default:
					return 0;
				break;
			}
		break;

		case V_6847_RAM:
			switch(runningComputer_)
			{
				case ELF:
					return p_Elf->readDirect6847(address);
				break;

				case ELFII:
					return p_Elf2->readDirect6847(address);
				break;

				case SUPERELF:
					return p_Super->readDirect6847(address);
				break;

				default:
					return 0;
				break;
			}
		break;

		default:
			return 0;
		break;
	}
}

void DebugWindow::debugWriteMem(Word address, Byte value)
{
	switch (memoryDisplay_)
	{
		case CPU_MEMORY:
			p_Computer->writeMem(address, value, false);
		break;

		case CDP_1870_C:
			switch (runningComputer_)
			{
				case COMX:
					p_Comx->writeCramDirect(address, value);
				break;
				case CIDELSA:
					p_Cidelsa->writeCramDirect(address, value);
				break;
				case TMC600:
					p_Tmc600->writeCramDirect(address, value);
				break;
				case PECOM:
					p_Pecom->writeCramDirect(address, value);
				break;
			}
		break;

		case CDP_1870_P:
			switch (runningComputer_)
			{
				case COMX:
					p_Comx->writePramDirect(address, value);
				break;
				case CIDELSA:
					p_Cidelsa->writePramDirect(address, value);
				break;
				case TMC600:
					p_Tmc600->writePramDirect(address, value);
				break;
				case PECOM:
					p_Pecom->writePramDirect(address, value);
				break;
			}
		break;

		case TMS_MEMORY:
			switch(runningComputer_)
			{
				case ELF:
					p_Elf->setTmsMemory(address, value);
				break;

				case ELFII:
					p_Elf2->setTmsMemory(address, value);
				break;

				case SUPERELF:
					p_Super->setTmsMemory(address, value);
				break;
			}
		break;

		case VT_RAM:
			if (computerRunning_ && (p_Vt100 != NULL))
				p_Vt100->setVtMemory(address, value);
		break;

		case CDP_1864:
			switch (runningComputer_)
			{
				case ETI:
					p_Eti->write1864ColorDirect(address, value);
				break;
				case TMC2000:
					p_Tmc2000->write1864ColorDirect(address, value);
				break;
				case VIP:
					p_Vip->write1864ColorDirect(address, value);
				break;
			}
		break;

		case I_8275:
			switch(runningComputer_)
			{
				case ELF:
					p_Elf->write8275CharRom(address, value);
				break;

				case ELFII:
					p_Elf2->write8275CharRom(address, value);
				break;

				case SUPERELF:
					p_Super->write8275CharRom(address, value);
				break;

				case ELF2K:
					p_Elf2K->write8275CharRom(address, value);
				break;
			}
		break;

		case V_6845:
			switch(runningComputer_)
			{
				case COMX:
					p_Comx->write6845CharRom(address, value);
				break;

				case ELF:
					p_Elf->write6845CharRom(address, value);
				break;

				case ELFII:
					p_Elf2->write6845CharRom(address, value);
				break;

				case SUPERELF:
					p_Super->write6845CharRom(address, value);
				break;
			}
		break;

		case V_6847:
			switch(runningComputer_)
			{
				case ELF:
					p_Elf->write6847CharRom(address, value);
				break;

				case ELFII:
					p_Elf2->write6847CharRom(address, value);
				break;

				case SUPERELF:
					p_Super->write6847CharRom(address, value);
				break;
			}
		break;

		case V_6847_RAM:
			switch(runningComputer_)
			{
				case ELF:
					p_Elf->writeDirect6847(address, value);
				break;

				case ELFII:
					p_Elf2->writeDirect6847(address, value);
				break;

				case SUPERELF:
					p_Super->writeDirect6847(address, value);
				break;
			}
		break;
	}
}

void DebugWindow::setSwName(wxString swName)
{
	swName_ = swName;
	if (swName != "")  
		swName_ = ", Software: " + swName_;
	updateTitle();
}

void DebugWindow::updateTitle()
{
	wxString title;

	if (debugMode_)
		title = swName_ + ", Trace Mode";
	else
		title = swName_;

	switch (runningComputer_)
	{
		case COMX:
			if (p_Comx->getSteps()==0)
				title = title + " ** PAUSED **";
			p_Comx->SetTitle("COMX-35" + title);
			p_Comx->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case CIDELSA:
			if (p_Cidelsa->getSteps()==0)
				title = title + " ** PAUSED **";
			p_Cidelsa->SetTitle("Cidelsa" + title);
			p_Cidelsa->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case TMC600:
			if (p_Tmc600->getSteps()==0)
				title = title + " ** PAUSED **";
			if (p_Tmc600->getClear()==0)
				title = title + " ** CPU STOPPED **";
			p_Tmc600->SetTitle("Telmac" + title);
			p_Tmc600->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case PECOM:
			if (p_Pecom->getSteps()==0)
				title = title + " ** PAUSED **";
			if (p_Pecom->getClear()==0)
				title = title + " ** CPU STOPPED **";
			p_Pecom->SetTitle("Pecom 64" + title);
			p_Pecom->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case STUDIO:
			if (p_Studio2->getSteps()==0)
				title = title + " ** PAUSED **";
			p_Studio2->SetTitle("Studio II" + title);
			p_Studio2->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case VISICOM:
			if (p_Visicom->getSteps()==0)
				title = title + " ** PAUSED **";
			p_Visicom->SetTitle("Visicom COM-100" + title);
			p_Visicom->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case VICTORY:
			if (p_Victory->getSteps()==0)
				title = title + " ** PAUSED **";
			p_Victory->SetTitle("Victory MPT-02" + title);
			p_Victory->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case VIP:
			if (p_Vip->getSteps()==0)
				title = title + " ** PAUSED **";
			if (p_Vip->getClear()==0)
				title = title + " ** CPU STOPPED **";
			p_Vip->SetTitle("Cosmac VIP" + title);
			p_Vip->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case TMC2000:
			if (p_Tmc2000->getSteps()==0)
				title = title + " ** PAUSED **";
			if (p_Tmc2000->getClear()==0)
				title = title + " ** CPU STOPPED **";
			p_Tmc2000->SetTitle("Telmac 2000" + title);
			p_Tmc2000->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case TMC1800:
			if (p_Tmc1800->getSteps()==0)
				title = title + " ** PAUSED **";
			if (p_Tmc1800->getClear()==0)
				title = title + " ** CPU STOPPED **";
			p_Tmc1800->SetTitle("Telmac 1800" + title);
			p_Tmc1800->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case ETI:
			if (p_Eti->getSteps()==0)
				title = title + " ** PAUSED **";
			if (p_Eti->getClear()==0)
				title = title + " ** CPU STOPPED **";
			p_Eti->SetTitle("ETI 660" + title);
			p_Eti->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case NANO:
			if (p_Nano->getSteps()==0)
				title = title + " ** PAUSED **";
			if (p_Nano->getClear()==0)
				title = title + " ** CPU STOPPED **";
			p_Nano->SetTitle("Telmac Nano" + title);
			p_Nano->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case ELF2K:
			if (p_Elf2K->getSteps()==0)
				title = title + " ** PAUSED **";
			if (p_Elf2K->getClear()==0)
				title = title + " ** CPU STOPPED **";
			p_Elf2K->SetTitle("Elf 2000" + title);
			p_Elf2K->updateTitle(title);
			p_Elf2K->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case COSMICOS:
			if (p_Cosmicos->getSteps()==0)
				title = title + " ** PAUSED **";
			if (p_Cosmicos->getClear()==0)
				title = title + " ** CPU STOPPED **";
			p_Cosmicos->SetTitle("Cosmicos" + title);
			p_Cosmicos->updateTitle(title);
			p_Cosmicos->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case ELF:
			if (p_Elf->getSteps()==0)
				title = title + " ** PAUSED **";
			if (p_Elf->getClear()==0)
				title = title + " ** CPU STOPPED **";
			p_Elf->SetTitle("Elf" + title);
			p_Elf->updateTitle(title);
			p_Elf->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case ELFII:
			if (p_Elf2->getSteps()==0)
				title = title + " ** PAUSED **";
			if (p_Elf2->getClear()==0)
				title = title + " ** CPU STOPPED **";
			p_Elf2->SetTitle("Elf II" + title);
			p_Elf2->updateTitle(title);
			p_Elf2->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;

		case SUPERELF:
			if (p_Super->getSteps()==0)
				title = title + " ** PAUSED **";
			if (p_Super->getClear()==0)
				title = title + " ** CPU STOPPED **";
			p_Super->SetTitle("Super Elf" + title);
			p_Super->updateTitle(title);
			p_Super->setDebugMode(debugMode_, trace_, traceDma_, traceInt_, traceInp_, traceOut_);
		break;
	}
}

void DebugWindow::updateDebugMenu(bool debugMode)
{
	debugMode_ = debugMode;
	XRCCTRL(*this,"DebugMode", wxCheckBox)->SetValue(debugMode_);
	updateTitle();
}

void DebugWindow::onDebugMode(wxCommandEvent&event)
{
	debugMode_ = event.IsChecked();
	updateDebugMenu(debugMode_);
}

void DebugWindow::onF1()
{
	debugMode_ = !debugMode_;
 	updateDebugMenu(debugMode_);
}
