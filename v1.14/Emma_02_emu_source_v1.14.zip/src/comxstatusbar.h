#ifndef COMXSTATUSBAR_H
#define COMXSTATUSBAR_H

#define LED_SIZE_X 12
#define LED_SIZE_Y 7

class ComxStatusBar : public wxStatusBar
{
public:
	ComxStatusBar(wxWindow *parent, int size);
	~ComxStatusBar();

	void initComxBar(double zoom, bool expansionRomLoaded, int expansionTypeCard0);
	void updateLedStatus(int card, int i, bool status);
	void reDrawBar(double zoom);
	void setBarSize(int size, double zoom);

private:
	void displayText(double zoom);
	void displayLeds(double zoom);
	void deleteBitmaps();
	void updateStatusBarText(double zoom);

	wxButton *ledBitmapPointers [4][2];
	wxBitmap *ledOffPointer;
	wxBitmap *ledOnPointer;

	int statusBarSize_;
	bool expansionRomLoaded_;
	int expansionTypeCard0_;
	bool ledsDefined_;
};

#endif  //_comxstatusbar_H_