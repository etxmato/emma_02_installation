/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guitmc600.h"
#include "psave.h"

BEGIN_EVENT_TABLE(GuiTelmac, GuiPecom)

	EVT_BUTTON(XRCID("RomButtonTmc600"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("ExpRomButtonTmc600"), GuiTelmac::onTelmacExpRom)
	EVT_BUTTON(XRCID("CharRomButtonTmc600"), GuiMain::onCharRom)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonTmc600"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Tmc600"), GuiMain::onScreenDump)
	EVT_SPINCTRL(XRCID("ZoomTmc600"), GuiMain::onZoom)
	EVT_BUTTON(XRCID("FullScreenF3Tmc600"), GuiMain::onFullScreen)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeTmc600"), GuiMain::onVolume) 
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeTmc600"), GuiMain::onVolume) 
	EVT_TEXT(XRCID("ClockTmc600"), GuiMain::onClock)
	EVT_BUTTON(XRCID("CasButtonTmc600"), GuiMain::onCassette)
	EVT_BUTTON(XRCID("EjectCasTmc600"), GuiMain::onCassetteEject)
	EVT_BUTTON(XRCID("RealCasLoadTmc600"), GuiMain::onRealCas)
	EVT_BUTTON(XRCID("CasLoadTmc600"), GuiMain::onCassetteLoad)
	EVT_BUTTON(XRCID("CasSaveTmc600"), GuiMain::onCassetteSave)
	EVT_BUTTON(XRCID("CasStopTmc600"), GuiMain::onCassetteStop)
	EVT_CHECKBOX(XRCID("TurboTmc600"), GuiMain::onTurbo)
	EVT_TEXT(XRCID("TurboClockTmc600"), GuiMain::onTurboClock)
	EVT_CHECKBOX(XRCID("AutoCasLoadTmc600"), GuiMain::onAutoLoad)
	EVT_BUTTON(XRCID("PrintFileButtonTmc600"), GuiMain::onPrintFile)
	EVT_TEXT(XRCID("PrintFileTmc600"), GuiMain::onPrintFileText)
	EVT_BUTTON(XRCID("PrintButtonTmc600"), GuiMain::onPrintButton)
	EVT_CHOICE(XRCID("PrintModeTmc600"), GuiMain::onPrintMode)
	EVT_BUTTON(XRCID("KeyFileButtonTmc600"), GuiMain::onKeyFile)
	EVT_BUTTON(XRCID("EjectKeyFileTmc600"), GuiMain::onKeyFileEject)
	EVT_SPINCTRL(XRCID("AdsChannel"), GuiTelmac::onTelmacAdsChannel)
	EVT_TEXT(XRCID("AdsChannel"), GuiTelmac::onTelmacAdsChannelText)
	EVT_SPINCTRL(XRCID("AdsVolt"), GuiTelmac::onTelmacAdsVolt)
	EVT_TEXT(XRCID("AdsVolt"), GuiTelmac::onTelmacAdsVoltText)
	EVT_SPINCTRL(XRCID("AdiChannel"), GuiTelmac::onTelmacAdiChannel)
	EVT_TEXT(XRCID("AdiChannel"), GuiTelmac::onTelmacAdiChannelText)
	EVT_SPINCTRL(XRCID("AdiVolt"), GuiTelmac::onTelmacAdiVolt)
	EVT_TEXT(XRCID("AdiVolt"), GuiTelmac::onTelmacAdiVoltText)
	EVT_CHECKBOX(XRCID("UseLocationTmc600"), GuiMain::onUseLocation)
	EVT_BUTTON(XRCID("SaveButtonTmc600"), GuiMain::onSaveButton) 
	EVT_BUTTON(XRCID("LoadButtonTmc600"), GuiMain::onLoadButton)
	EVT_BUTTON(XRCID("RunButtonTmc600"), GuiMain::onPloadRun)
	EVT_BUTTON(XRCID("DsaveButtonTmc600"), GuiMain::onDsave)
	EVT_COMMAND(wxID_ANY, OPEN_PRINTER_WINDOW, GuiMain::openPrinterFrame) 
	EVT_BUTTON(XRCID("ColoursTmc600"), Main::onColoursDef)

END_EVENT_TABLE()

GuiTelmac::GuiTelmac(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiPecom(title, pos, size)
{
	conf[TMC600].loadFileNameFull_ = "";
	conf[TMC600].loadFileName_ = "";

	conf[TMC600].pLoadSaveName_[0] = 'T';
	conf[TMC600].pLoadSaveName_[1] = 'M';
	conf[TMC600].pLoadSaveName_[2] = 'C';
	conf[TMC600].pLoadSaveName_[3] = '6';

	conf[TMC600].defus_ = 0x6181;
	conf[TMC600].eop_ = 0x6183;
	conf[TMC600].string_ = 0x6192;
	conf[TMC600].arrayValue_ = 0x6194;
	conf[TMC600].eod_ = 0x6199;
	conf[TMC600].basicRamAddress_ = 0x6300;
}

void GuiTelmac::readTelmacConfig()
{
	bool turbo;
	selectedComputer_ = TMC600;

	XRCCTRL(*this, "MainRomTmc600", wxComboBox)->SetValue(configPointer->Read("/TMC600/TMC600MainRom", "tmc.24.3.bin"));
	XRCCTRL(*this, "ExpRomTmc600", wxComboBox)->SetValue(configPointer->Read("/TMC600/TMC600ExpRom", "151182.bin"));
	XRCCTRL(*this, "CharRomTmc600", wxComboBox)->SetValue(configPointer->Read("/TMC600/TMC600CharRom", "character.bin"));
	XRCCTRL(*this, "ZoomTmc600", wxSpinCtrl)->SetValue(configPointer->Read("/TMC600/TMC600Zoom", 2l));
	conf[TMC600].volume_ = configPointer->Read("/TMC600/TMC600Volume", 25l);
	XRCCTRL(*this, "VolumeTmc600", wxSlider)->SetValue(conf[TMC600].volume_);
	conf[TMC600].romDir_[MAINROM] = configPointer->Read("/TMC600/TMC600RomDir", dataDir_ + "TMC600" + pathSeparator_);
	conf[TMC600].romDir_[EXPROM] = configPointer->Read("/TMC600/TMC600ExpRomDir", dataDir_ + "TMC600" + pathSeparator_);
	conf[TMC600].charRomDir_ = configPointer->Read("/TMC600/TMC600CharRomDir", dataDir_ + "TMC600" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileTmc600", wxComboBox)->SetValue(configPointer->Read("/TMC600/TMC600ScreenDumpFile", "screendump.bmp"));
	conf[TMC600].screenDumpFileDir_ = configPointer->Read("/TMC600/TMC600ScreenDumpFileDir", dataDir_ + "TMC600" + pathSeparator_); 
	conf[TMC600].ramDir_ = configPointer->Read("/TMC600/TMC600SWDir", dataDir_ + "TMC600" + pathSeparator_); 

	conf[TMC600].mainX_ = configPointer->Read("/TMC600/TMC600X", mainWindowX_+windowInfo.mainwX); 
	conf[TMC600].mainY_ = configPointer->Read("/TMC600/TMC600Y", mainWindowY_); 

	wxString defaultClock;
	defaultClock.Printf("%1.3f", 3.579);
	conf[TMC600].clock_ = configPointer->Read("/TMC600/Clock", defaultClock);
	XRCCTRL(*this, "ClockTmc600", wxTextCtrl)->ChangeValue(conf[TMC600].clock_);
	XRCCTRL(*this, "WavFileTmc600", wxTextCtrl)->SetValue(configPointer->Read("/TMC600/TMC600WavFile", ""));
	conf[TMC600].wavFileDir_ = configPointer->Read("/TMC600/WavFileDir", dataDir_ + "TMC600" + pathSeparator_); 
	configPointer->Read("/TMC600/TMC600Turbo", &turbo, true);
	XRCCTRL(*this, "TurboTmc600", wxCheckBox)->SetValue(turbo);
	turboGui("Tmc600");
	conf[TMC600].turboClock_ = configPointer->Read("/TMC600/TMC600TurboClock", "15"); 
	XRCCTRL(*this, "TurboClockTmc600", wxTextCtrl)->SetValue(conf[TMC600].turboClock_);
	configPointer->Read("/TMC600/TMC600AutoCasLoad", &conf[TMC600].autoCassetteLoad_, true);
	XRCCTRL(*this, "AutoCasLoadTmc600", wxCheckBox)->SetValue(conf[TMC600].autoCassetteLoad_);
	configPointer->Read("/TMC600/RealCasLoad", &conf[TMC600].realCassetteLoad_, false);
	setRealCas(TMC600);

	XRCCTRL(*this, "RamTmc600", wxChoice)->SetSelection(configPointer->Read("/TMC600/TMC600Ram", 02));

	XRCCTRL(*this, "PrintFileTmc600", wxTextCtrl)->SetValue(configPointer->Read("/TMC600/TMC600PrintFile", "printerout.txt"));
	conf[TMC600].printFileDir_ = configPointer->Read("/TMC600/TMC600PrintFileDir", dataDir_ + "TMC600" + pathSeparator_); 
	XRCCTRL(*this, "PrintModeTmc600", wxChoice)->SetSelection(configPointer->Read("/TMC600/TMC600PrintMode", 1l));
	conf[TMC600].printMode_ = configPointer->Read("/TMC600/TMC600PrintMode", 1l);
	setPrintMode();
	conf[TMC600].keyFileDir_ = configPointer->Read("/TMC600/TMC600KeyFileDir", dataDir_ + "TMC600" + pathSeparator_);
	XRCCTRL(*this, "KeyFileTmc600", wxTextCtrl)->SetValue(configPointer->Read("/TMC600/TMC600KeyFile", ""));
	XRCCTRL(*this, "UseLocationTmc600", wxCheckBox)->SetValue(false);
	conf[TMC600].useLoadLocation_ = false;
}

void GuiTelmac::writeTelmacConfig()
{
	configPointer->Write("/TMC600/TMC600MainRom", XRCCTRL(*this, "MainRomTmc600", wxComboBox)->GetValue());
	configPointer->Write("/TMC600/TMC600ExpRom", XRCCTRL(*this, "ExpRomTmc600", wxComboBox)->GetValue());
	configPointer->Write("/TMC600/TMC600CharRom", XRCCTRL(*this, "CharRomTmc600", wxComboBox)->GetValue());
	configPointer->Write("/TMC600/TMC600Zoom", XRCCTRL(*this, "ZoomTmc600", wxSpinCtrl)->GetValue());
	configPointer->Write("/TMC600/TMC600Volume", XRCCTRL(*this, "VolumeTmc600", wxSlider)->GetValue());
	configPointer->Write("/TMC600/TMC600RomDir", conf[TMC600].romDir_[MAINROM]);
	configPointer->Write("/TMC600/TMC600ExpRomDir", conf[TMC600].romDir_[EXPROM]);
	configPointer->Write("/TMC600/TMC600CharRomDir", conf[TMC600].charRomDir_);
	configPointer->Write("/TMC600/TMC600ScreenDumpFile", XRCCTRL(*this, "ScreenDumpFileTmc600", wxComboBox)->GetValue());
	configPointer->Write("/TMC600/TMC600ScreenDumpFileDir", conf[TMC600].screenDumpFileDir_);
	configPointer->Write("/TMC600/TMC600SWDir", conf[TMC600].ramDir_);

	if (conf[TMC600].mainX_ > 0)
		configPointer->Write("/TMC600/TMC600X", conf[TMC600].mainX_);
	if (conf[TMC600].mainY_ > 0)
		configPointer->Write("/TMC600/TMC600Y", conf[TMC600].mainY_);

	configPointer->Write("/TMC600/Clock", conf[TMC600].clock_);
	configPointer->Write("/TMC600/TMC600WavFile", XRCCTRL(*this, "WavFileTmc600", wxTextCtrl)->GetValue());
	configPointer->Write("/TMC600/WavFileDir", conf[TMC600].wavFileDir_);
	configPointer->Write("/TMC600/TMC600Turbo", XRCCTRL(*this, "TurboTmc600", wxCheckBox)->GetValue());
	configPointer->Write("/TMC600/TMC600TurboClock", conf[TMC600].turboClock_); 
	configPointer->Write("/TMC600/TMC600AutoCasLoad", XRCCTRL(*this, "AutoCasLoadTmc600", wxCheckBox)->GetValue());
	configPointer->Write("/TMC600/RealCasLoad", conf[TMC600].realCassetteLoad_);
	configPointer->Write("/TMC600/TMC600Ram", XRCCTRL(*this, "RamTmc600", wxChoice)->GetSelection());
	configPointer->Write("/TMC600/TMC600PrintFile", XRCCTRL(*this, "PrintFileTmc600", wxTextCtrl)->GetValue());
	configPointer->Write("/TMC600/TMC600PrintFileDir", conf[TMC600].printFileDir_);
	configPointer->Write("/TMC600/TMC600PrintMode", conf[TMC600].printMode_);
	configPointer->Write("/TMC600/TMC600KeyFileDir", conf[TMC600].keyFileDir_);
	configPointer->Write("/TMC600/TMC600KeyFile", XRCCTRL(*this, "KeyFileTmc600", wxTextCtrl)->GetValue());
}

void GuiTelmac::onTelmacExpRom(wxCommandEvent& WXUNUSED(event) )
{
	wxString fileName;

	fileName = wxFileSelector( "Select the Expansion ROM file to load",
                               conf[TMC600].romDir_[EXPROM], XRCCTRL(*this, "ExpRomTmc600", wxComboBox)->GetValue(),
                               "",
                               wxString::Format
                              (
                                   "Binary File|*.bin;*.rom;*.ram;*.cos|Intel Hex File|*.hex|All files (%s)|%s",
                                   wxFileSelectorDefaultWildcardStr,
                                   wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_OPEN|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );
	if (!fileName)
		return;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	conf[TMC600].romDir_[EXPROM] = FullPath.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);

	XRCCTRL(*this, "ExpRomTmc600", wxComboBox)->SetValue(FullPath.GetFullName());
}

void GuiTelmac::onTelmacAdsChannel(wxSpinEvent&event)
{
	if (runningComputer_ == TMC600)
	{
		XRCCTRL(*this, "AdsVolt", wxSpinCtrl)->SetValue(p_Tmc600->getAds(event.GetPosition())); 
	}
}

void GuiTelmac::onTelmacAdsVolt(wxSpinEvent&event)
{
	if (runningComputer_ == TMC600)
	{
		p_Tmc600->setAds(XRCCTRL(*this, "AdsChannel", wxSpinCtrl)->GetValue(), event.GetPosition());
	}
}

void GuiTelmac::onTelmacAdsChannelText(wxCommandEvent&WXUNUSED(event))
{
	if (runningComputer_ == TMC600)
	{
		XRCCTRL(*this, "AdsVolt", wxSpinCtrl)->SetValue(p_Tmc600->getAds(XRCCTRL(*this, "AdsChannel", wxSpinCtrl)->GetValue())); 
	}
}

void GuiTelmac::onTelmacAdsVoltText(wxCommandEvent&WXUNUSED(event))
{
	if (runningComputer_ == TMC600)
	{
		p_Tmc600->setAds(XRCCTRL(*this, "AdsChannel", wxSpinCtrl)->GetValue(), XRCCTRL(*this, "AdsVolt", wxSpinCtrl)->GetValue());
	}
}

void GuiTelmac::onTelmacAdiChannel(wxSpinEvent&event)
{
	if (runningComputer_ == TMC600)
	{
		XRCCTRL(*this, "AdiVolt", wxSpinCtrl)->SetValue(p_Tmc600->getAdi(event.GetPosition())); 
	}
}

void GuiTelmac::onTelmacAdiVolt(wxSpinEvent&event)
{
	if (runningComputer_ == TMC600)
	{
		p_Tmc600->setAdi(XRCCTRL(*this, "AdiChannel", wxSpinCtrl)->GetValue(), event.GetPosition());
	}
}

void GuiTelmac::onTelmacAdiChannelText(wxCommandEvent&WXUNUSED(event))
{
	if (runningComputer_ == TMC600)
	{
		XRCCTRL(*this, "AdiVolt", wxSpinCtrl)->SetValue(p_Tmc600->getAdi(XRCCTRL(*this, "AdiChannel", wxSpinCtrl)->GetValue())); 
	}
}

void GuiTelmac::onTelmacAdiVoltText(wxCommandEvent&WXUNUSED(event))
{
	if (runningComputer_ == TMC600)
	{
		p_Tmc600->setAdi(XRCCTRL(*this, "AdiChannel", wxSpinCtrl)->GetValue(), XRCCTRL(*this, "AdiVolt", wxSpinCtrl)->GetValue());
	}
}

void GuiTelmac::enableIoGui()
{
	XRCCTRL(*this,"AdiInputText", wxStaticText)->Enable(true);
	XRCCTRL(*this,"AdiChannel", wxSpinCtrl)->Enable(true);
	XRCCTRL(*this,"AdiVolt", wxSpinCtrl)->Enable(true);
	XRCCTRL(*this,"AdiVoltText", wxStaticText)->Enable(true);
	XRCCTRL(*this,"AdsInputText", wxStaticText)->Enable(true);
	XRCCTRL(*this,"AdsChannel", wxSpinCtrl)->Enable(true);
	XRCCTRL(*this,"AdsVolt", wxSpinCtrl)->Enable(true);
	XRCCTRL(*this,"AdsVoltText", wxStaticText)->Enable(true);
}