/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "main.h"
#include "keymap.h"

#define KEYPAD_HEX_A 0
#define KEYPAD_GAME_A 1
#define KEYPAD_HEX_B 2
#define KEYPAD_GAME_B 3

#include "wx/xrc/xmlres.h"             

BEGIN_EVENT_TABLE(KeyMapDialog, wxDialog)
   EVT_BUTTON(XRCID("HexSave"), KeyMapDialog::onSaveButton)
   EVT_BUTTON(XRCID("HexSwitchPad"), KeyMapDialog::onSwitchPad)
   EVT_BUTTON(XRCID("HexSwitchPlayer"), KeyMapDialog::onSwitchPlayer)
   EVT_BUTTON(XRCID("HexLocation"), KeyMapDialog::onHexLocation)
   EVT_BUTTON(XRCID("GameDefault"), KeyMapDialog::onGameDefault)
   EVT_BUTTON(XRCID("HexChar"), KeyMapDialog::onHexChar)
   EVT_BUTTON(XRCID("StudioSwitchPad"), KeyMapDialog::onSwitchStudio)
   EVT_BUTTON(XRCID("StudioLocation"), KeyMapDialog::onStudioLocation)
   EVT_BUTTON(XRCID("StudioChar"), KeyMapDialog::onStudioChar)
   EVT_BUTTON(XRCID("HexKey0"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKey1"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKey2"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKey3"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKey4"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKey5"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKey6"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKey7"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKey8"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKey9"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKeyA"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKeyB"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKeyC"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKeyD"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKeyE"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("HexKeyF"), KeyMapDialog::onHexKey)
   EVT_BUTTON(XRCID("GameKey0"), KeyMapDialog::onGameKey)
   EVT_BUTTON(XRCID("GameKey1"), KeyMapDialog::onGameKey)
   EVT_BUTTON(XRCID("GameKey2"), KeyMapDialog::onGameKey)
   EVT_BUTTON(XRCID("GameKey3"), KeyMapDialog::onGameKey)
   EVT_BUTTON(XRCID("GameKey4"), KeyMapDialog::onGameKey)
   EVT_CHOICE(XRCID("GameHex0"), KeyMapDialog::onGameHex)
   EVT_CHOICE(XRCID("GameHex1"), KeyMapDialog::onGameHex)
   EVT_CHOICE(XRCID("GameHex2"), KeyMapDialog::onGameHex)
   EVT_CHOICE(XRCID("GameHex3"), KeyMapDialog::onGameHex)
   EVT_CHOICE(XRCID("GameHex4"), KeyMapDialog::onGameHex)
   EVT_CHECKBOX(XRCID("GameAuto"), KeyMapDialog::onAuto)
END_EVENT_TABLE()

KeyMapDialog::KeyMapDialog(wxWindow* parent)
{
	computerTypeStr_ = p_Main->getSelectedComputerStr();
	int computerType = p_Main->getSelectedComputerId();

	hexKey_ = -1;
	gameKey_ = -1;
	numberOfKeys_ = 16;
	hexPadBdefined_ = false;
	player2defined_ = false;

	for (int i=0; i<16; i++)
	{
		hexKeyDefA_[i] = 0;
		hexKeyDefB_[i] = 0;
	}
	for (int i=0; i<5; i++)
	{
		keyDefGameValueB_[i] = 0;
		keyDefGameValueB_[i] = 0;
	}
	hexPadA_ = true;

	switch (computerType)
	{
		case ELF:
		case ELFII:
		case SUPERELF:
			wxXmlResource::Get()->LoadDialog(this, parent, wxT("KeyMapDialog2"));
			player2defined_ = true;
			p_Main->getDefaultHexKeys(computerTypeStr_, "A", hexKeyDefA_);
			p_Main->getDefaultHexKeys(computerTypeStr_, "B", hexKeyDefB_);
			autoGame_ = p_Main->getConfigBool(computerTypeStr_+"/GameAuto", true);
			XRCCTRL(*this, "GameAuto", wxCheckBox)->SetValue(autoGame_);
		break;

		case ELF2K:
		case COSMICOS:
			wxXmlResource::Get()->LoadDialog(this, parent, wxT("KeyMapDialog2"));
			player2defined_ = true;
			p_Main->getDefaultHexKeys(computerTypeStr_, "A", hexKeyDefA_);
			p_Main->getDefaultHexKeys(computerTypeStr_, "B", hexKeyDefB_);
			XRCCTRL(*this, "GameAuto", wxCheckBox)->Hide();
			autoGame_ = false;
		break;

		case STUDIO:
		case VISICOM:
		case VICTORY:
			wxXmlResource::Get()->LoadDialog(this, parent, wxT("KeyMapDialog3"));
			hexPadBdefined_ = true;
			hexKeyDefB_[0] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyB0", WXK_NUMPAD0);
			hexKeyDefB_[1] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyB1", WXK_NUMPAD7);
			hexKeyDefB_[2] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyB2", WXK_NUMPAD8);
			hexKeyDefB_[3] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyB3", WXK_NUMPAD9);
			hexKeyDefB_[4] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyB4", WXK_NUMPAD4);
			hexKeyDefB_[5] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyB5", WXK_NUMPAD5);
			hexKeyDefB_[6] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyB6", WXK_NUMPAD6);
			hexKeyDefB_[7] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyB7", WXK_NUMPAD1);
			hexKeyDefB_[8] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyB8", WXK_NUMPAD2);
			hexKeyDefB_[9] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyB9", WXK_NUMPAD3);

			hexKeyDefA_[0] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyA0", 88);
			hexKeyDefA_[1] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyA1", 49);
			hexKeyDefA_[2] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyA2", 50);
			hexKeyDefA_[3] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyA3", 51);
			hexKeyDefA_[4] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyA4", 81);
			hexKeyDefA_[5] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyA5", 87);
			hexKeyDefA_[6] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyA6", 69);
			hexKeyDefA_[7] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyA7", 65);
			hexKeyDefA_[8] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyA8", 83);
			hexKeyDefA_[9] = p_Main->getConfigItem(computerTypeStr_+"/HexKeyA9", 68);
			numberOfKeys_ = 10;
			autoGame_ = p_Main->getConfigBool(computerTypeStr_+"/GameAuto", true);
			XRCCTRL(*this, "GameAuto", wxCheckBox)->SetValue(autoGame_);
		break;

		case ETI:
		case TMC1800:
		case TMC2000:
		case NANO:
			wxXmlResource::Get()->LoadDialog(this, parent, wxT("KeyMapDialog1"));
			player2defined_ = true;
			XRCCTRL(*this, "PadText", wxStaticText)->SetLabel("Hex Keypad Definition"); 
			XRCCTRL(*this, "GamePlayer", wxStaticText)->SetLabel("Arcade Key Definition: Player 1"); 
			XRCCTRL(*this, "HexSwitchPad", wxButton)->Hide();
			p_Main->getDefaultHexKeys(computerTypeStr_, "A", hexKeyDefA_);
			p_Main->getDefaultHexKeys(computerTypeStr_, "B", hexKeyDefB_);
			autoGame_ = p_Main->getConfigBool(computerTypeStr_+"/GameAuto", true);
			XRCCTRL(*this, "GameAuto", wxCheckBox)->SetValue(autoGame_);
		break;

		case VIP:
			wxXmlResource::Get()->LoadDialog(this, parent, wxT("KeyMapDialog1"));
			if (!p_Main->getCheckBox("VP590") && !p_Main->getCheckBox("VP580"))
			{
				XRCCTRL(*this, "PadText", wxStaticText)->SetLabel("Hex Keypad Definition");
				XRCCTRL(*this, "GamePlayer", wxStaticText)->SetLabel("Arcade Key Definition: Player 1"); 
				XRCCTRL(*this, "HexSwitchPad", wxButton)->Hide();
				player2defined_ = true;
			}
			else
			{
				hexPadBdefined_ = true;
				XRCCTRL(*this, "HexSwitchPlayer", wxButton)->Hide();
			}
			p_Main->getDefaultHexKeys(computerTypeStr_, "A", hexKeyDefA_);
			p_Main->getDefaultHexKeys(computerTypeStr_, "B", hexKeyDefB_);
			autoGame_ = p_Main->getConfigBool(computerTypeStr_+"/GameAuto", true);
			XRCCTRL(*this, "GameAuto", wxCheckBox)->SetValue(autoGame_);
		break;
	}

	p_Main->getDefaultGameKeys(computerTypeStr_, "A", keyDefGameValueA_, keyDefGameHexA_);
	p_Main->getDefaultGameKeys(computerTypeStr_, "B", keyDefGameValueB_, keyDefGameHexB_);

	enableAuto(autoGame_);

	this->connectKeyDownEvent(this); 
	updateButtons();
}

void KeyMapDialog::compareButtons(int toBeCheckedHex, int toBeCheckedValue, int type)
{
	wxString button;
	if (type == 0 || type == 2)
		button.Printf("HexKey%01X", toBeCheckedHex);
	else
		button.Printf("GameKey%01X", toBeCheckedHex);

	for (int j=0; j<numberOfKeys_; j++)
	{
		if ((toBeCheckedHex != j && type == KEYPAD_HEX_A) || type != KEYPAD_HEX_A) 
		{
			if (toBeCheckedValue == hexKeyDefA_[j])	
			{		
				XRCCTRL(*this, button, wxButton)->SetForegroundColour(wxColour(255,0,0));
			}
		}
	}
	for (int j=0; j<5; j++)
	{
		if ((toBeCheckedHex != j && type == KEYPAD_GAME_A)  || type != KEYPAD_GAME_A) 
		{
			if (toBeCheckedValue == keyDefGameValueA_[j])			
			{		
				XRCCTRL(*this, button, wxButton)->SetForegroundColour(wxColour(255,0,0));
			}
		}				
	}
	if (!hexPadBdefined_ && !player2defined_)
		return;
	for (int j=0; j<numberOfKeys_; j++)
	{
		if ((toBeCheckedHex != j && type == KEYPAD_HEX_B) || type != KEYPAD_HEX_B) 
		{
			if (toBeCheckedValue == hexKeyDefB_[j])			
			{		
				XRCCTRL(*this, button, wxButton)->SetForegroundColour(wxColour(255,0,0));
			}
		}				
	}
	for (int j=0; j<5; j++)
	{
		if ((toBeCheckedHex != j && type == KEYPAD_GAME_B)  || type != KEYPAD_GAME_B)  
		{
			if (toBeCheckedValue == keyDefGameValueB_[j])			
			{		
				XRCCTRL(*this, button, wxButton)->SetForegroundColour(wxColour(255,0,0));
			}
		}				
	}
}

void KeyMapDialog::updateButtons()
{
	wxString button, keyStr;
	if (hexPadA_)
	{
		for (int i= 0; i < numberOfKeys_; i++)
		{
			setLabel("HexKey%01X", i, hexKeyDefA_[i]);
			compareButtons(i, hexKeyDefA_[i], KEYPAD_HEX_A);
		}
		for (int i=0; i<5; i++)
		{
			setLabel("GameKey%01X", i, keyDefGameValueA_[i]);
			button.Printf("GameHex%01X", i);
			XRCCTRL(*this, button, wxChoice)->SetSelection(keyDefGameHexA_[i]);
			compareButtons(i, keyDefGameValueA_[i], KEYPAD_GAME_A);
		}
	}
	else
	{
		if (player2defined_)
		{
			for (int i= 0; i < numberOfKeys_; i++)
			{
				setLabel("HexKey%01X", i, hexKeyDefA_[i]);
				compareButtons(i, hexKeyDefA_[i], KEYPAD_HEX_A);
			}
		}
		else
		{
			for (int i= 0; i < numberOfKeys_; i++)
			{
				setLabel("HexKey%01X", i, hexKeyDefB_[i]);
				compareButtons(i, hexKeyDefB_[i], KEYPAD_HEX_B);
			}
		}
		for (int i=0; i<5; i++)
		{
			setLabel("GameKey%01X", i, keyDefGameValueB_[i]);
			button.Printf("GameHex%01X", i);
			XRCCTRL(*this, button, wxChoice)->SetSelection(keyDefGameHexB_[i]);
			compareButtons(i, keyDefGameValueB_[i], KEYPAD_GAME_B);
		}
	}
}

void KeyMapDialog::onSaveButton( wxCommandEvent& WXUNUSED(event) )
{
	wxString conf;
	for (int i= 0; i < numberOfKeys_; i++)
	{	
		conf.Printf("/HexKeyA%01X", i);
		p_Main->setConfigItem(computerTypeStr_+conf, hexKeyDefA_[i]);
	}
	p_Main->storeDefaultGameKeys(computerTypeStr_, "A", keyDefGameValueA_, keyDefGameHexA_);

	if ((computerTypeStr_ == "Vip") || (computerTypeStr_ == "Studio2") || (computerTypeStr_ == "Visicom") || (computerTypeStr_ == "Victory"))
	{
		for (int i= 0; i < numberOfKeys_; i++)
		{	
			conf.Printf("/HexKeyB%01X", i);
			p_Main->setConfigItem(computerTypeStr_+conf, hexKeyDefB_[i]);
		}
		p_Main->storeDefaultGameKeys(computerTypeStr_, "B", keyDefGameValueB_, keyDefGameHexB_);

	}
	p_Main->setConfigBool(computerTypeStr_+"/GameAuto", autoGame_);
	if (p_Computer != NULL)
	{
		p_Computer->reDefineKeysA(hexKeyDefA_, keyDefGameValueA_, keyDefGameHexA_); 
		if (hexPadBdefined_ || player2defined_)
			p_Computer->reDefineKeysA(hexKeyDefB_, keyDefGameValueB_, keyDefGameHexB_); 
	}
	EndModal( wxID_OK );
}

void KeyMapDialog::onHexKey(wxCommandEvent &event)
{
	wxString button;

	if (hexKey_ != -1)
	{
		if (hexPadA_)
			setLabel("HexKey%01X", hexKey_, hexKeyDefA_[hexKey_]);
		else
			setLabel("HexKey%01X", hexKey_, hexKeyDefB_[hexKey_]);
	}
	if (gameKey_ != -1)
	{
		if (hexPadA_)
			setLabel("GameKey%01X", gameKey_, keyDefGameValueA_[gameKey_]);
		else
			setLabel("GameKey%01X", gameKey_, keyDefGameValueB_[gameKey_]);
		gameKey_ = -1;
	}
	hexKey_ = event.GetId();
	hexKey_ -= XRCID("HexKey0");
	button.Printf("HexKey%01X", hexKey_);
	XRCCTRL(*this, button, wxButton)->SetLabel("Press Key");
}

void KeyMapDialog::onGameKey(wxCommandEvent &event)
{
	wxString button;

	if (hexKey_ != -1)
	{
		if (hexPadA_ || player2defined_)
			setLabel("HexKey%01X", hexKey_, hexKeyDefA_[hexKey_]);
		else
			setLabel("HexKey%01X", hexKey_, hexKeyDefB_[hexKey_]);
		hexKey_ = -1;
	}
	if (gameKey_ != -1)
	{
		if (hexPadA_)
			setLabel("GameKey%01X", gameKey_, keyDefGameValueA_[gameKey_]);
		else
			setLabel("GameKey%01X", gameKey_, keyDefGameValueB_[gameKey_]);
	}
	gameKey_ = event.GetId();
	gameKey_ -= XRCID("GameKey0");
	button.Printf("GameKey%01X", gameKey_);
	XRCCTRL(*this, button, wxButton)->SetLabel("Press Key");
}

void KeyMapDialog::onGameHex(wxCommandEvent &event)
{
	wxString button;

	int gameHex = event.GetId();
	gameHex -= XRCID("GameHex0");
	
	if (hexPadA_)
		keyDefGameHexA_[gameHex] = event.GetSelection();
	else
		keyDefGameHexB_[gameHex] = event.GetSelection();
}

void KeyMapDialog::onHexLocation(wxCommandEvent& WXUNUSED(event))
{
	if ((computerTypeStr_ == "Elf") || (computerTypeStr_ == "ElfII") || (computerTypeStr_ == "SuperElf") || (computerTypeStr_ == "Elf2K"))
	{
		hexKeyDefA_[0] = 90;
		hexKeyDefA_[1] = 88;
		hexKeyDefA_[2] = 67;
		hexKeyDefA_[3] = 86;
		hexKeyDefA_[4] = 65;
		hexKeyDefA_[5] = 83;
		hexKeyDefA_[6] = 68;
		hexKeyDefA_[7] = 70;
		hexKeyDefA_[8] = 81;
		hexKeyDefA_[9] = 87;
		hexKeyDefA_[10] = 69;
		hexKeyDefA_[11] = 82;
		hexKeyDefA_[12] = 49;
		hexKeyDefA_[13] = 50;
		hexKeyDefA_[14] = 51;
		hexKeyDefA_[15] = 52;
		updateButtons();
		hexKey_ = -1;
		gameKey_ = -1;
		return;
	}

	hexKeyDefA_[0] = 88;
	hexKeyDefA_[1] = 49;
	hexKeyDefA_[2] = 50;
	hexKeyDefA_[3] = 51;
	hexKeyDefA_[4] = 81;
	hexKeyDefA_[5] = 87;
	hexKeyDefA_[6] = 69;
	hexKeyDefA_[7] = 65;
	hexKeyDefA_[8] = 83;
	hexKeyDefA_[9] = 68;
	hexKeyDefA_[10] = 90;
	hexKeyDefA_[11] = 67;
	hexKeyDefA_[12] = 52;
	hexKeyDefA_[13] = 82;
	hexKeyDefA_[14] = 70;
	hexKeyDefA_[15] = 86;

	hexKeyDefB_[0] = 44;
	hexKeyDefB_[1] = 55;
	hexKeyDefB_[2] = 56;
	hexKeyDefB_[3] = 57;
	hexKeyDefB_[4] = 85;
	hexKeyDefB_[5] = 73;
	hexKeyDefB_[6] = 79;
	hexKeyDefB_[7] = 74;
	hexKeyDefB_[8] = 75;
	hexKeyDefB_[9] = 76;
	hexKeyDefB_[10] = 77;
	hexKeyDefB_[11] = 46;
	hexKeyDefB_[12] = 48;
	hexKeyDefB_[13] = 80;
	hexKeyDefB_[14] = 126;
	hexKeyDefB_[15] = 45;

	updateButtons();
	hexKey_ = -1;
	gameKey_ = -1;
}

void KeyMapDialog::onHexChar(wxCommandEvent& WXUNUSED(event))
{
	hexKeyDefA_[0] = 48;
	hexKeyDefA_[1] = 49;
	hexKeyDefA_[2] = 50;
	hexKeyDefA_[3] = 51;
	hexKeyDefA_[4] = 52;
	hexKeyDefA_[5] = 53;
	hexKeyDefA_[6] = 54;
	hexKeyDefA_[7] = 55;
	hexKeyDefA_[8] = 56;
	hexKeyDefA_[9] = 57;
	hexKeyDefA_[10] = 65;
	hexKeyDefA_[11] = 66;
	hexKeyDefA_[12] = 67;
	hexKeyDefA_[13] = 68;
	hexKeyDefA_[14] = 69;
	hexKeyDefA_[15] = 70;

	hexKeyDefB_[0] = WXK_NUMPAD0;
	hexKeyDefB_[1] = WXK_NUMPAD1;
	hexKeyDefB_[2] = WXK_NUMPAD2;
	hexKeyDefB_[3] = WXK_NUMPAD3;
	hexKeyDefB_[4] = WXK_NUMPAD4;
	hexKeyDefB_[5] = WXK_NUMPAD5;
	hexKeyDefB_[6] = WXK_NUMPAD6;
	hexKeyDefB_[7] = WXK_NUMPAD7;
	hexKeyDefB_[8] = WXK_NUMPAD8;
	hexKeyDefB_[9] = WXK_NUMPAD9;
	hexKeyDefB_[10] = WXK_HOME;
	hexKeyDefB_[11] = WXK_END;
	hexKeyDefB_[12] = WXK_PAGEUP;
	hexKeyDefB_[13] = WXK_PAGEDOWN;
	hexKeyDefB_[14] = WXK_NUMPAD_DIVIDE;
	hexKeyDefB_[15] = WXK_NUMPAD_MULTIPLY;

	updateButtons();
	hexKey_ = -1;
	gameKey_ = -1;
}

void KeyMapDialog::onGameDefault(wxCommandEvent& WXUNUSED(event))
{
	keyDefGameValueA_[HEX_UP] = WXK_UP;
	keyDefGameValueA_[HEX_LEFT] = WXK_LEFT;
	keyDefGameValueA_[HEX_RIGHT] = WXK_RIGHT;
	keyDefGameValueA_[HEX_DOWN] = WXK_DOWN;
	keyDefGameValueA_[HEX_FIRE] = WXK_SPACE;
	keyDefGameValueB_[HEX_UP] = WXK_NUMPAD_UP;
	keyDefGameValueB_[HEX_LEFT] = WXK_NUMPAD_LEFT;
	keyDefGameValueB_[HEX_RIGHT] = WXK_NUMPAD_RIGHT;
	keyDefGameValueB_[HEX_DOWN] = WXK_NUMPAD_DOWN;
	keyDefGameValueB_[HEX_FIRE] = WXK_NUMPAD_ENTER;

	keyDefGameHexA_[HEX_UP] = 2;
	keyDefGameHexA_[HEX_LEFT] = 4;
	keyDefGameHexA_[HEX_RIGHT] = 6;
	keyDefGameHexA_[HEX_DOWN] = 8;
	keyDefGameHexA_[HEX_FIRE] = 5;
	keyDefGameHexB_[HEX_UP] = 2;
	keyDefGameHexB_[HEX_LEFT] = 4;
	keyDefGameHexB_[HEX_RIGHT] = 6;
	keyDefGameHexB_[HEX_DOWN] = 8;
	keyDefGameHexB_[HEX_FIRE] = 5;

	updateButtons();
	hexKey_ = -1;
	gameKey_ = -1;
}

void KeyMapDialog::onStudioLocation(wxCommandEvent& WXUNUSED(event))
{
	hexKeyDefA_[0] = 88;
	hexKeyDefA_[1] = 49;
	hexKeyDefA_[2] = 50;
	hexKeyDefA_[3] = 51;
	hexKeyDefA_[4] = 81;
	hexKeyDefA_[5] = 87;
	hexKeyDefA_[6] = 69;
	hexKeyDefA_[7] = 65;
	hexKeyDefA_[8] = 83;
	hexKeyDefA_[9] = 68;

	hexKeyDefB_[0] = WXK_NUMPAD0;
	hexKeyDefB_[1] = WXK_NUMPAD7;
	hexKeyDefB_[2] = WXK_NUMPAD8;
	hexKeyDefB_[3] = WXK_NUMPAD9;
	hexKeyDefB_[4] = WXK_NUMPAD4;
	hexKeyDefB_[5] = WXK_NUMPAD5;
	hexKeyDefB_[6] = WXK_NUMPAD6;
	hexKeyDefB_[7] = WXK_NUMPAD1;
	hexKeyDefB_[8] = WXK_NUMPAD2;
	hexKeyDefB_[9] = WXK_NUMPAD3;

	updateButtons();
	hexKey_ = -1;
	gameKey_ = -1;
}

void KeyMapDialog::onStudioChar(wxCommandEvent& WXUNUSED(event))
{
	hexKeyDefA_[0] = 48;
	hexKeyDefA_[1] = 49;
	hexKeyDefA_[2] = 50;
	hexKeyDefA_[3] = 51;
	hexKeyDefA_[4] = 52;
	hexKeyDefA_[5] = 53;
	hexKeyDefA_[6] = 54;
	hexKeyDefA_[7] = 55;
	hexKeyDefA_[8] = 56;
	hexKeyDefA_[9] = 57;

	hexKeyDefB_[0] = WXK_NUMPAD0;
	hexKeyDefB_[1] = WXK_NUMPAD1;
	hexKeyDefB_[2] = WXK_NUMPAD2;
	hexKeyDefB_[3] = WXK_NUMPAD3;
	hexKeyDefB_[4] = WXK_NUMPAD4;
	hexKeyDefB_[5] = WXK_NUMPAD5;
	hexKeyDefB_[6] = WXK_NUMPAD6;
	hexKeyDefB_[7] = WXK_NUMPAD7;
	hexKeyDefB_[8] = WXK_NUMPAD8;
	hexKeyDefB_[9] = WXK_NUMPAD9;

	updateButtons();
	hexKey_ = -1;
	gameKey_ = -1;
}

void KeyMapDialog::onSwitchPad(wxCommandEvent & WXUNUSED(event))
{
	hexPadA_ = !hexPadA_;
//	if (hexPadBdefined_)
//	{
	if (hexPadA_)
		XRCCTRL(*this, "PadText", wxStaticText)->SetLabel("Hex Keypad Definition: A");
	else
		XRCCTRL(*this, "PadText", wxStaticText)->SetLabel("Hex Keypad Definition: B");
//	}

	updateButtons();
	hexKey_ = -1;
	gameKey_ = -1;
}

void KeyMapDialog::onSwitchPlayer(wxCommandEvent & WXUNUSED(event))
{
	hexPadA_ = !hexPadA_;
	if (hexPadA_)
		XRCCTRL(*this, "GamePlayer", wxStaticText)->SetLabel("Arcade Key Definition: Player 1");
	else
		XRCCTRL(*this, "GamePlayer", wxStaticText)->SetLabel("Arcade Key Definition: Player 2");
	updateButtons();
	hexKey_ = -1;
	gameKey_ = -1;
}

void KeyMapDialog::onSwitchStudio(wxCommandEvent & WXUNUSED(event))
{
	hexPadA_ = !hexPadA_;
	if (hexPadA_)
	{
		XRCCTRL(*this, "PadText", wxStaticText)->SetLabel("Keypad Definition: A - Left");
	}
	else
	{
		XRCCTRL(*this, "PadText", wxStaticText)->SetLabel("Keypad Definition: B - Right");
	}
	updateButtons();
	hexKey_ = -1;
	gameKey_ = -1;
}

void KeyMapDialog::onKeyDown(wxKeyEvent& event)
{
	if (gameKey_ != -1)
	{
		int key = event.GetKeyCode();
		setLabel("GameKey%01X", gameKey_, key);
		if (hexPadA_ || player2defined_)
			keyDefGameValueA_[gameKey_] = key;
		else
			keyDefGameValueB_[gameKey_] = key;
		gameKey_ = -1;
	}
	if (hexKey_ != -1)
	{
		int key = event.GetKeyCode();
		setLabel("HexKey%01X", hexKey_, key);
		if (hexPadA_)
			hexKeyDefA_[hexKey_] = key;
		else
			hexKeyDefB_[hexKey_] = key;
		hexKey_ = -1;
	}
	updateButtons();
}

void KeyMapDialog::connectKeyDownEvent(wxWindow* pclComponent) 
{ 
  if(pclComponent) 
  { 
    pclComponent->Connect(wxID_ANY, 
                          wxEVT_KEY_DOWN, 
                          wxKeyEventHandler(KeyMapDialog::onKeyDown), 
                          (wxObject*) NULL, 
                          this); 

    wxWindowListNode* pclNode = pclComponent->GetChildren().GetFirst(); 
    while(pclNode) 
    { 
      wxWindow* pclChild = pclNode->GetData(); 
      this->connectKeyDownEvent(pclChild); 
      
      pclNode = pclNode->GetNext(); 
    } 
  } 
} 

void KeyMapDialog::setLabel(wxString printStr, int button, int key)
{
	wxString keyStr, buttonStr;

	switch (key)
	{
		case WXK_NUMPAD0:
			keyStr.Printf("Pd 0 (%i)", key);
		break;

		case WXK_NUMPAD1:
			keyStr.Printf("Pd 1 (%i)", key);
		break;

		case WXK_NUMPAD2:
			keyStr.Printf("Pd 2 (%i)", key);
		break;

		case WXK_NUMPAD3:
			keyStr.Printf("Pd 3 (%i)", key);
		break;

		case WXK_NUMPAD4:
			keyStr.Printf("Pd 4 (%i)", key);
		break;

		case WXK_NUMPAD5:
			keyStr.Printf("Pd 5 (%i)", key);
		break;

		case WXK_NUMPAD6:
			keyStr.Printf("Pd 6 (%i)", key);
		break;

		case WXK_NUMPAD7:
			keyStr.Printf("Pd 7 (%i)", key);
		break;

		case WXK_NUMPAD8:
			keyStr.Printf("Pd 8 (%i)", key);
		break;

		case WXK_NUMPAD9:
			keyStr.Printf("Pd 9 (%i)", key);
		break;

		case WXK_BACK:
			keyStr.Printf("Back (%i)", key);
		break;

		case WXK_TAB:
			keyStr.Printf("Tab (%i)", key);
		break;

		case WXK_RETURN:
			keyStr.Printf("Return (%i)", key);
		break;

		case WXK_ESCAPE:
			keyStr.Printf("ESC (%i)", key);
		break;

		case WXK_DELETE:
			keyStr.Printf("Delete (%i)", key);
		break;

		case WXK_SHIFT:
			keyStr.Printf("Shift (%i)", key);
		break;

		case WXK_START:
 			keyStr.Printf("START (%i)", key);
		break;
		case WXK_LBUTTON:
 			keyStr.Printf("LButton (%i)", key);
		break;
		case WXK_RBUTTON:
 			keyStr.Printf("RButton (%i)", key);
		break;
		case WXK_CANCEL:
 			keyStr.Printf("Cancel (%i)", key);
		break;
		case WXK_MBUTTON:
 			keyStr.Printf("MButton (%i)", key);
		break;
		case WXK_CLEAR:
 			keyStr.Printf("Clear (%i)", key);
		break;
		case WXK_ALT:
 			keyStr.Printf("Alt (%i)", key);
		break;
		case WXK_CONTROL:
 			keyStr.Printf("Ctrl (%i)", key);
		break;
		case WXK_MENU:
 			keyStr.Printf("Menu (%i)", key);
		break;
  		case WXK_PAUSE:
 			keyStr.Printf("Pause (%i)", key);
		break;
  		case WXK_CAPITAL:
 			keyStr.Printf("Caps (%i)", key);
		break;
  		case WXK_END:
 			keyStr.Printf("End (%i)", key);
		break;
  		case WXK_HOME:
 			keyStr.Printf("Home (%i)", key);
		break;
  		case WXK_LEFT:
 			keyStr.Printf("Left (%i)", key);
		break;
  		case WXK_UP:
 			keyStr.Printf("Up (%i)", key);
		break;
  		case WXK_RIGHT:
 			keyStr.Printf("Right (%i)", key);
		break;
  		case WXK_DOWN:
 			keyStr.Printf("Down (%i)", key);
		break;
     	case WXK_SELECT:
 			keyStr.Printf("Select (%i)", key);
		break;
  		case WXK_PRINT:
 			keyStr.Printf("Print (%i)", key);
		break;
  		case WXK_EXECUTE:
 			keyStr.Printf("Exec (%i)", key);
		break;
  		case WXK_SNAPSHOT:
 			keyStr.Printf("Snap (%i)", key);
		break;
  		case WXK_INSERT:
 			keyStr.Printf("Ins (%i)", key);
		break;
  		case WXK_HELP:
 			keyStr.Printf("Help (%i)", key);
		break;
  		case WXK_MULTIPLY:
 			keyStr.Printf("* (%i)", key);
		break;
  		case WXK_ADD:
 			keyStr.Printf("+ (%i)", key);
		break;
  		case WXK_SEPARATOR:
 			keyStr.Printf("Sep (%i)", key);
		break;
  		case WXK_SUBTRACT:
 			keyStr.Printf("- (%i)", key);
		break;
  		case WXK_DECIMAL:
 			keyStr.Printf(", (%i)", key);
		break;
  		case WXK_DIVIDE:
 			keyStr.Printf("/ (%i)", key);
		break;
  		case WXK_F1:
 			keyStr.Printf("F1 (%i)", key);
		break;
  		case WXK_F2:
 			keyStr.Printf("F2 (%i)", key);
		break;
  		case WXK_F3:
 			keyStr.Printf("F3 (%i)", key);
		break;
  		case WXK_F4:
 			keyStr.Printf("F4 (%i)", key);
		break;
  		case WXK_F5:
 			keyStr.Printf("F5 (%i)", key);
		break;
  		case WXK_F6:
 			keyStr.Printf("F6 (%i)", key);
		break;
   		case WXK_F7:
 			keyStr.Printf("F7 (%i)", key);
		break;
  		case WXK_F8:
 			keyStr.Printf("F8 (%i)", key);
		break;
  		case WXK_F9:
 			keyStr.Printf("F9 (%i)", key);
		break;
  		case WXK_F10:
 			keyStr.Printf("F10 (%i)", key);
		break;
  		case WXK_F11:
 			keyStr.Printf("F11 (%i)", key);
		break;
  		case WXK_F12:
 			keyStr.Printf("F12 (%i)", key);
		break;
  		case WXK_F13:
 			keyStr.Printf("F13 (%i)", key);
		break;
  		case WXK_F14:
 			keyStr.Printf("F14 (%i)", key);
		break;
  		case WXK_F15:
 			keyStr.Printf("F15 (%i)", key);
		break;
  		case WXK_F16:
 			keyStr.Printf("F16 (%i)", key);
		break;
  		case WXK_F17:
 			keyStr.Printf("F17 (%i)", key);
		break;
  		case WXK_F18:
 			keyStr.Printf("F18 (%i)", key);
		break;
  		case WXK_F19:
 			keyStr.Printf("F19 (%i)", key);
		break;
  		case WXK_F20:
 			keyStr.Printf("F20 (%i)", key);
		break;
  		case WXK_F21:
 			keyStr.Printf("F21 (%i)", key);
		break;
  		case WXK_F22:
 			keyStr.Printf("F22 (%i)", key);
		break;
  		case WXK_F23:
 			keyStr.Printf("F23 (%i)", key);
		break;
  		case WXK_F24:
 			keyStr.Printf("F24 (%i)", key);
		break;
  		case WXK_NUMLOCK:
 			keyStr.Printf("NumLock (%i)", key);
		break;
  		case WXK_SCROLL:
 			keyStr.Printf("Scroll (%i)", key);
		break;
  		case WXK_PAGEUP:
 			keyStr.Printf("PgUp (%i)", key);
		break;
  		case WXK_PAGEDOWN:
 			keyStr.Printf("PgDn (%i)", key);
		break;
  		case WXK_NUMPAD_SPACE:
 			keyStr.Printf("Pd space (%i)", key);
		break;
  		case WXK_NUMPAD_TAB:
 			keyStr.Printf("Pd tab (%i)", key);
		break;
   		case WXK_NUMPAD_ENTER:
 			keyStr.Printf("Enter (%i)", key);
		break;
   		case WXK_NUMPAD_F1:
 			keyStr.Printf("Pd F1 (%i)", key);
		break;
   		case WXK_NUMPAD_F2:
 			keyStr.Printf("Pd F2 (%i)", key);
		break;
   		case WXK_NUMPAD_F3:
 			keyStr.Printf("Pd F3 (%i)", key);
		break;
   		case WXK_NUMPAD_F4:
 			keyStr.Printf("Pd F4 (%i)", key);
		break;
    	case WXK_NUMPAD_HOME:
 			keyStr.Printf("Pd Home (%i)", key);
		break;
    	case WXK_NUMPAD_LEFT:
 			keyStr.Printf("Pd Left (%i)", key);
		break;
    	case WXK_NUMPAD_UP:
 			keyStr.Printf("Pd Up (%i)", key);
		break;
    	case WXK_NUMPAD_RIGHT:
 			keyStr.Printf("Pd Right (%i)", key);
		break;
    	case WXK_NUMPAD_DOWN:
 			keyStr.Printf("Pd Dwn (%i)", key);
		break;
    	case WXK_NUMPAD_PAGEUP:
 			keyStr.Printf("Pd PgUp (%i)", key);
		break;
    	case WXK_NUMPAD_PAGEDOWN:
 			keyStr.Printf("Pd PgDn (%i)", key);
		break;
    	case WXK_NUMPAD_END:
 			keyStr.Printf("Pd End (%i)", key);
		break;
    	case WXK_NUMPAD_BEGIN:
 			keyStr.Printf("Pd Bgn (%i)", key);
		break;
    	case WXK_NUMPAD_INSERT:
 			keyStr.Printf("Pd Ins (%i)", key);
		break;
    	case WXK_NUMPAD_DELETE:
 			keyStr.Printf("Pd Del (%i)", key);
		break;
    	case WXK_NUMPAD_EQUAL:
 			keyStr.Printf("Pd = (%i)", key);
		break;
    	case WXK_NUMPAD_MULTIPLY:
 			keyStr.Printf("Pd * (%i)", key);
		break;
    	case WXK_NUMPAD_ADD:
 			keyStr.Printf("Pd + (%i)", key);
		break;
    	case WXK_NUMPAD_SEPARATOR:
 			keyStr.Printf("Pd Sep (%i)", key);
		break;
    	case WXK_NUMPAD_SUBTRACT:
 			keyStr.Printf("Pd - (%i)", key);
		break;
    	case WXK_NUMPAD_DECIMAL:
 			keyStr.Printf("Pd , (%i)", key);
		break;
    	case WXK_NUMPAD_DIVIDE:
 			keyStr.Printf("Pd / (%i)", key);
		break;
    	case WXK_WINDOWS_LEFT:
 			keyStr.Printf("Win Left (%i)", key);
		break;
    	case WXK_WINDOWS_RIGHT:
 			keyStr.Printf("Win Right (%i)", key);
		break;
    	case WXK_WINDOWS_MENU:
 			keyStr.Printf("Win Menu (%i)", key);
		break;
    	case WXK_COMMAND:
 			keyStr.Printf("Command (%i)", key);
		break;
		default:
			keyStr.Printf("%c (%i)", key, key);
		break;
	}
	if (button < 16)
		buttonStr.Printf(printStr, button);
	else
		buttonStr = printStr;
	XRCCTRL(*this, buttonStr, wxButton)->SetLabel(keyStr);
	XRCCTRL(*this, buttonStr, wxButton)->SetForegroundColour(wxNullColour);
}

void KeyMapDialog::onAuto(wxCommandEvent&event)
{
	autoGame_ = event.IsChecked();
	enableAuto(autoGame_);
}

void KeyMapDialog::enableAuto(bool status)
{
	XRCCTRL(*this, "GameHex0", wxChoice)->Enable(!status);
	XRCCTRL(*this, "GameHex1", wxChoice)->Enable(!status);
	XRCCTRL(*this, "GameHex2", wxChoice)->Enable(!status);
	XRCCTRL(*this, "GameHex3", wxChoice)->Enable(!status);
	XRCCTRL(*this, "GameHex4", wxChoice)->Enable(!status);
}
