/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "main.h"
#include "eti660.h"

Eti::Eti(const wxString& title, const wxPoint& pos, const wxSize& size, double zoom, int computerType)
:Pixie(title, pos, size, zoom, computerType)
{
	threadPointer = new RunEti();
	if ( threadPointer->Create() != wxTHREAD_NO_ERROR )
	{
		p_Main->message("Can't create thread");
	}
	threadPointer->SetPriority(WXTHREAD_MAX_PRIORITY);
}

Eti::~Eti()
{
	p_Main->setMainPos(ETI, GetPosition());
}

void Eti::stopComputer()
{
	threadPointer->Delete();
}

void Eti::configureComputer()
{
	outType_[1] = ETIPIAOUT;
	inType_[1] = ETIPIAIN;
	outType_[2] = ETICOLOURRAM;
	outType_[3] = VIPOUT4;
	efType_[2] = VIPEF2;
	efType_[4] = VIPKEYEF;

	p_Main->message("Configuring ETI 660");
	p_Main->message("	Output/input 2: PIA, output 3: colour RAM");
	p_Main->message("	EF 2: cassette in, EF 4: step key\n");

	p_Main->getDefaultHexKeys("Eti", "A", hexKeyDefA_);
	p_Main->getDefaultGameKeys("Eti", "A", keyDefGameValueA_, keyDefGameHexA_);
	p_Main->getDefaultGameKeys("Eti", "B", keyDefGameValueB_, keyDefGameHexB_);

	if (p_Main->getConfigBool("/Eti/GameAuto", true))
	{
		p_Main->loadKeyDefinition("xxxx", p_Main->getTextValue("Chip8SWEti"), keyDefGameHexA_, keyDefGameHexB_);
		p_Main->storeDefaultGameKeys("Eti", "A", keyDefGameValueA_, keyDefGameHexA_);
		p_Main->storeDefaultGameKeys("Eti", "B", keyDefGameValueB_, keyDefGameHexB_);
	}

	resetCpu();
	DataDirection_ = true;
}

void Eti::reDefineKeysA(int hexKeyDefA[], int keyDefGameValueA[], int keyDefGameHexA[])
{
	for (int i=0; i<16; i++)
	{
		hexKeyDefA_[i] = hexKeyDefA[i];
	}
	for (int i=0; i<5; i++)
	{
		keyDefGameValueA_[i] = keyDefGameValueA[i];
		keyDefGameHexA_[i] = keyDefGameHexA[i];
	}
}

void Eti::reDefineKeysB(int* WXUNUSED(hexKeyDefB[]), int keyDefGameValueB[], int keyDefGameHexB[])
{
	for (int i=0; i<5; i++)
	{
		keyDefGameValueB_[i] = keyDefGameValueB[i];
		keyDefGameHexB_[i] = keyDefGameHexB[i];
	}
}

void Eti::initComputer()
{
	setClear(1);
	setWait(1);
	cassetteEf_ = 0;

	for (int i=0; i<16; i++)
		eti660KeyState_[i] = false;

	colorLatch_ = false;
	step_ = false;
	endSave_ = 0x600;
}

void Eti::keyDown(int keycode)
{
	for (int i=0; i<16; i++)
	{
		if (keycode == hexKeyDefA_[i])
			eti660KeyState_[i] = true;
	}
	for (int i=0; i<5; i++)
	{
		if (keycode == keyDefGameValueA_[i])
			eti660KeyState_[keyDefGameHexA_[i]&0xf] = true;
		if (keycode == keyDefGameValueB_[i])
			eti660KeyState_[keyDefGameHexB_[i]&0xf] = true;
	}

	if (keycode == 43)
		step_ = true;

	if (keycode == WXK_NUMPAD_ADD)
		step_ = true;

	if (keycode == WXK_INSERT)
		step_ = true;
}

void Eti::keyUp(int keycode)
{
	for (int i=0; i<16; i++)
	{
		if (keycode == hexKeyDefA_[i])
			eti660KeyState_[i] = false;
	}
	for (int i=0; i<5; i++)
	{
		if (keycode == keyDefGameValueA_[i])
			eti660KeyState_[keyDefGameHexA_[i]&0xf] = false;
		if (keycode == keyDefGameValueB_[i])
			eti660KeyState_[keyDefGameHexB_[i]&0xf] = false;
	}

	if (keycode == 43)
		step_ = false;

	if (keycode == WXK_NUMPAD_ADD)
		step_ = false;

	if (keycode == WXK_INSERT)
		step_ = false;
}

void Eti::onRun()
{
	resetPressed_ = true;
}

Byte Eti::ef(int flag)
{
	switch(efType_[flag])
	{
		case 0:
			return 1;
		break;

		case PIXIEEF:
			return efPixie();
		break;

		case VIPEF2:
			return cassetteEf_;
		break;

		case VIPKEYEF:
			return ef3();
		break;

		default:
			return 1;
	}
}

Byte Eti::ef3()
{
	return step_;
}

Byte Eti::in(Byte port, Word address)
{
	Byte ret;
//	p_Main->messageInt(port);
//	p_Main->messageInt(address);

	switch(inType_[port-1])
	{
		case 0:
			ret = 255;
		break;

		case ETIPIAIN:
			ret = inEti(address);
		break;

		case PIXIEIN:
			p_Main->stopCassette();
			ret = inPixie();
		break;

		case PIXIEOUT:
			outPixie();
			return 0;
		break;

		default:
//			p_Main->messageInt(port);
			ret = 255;
	}
	inValues_[port] = ret;
	return ret;
}

void Eti::out(Byte port, Word address, Byte value)
{
	outValues_[port] = value;
//	p_Main->messageInt(port);
//	p_Main->messageInt(value);

	switch(outType_[port-1])
	{
		case 0:
			return;
		break;

		case PIXIEOUT:
			outPixie();
		break;

		case PIXIEBACKGROUND:
			outPixieBackGround();
		break;

		case ETIPIAOUT:
			outEti(address, value);
		break;

		case ETICOLOURRAM:
//			p_Main->messageHex(address);
//			p_Main->messageHex(value);
//			colorMemory1864_[address&0xff] = value &0xf;
			colorMemory1864_[((address >> 1) & 0xf8) + (address & 0x7)] = value &0xf;
			return;
		break;

		case VIPOUT4:
			tone1864Latch(value);
		break;

//		default:
//			p_Main->messageInt(port);
	}
}

Byte Eti::inEti(WORD address)
{
	Byte ret = 0xff;

	if ((address&0x3) == 0)
	{
		if (DataDirection_)	// Data Direction A
		{
//			p_Main->message("Data Direction Register: Input");
		}
		else				// Output Register
		{
			if ((outputKeyValue_&0x1) == 0)
			{
				if (eti660KeyState_[3])
					ret &= 0x7f;
				if (eti660KeyState_[2])
					ret &= 0xbf;
				if (eti660KeyState_[1])
					ret &= 0xdf;
				if (eti660KeyState_[0])
					ret &= 0xef;
			}

			if ((outputKeyValue_&0x2) == 0)
			{
				if (eti660KeyState_[7])
					ret &= 0x7f;
				if (eti660KeyState_[6])
					ret &= 0xbf;
				if (eti660KeyState_[5])
					ret &= 0xdf;
				if (eti660KeyState_[4])
					ret &= 0xef;
			}

			if ((outputKeyValue_&0x4) == 0)
			{
				if (eti660KeyState_[0xb])
					ret &= 0x7f;
				if (eti660KeyState_[0xa])
					ret &= 0xbf;
				if (eti660KeyState_[9])
					ret &= 0xdf;
				if (eti660KeyState_[8])
					ret &= 0xef;
			}

			if ((outputKeyValue_&0x8) == 0)
			{
				if (eti660KeyState_[0xf])
					ret &= 0x7f;
				if (eti660KeyState_[0xe])
					ret &= 0xbf;
				if (eti660KeyState_[0xd])
					ret &= 0xdf;
				if (eti660KeyState_[0xc])
					ret &= 0xef;
			}

			if ((outputKeyValue_&0x10) == 0)
			{
				if (eti660KeyState_[0xc])
					ret &= 0xf7;
				if (eti660KeyState_[8])
					ret &= 0xfb;
				if (eti660KeyState_[4])
					ret &= 0xfd;
				if (eti660KeyState_[0])
					ret &= 0xfe;
			}

			if ((outputKeyValue_&0x20) == 0)
			{
				if (eti660KeyState_[0xd])
					ret &= 0xf7;
				if (eti660KeyState_[9])
					ret &= 0xfb;
				if (eti660KeyState_[5])
					ret &= 0xfd;
				if (eti660KeyState_[1])
					ret &= 0xfe;
			}

			if ((outputKeyValue_&0x40) == 0)
			{
				if (eti660KeyState_[0xe])
					ret &= 0xf7;
				if (eti660KeyState_[0xa])
					ret &= 0xfb;
				if (eti660KeyState_[6])
					ret &= 0xfd;
				if (eti660KeyState_[2])
					ret &= 0xfe;
			}

			if ((outputKeyValue_&0x80) == 0)
			{
				if (eti660KeyState_[0xf])
					ret &= 0xf7;
				if (eti660KeyState_[0xb])
					ret &= 0xfb;
				if (eti660KeyState_[7])
					ret &= 0xfd;
				if (eti660KeyState_[3])
					ret &= 0xfe;
			}

			ret &= inputKeyLatch_;
			ret |= (outputKeyValue_&outputKeyLatch_);
//			p_Main->messageHex(ret);
		}
	}
//	else
//		p_Main->message("Other Input");
	return ret;
}

void Eti::outEti(WORD address, Byte value)
{
	if ((address&0x3) == 1)	// Control register A
	{
		if ((value&0x4) == 0x4)
		{
//			p_Main->message("Data Direction Register Selected");
			initiateColour(true);
			DataDirection_ = true;
		}
		else
		{
//			p_Main->message("Output Register Selected");
			DataDirection_ = false;
		}
//		p_Main->messageHex(value);
	}

	if ((address&0x3) == 0)
	{
		if (DataDirection_)	// Data Direction A
		{
//			p_Main->message("Data Direction Register");
//			p_Main->messageHex(value);
			outputKeyLatch_ = value;
			inputKeyLatch_ = value^0xff;
		}
		else				// Output Register A
		{
//			p_Main->message("Output Register");
			outputKeyValue_ = value&outputKeyLatch_;
			outputKeyValue_ |= inputKeyLatch_;
//			p_Main->messageHex(outputKeyValue_);
		}
	}
}

void Eti::cycle(int type)
{
	switch(cycleType_[type])
	{
		case 0:
			return;
		break;

		case PIXIECYCLE:
			cyclePixieTelmac();
		break;
	}
}

void Eti::startComputer()
{
	resetPressed_ = false;
	ramMask_ = 0xfff;

	p_Main->setSwName("");
	p_Main->updateTitle();

	readProgramCombo(p_Main->getRomDir(ETI, MAINROM), "MainRomEti", ROM, 0, NONAME);

	if (p_Main->getChoiceSelection("RamEti") == 0)
	{
		defineMemoryType(0x0400, 0xfff, RAM);
		randomMemory (0x404, 0xfff);
	}
	else
	{
		for (int i=0x400; i<0x800; i++)
		{
			mainMemory_[i+0x800] = mainMemory_[i];
		}
		defineMemoryType(0x0c00, 0xfff, ROM);
		defineMemoryType(0x0400, 0xbff, RAM);
		randomMemory (0x404, 0xbff);
	}
	mainMemory_[0x400] = 0;
	mainMemory_[0x401] = 0;
	mainMemory_[0x402] = 0;
	mainMemory_[0x403] = 0;

	readProgram(p_Main->getChip8Dir(ETI), "Chip8SWEti", NOCHANGE, 0x0600, SHOWNAME);
	int	zoom = p_Main->getSpinValue("ZoomEti");

	configurePixieEti();
	setZoom(zoom);
	Show(true);
	initPixie();

	cpuCycles_ = 0;
	startTime_ = wxGetLocalTime();

	threadPointer->Run();
}

Byte Eti::readMem(Word addr)
{
	address_ = addr & ramMask_;

	if (memoryType_[address_/256] == UNDEFINED) return 255;
	return mainMemory_[address_];
}

void Eti::writeMem(Word addr, Byte value, bool writeRom)
{
	address_ = addr & ramMask_;

	if (!writeRom)
		if (memoryType_[address_/256] != RAM)  return;

	if (address_ > endSave_)
		endSave_ = address_;

	mainMemory_[address_]=value;
}

Byte Eti::read1864ColorDirect(Word addr)
{
	return colorMemory1864_[addr] & 0xf;
}

void Eti::write1864ColorDirect(Word addr, Byte value)
{
	colorMemory1864_[addr] = value & 0xf;
}

void Eti::cpuInstruction()
{
	if (debugMode_)
		p_Main->updateWindow();

	if (steps_ != 0)
	{
		cycle0_=0;
		machineCycle();
		if (cycle0_ == 0) machineCycle();
		if (cycle0_ == 0 && steps_ != 0)
		{
			cpuCycle();
			cpuCycles_ += 2;
		}
	}
	else
		soundCycle();

	playSaveLoad();
	checkEtiFunction();

	if (resetPressed_)
	{
		resetCpu();
		resetPressed_ = false;
		initPixie();
		initiateColour(false);
	}
	if (debugMode_)
		p_Main->cycleDebug();
}

void Eti::onReset()
{
	resetPressed_ = true;
}

void Eti::checkEtiFunction()
{
	switch(scratchpadRegister_[programCounter_])
	{
		case 0x018B:	// SAVE
			if (p_Main->getAutCassetteLoad())
			{
				writeMem(0x400, 0x06, false);
				writeMem(0x401, 0, false);
				p_Main->setSaveAddress("SaveStart", 0x600);

				writeMem(0x402, (endSave_>>8) & 0xff, false);
				writeMem(0x403, endSave_&0xff, false);
				p_Main->setSaveAddress("SaveEnd", endSave_);

			}
			p_Main->startCassetteSave();
		break;

		case 0x0160:	// LOAD
			if (p_Main->getAutCassetteLoad())
			{
				writeMem(0x400, 0x06, false);
				writeMem(0x401, 0, false);
				p_Main->setSaveAddress("SaveStart", 0x600);
			}
			p_Main->startCassetteLoad();
		break;
	}
}

void Eti::finishStopTape()
{
	WORD end = scratchpadRegister_[0xe] - 1;
	if (p_Main->getAutCassetteLoad())
	{
		p_Computer->writeMem(0x402, (end>>8) & 0xff, false);
		p_Computer->writeMem(0x403, (end & 0xff), false);
	}
	p_Main->setSaveAddress("SaveEnd", end);
	resetPressed_ = true;
}

void Eti::keyClear()
{
	for (int i=0; i<16; i++)
		eti660KeyState_[i] = false;
}

void *RunEti::Entry()
{
	while(!TestDestroy())
	{
		p_Computer->cpuInstruction();
	}
	return NULL;
}
