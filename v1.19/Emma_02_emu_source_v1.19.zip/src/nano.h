#ifndef NANO_H
#define NANO_H

#include "cdp1802.h"
#include "pixie.h"

class Nano : public Cdp1802, public Pixie
{
public:
	Nano(const wxString& title, const wxPoint& pos, const wxSize& size, double zoom, double zoomfactor, int computerType);
	~Nano();

	void configureComputer();
	void reDefineKeysA(int *, int *, int *);
	void reDefineKeysB(int *, int *, int *);
	void initComputer();
	void keyDown(int keycode);
	void keyUp(int keycode);

	Byte ef(int flag);
	Byte ef3();
	Byte in(Byte port, Word address);
	void out(Byte port, Word address, Byte value);
	void outNano(Byte value);
	void cycle(int type);

	void startComputer();
	void writeMemDataType(Word address, Byte type);
	Byte readMemDataType(Word address);
	Byte readMem(Word addr);
	void writeMem(Word addr, Byte value, bool writeRom);
	void cpuInstruction();
	void onReset();
	void checkNanoFunction();

private:
	Byte NanoKeyPort_;
	Byte NanoKeyState_[64];
	int cPressed;
	int tabPressed_;
	Word addressLatch_;

	int hexKeyDefA_[16];
	int keyDefGameHexA_[5];
	int keyDefGameValueA_[5];
	int keyDefGameHexB_[5];
	int keyDefGameValueB_[5];
};

#endif  // NANO_H
