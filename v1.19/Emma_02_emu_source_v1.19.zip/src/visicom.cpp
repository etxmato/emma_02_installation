/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

/*
 *******************************************************************
 *** This software is copyright 2006 by Michael H Riley          ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "main.h"
#include "visicom.h"

Visicom::Visicom(const wxString& title, const wxPoint& pos, const wxSize& size, double zoom, double zoomfactor, int computerType)
:Pixie(title, pos, size, zoom, zoomfactor, computerType)
{
}

Visicom::~Visicom()
{
	p_Main->setMainPos(VISICOM, GetPosition());
}

void Visicom::configureComputer()
{
	chip8baseVar_ = 0x10c0;
	chip8mainLoop_ = 0x281;
	chip8type_ = CHIPST2;

	outType_[1] = STUDIOOUT;
	studioKeyPort_ = 0;
	efType_[3] = STUDIOEF3;
	efType_[4] = STUDIOEF4;

	for (int j=0; j<2; j++) for (int i=0; i<10; i++)
		studioKeyState_[j][i] = 0;

	p_Main->message("Configuring Visicom COM-100");
	p_Main->message("	Output 2: select port, EF 3: read selected port 1, EF4: read selected port 2\n");

	keyDefA_[0] = p_Main->getConfigItem("/Visicom/HexKeyA0", 88);
	keyDefA_[1] = p_Main->getConfigItem("/Visicom/HexKeyA1", 49);
	keyDefA_[2] = p_Main->getConfigItem("/Visicom/HexKeyA2", 50);
	keyDefA_[3] = p_Main->getConfigItem("/Visicom/HexKeyA3", 51);
	keyDefA_[4] = p_Main->getConfigItem("/Visicom/HexKeyA4", 81);
	keyDefA_[5] = p_Main->getConfigItem("/Visicom/HexKeyA5", 87);
	keyDefA_[6] = p_Main->getConfigItem("/Visicom/HexKeyA6", 69);
	keyDefA_[7] = p_Main->getConfigItem("/Visicom/HexKeyA7", 65);
	keyDefA_[8] = p_Main->getConfigItem("/Visicom/HexKeyA8", 83);
	keyDefA_[9] = p_Main->getConfigItem("/Visicom/HexKeyA9", 68);

	keyDefB_[0] = p_Main->getConfigItem("/Visicom/HexKeyB0", WXK_NUMPAD0);
	keyDefB_[1] = p_Main->getConfigItem("/Visicom/HexKeyB1", WXK_NUMPAD7);
	keyDefB_[2] = p_Main->getConfigItem("/Visicom/HexKeyB2", WXK_NUMPAD8);
	keyDefB_[3] = p_Main->getConfigItem("/Visicom/HexKeyB3", WXK_NUMPAD9);
	keyDefB_[4] = p_Main->getConfigItem("/Visicom/HexKeyB4", WXK_NUMPAD4);
	keyDefB_[5] = p_Main->getConfigItem("/Visicom/HexKeyB5", WXK_NUMPAD5);
	keyDefB_[6] = p_Main->getConfigItem("/Visicom/HexKeyB6", WXK_NUMPAD6);
	keyDefB_[7] = p_Main->getConfigItem("/Visicom/HexKeyB7", WXK_NUMPAD1);
	keyDefB_[8] = p_Main->getConfigItem("/Visicom/HexKeyB8", WXK_NUMPAD2);
	keyDefB_[9] = p_Main->getConfigItem("/Visicom/HexKeyB9", WXK_NUMPAD3);

	p_Main->getDefaultGameKeys("Visicom", "A", keyDefGameValueA_, keyDefGameHexA_);
	p_Main->getDefaultGameKeys("Visicom", "B", keyDefGameValueB_, keyDefGameHexB_);

	if (p_Main->getConfigBool("/Visicom/GameAuto", true))
	{
		p_Main->loadKeyDefinition("xxxx", p_Main->getRomFile(VISICOM, MAINROM1), keyDefGameHexA_, keyDefGameHexB_);
		p_Main->storeDefaultGameKeys("Visicom", "A", keyDefGameValueA_, keyDefGameHexA_);
		p_Main->storeDefaultGameKeys("Visicom", "B", keyDefGameValueB_, keyDefGameHexB_);
	}

	for (int i=0; i<512; i++)
	{
		keyDefinition[i].defined = false;
	}
	for (int i=0; i<10; i++)
	{
		keyDefinition[keyDefA_[i]].defined = true;
		keyDefinition[keyDefA_[i]].player = 0;
		keyDefinition[keyDefA_[i]].key = i;

		keyDefinition[keyDefB_[i]].defined = true;
		keyDefinition[keyDefB_[i]].player = 1;
		keyDefinition[keyDefB_[i]].key = i;
	}
	for (int i=0; i<5; i++)
	{
		keyDefinition[keyDefGameValueA_[i]].defined = true;
		keyDefinition[keyDefGameValueA_[i]].player = 0;
		keyDefinition[keyDefGameValueA_[i]].key = keyDefGameHexA_[i];

		keyDefinition[keyDefGameValueB_[i]].defined = true;
		keyDefinition[keyDefGameValueB_[i]].player = 1;
		keyDefinition[keyDefGameValueB_[i]].key = keyDefGameHexB_[i];
	}

	resetCpu();
}

void Visicom::reDefineKeysA(int hexKeyDefA[], int keyDefGameValueA[], int keyDefGameHexA[])
{
	for (int i=0; i<512; i++)
	{
		keyDefinition[i].defined = false;
	}
	for (int i=0; i<10; i++)
	{
		keyDefA_[i] = hexKeyDefA[i];
		keyDefinition[keyDefA_[i]].defined = true;
		keyDefinition[keyDefA_[i]].player = 0;
		keyDefinition[keyDefA_[i]].key = i;
	}
	for (int i=0; i<5; i++)
	{
		keyDefGameValueA_[i] = keyDefGameValueA[i];
		keyDefGameHexA_[i] = keyDefGameHexA[i];
		keyDefinition[keyDefGameValueA_[i]].defined = true;
		keyDefinition[keyDefGameValueA_[i]].player = 0;
		keyDefinition[keyDefGameValueA_[i]].key = keyDefGameHexA_[i];
	}
}

void Visicom::reDefineKeysB(int hexKeyDefB[], int keyDefGameValueB[], int keyDefGameHexB[])
{
	for (int i=0; i<10; i++)
	{
		keyDefB_[i] = hexKeyDefB[i];
		keyDefinition[keyDefB_[i]].defined = true;
		keyDefinition[keyDefB_[i]].player = 1;
		keyDefinition[keyDefB_[i]].key = i;
	}
	for (int i=0; i<5; i++)
	{
		keyDefGameValueB_[i] = keyDefGameValueB[i];
		keyDefGameHexB_[i] = keyDefGameHexB[i];
		keyDefinition[keyDefGameValueB_[i]].defined = true;
		keyDefinition[keyDefGameValueB_[i]].player = 1;
		keyDefinition[keyDefGameValueB_[i]].key = keyDefGameHexB_[i];
	}
}

void Visicom::keyDown(int keycode)
{
	if (keyDefinition[keycode].defined)
		studioKeyState_[keyDefinition[keycode].player][keyDefinition[keycode].key] = 1;
}

void Visicom::keyUp(int keycode)
{
	if (keyDefinition[keycode].defined)
		studioKeyState_[keyDefinition[keycode].player][keyDefinition[keycode].key] = 0;
}

Byte Visicom::ef(int flag)
{
	switch(efType_[flag])
	{
		case 0:
			return 1;
		break;

		case PIXIEEF:
			return efPixie();
		break;

		case STUDIOEF3:
			return ef3();
		break;

		case STUDIOEF4:
			return ef4();
		break;

		default:
			return 1;
	}
}

Byte Visicom::ef3()
{
	if (studioKeyPort_<0 || studioKeyPort_>9)
		return 1;
	return(studioKeyState_[0][studioKeyPort_]) ? 0 : 1;
}

Byte Visicom::ef4()
{
	if (studioKeyPort_<0 || studioKeyPort_>9)
		return 1;
	return(studioKeyState_[1][studioKeyPort_]) ? 0 : 1;
}

Byte Visicom::in(Byte port, Word WXUNUSED(address))
{
	Byte ret;

	switch(inType_[port-1])
	{
		case 0:
			ret = 255;
		break;

		default:
			ret = 255;
	}
	inValues_[port] = ret;
	return ret;
}

void Visicom::out(Byte port, Word WXUNUSED(address), Byte value)
{
	outValues_[port] = value;

	switch(outType_[port-1])
	{
		case 0:
			return;
		break;

		case PIXIEOUT:
			inPixie();
		break;

		case STUDIOOUT:
			outStudio(value);
		break;

		case VIPOUT5:
			outPixieBackGround();
		break;
	}
}

void Visicom::outStudio(Byte value)
{
//	while(value >= 0x10) value -= 0x10;
	studioKeyPort_ = value & 0xf;
}

void Visicom::cycle(int type)
{
	switch(cycleType_[type])
	{
		case 0:
			return;
		break;

		case PIXIECYCLE:
			cyclePixie();
		break;
	}
}

void Visicom::startComputer()
{
	resetPressed_ = false;

	p_Main->setSwName("");
	p_Main->updateTitle();

	for (int i=0x800; i<0xff00; i+=0x400)
	{
		defineMemoryType(i, MAPPEDRAM);
		defineMemoryType(i+0x100, MAPPEDRAM);
		defineMemoryType(i+0x300, MAPPEDRAM);
	}
	readProgram(p_Main->getRomDir(VISICOM, MAINROM1), p_Main->getRomFile(VISICOM, MAINROM1), ROM, 0, NONAME);
	readSt2Program(VISICOM);
	defineMemoryType(0x800, 0xfff, CARTRIDGEROM);
	defineMemoryType(0x1000, 0x11ff, RAM);
	defineMemoryType(0x1300, 0x13ff, RAM);
	double zoom = p_Main->getZoom();

	configurePixieVisicom();
	initPixie();
	setZoom(zoom);
	Show(true);
	setWait(1);
	setClear(0);
	setWait(1);
	setClear(1);

	p_Main->updateTitle();

	cpuCycles_ = 0;
	p_Main->startTime();

	threadPointer->Run();
}

void Visicom::writeMemDataType(Word address, Byte type)
{
	switch (memoryType_[address/256])
	{
		case RAM:
		case ROM:
		case CARTRIDGEROM:
			if (mainMemoryDataType_[address] != type)
			{
				p_Main->updateAssTabCheck(scratchpadRegister_[programCounter_]);
				mainMemoryDataType_[address] = type;
			}
		break;

		case MAPPEDRAM:
			address = (address & 0x1ff) | 0x800;
			if (mainMemoryDataType_[address] != type)
			{
				p_Main->updateAssTabCheck(scratchpadRegister_[programCounter_]);
				mainMemoryDataType_[address] = type;
			}
		break;
	}
}

Byte Visicom::readMemDataType(Word address)
{
	switch (memoryType_[address/256])
	{
		case RAM:
		case ROM:
			return mainMemoryDataType_[address];
		break;

		case CARTRIDGEROM:
			return mainMemoryDataType_[address&0xfff];
		break;

		case MAPPEDRAM:
			address = (address & 0x1ff) | 0x800;
			return mainMemoryDataType_[address];
		break;
	}
	return MEM_TYPE_UNDEFINED;
}

Byte Visicom::readMem(Word addr)
{
	address_ = addr;

	switch (memoryType_[addr/256])
	{
		case UNDEFINED:
			return 255;
		break;

		case CARTRIDGEROM:
			addr = addr&0xfff;
		break;

//		case CARTRIDGEROM:
//			addr = (addr & 0x3ff) | 0x400;
//		break;

		case MAPPEDRAM:
			addr = (addr & 0x3ff) | 0x1000;
		break;
	}

	return mainMemory_[addr];
}

void Visicom::writeMem(Word addr, Byte value, bool writeRom)
{
	address_ = addr;

	switch (memoryType_[addr/256])
	{
		case RAM:
			if (mainMemory_[addr]==value)
				return;
			mainMemory_[addr]=value;
			if (addr>= memoryStart_ && addr<(memoryStart_+256))
				p_Main->updateDebugMemory(addr);
		break;

		case MAPPEDRAM:
			addr = (addr & 0x3ff) | 0x1000;
			if (mainMemory_[addr]==value)
				return;
			mainMemory_[addr]=value;
			if (addr>= memoryStart_ && addr<(memoryStart_+256))
				p_Main->updateDebugMemory(addr);
		break;

		default:
			if (writeRom)
				mainMemory_[addr]=value;
		break;
	}
}

void Visicom::cpuInstruction()
{
	if (cpuMode_ == RUN)
	{
		if (steps_ != 0)
		{
			cycle0_=0;
			machineCycle();
			if (cycle0_ == 0) machineCycle();
			if (cycle0_ == 0 && steps_ != 0)
			{
				cpuCycle();
				cpuCycles_ += 2;
			}
			if (debugMode_)
				p_Main->showInstructionTrace();
		}
		else
			soundCycle();

		if (resetPressed_)
		{
			resetCpu();
			resetPressed_ = false;
			setWait(1);
			setClear(0);
			setWait(1);
			setClear(1);
			initPixie();
		}
		if (debugMode_)
			p_Main->cycleDebug();
		p_Main->cycleSt2Debug();
	}
	else
	{
		initPixie();;
		cpuCycles_ = 0;
		p_Main->startTime();
	}
}

void Visicom::onReset()
{
	resetPressed_ = true;
}
