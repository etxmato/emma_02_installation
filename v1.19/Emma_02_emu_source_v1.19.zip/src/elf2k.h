#ifndef ELF2K_H
#define ELF2K_H

#include "elf2kswitch.h"
#include "elf2khex.h"
#include "cdp1802.h"
#include "elf2kdisk.h"
#include "tms9918.h"
#include "pixie.h"
#include "mc6847.h"
#include "mc6845.h"
#include "keyboard.h"
#include "keypad.h"
#include "ps2gpio.h"
#include "ledmodule.h"
#include "vt100.h"
#include "portext.h"
#include "printer.h"
#include "ps2.h"
#include "elfconfiguration.h"

DECLARE_EVENT_TYPE(ON_UART_ELF2K, 808) 

class Elf2KScreen : public Panel
{
public:
	Elf2KScreen(wxWindow *parent, const wxSize& size);
	~Elf2KScreen();

	void init();
	void onPaint(wxPaintEvent&event);
	void onMouseRelease(wxMouseEvent& event);

private:
};

class Elf2K : public wxFrame, public Cdp1802, public Elf2KDisk, public Ps2gpio
{
public:
	Elf2K(const wxString& title, const wxPoint& pos, const wxSize& size, double clock, ElfConfiguration conf);
	Elf2K() {};
	~Elf2K();

	void onClose(wxCloseEvent&event);
	bool keyDownPressed(int keycode);
	bool keyUpReleased(int keycode);
	void charEvent(int keycode);

	void onLoadButton();
	void onMpButton();
	void dataSwitch(int number);
	Byte getData();

	void onRun();
	void autoBoot();
	Byte inPressed();
	void onInButtonPress(Byte value);
	void onInButtonRelease();
	void onInButtonPress();
	void checkHexKey(int keycode);
	void onHexKeyDown(int hexkey);
	void onHexKeyUp(int keycode);

	void configureComputer();
	void reDefineKeysA(int *, int *, int *);
	void reDefineKeysB(int *, int *, int *);
	void initComputer();
	Byte ef(int flag);
	Byte in(Byte port, Word address);
	void out(Byte port, Word address, Byte value);
	void showData(Byte value);
	void cycle(int type);
	void cycleElf2K();

	void resetComputer();
	void resetVideo();
	void switchQ(int value);

	void startComputer();
	void writeMemDataType(Word address, Byte type);
	Byte readMemDataType(Word address);
	Byte readMem(Word addr);
	void writeMem(Word addr, Byte value, bool writeRom);
	void cpuInstruction();
	void configureElfExtensions();
	void moveWindows();
	void updateTitle(wxString Title);
	void setForceUpperCase(bool status);
	void onReset();
	Byte read8275CharRom(Word addr);
	void write8275CharRom(Word addr, Byte value);
	void OnRtcTimer(wxTimerEvent& event);
	void saveRam();
	void loadRam();
	void saveRtc();
	void loadRtc();

	void removeElf2KSwitch();
	void removeElfHex();
	void showModules(bool useSwitch, bool useHex);
	void clearBootstrap() {bootstrap_ = 0;};
	void setElf2KDivider(Byte value);
	void setElf2KClockSpeed(double clock) {elfClockSpeed_ = clock;};
	void dataAvailable(bool data); 
	void thrStatus(bool data); 
	void ledTimeout();
	void setLedMs(long ms);
	Byte getKey(Byte vtOut);
	void activateMainWindow();

private:
	class Elf2KScreen *elf2KScreenPointer;
	Pixie *pixiePointer;
	i8275 *i8275Pointer;
	Vt100 *vtPointer;
	wxTimer *rtcTimerPointer;

	Elf2Kswitch *p_Elf2Kswitch;
	Elf2Khex *p_Elf2Khex;
	Keypad *keypadPointer;

	ElfConfiguration elfConfiguration;

	Byte ef3State_;
	Byte switches_;
	Byte data_;
	Byte lastMode_;

	int hexKeyDefA_[16];
	int keyDefGameHexA_[5];
	int keyDefGameValueA_[5];
	int keyDefGameHexB_[5];
	int keyDefGameValueB_[5];

	double elfClockSpeed_;
	Word bootstrap_;
	Word lastAddress_;

	int cycleValue_;
	int cycleSize_;

	int runButtonState_;
	bool inPressed_;
	int loadButtonState_;
	int mpButtonState_;
	int dataSwitchState_[8];

	DECLARE_EVENT_TABLE()
};

#endif  // ELF2K_H
