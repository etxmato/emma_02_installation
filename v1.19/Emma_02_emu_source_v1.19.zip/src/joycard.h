#ifndef JOYCARD_H
#define JOYCARD_H

class Joycard
{
public:
	Joycard ();
	~Joycard () {};

	Byte stick1();
	Byte stick2();

private:

};

#endif  // JOYCARD_H