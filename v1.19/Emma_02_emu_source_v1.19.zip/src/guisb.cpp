/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "main.h"
#include "guisb.h"

#include "wx/xrc/xmlres.h"             

BEGIN_EVENT_TABLE(SBDialog, wxDialog)
    EVT_BUTTON(XRCID("SBSave"), SBDialog::onSaveButton)
    EVT_CHOICE(XRCID("OnlineBMChoice"), SBDialog::onBMChoice)
    EVT_BUTTON(XRCID("OnlineBMStore"), SBDialog::onBMStore)
    EVT_CHOICE(XRCID("OnlineAliasChoice"), SBDialog::onAliasChoice)
    EVT_BUTTON(XRCID("OnlineAliasStore"), SBDialog::onAliasStore)
    EVT_BUTTON(XRCID("OnlineAliasDel"), SBDialog::onAliasDel)
    EVT_BUTTON(XRCID("SB_ROM_00_Button"), SBDialog::onSB0Button)
    EVT_BUTTON(XRCID("SB_ROM_01_Button"), SBDialog::onSB1Button)
    EVT_BUTTON(XRCID("SB_ROM_02_Button"), SBDialog::onSB2Button)
    EVT_BUTTON(XRCID("SB_ROM_03_Button"), SBDialog::onSB3Button)
    EVT_BUTTON(XRCID("SB_ROM_04_Button"), SBDialog::onSB4Button)
    EVT_BUTTON(XRCID("SB_ROM_05_Button"), SBDialog::onSB5Button)
    EVT_BUTTON(XRCID("SB_ROM_06_Button"), SBDialog::onSB6Button)
    EVT_BUTTON(XRCID("SB_ROM_07_Button"), SBDialog::onSB7Button)
    EVT_BUTTON(XRCID("SB_ROM_08_Button"), SBDialog::onSB8Button)
    EVT_BUTTON(XRCID("SB_ROM_09_Button"), SBDialog::onSB9Button)
    EVT_BUTTON(XRCID("SB_ROM_10_Button"), SBDialog::onSB10Button)
    EVT_BUTTON(XRCID("SettingsRoot"), SBDialog::onRoot)
	EVT_TEXT(XRCID("OnlineBM"), SBDialog::onOnlineBMChange)
	EVT_TEXT(XRCID("OnlineAlias"), SBDialog::onOnlineAliasChange)
	EVT_TEXT(XRCID("OnlineAliasEmail"), SBDialog::onOnlineAliasChange)

    EVT_BUTTON(XRCID("BackupYes"), SBDialog::onYesButton)
    EVT_CHECKBOX(XRCID("BackupSub"), SBDialog::onSub)
    EVT_BUTTON(XRCID("BackupFolder"), SBDialog::onFolder)
END_EVENT_TABLE()

SBDialog::SBDialog(wxWindow* parent)
{
	wxXmlResource::Get()->Load(p_Main->getApplicationDir()+p_Main->getPathSep()+"sb.xrc");
	wxXmlResource::Get()->LoadDialog(this, parent, wxT("SBDialog"));

	rootDir_ = p_Main->getConfigItem("/Comx/RootDirectory", p_Main->getDataDir() + "Comx" + p_Main->getPathSep());
	wxString number;

	for (int i=0; i<11; i++)
	{
		number.Printf("%02d",i);
		SBRomDir_[i-1] = p_Main->getConfigItem("/Dir/Comx/SB_ROM_"+number, p_Main->getDataDir() + "Comx" + p_Main->getPathSep() + "Usb FW"+ p_Main->getPathSep());
	}

	XRCCTRL(*this, "SB_ROM_00", wxComboBox)->SetValue(p_Main->getConfigItem("/Comx/SB_ROM_00", "sb.0000.bin"));
	XRCCTRL(*this, "SB_ROM_01", wxComboBox)->SetValue(p_Main->getConfigItem("/Comx/SB_ROM_01", "sb.e000.bin"));
	XRCCTRL(*this, "SB_ROM_02", wxComboBox)->SetValue(p_Main->getConfigItem("/Comx/SB_ROM_02", "sb.f800.bin"));
	XRCCTRL(*this, "SB_ROM_03", wxComboBox)->SetValue(p_Main->getConfigItem("/Comx/SB_ROM_03", "sb.c000-0.bin"));
	XRCCTRL(*this, "SB_ROM_04", wxComboBox)->SetValue(p_Main->getConfigItem("/Comx/SB_ROM_04", "sb.c000-1.bin"));
	XRCCTRL(*this, "SB_ROM_05", wxComboBox)->SetValue(p_Main->getConfigItem("/Comx/SB_ROM_05", "sb.c000-2.bin"));
	XRCCTRL(*this, "SB_ROM_06", wxComboBox)->SetValue(p_Main->getConfigItem("/Comx/SB_ROM_06", "sb.c000-3.bin"));
	XRCCTRL(*this, "SB_ROM_07", wxComboBox)->SetValue(p_Main->getConfigItem("/Comx/SB_ROM_07", "sb.c000-4.bin"));
	XRCCTRL(*this, "SB_ROM_08", wxComboBox)->SetValue(p_Main->getConfigItem("/Comx/SB_ROM_08", "sb.c000-5.bin"));
	XRCCTRL(*this, "SB_ROM_09", wxComboBox)->SetValue(p_Main->getConfigItem("/Comx/SB_ROM_09", "sb.c000-6.bin"));
	XRCCTRL(*this, "SB_ROM_10", wxComboBox)->SetValue(p_Main->getConfigItem("/Comx/SB_ROM_10", "sb.c000-7.bin"));

	wxString name=wxGetUserName();

	XRCCTRL(*this, "OnlinePlayer", wxTextCtrl)->SetValue(p_Main->getConfigItem("/Comx/PlayerName", name));
	XRCCTRL(*this, "OnlineLocation", wxTextCtrl)->SetValue(p_Main->getConfigItem("/Comx/PlayerLocation", ""));
	XRCCTRL(*this, "OnlineEmailAddress", wxTextCtrl)->SetValue(p_Main->getConfigItem("/Comx/Email", ""));
	XRCCTRL(*this, "OnlineHome", wxTextCtrl)->SetValue(p_Main->getConfigItem("/Comx/HomePage", "http://www.emma02.hobby-site.com"));

	for (int i=0; i<10; i++)
		urlBookMark_[i] = p_Main->getUrlBookMark(i);

	XRCCTRL(*this, "OnlineBM", wxTextCtrl)->SetValue(urlBookMark_[0]);
	XRCCTRL(*this, "OnlineBMStore", wxButton)->SetForegroundColour(*wxBLACK);
	XRCCTRL(*this,"OnlineBMStore",wxButton)->Enable(false);
	bmNumber_ = 0;

	aliasNumber_ = 0;
	while (p_Main->getAlias(aliasNumber_) != "")
	{
		XRCCTRL(*this, "OnlineAliasChoice", wxChoice)->Append(p_Main->getAlias(aliasNumber_));
		aliasNumber_++;
	}
	XRCCTRL(*this, "OnlineAliasStore", wxButton)->SetForegroundColour(*wxBLACK);
	XRCCTRL(*this,"OnlineAliasStore",wxButton)->Enable(false);

	aliasNumber_ = -1;

	XRCCTRL(*this, "SettingsRootTxt", wxTextCtrl)->SetValue(rootDir_);

	XRCCTRL(*this, "SettingsCdRoot", wxChoice)->SetSelection(p_Main->getConfigItem("/Comx/CdRoot", 0l));
	XRCCTRL(*this, "SettingsBackup", wxChoice)->SetSelection(p_Main->getConfigItem("/Comx/Backup", 0l));
	XRCCTRL(*this, "SettingsBackupSys", wxChoice)->SetSelection(p_Main->getConfigItem("/Comx/BackupSys", 1l));
	XRCCTRL(*this, "SettingsCaseFile", wxChoice)->SetSelection(p_Main->getConfigItem("/Comx/CaseFile", 0l));
	XRCCTRL(*this, "SettingsCaseDir", wxChoice)->SetSelection(p_Main->getConfigItem("/Comx/CaseDir", 2l));

	if (p_Main->isComputerRunning())
	{
		XRCCTRL(*this, "SB_ROMS", wxPanel)->Enable(false);
		XRCCTRL(*this, "SettingsRoot", wxButton)->Enable(false);
		XRCCTRL(*this, "SettingsRootTxt", wxTextCtrl)->Enable(false);
	}
	else
		XRCCTRL(*this, "SB_Backup", wxPanel)->Enable(false);

	XRCCTRL(*this, "BackupRootTxt", wxTextCtrl)->SetValue(rootDir_);
	sub_ = false;

	onListBackup();
}

void SBDialog::onSaveButton( wxCommandEvent& WXUNUSED(event) )
{
	wxString number;

	for (int i=0; i<11; i++)
	{
		number.Printf("%02d",i);
		p_Main->setConfigItem("/Dir/Comx/SB_ROM_"+number, SBRomDir_[i-1]);
		p_Main->setConfigItem("/Comx/SB_ROM_"+number, XRCCTRL(*this, "SB_ROM_"+number, wxComboBox)->GetValue());
	}
	p_Main->setConfigItem("/Comx/PlayerName", XRCCTRL(*this, "OnlinePlayer", wxTextCtrl)->GetValue());
	p_Main->setConfigItem("/Comx/PlayerLocation", XRCCTRL(*this, "OnlineLocation", wxTextCtrl)->GetValue());
	p_Main->setConfigItem("/Comx/Email", XRCCTRL(*this, "OnlineEmailAddress", wxTextCtrl)->GetValue());
	p_Main->setConfigItem("/Comx/HomePage", XRCCTRL(*this, "OnlineHome", wxTextCtrl)->GetValue());

	urlBookMark_[bmNumber_] = XRCCTRL(*this, "OnlineBM", wxTextCtrl)->GetValue();
	p_Main->setUrlBookMark(bmNumber_, urlBookMark_[bmNumber_]); 

	for (int i=0; i<10; i++)
	{
		wxString numberStr;
		numberStr.Printf("/Comx/BookMark%d",i);
		p_Main->setConfigItem(numberStr, urlBookMark_[i]);
	}

	p_Main->setConfigItem("/Comx/RootDirectory", XRCCTRL(*this, "SettingsRootTxt", wxTextCtrl)->GetValue());
	p_Main->setConfigItem("/Comx/CdRoot", XRCCTRL(*this, "SettingsCdRoot", wxChoice)->GetSelection());
	p_Main->setConfigItem("/Comx/Backup", XRCCTRL(*this, "SettingsBackup", wxChoice)->GetSelection());
	p_Main->setConfigItem("/Comx/BackupSys", XRCCTRL(*this, "SettingsBackupSys", wxChoice)->GetSelection());
	p_Main->setConfigItem("/Comx/CaseFile", XRCCTRL(*this, "SettingsCaseFile", wxChoice)->GetSelection());
	p_Main->setConfigItem("/Comx/CaseDir", XRCCTRL(*this, "SettingsCaseDir", wxChoice)->GetSelection());

	wxString alias, aliasEmail;

	alias = XRCCTRL(*this, "OnlineAlias", wxTextCtrl)->GetValue();
	aliasEmail = XRCCTRL(*this, "OnlineAliasEmail", wxTextCtrl)->GetValue();
	if (alias != "alias" && aliasEmail != "email address")
		p_Main->setAlias(aliasNumber_, alias, aliasEmail); 

	wxString aliasStr, aliasEmailStr;
	for (size_t i=0; i<p_Main->getNumberOfAlias(); i++)
	{
		aliasStr.Printf("/Comx/Alias%d", i);
		aliasEmailStr.Printf("/Comx/AliasEmail%d", i);

		p_Main->setConfigItem(aliasStr, p_Main->getAlias(i));
		p_Main->setConfigItem(aliasEmailStr, p_Main->getAliasEmail(i));
	}
	p_Main->setConfigItem("/Comx/AliasNumberOf", p_Main->getNumberOfAlias());

	EndModal( wxID_OK );
}


void SBDialog::onBMChoice(wxCommandEvent&event)
{
	bmNumber_ = event.GetSelection();
	XRCCTRL(*this, "OnlineBM", wxTextCtrl)->SetValue(urlBookMark_[bmNumber_]);
	XRCCTRL(*this, "OnlineBMStore", wxButton)->SetForegroundColour(*wxBLACK);
	XRCCTRL(*this,"OnlineBMStore",wxButton)->Enable(false);
}

void SBDialog::onBMStore(wxCommandEvent& WXUNUSED(event) )
{
	XRCCTRL(*this,"OnlineBMStore",wxButton)->Enable(false);
	XRCCTRL(*this, "OnlineBMStore", wxButton)->SetForegroundColour(*wxBLACK);
	urlBookMark_[bmNumber_] = XRCCTRL(*this, "OnlineBM", wxTextCtrl)->GetValue();
	p_Main->setUrlBookMark(bmNumber_, urlBookMark_[bmNumber_]); 
}

void SBDialog::onAliasChoice(wxCommandEvent&event)
{
	aliasNumber_ = event.GetSelection()-1;

	if (aliasNumber_ == -1)
	{
		XRCCTRL(*this, "OnlineAlias", wxTextCtrl)->SetValue("alias");
		XRCCTRL(*this, "OnlineAliasEmail", wxTextCtrl)->SetValue("email address");
	}
	else
	{
		XRCCTRL(*this, "OnlineAlias", wxTextCtrl)->SetValue(p_Main->getAlias(aliasNumber_));
		XRCCTRL(*this, "OnlineAliasEmail", wxTextCtrl)->SetValue(p_Main->getAliasEmail(aliasNumber_));
	}
	XRCCTRL(*this, "OnlineAliasStore", wxButton)->SetForegroundColour(*wxBLACK);
	XRCCTRL(*this,"OnlineAliasStore",wxButton)->Enable(false);
}

void SBDialog::onAliasStore(wxCommandEvent& WXUNUSED(event) )
{
	wxString alias, aliasEmail;

	alias = XRCCTRL(*this, "OnlineAlias", wxTextCtrl)->GetValue();
	aliasEmail = XRCCTRL(*this, "OnlineAliasEmail", wxTextCtrl)->GetValue();
	p_Main->setAlias(aliasNumber_, alias, aliasEmail); 
	if (aliasNumber_ == -1)
		XRCCTRL(*this, "OnlineAliasChoice", wxChoice)->Append(alias);

	XRCCTRL(*this, "OnlineAlias", wxTextCtrl)->SetValue("alias");
	XRCCTRL(*this, "OnlineAliasEmail", wxTextCtrl)->SetValue("email address");

	XRCCTRL(*this, "OnlineAliasStore", wxButton)->SetForegroundColour(*wxBLACK);
	XRCCTRL(*this,"OnlineAliasStore",wxButton)->Enable(false);
}

void SBDialog::onAliasDel(wxCommandEvent& WXUNUSED(event) )
{
	if (aliasNumber_ != -1)
	{
		p_Main->deleteAlias(aliasNumber_);
		XRCCTRL(*this, "OnlineAliasChoice", wxChoice)->Delete(aliasNumber_+1);

		XRCCTRL(*this, "OnlineAlias", wxTextCtrl)->SetValue("alias");
		XRCCTRL(*this, "OnlineAliasEmail", wxTextCtrl)->SetValue("email address");

		XRCCTRL(*this, "OnlineAliasStore", wxButton)->SetForegroundColour(*wxBLACK);
		XRCCTRL(*this,"OnlineAliasStore",wxButton)->Enable(false);

		aliasNumber_ = -1;
	}
}

void SBDialog::onSB0Button(wxCommandEvent& WXUNUSED(event) )
{
	SBButton(0, "Main ROM replacement");
}

void SBDialog::onSB1Button(wxCommandEvent& WXUNUSED(event) )
{
	SBButton(1, "Expansion ROM at E000-EFFF");
}

void SBDialog::onSB2Button(wxCommandEvent& WXUNUSED(event) )
{
	SBButton(2, "Expansion ROM at F800-FFFF");
}

void SBDialog::onSB3Button(wxCommandEvent& WXUNUSED(event) )
{
	SBButton(3, "BANK 0");
}

void SBDialog::onSB4Button(wxCommandEvent& WXUNUSED(event) )
{
	SBButton(4, "BANK 1");
}

void SBDialog::onSB5Button(wxCommandEvent& WXUNUSED(event) )
{
	SBButton(5, "BANK 2");
}

void SBDialog::onSB6Button(wxCommandEvent& WXUNUSED(event) )
{
	SBButton(6, "BANK 3");
}

void SBDialog::onSB7Button(wxCommandEvent& WXUNUSED(event) )
{
	SBButton(7, "BANK 4");
}

void SBDialog::onSB8Button(wxCommandEvent& WXUNUSED(event) )
{
	SBButton(8, "BANK 5");
}

void SBDialog::onSB9Button(wxCommandEvent& WXUNUSED(event) )
{
	SBButton(10, "BANK 6");
}

void SBDialog::onSB10Button(wxCommandEvent& WXUNUSED(event) )
{
	SBButton(11, "BANK 7");
}

void SBDialog::SBButton(int number, wxString textMessage)
{
	wxString stringNumber;
	wxString fileName;

	stringNumber.Printf("%02d", number);
	fileName = wxFileSelector( "Select the SB " + textMessage +" file to load",
                               SBRomDir_[number-1], XRCCTRL(*this, "SB_ROM_" + stringNumber, wxComboBox)->GetValue(),
                               "",
                               wxString::Format
                              (
                                    "Binary File|*.bin;*.rom;*.ram;*.cos|Intel Hex File|*.hex|All files (%s)|%s",
                                    wxFileSelectorDefaultWildcardStr,
                                    wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_OPEN|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );
	if (!fileName)
		return;

	wxFileName FullPath = wxFileName(fileName, wxPATH_NATIVE);
	SBRomDir_[number-1] = FullPath.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);

	XRCCTRL(*this, "SB_ROM_" + stringNumber, wxComboBox)->SetValue(FullPath.GetFullName());
}

void SBDialog::onOnlineBMChange(wxCommandEvent&WXUNUSED(event))
{
	XRCCTRL(*this,"OnlineBMStore",wxButton)->Enable(true);
	XRCCTRL(*this, "OnlineBMStore", wxButton)->SetForegroundColour(*wxRED);
}

void SBDialog::onOnlineAliasChange(wxCommandEvent&WXUNUSED(event))
{
	XRCCTRL(*this,"OnlineAliasStore",wxButton)->Enable(true);
	XRCCTRL(*this, "OnlineAliasStore", wxButton)->SetForegroundColour(*wxRED);
}

void SBDialog::onRoot(wxCommandEvent& WXUNUSED(event))
{
	wxString dirName = wxDirSelector( "Select the COMX root folder", XRCCTRL(*this, "SettingsRootTxt", wxTextCtrl)->GetValue());
	if (!dirName)
		return;

	rootDir_ = dirName + wxFileName::GetPathSeparator(wxPATH_NATIVE);
	XRCCTRL(*this, "SettingsRootTxt", wxTextCtrl)->SetValue(rootDir_);
}

void SBDialog::onYesButton( wxCommandEvent& WXUNUSED(event) )
{
	p_Computer->onBackupYes(rootDir_, sub_);
	EndModal( wxID_OK );
}

void SBDialog::onNoButton(wxCommandEvent& WXUNUSED(event))
{

	EndModal( wxID_OK );
}

void SBDialog::onSub(wxCommandEvent&event)
{
	sub_ = event.IsChecked();
	XRCCTRL(*this, "BackupList", wxTextCtrl)->Clear();

	onListBackup();
}

void SBDialog::onFolder(wxCommandEvent& WXUNUSED(event))
{
	wxString dirName = wxDirSelector( "Select the desired folder", rootDir_);
	if (dirName.empty() )
		return;

	XRCCTRL(*this, "BackupRootTxt", wxTextCtrl)->SetValue(dirName + p_Main->getPathSep());
	XRCCTRL(*this, "BackupSub", wxCheckBox)->SetValue(false);
	XRCCTRL(*this, "BackupList", wxTextCtrl)->Clear();
	rootDir_ = dirName+p_Main->getPathSep();
	sub_ = false;

	onListBackup();
}

void SBDialog::listBackup(wxFileName directory, wxString name, wxString ext, int flags)
{
	wxString fileName, fullName;
	bool fileFound;
	int number;

	wxDir *dir;

	dir = new wxDir (directory.GetLongPath());
	fileFound = dir->GetFirst(&fileName, name+"*" + ext + ".bak", flags);

	while (fileFound)
	{
		fullName = directory.GetLongPath() + fileName;
		number = 1;
		while (fullName.Left(number) == rootDir_.Left(number))
			number++;
		if (!first_)
			XRCCTRL(*this, "BackupList", wxTextCtrl)->AppendText("\n");
		else
			first_ = false;
		XRCCTRL(*this, "BackupList", wxTextCtrl)->AppendText(fullName.Right(fullName.Len()-number+1));

		fileFound = dir->GetNext(&fileName);
	}

	delete dir;
}

void SBDialog::listAllBackup(wxString directory)
{
	wxString dirName;
	bool dirFound;
	wxFileName directoryName;

	wxDir *dir;

	directoryName = wxFileName(directory);
	dir = new wxDir (directoryName.GetLongPath());

	listBackup(directoryName, "", ".*", wxDIR_FILES);

	if (sub_)
	{
	
		dirFound = dir->GetFirst(&dirName, "", wxDIR_DIRS);

		while (dirFound)
		{

			listAllBackup(directory+dirName+p_Main->getPathSep());
			dirFound = dir->GetNext(&dirName);
		}
	}
	delete dir;
}

void SBDialog::onListBackup()
{
	first_ = true;
	listAllBackup(rootDir_);
}
