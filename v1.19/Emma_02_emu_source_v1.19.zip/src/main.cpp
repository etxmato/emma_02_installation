/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ******************************************************************* 
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#define MAIN

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/fs_inet.h"
#include "wx/filesys.h"
#include "wx/url.h"
#include "wx/dir.h"
#include "wx/fs_zip.h"
#include "wx/sysopt.h" 
#include "wx/stdpaths.h"
#include "wx/platinfo.h"
#include "wx/tglbtn.h"
#include "wx/fileconf.h"
#include "wx/cmdline.h"
#include "wx/sstream.h"

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMGL__)
#include "app_icon.xpm"
#endif

#include "main.h"
#include "ports.h"
#include "psave.h"
#include "functionkey.h"
#include "datadir.h"
#include "printer.h"
#include "about.h"
#include "guipopup.h"

//For memory leak debugging, uncomment next line
//#include <vld.h> 

#define VU_RED 60
#define VU_MAX 100
#define VU_HI 10

PopupDialog *popupDialog_;

IMPLEMENT_DYNAMIC_CLASS(FloatEdit, wxTextCtrl) 
IMPLEMENT_DYNAMIC_CLASS(IntEdit, wxTextCtrl) 
IMPLEMENT_DYNAMIC_CLASS(CheckBoxListCtrl, wxListCtrl) 
IMPLEMENT_DYNAMIC_CLASS(SlotEdit, wxTextCtrl) 
IMPLEMENT_DYNAMIC_CLASS(HexEdit, wxTextCtrl) 
IMPLEMENT_DYNAMIC_CLASS(HexEditX, wxTextCtrl) 
IMPLEMENT_DYNAMIC_CLASS(MemEdit, wxTextCtrl) 

FloatEdit::FloatEdit() 
: wxTextCtrl() 
{ 
	Connect(wxEVT_CHAR, wxKeyEventHandler( FloatEdit::OnChar ), NULL, this ); 
	wxString tempText;
	tempText.Printf("%1.1f", 0.0);
	comma_ = tempText.Mid(1,1);
} 

FloatEdit::FloatEdit(wxWindow *parent, wxWindowID id, const wxString& value, const wxPoint& pos, const wxSize& size) 
: wxTextCtrl(parent, id, value, pos, size) 
{ 
	Connect(wxEVT_CHAR, wxKeyEventHandler( FloatEdit::OnChar ), NULL, this ); 
	wxString tempText;
	tempText.Printf("%1.1f", 0.0);
	comma_ = tempText.Mid(1,1);
} 

void FloatEdit::OnChar(wxKeyEvent& event) 
{ 
	const int keyCode = event.GetKeyCode(); 

	// Accept a number 
	if (keyCode >= '0' && keyCode <= '9') 
		event.Skip(); 

	if (keyCode == comma_) 
		event.Skip(); 

	// Accept some other keys 
	switch (keyCode) 
	{ 
		case WXK_BACK: 
		case WXK_LEFT: 
		case WXK_RIGHT: 
		case WXK_TAB: 
		case WXK_DELETE: 
		case WXK_END: 
		case WXK_HOME: 
		case WXK_RETURN:
			event.Skip(); 
		break; 
	} 
}

IntEdit::IntEdit() 
: wxTextCtrl() 
{ 
	Connect(wxEVT_CHAR, wxKeyEventHandler( IntEdit::OnChar ), NULL, this ); 
} 

void IntEdit::OnChar(wxKeyEvent& event) 
{ 
	const int keyCode = event.GetKeyCode(); 

	// Accept a number 
	if (keyCode >= '0' && keyCode <= '9')
	{
		event.Skip(); 
//		return;
	}

	// Accept some other keys 
	switch (keyCode) 
	{ 
		case WXK_BACK: 
		case WXK_LEFT: 
		case WXK_RIGHT: 
		case WXK_TAB: 
		case WXK_DELETE: 
		case WXK_END: 
		case WXK_HOME: 
		case WXK_RETURN:
			event.Skip(); 
		break; 

		default:
//			wxNotificationMessage notify("test", "error", this); 
//			notify.SetFlags( wxICON_ERROR ); 
//			notify.Show(); 
		break; 
	} 
}

CheckBoxListCtrl::CheckBoxListCtrl() 
: wxListCtrl() 
{ 
	Connect(wxEVT_LEFT_DOWN, wxMouseEventHandler( CheckBoxListCtrl::onMouseRelease ), NULL, this ); 
} 

void CheckBoxListCtrl::onMouseRelease(wxMouseEvent& event) 
{ 
	wxString idReference = wxWindow::FindWindowById(event.GetId())->GetName();

	int flags;

	long item = HitTest(event.GetPosition(), flags);
	if (flags == wxLIST_HITTEST_ONITEMICON)
	{
		if (idReference == "BreakPointWindow")
			p_Main->switchBreakPoint(item);
		if (idReference == "Chip8BreakPointWindow")
			p_Main->switchChip8BreakPoint(item);
		if (idReference == "TrapWindow")
			p_Main->switchTrap(item);
		if (idReference == "TregWindow")
			p_Main->switchTreg(item);

	}
	else
		event.Skip();
}

SlotEdit::SlotEdit() 
: wxTextCtrl() 
{ 
	Connect(wxEVT_CHAR, wxKeyEventHandler( SlotEdit::OnChar ), NULL, this ); 
	min_ = 0;
	max_ = 9;
	number_ = -1;
} 

void SlotEdit::OnChar(wxKeyEvent& event) 
{ 
	const int keyCode = event.GetKeyCode(); 

	// Accept a number 
	if (keyCode >= ('0' + min_) && keyCode <= ('0' + max_)) 
		event.Skip(); 

	// Accept some other keys 
	switch (keyCode) 
	{ 
		case WXK_BACK: 
		case WXK_LEFT: 
		case WXK_RIGHT: 
		case WXK_TAB: 
		case WXK_DELETE: 
		case WXK_END: 
		case WXK_HOME: 
		case WXK_RETURN:
			event.Skip(); 
		break; 
	} 
}

void SlotEdit::setRange(int min, int max)
{
	min_ = min;
	max_ = max;
}

void SlotEdit::changeNumber(int number)
{
	wxString numberString;

	if (number == number_) return;
	number_ = number;

	numberString.Printf("%X", number);
	ChangeValue(numberString);
}

void SlotEdit::saveNumber(int number)
{
	number_ = number;
}

HexEdit::HexEdit() 
: wxTextCtrl() 
{ 
	Connect(wxEVT_CHAR, wxKeyEventHandler( HexEdit::OnChar ), NULL, this ); 
	number_ = -1;
	min_ = 0;
} 

void HexEdit::OnChar(wxKeyEvent& event) 
{ 
	const int keyCode = event.GetKeyCode(); 

	// Accept a number 
	if (keyCode >= ('0'+min_) && keyCode <= '9') 
		event.Skip(); 

	if (keyCode >= 'a' && keyCode <= 'f')
		event.Skip(); 

	if (keyCode >= 'A' && keyCode <= 'F') 
		event.Skip(); 

	// Accept some other keys 
	switch (keyCode) 
	{ 
		case WXK_BACK: 
		case WXK_LEFT: 
		case WXK_RIGHT: 
		case WXK_TAB: 
		case WXK_DELETE: 
		case WXK_END: 
		case WXK_HOME: 
		case WXK_RETURN:
			event.Skip(); 
		break; 
	} 
}

void HexEdit::setStart(int min)
{
	min_ = min;
}

void HexEdit::changeNumber(int number)
{
	wxString numberString;

	if (number == number_) return;
	number_ = number;

	numberString.Printf("%X", number);
	ChangeValue(numberString);
}

void HexEdit::saveNumber(int number)
{
	number_ = number;
}

HexEditX::HexEditX() 
: wxTextCtrl() 
{ 
	Connect(wxEVT_CHAR, wxKeyEventHandler( HexEditX::OnChar ), NULL, this ); 
} 

void HexEditX::OnChar(wxKeyEvent& event) 
{ 
	const int keyCode = event.GetKeyCode(); 

	// Accept a number 
	if (keyCode >= '0' && keyCode <= '9') 
		event.Skip(); 

	if (keyCode >= 'a' && keyCode <= 'f')
		event.Skip(); 

	if (keyCode >= 'A' && keyCode <= 'F') 
		event.Skip(); 

	if (keyCode == 'X' || keyCode == 'x') 
		event.Skip(); 

	// Accept some other keys 
	switch (keyCode) 
	{ 
		case WXK_BACK: 
		case WXK_LEFT: 
		case WXK_RIGHT: 
		case WXK_TAB: 
		case WXK_DELETE: 
		case WXK_END: 
		case WXK_HOME: 
		case WXK_RETURN:
			event.Skip(); 
		break; 
	} 
}

MemEdit::MemEdit() 
: wxTextCtrl() 
{ 
	Connect(wxEVT_CHAR, wxKeyEventHandler( MemEdit::OnChar ), NULL, this ); 
	number_ = -1;
} 

void MemEdit::OnChar(wxKeyEvent& event) 
{ 
	if (p_Main->getChoiceSelection("DebugMemType") == 1)
		event.Skip(); 

	const int keyCode = event.GetKeyCode(); 

	// Accept a number 
	if (keyCode >= '0' && keyCode <= '9') 
		event.Skip(); 

	if (keyCode >= 'a' && keyCode <= 'f')
		event.Skip(); 

	if (keyCode >= 'A' && keyCode <= 'F') 
		event.Skip(); 

	// Accept some other keys 
	switch (keyCode) 
	{ 
		case WXK_BACK: 
		case WXK_LEFT: 
		case WXK_RIGHT: 
		case WXK_TAB: 
		case WXK_DELETE: 
		case WXK_END: 
		case WXK_HOME: 
		case WXK_RETURN:
			event.Skip(); 
		break; 
	} 
}

void MemEdit::changeNumber1X(int number)
{
	wxString numberString;

	if (number == number_) return;
	number_ = number;

	numberString.Printf("%01X", number);
	ChangeValue(numberString);
}

void MemEdit::changeNumber2X(int number)
{
	wxString numberString;

	if (number == number_) return;
	number_ = number;

	numberString.Printf("%02X", number);
	ChangeValue(numberString);
}

void MemEdit::saveNumber(int number)
{
	number_ = number;
}

DEFINE_EVENT_TYPE(OPEN_COMX_PRINTER_WINDOW)
DEFINE_EVENT_TYPE(OPEN_PRINTER_WINDOW)
DEFINE_EVENT_TYPE(wxEVT_ERROR_MSG)
DEFINE_EVENT_TYPE(KILL_COMPUTER)
//DEFINE_EVENT_TYPE(GUI_MSG) // This is for wx 2.8.12 but doesn't actually work

BEGIN_EVENT_TABLE(Main, DebugWindow)

	EVT_CLOSE(Main::onClose)

	EVT_MENU(wxID_EXIT, Main::onQuit)
	EVT_MENU(wxID_ABOUT, Main::onAbout)
	EVT_MENU(XRCID("MI_DataDir"), Main::onDataDir)
	EVT_MENU(XRCID("MI_Home"), Main::onHome)
	EVT_MENU(XRCID("MI_Home_SB"), Main::onHomeSb)
	EVT_MENU(XRCID("MI_Home_SBHS"), Main::onHomeSbHs)
	EVT_MENU(XRCID("MI_UpdateCheck"), Main::onUpdateCheck)
	EVT_MENU(XRCID("MI_UpdateEmma"), Main::onUpdateEmma)
	EVT_MENU(wxID_HELP, Main::onHelp)
	EVT_MENU(XRCID(GUISAVECONFIG), Main::onSaveConfig)
	EVT_MENU(XRCID(GUISAVEONEXIT), Main::onSaveOnExit)
	EVT_MENU(XRCID(GUIDEFAULTWINDOWPOS), Main::onDefaultWindowPosition)
	EVT_MENU(XRCID("MI_FixedWindowPosition"), Main::onFixedWindowPosition)
	EVT_MENU(XRCID("MI_FunctionKeys"), Main::onFunctionKeys)
	EVT_MENU(XRCID("MI_ActivateMain"), Main::onActivateMainWindow)
	EVT_MENU(XRCID("MI_FullScreen"), Main::onFullScreenMenu)
	EVT_MENU(XRCID(GUIDEFAULT), Main::onDefaultSettings)
	EVT_MENU(XRCID("CDP1802"), Main::on1802)
	EVT_MENU(XRCID("CDP1804"), Main::on1804)
	EVT_MENU(XRCID("CDP1805"), Main::on1805)
	EVT_MENU(XRCID("Flat"), Main::onFlat)
	EVT_MENU(XRCID("Crisp"), Main::onCrisp)
	EVT_MENU(XRCID("Default"), Main::onDefault)
	EVT_MENU(XRCID("TV Speaker"), Main::onTvSpeaker)
	EVT_MENU(XRCID("Handheld"), Main::onHandheld)
	EVT_MENU(XRCID("MI_1802"), Main::on1802)
	EVT_MENU(XRCID("MI_1804"), Main::on1804)
	EVT_MENU(XRCID("MI_1805"), Main::on1805)

	EVT_CHOICEBOOK_PAGE_CHANGED(XRCID("StudioChoiceBook"), Main::onStudioChoiceBook)
	EVT_CHOICEBOOK_PAGE_CHANGED(XRCID("TelmacChoiceBook"), Main::onTelmacChoiceBook)
	EVT_CHOICEBOOK_PAGE_CHANGED(XRCID("CosmacChoiceBook"), Main::onCosmacChoiceBook)
	EVT_CHOICEBOOK_PAGE_CHANGED(XRCID("DebuggerChoiceBook"), Main::onDebuggerChoiceBook)
	EVT_TIMER(902, Main::vuTimeout)
	EVT_TIMER(903, Main::cpuTimeout)
	EVT_TIMER(904, Main::ledTimeout)
	EVT_TIMER(905, Main::updateCheckTimeout)

	EVT_KEY_DOWN(Main::onKeyDown)
	EVT_KEY_UP(Main::onKeyUp)
	EVT_MOUSEWHEEL(Main::onWheel)

	EVT_ERROR_MSG(wxID_ANY, Main::errorMessageEvent)

	EVT_GUI_MSG(SET_LOCATION, Main::setLocationEvent)
	EVT_GUI_MSG(SET_SW_NAME, Main::setSwNameEvent)
	EVT_GUI_MSG(SET_TAPE_STATE, Main::setTapeStateEvent)
	EVT_GUI_MSG(SET_TEXT_VALUE, Main::setTextValueEvent)
	EVT_GUI_MSG(SET_CHECK_BOX, Main::setCheckBoxEvent)
	EVT_GUI_MSG(PRINT_DEFAULT, Main::printDefaultEvent)
	EVT_GUI_MSG(PRINT_PARALLEL, Main::printParallelEvent)
	EVT_GUI_MSG(PRINT_PARALLEL_FINISHED, Main::printParallelFinishedEvent)
	EVT_GUI_MSG(PRINT_THERMAL, Main::printThermalEvent)
	EVT_GUI_MSG(PRINT_THERMAL_FINISHED, Main::printThermalFinishedEvent)
	EVT_GUI_MSG(PRINT_SERIAL, Main::printSerialEvent)
	EVT_GUI_MSG(PRINT_SERIAL_FINISHED, Main::printSerialFinishedEvent)
	EVT_GUI_MSG(PRINT_PECOM, Main::printPecomEvent)
	EVT_GUI_MSG(SET_FM_GUI, Main::setFandMBasicGuiEvent) 
	EVT_GUI_MSG(SET_SAVE_START, Main::setSaveStartEvent) 
	EVT_GUI_MSG(SET_SAVE_END, Main::setSaveEndEvent) 
	EVT_GUI_MSG(ENABLE_MEM_ACCESS, Main::enableMemAccesEvent) 
	EVT_GUI_MSG(SET_VIDEO_FULLSCREEN, Main::setVideoFullScreenEvent)
	EVT_GUI_MSG(SET_VT_FULLSCREEN, Main::setVtFullScreenEvent)
	EVT_GUI_MSG(CHANGE_NOTEBOOK, Main::setChangeNoteBookEvent)
	EVT_GUI_MSG(DISABLE_CONTROLS, Main::setDisableControlsEvent)
	EVT_GUI_MSG(UPDATE_TITLE, Main::setUpdateTitle)

	EVT_COMMAND(wxID_ANY, KILL_COMPUTER, Main::killComputer)

END_EVENT_TABLE()

IMPLEMENT_APP(Emu1802)

WindowInfo getWinSizeInfo()
{
	int major, minor;
	wxString var, value;

	WindowInfo returnValue;

	wxOperatingSystemId operatingSystemId;
	operatingSystemId = wxGetOsVersion(&major, &minor);

	if (operatingSystemId == wxOS_UNIX_LINUX)
	{	 
#if wxCHECK_VERSION(2, 9, 0)
		wxLinuxDistributionInfo distInfo;

		distInfo = wxPlatformInfo::Get().GetLinuxDistributionInfo();
		if (distInfo.Id == "Ubuntu")
		{
#endif
			if (major > 2)
			{	// Ubuntu 11.10
				returnValue.mainwY = 460;
				var = "UBUNTU_MENUPROXY";
				if (wxGetEnv(var , &value))
				{
					if (value == "libappmenu.so")
						returnValue.mainwY = 454;
				}
				returnValue.xBorder = 2;
				returnValue.yBorder = 30;
				returnValue.xBorder2 = 1;
				returnValue.yBorder2 = 60;
				returnValue.mainwX = 541;
				returnValue.xPrint = 2;
				returnValue.RegularClockY = 375;
				returnValue.RegularClockX = 333;
				returnValue.ChoiceClockY = 344;
				returnValue.ChoiceClockX = 334;
				returnValue.operatingSystem = OS_LINUX_UBUNTU_11_10;
			}
			else
			{	// Ubuntu 11.04
				returnValue.xBorder = 0;	
				returnValue.yBorder = 0;	
				returnValue.xBorder2 = 0;	
				returnValue.yBorder2 = 30;
				returnValue.mainwY = 500;
				returnValue.mainwX = 545;
				returnValue.xPrint = 2;
				returnValue.RegularClockY = 375;
				returnValue.RegularClockX = 333;
				returnValue.ChoiceClockY = 344;
				returnValue.ChoiceClockX = 334;
				returnValue.operatingSystem = OS_LINUX_UBUNTU_11_04;
			}
#if wxCHECK_VERSION(2, 9, 0)
		}
		else
		{
			wxString desktop = wxPlatformInfo::Get().GetDesktopEnvironment();
			if (desktop == "KDE")
			{ // openSUSE KDE
				returnValue.xBorder = 6;	
				returnValue.yBorder = 27;	
				returnValue.xBorder2 = 6;	
				returnValue.yBorder2 = 54;	
				returnValue.mainwY = 470;
				returnValue.mainwX = 551;
				returnValue.xPrint = 21;
				returnValue.RegularClockY = 383;
				returnValue.RegularClockX = 333;
				returnValue.ChoiceClockY = 354;
				returnValue.ChoiceClockX = 334;
				returnValue.operatingSystem = OS_LINUX_OPENSUSE_KDE;
			}
			else
			{ // openSUSE GNOME
				returnValue.xBorder = 0;
				returnValue.yBorder = 0;	
				returnValue.xBorder2 = 2;
				returnValue.yBorder2 = 36;
				returnValue.mainwY = 510;
				returnValue.mainwX = 545;
				returnValue.xPrint = 20;
				returnValue.RegularClockY = 365;
				returnValue.RegularClockX = 333;
				returnValue.ChoiceClockY = 334;
				returnValue.ChoiceClockX = 334;
				returnValue.operatingSystem = OS_LINUX_OPENSUSE_GNOME;
			}
		}
#endif
	}
	else
	{
		if (operatingSystemId == wxOS_MAC_OSX_DARWIN)
		{
				returnValue.mainwY = 480;
				returnValue.xBorder = 1;
				returnValue.yBorder = 1;
				returnValue.xBorder2 = 1;
				returnValue.yBorder2 = 1;
				returnValue.mainwX = 598;
				returnValue.xPrint = 2;
				returnValue.RegularClockY = 375;
				returnValue.RegularClockX = 333;
				returnValue.ChoiceClockY = 351;
				returnValue.ChoiceClockX = 334;
				returnValue.operatingSystem = OS_MAC;
		}
		else
		{
			if (major == 6) 
			{
				if (minor == 0) // Vista
				{
					returnValue.xBorder2 = 16;
					returnValue.yBorder2 = 36;
					returnValue.mainwY = 491;
					returnValue.operatingSystem = OS_WINDOWS_VISTA;
				}
				else // 7
				{
					returnValue.xBorder2 = 16;
					returnValue.yBorder2 = 36;
					returnValue.mainwY = 495;
					returnValue.operatingSystem = OS_WINDOWS_7;
				}

			}
			else
			{
				if (minor == 1) // XP
				{
					returnValue.xBorder2 = 8;
					returnValue.yBorder2 = 36;
					returnValue.mainwY = 489;
					returnValue.operatingSystem = OS_WINDOWS_XP;
				}
				else // 2000
				{
					returnValue.xBorder2 = 8;
					returnValue.yBorder2 = 36;
					returnValue.mainwY = 489;
					returnValue.operatingSystem = OS_WINDOWS_2000;
				}
			}
			returnValue.RegularClockY = 370;
			returnValue.RegularClockX = 333;
			returnValue.ChoiceClockY = 343;
			returnValue.ChoiceClockX = 333;
			returnValue.xPrint = 21;
			returnValue.xBorder = 0;
			returnValue.yBorder = 0;
			returnValue.mainwX = 550;
		}
	}


	return returnValue;
}

class MyFrame : public wxFrame
{
public:
	MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);
	~MyFrame();

	void onClose(wxCloseEvent&event );
private:
};

bool Emu1802::OnInit()
{
	if (!wxApp::OnInit())
        return false;

	wxSystemOptions::SetOption("msw.window.no-clip-children", 1);
	int ubuntuOffsetX;

	wxInitAllImageHandlers();
    wxFileSystem::AddHandler(new wxZipFSHandler);
	wxXmlResource::Get()->InitAllHandlers();

 	wxConfigBase *configPointer = wxConfigBase::Get();

	wxString xrcFile;
#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
	wxStandardPaths stPath;
	wxString workingDir_;
	if (mode_.portable)
		workingDir_ = wxGetCwd();
	else
		workingDir_ = stPath.GetDataDir();
	wxFileName applicationFile = wxFileName(workingDir_, "", wxPATH_NATIVE);
	wxString pathSeparator_ = applicationFile.GetPathSeparator(wxPATH_NATIVE);
	wxString applicationDirectory_;
	if (mode_.portable)
		applicationDirectory_ = applicationFile.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);
	else
		applicationDirectory_ = workingDir_ + pathSeparator_;
	ubuntuOffsetX = 36;
#else
	wxString workingDir_ = wxGetCwd();
	wxFileName applicationFile = wxFileName(workingDir_, "", wxPATH_NATIVE);
	wxString pathSeparator_ = applicationFile.GetPathSeparator(wxPATH_NATIVE);
	wxString applicationDirectory_ = applicationFile.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);
	ubuntuOffsetX = 0;
#endif

	xrcFile = applicationDirectory_ + "main.xrc";
#if wxCHECK_VERSION(2, 9, 0)
	if (!wxXmlResource::Get()->LoadFile(xrcFile))
#else
	if (!wxXmlResource::Get()->Load(xrcFile))
#endif
	{
		(void)wxMessageBox( "Error loading " + xrcFile + "\n",
							"Emma 02", wxICON_ERROR | wxOK );
		return false;
	}

	PrintDataPointer = new wxPrintData;
	PrintDataPointer->SetPaperId(wxPAPER_A4);

	p_PageSetupData = new wxPageSetupDialogData;
	(*p_PageSetupData) = *PrintDataPointer;
	p_PageSetupData->SetMarginTopLeft(wxPoint(9, 9));
	p_PageSetupData->SetMarginBottomRight(wxPoint(9, 9));

	int mainWindowX = configPointer->Read("/Main/Window_Position_X", 30 + ubuntuOffsetX);
	int mainWindowY = configPointer->Read("/Main/Window_Position_Y", 30);

	WindowInfo windowInfo = getWinSizeInfo();

	p_Main = new Main("Emma 02", wxPoint(mainWindowX, mainWindowY), wxSize(windowInfo.mainwX, windowInfo.mainwY), mode_, dataDir_, regPointer);

	configPointer->Write("/Main/Version", EMMA_VERSION);

	p_Main->Show(mode_.gui);

	if (startComputer_ != -1)
		p_Main->onStart(startComputer_);
	if (mode_.run || mode_.load)
		p_Main->runSoftware(!mode_.run);
	return true;
}

int Emu1802::OnExit()
{
	delete wxConfigBase::Set((wxConfigBase *) NULL);
	delete regPointer;
	delete PrintDataPointer;
	delete p_PageSetupData;
	return 0;
}

int Emu1802::OnRun()
{
    int exitcode = wxApp::OnRun();
    //wxTheClipboard->Flush();
    //if (exitcode!=0)
    return exitcode;
}
 
static const wxCmdLineEntryDesc cmdLineDesc[] =
{
    { wxCMD_LINE_SWITCH, "h", "help", "show this help message", wxCMD_LINE_VAL_NONE, wxCMD_LINE_OPTION_HELP },
	{ wxCMD_LINE_SWITCH, "p", "portable", "run in portable mode" },									
	{ wxCMD_LINE_SWITCH, "v", "verbose", "verbose output"},											// only valid in combination with -c
	{ wxCMD_LINE_SWITCH, "f", "fullscreen", "full screen mode"},									// only valid in combination with -c
	{ wxCMD_LINE_SWITCH, "u", "skipupdate", "skip update check"},									
	{ wxCMD_LINE_SWITCH, "w", "window", "non fixed window positions"},									
    { wxCMD_LINE_OPTION, "c", "computer", "start emulator without gui and for specified computer" },// Switch off GUI
	{ wxCMD_LINE_OPTION, "s", "software", "load specified software on start" },						// only valid in combination with -c
	{ wxCMD_LINE_OPTION, "r", "run", "run specified software on start" },							// only valid in combination with -c
	{ wxCMD_LINE_OPTION, "ch", "chip8", "load specified chip8 software on start" },					// only valid in combination with -c

    { wxCMD_LINE_NONE }
};

void Emu1802::OnInitCmdLine(wxCmdLineParser& parser)
{
    parser.SetDesc (cmdLineDesc);
    // must refuse '/' as parameter starter or cannot use "/path" style paths
    parser.SetSwitchChars (wxT("-"));
}
 
bool Emu1802::OnCmdLineParsed(wxCmdLineParser& parser)
{
	mode_.window_position_fixed = !parser.Found("w");
 	mode_.portable = parser.Found("p");
	mode_.verbose = parser.Found("v");
	mode_.full_screen = parser.Found("f");
	mode_.update_check = !parser.Found("u");

	SetVendorName("Marcel van Tongeren");
#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
	wxString appName = "emma_02";
#else
	wxString appName = "Emma 02";
#endif
	SetAppName(appName);

	regPointer = wxConfigBase::Get();
	regPointer->SetRecordDefaults();

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
	wxString workingDir_;
	if (mode_.portable)
		workingDir_ = wxGetCwd();
	else
		workingDir_ = wxStandardPaths::Get().GetDataDir();
	wxFileName applicationFile = wxFileName(workingDir_, "", wxPATH_NATIVE);
	wxString pathSeparator_ = applicationFile.GetPathSeparator(wxPATH_NATIVE);
	dataDir_ = regPointer->Read("/DataDir", stPath.GetDocumentsDir() + pathSeparator_ + "Documents" + pathSeparator_ + "emma_02" + pathSeparator_);
	wxString applicationDirectory_;
	if (mode_.portable)
		applicationDirectory_ = applicationFile.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);
	else
		applicationDirectory_ = workingDir_ + pathSeparator_;
#else
	wxString workingDir_ = wxGetCwd();
	wxFileName applicationFile = wxFileName(workingDir_, "", wxPATH_NATIVE);
	wxString pathSeparator_ = applicationFile.GetPathSeparator(wxPATH_NATIVE);
	dataDir_ = regPointer->Read("/DataDir", wxStandardPaths::Get().GetUserDataDir() + pathSeparator_);
	wxString applicationDirectory_ = applicationFile.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);
#endif

	if (mode_.portable)
	{
		dataDir_ = applicationDirectory_ + "data" + pathSeparator_;
#if wxCHECK_VERSION(2, 9, 0)
		if (!wxDir::Exists(dataDir_))
			wxDir::Make(dataDir_);
#endif
	}

	wxFileConfig *pConfig = new wxFileConfig(appName, "Marcel van Tongeren", dataDir_ + "emma_02.ini");
    wxConfigBase::Set(pConfig);
	configPointer= wxConfigBase::Get();

	if (mode_.portable)
	{
		if (configPointer->Read("Dir/Main/Debug", dataDir_) != dataDir_)
			configPointer->DeleteGroup("Dir");
	}

	startComputer_ = -1;
    mode_.gui = true;
    mode_.run = false;
    mode_.load = false;
	wxString software = "";
	wxString computer;
 
	if (parser.Found("c", &computer))
	{
#if wxCHECK_VERSION(2, 9, 0)
		computer = computer.Capitalize();
		switch(computer[0].GetValue())
#else
		computer = computer.MakeUpper();
		switch(computer[0])
#endif
		{
			case 'C':
				if (computer == "Comx")
				{
					startComputer_ = COMX;
					mode_.gui = false;
					if (parser.Found("s", &software))
					{
						mode_.load = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("r", &software))
					{
						mode_.run = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on COMX-35 emulator");
						return false;
					}
					return true;
				}
				if (computer == "Cosmicos")
				{
					startComputer_ = COSMICOS;
					mode_.gui = false;
					if (parser.Found("s", &software))
					{
						mode_.load = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("r", &software))
					{
						wxMessageOutput::Get()->Printf("Option -r is not supported on Cosmicos emulator");
						return false;
					}
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on Cosmicosemulator");
						return false;
					}
					return true;
				}
				if (computer == "Cosmac")
				{
					startComputer_ = ELF;
					computer = "Elf";
					mode_.gui = false;
					if (parser.Found("s", &software))
					{
						mode_.load = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("r", &software))
					{
						mode_.run = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on Cosmac Elf emulator");
						return false;
					}
					return true;
				}
				if (computer == "Cidelsa")
				{
					startComputer_ = CIDELSA;
					mode_.gui = false;
					if (parser.Found("s", &software))
						getSoftware(computer, "Main_Rom_File", software);
					if (parser.Found("r", &software))
						getSoftware(computer, "Main_Rom_File", software);
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on Cidelsa emulator");
						return false;
					}
					return true;
				}
				wxMessageOutput::Get()->Printf("Incorrect computer name specified");
				return false;
			break;

			case 'E':
				if (computer == "Elf2k")
				{
					startComputer_ = ELF2K;
					mode_.gui = false;
					if (parser.Found("s", &software))
					{
						mode_.load = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("r", &software))
					{
						wxMessageOutput::Get()->Printf("Option -r is not supported on Elf 2000 emulator");
						return false;
					}
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on Elf 2000 emulator");
						return false;
					}
					return true;
				}
				if (computer == "Eti" || computer == "Eti660")
				{
					startComputer_ = ETI;
					mode_.gui = false;
					if (parser.Found("s", &software))
					{
						mode_.load = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("ch", &software))
						getSoftware(computer, "Chip_8_Software", software);
					if (parser.Found("r", &software))
					{
						wxMessageOutput::Get()->Printf("Option -r is not supported on ETI 660 emulator");
						return false;
					}
					return true;
				}
				wxMessageOutput::Get()->Printf("Incorrect computer name specified");
				return false;
			break;

			case 'M':
				if (computer == "Membership")
				{
					startComputer_ = MEMBER;
					mode_.gui = false;
					if (parser.Found("s", &software))
					{
						mode_.load = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("r", &software))
					{
						wxMessageOutput::Get()->Printf("Option -r is not supported on Membership Card emulator");
						return false;
					}
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on Membership Card emulator");
						return false;
					}
					return true;
				}
				wxMessageOutput::Get()->Printf("Incorrect computer name specified");
				return false;
			break;

			case 'N':
				if (computer == "Netronics")
				{
					startComputer_ = ELFII;
					computer = "ElfII";
					mode_.gui = false;
					if (parser.Found("s", &software))
					{
						mode_.load = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("r", &software))
					{
						mode_.run = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on Netronics Elf II emulator");
						return false;
					}
					return true;
				}
				if (computer == "Nano")
				{
					startComputer_ = NANO;
					mode_.gui = false;
					if (parser.Found("s", &software))
						getSoftware(computer, "Ram_Software", software);
					if (parser.Found("ch", &software))
						getSoftware(computer, "Chip_8_Software", software);
					if (parser.Found("r", &software))
					{
						wxMessageOutput::Get()->Printf("Option -r is not supported on Oscom Nano emulator");
						return false;
					}
					return true;
				}
				wxMessageOutput::Get()->Printf("Incorrect computer name specified");
				return false;
			break;

			case 'P':
				if (computer == "Pecom")
				{
					startComputer_ = PECOM;
					mode_.gui = false;
					if (parser.Found("s", &software))
					{
						mode_.load = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("r", &software))
					{
						mode_.run = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on Pecom 64 emulator");
						return false;
					}
					return true;
				}
			break;

			case 'Q':
				if (computer == "Quest")
				{
					startComputer_ = SUPERELF;
					computer = "SuperElf";
					mode_.gui = false;
					if (parser.Found("s", &software))
					{
						mode_.load = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("r", &software))
					{
						mode_.run = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on Quest Super Elf emulator");
						return false;
					}
					return true;
				}
				wxMessageOutput::Get()->Printf("Incorrect computer name specified");
				return false;
			break;

			case 'S':
				if (computer == "Studio")
				{
					startComputer_ = STUDIO;
					computer = "Studio2";
					mode_.gui = false;
					if (parser.Found("s", &software))
						getSoftware(computer, "St2_File", software);
					if (parser.Found("r", &software))
						getSoftware(computer, "St2_File", software);
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on RCA Studio II emulator");
						return false;
					}
					return true;
				}
				wxMessageOutput::Get()->Printf("Incorrect computer name specified");
				return false;
			break;

			case 'T':
				if (computer == "Tmc600" || computer == "Telmac600")
				{
					startComputer_ = TMC600;
					computer = "TMC600";
					mode_.gui = false;
					if (parser.Found("s", &software))
					{
						mode_.load = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("r", &software))
					{
						mode_.run = true;
						getSoftware(computer, "Software_File", software);
					}
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on TMC-600 emulator");
						return false;
					}
					return true;
				}
				if (computer == "Tmc1800" || computer == "Telmac1800")
				{
					startComputer_ = TMC1800;
					computer = "TMC1800";
					mode_.gui = false;
					if (parser.Found("s", &software))
						getSoftware(computer, "Ram_Software", software);
					if (parser.Found("ch", &software))
						getSoftware(computer, "Chip_8_Software", software);
					if (parser.Found("r", &software))
					{
						wxMessageOutput::Get()->Printf("Option -r is not supported on Telmac 1800 emulator");
						return false;
					}
					return true;
				}
				if (computer == "Tmc2000" || computer == "Telmac2000")
				{
					startComputer_ = TMC2000;
					computer = "TMC2000";
					mode_.gui = false;
					if (parser.Found("s", &software))
						getSoftware(computer, "Ram_Software", software);
					if (parser.Found("ch", &software))
						getSoftware(computer, "Chip_8_Software", software);
					if (parser.Found("r", &software))
					{
						wxMessageOutput::Get()->Printf("Option -r is not supported on Telmac 2000 emulator");
						return false;
					}
					return true;
				}
				wxMessageOutput::Get()->Printf("Incorrect computer name specified");
				return false;
			break;

			case 'V':
				if (computer == "Visicom")
				{
					startComputer_ = VISICOM;
					mode_.gui = false;
					if (parser.Found("s", &software))
						getSoftware(computer, "St2_File", software);
					if (parser.Found("r", &software))
						getSoftware(computer, "St2_File", software);
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on Visicom COM-100 emulator");
						return false;
					}
					return true;
				}
				if (computer == "Victory")
				{
					startComputer_ = VICTORY;
					mode_.gui = false;
					if (parser.Found("s", &software))
						getSoftware(computer, "St2_File", software);
					if (parser.Found("r", &software))
						getSoftware(computer, "St2_File", software);
					if (parser.Found("ch", &software))
					{
						wxMessageOutput::Get()->Printf("Option -ch is not supported on Victory MPT-02 emulator");
						return false;
					}
					return true;
				}
				if (computer == "Vip")
				{
					startComputer_ = VIP;
					mode_.gui = false;
					if (parser.Found("s", &software))
						getSoftware(computer, "Ram_Software", software);
					if (parser.Found("ch", &software))
						getSoftware(computer, "Chip_8_Software", software);
					if (parser.Found("r", &software))
					{
						wxMessageOutput::Get()->Printf("Option -r is not supported on Cosmac VIP emulator");
						return false;
					}
					return true;
				}
				if (computer == "VipII")
				{
					startComputer_ = VIPII;
					mode_.gui = false;
					if (parser.Found("s", &software))
						getSoftware(computer, "Ram_Software", software);
					if (parser.Found("ch", &software))
						getSoftware(computer, "Chip_8_Software", software);
					if (parser.Found("r", &software))
					{
						wxMessageOutput::Get()->Printf("Option -r is not supported on Cosmac VIP II emulator");
						return false;
					}
					return true;
				}
				wxMessageOutput::Get()->Printf("Incorrect computer name specified");
				return false;
			break;

			default:
				wxMessageOutput::Get()->Printf("Incorrect computer name specified");
				return false;
			break;
		}
	} 
    return true;
}

void Emu1802::getSoftware(wxString computer, wxString type, wxString software)
{
	wxFileName FullPath = wxFileName(software, wxPATH_NATIVE);
	if (FullPath.IsRelative())
	{
		configPointer->Write(computer + "/"+type, software);
	}
	else
	{
		configPointer->Write("Dir/"+computer+"/"+type, FullPath.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE));
		configPointer->Write(computer + "/"+type, FullPath.GetFullName());
	}
}

Main::Main(const wxString& title, const wxPoint& pos, const wxSize& size, Mode mode, wxString dataDir, wxConfigBase *regP)
: DebugWindow(title, pos, size, mode, dataDir)
{
	wxFileSystem::AddHandler(new wxInternetFSHandler); 
	regPointer = regP;

	popupDialog_ = NULL;
	emmaClosing_ = false;
	windowInfo = getWinSizeInfo();
	xmlLoaded_ = false;

#ifndef __WXMAC__
	SetIcon(wxICON(app_icon));
#endif

	if (mode_.gui)
	{
        SetMenuBar(wxXmlResource::Get()->LoadMenuBar("Main_Menu"));
		wxXmlResource::Get()->LoadPanel(this, "Main_GUI");
	}

	updateMemory_ = false;
	updateSlotinfo_ = false;
	for (int x=0; x<16; x++)
		for (int y=0; y<16; y++)
			memoryChanged_[x][y] = false;
	for (int y=0; y<16; y++)
		rowChanged_[y] = false;

	xmlLoaded_ = true;
	computerRunning_ = false;
	runningComputer_ = NO_COMPUTER;

	eventNumber_ = 0;

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
	wxString helpFile = applicationDirectory_ + "emma_02.htb";
#else
	wxString helpFile = applicationDirectory_ + "Emma 02.htb";
#endif

    help_ = new wxHtmlHelpController(wxHF_TOOLBAR | wxHF_CONTENTS | wxHF_INDEX | wxHF_SEARCH | wxHF_BOOKMARKS | wxHF_PRINT | wxHF_BOOKMARKS);
	
 	if (!help_->AddBook(helpFile))
	{
		(void)wxMessageBox( "Failed adding book " + helpFile + "\n",
							"Emma 02", wxICON_ERROR | wxOK );
	}

	if (mode_.gui)
	{
		this->Connect(XRCID(GUICOMPUTERNOTEBOOK), wxEVT_COMMAND_NOTEBOOK_PAGE_CHANGED, wxNotebookEventHandler(Main::onComputer) );
		wxFont smallFont(6, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
		XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetFont(smallFont);
#if defined(__WXMAC__)
		wxFont defaultFont(9, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
		XRCCTRL(*this, "VuComx", wxStaticBitmap)->Hide();
		XRCCTRL(*this, "VuVip", wxStaticBitmap)->Hide();
		XRCCTRL(*this, "VuCosmicos", wxStaticBitmap)->Hide();
		XRCCTRL(*this, "VuElf", wxStaticBitmap)->Hide();
		XRCCTRL(*this, "VuElfII", wxStaticBitmap)->Hide();
		XRCCTRL(*this, "VuSuperElf", wxStaticBitmap)->Hide();
		XRCCTRL(*this, "VuTmc600", wxStaticBitmap)->Hide();
		XRCCTRL(*this, "VuTMC2000", wxStaticBitmap)->Hide();
		XRCCTRL(*this, "VuTMC1800", wxStaticBitmap)->Hide();
		XRCCTRL(*this, "VuNano", wxStaticBitmap)->Hide();
		XRCCTRL(*this, "VuPecom", wxStaticBitmap)->Hide();
		XRCCTRL(*this, "VuEti", wxStaticBitmap)->Hide();
#else
		wxFont defaultFont(8, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
#endif
		XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetFont(defaultFont);

		wxString text;
		pcTextPointer = XRCCTRL(*this,"Chip8PC", wxTextCtrl);
		iTextPointer = XRCCTRL(*this,"Chip8I", wxTextCtrl);
		chip8TraceWindowPointer = XRCCTRL(*this,"Chip8TraceWindow", wxTextCtrl);
		for (int i=0; i<16; i++)
		{
			text.Printf("R%d",i);
			registerTextPointer[i] = XRCCTRL(*this,text, wxTextCtrl);
			text.Printf("V%01X",i);
			chip8varTextPointer[i] = XRCCTRL(*this,text, wxTextCtrl);
		}
		for (int i=1; i<8; i++)
		{
			text.Printf("I%d",i);
			inTextPointer[i] = XRCCTRL(*this,text, wxTextCtrl);
			text.Printf("O%d",i);
			outTextPointer[i] = XRCCTRL(*this,text, wxTextCtrl);
		}
		for (int i=1; i<5; i++)
		{
			text.Printf("EF%d",i);
			efTextPointer[i] = XRCCTRL(*this,text, wxTextCtrl);
		}
		dfTextPointer = XRCCTRL(*this,"DF", wxTextCtrl);
		qTextPointer = XRCCTRL(*this,"Q", wxTextCtrl);
		ieTextPointer = XRCCTRL(*this,"IE", wxTextCtrl);
		dTextPointer = XRCCTRL(*this,"D", wxTextCtrl);
		pTextPointer = XRCCTRL(*this,"P", wxTextCtrl);
		xTextPointer = XRCCTRL(*this,"X", wxTextCtrl);
		tTextPointer = XRCCTRL(*this,"T", wxTextCtrl);

//		assemblerWindowPointer = XRCCTRL(*this,"AssemblerWindow", wxTextCtrl);
//		disassemblerWindowPointer = XRCCTRL(*this,"DisassemblerWindow", wxTextCtrl);
		traceWindowPointer = XRCCTRL(*this,"TraceWindow", wxTextCtrl);
//		inputWindowPointer = XRCCTRL(*this,"InputWindow", wxTextCtrl);
		assInputWindowPointer = XRCCTRL(*this,"AssInputWindow", wxTextCtrl);
		assErrorWindowPointer = XRCCTRL(*this,"AssErrorMultiLine", wxTextCtrl);
		breakPointWindowPointer = XRCCTRL(*this,"BreakPointWindow", wxListCtrl);
		chip8BreakPointWindowPointer = XRCCTRL(*this,"Chip8BreakPointWindow", wxListCtrl);
		tregWindowPointer = XRCCTRL(*this,"TregWindow", wxListCtrl);
		trapWindowPointer = XRCCTRL(*this,"TrapWindow", wxListCtrl);
	}
	readConfig();

	oldGauge_ = 1;
	vuPointer = new wxTimer(this, 902);
	cpuPointer = new wxTimer(this, 903);
	ledPointer = new wxTimer(this, 904);
	updateCheckPointer = new wxTimer(this, 905);

	this->connectKeyEvent(this);

	wxSystemOptions::SetOption("msw.window.no-clip-children", 0);

	int lastYearWeek;
	configPointer->Read("/Main/YearWeek", &lastYearWeek ,0);

	wxDateTime now = wxDateTime::Now();
	int yearWeek = now.GetYear()*100 + now.GetWeekOfYear();

	if (mode_.update_check) 
	{
		if (lastYearWeek < yearWeek)
		{
			updateCheckPointer->Start(10000, wxTIMER_ONE_SHOT);
			configPointer->Write("/Main/YearWeek", yearWeek);
		}
	}
}

Main::~Main()
{
	if (mode_.gui)
	{
		for (int computer=0; computer<NO_COMPUTER; computer++)
		{
			delete clockText[computer];
			delete clockTextCtrl[computer];
			delete mhzText[computer];
			delete startButton[computer];
		}
	}

	delete vuPointer;
	delete cpuPointer;
	delete updateCheckPointer;
	delete ledPointer;
	delete help_;
	if (configPointer == NULL || !saveOnExit_)
		return;

	this->GetPosition(&mainWindowX_, &mainWindowY_);
	writeConfig();
}

void Main::pageSetup()
{
	(*p_PageSetupData) = *PrintDataPointer;

	 wxPageSetupDialog pageSetupDialog(this, p_PageSetupData);
	 pageSetupDialog.ShowModal();

	(*PrintDataPointer) = pageSetupDialog.GetPageSetupDialogData().GetPrintData();
	(*p_PageSetupData) = pageSetupDialog.GetPageSetupDialogData();
}

void Main::writeConfig()
{
	wxMenuBar *menubarPointer = GetMenuBar();



	if (mainWindowX_ > 0)
		configPointer->Write("/Main/Window_Position_X", mainWindowX_);
	if (mainWindowY_ > 0)
		configPointer->Write("/Main/Window_Position_Y", mainWindowY_);

	if (mode_.gui)
	{
		configPointer->Write("/Main/Selected_Tab", XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->GetSelection());
		configPointer->Write("/Main/Selected_Cosmac_Tab", XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->GetSelection());
		configPointer->Write("/Main/Selected_Studio_Tab", XRCCTRL(*this, "StudioChoiceBook", wxChoicebook)->GetSelection());
		configPointer->Write("/Main/Selected_Telmac_Tab", XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->GetSelection());
		configPointer->Write("/Main/Selected_Debugger_Tab", XRCCTRL(*this, "DebuggerChoiceBook", wxChoicebook)->GetSelection());

		if (menubarPointer->IsChecked(XRCID("CDP1802")))
			configPointer->Write("/Main/Cpu_Type", "CDP1802");
		if (menubarPointer->IsChecked(XRCID("CDP1804")))
			configPointer->Write("/Main/Cpu_Type", "CDP1804");
		if (menubarPointer->IsChecked(XRCID("CDP1805")))
			configPointer->Write("/Main/Cpu_Type", "CDP1805");

		if (menubarPointer->IsChecked(XRCID("Flat")))
			configPointer->Write("/Main/Equalization", "Flat");
		if (menubarPointer->IsChecked(XRCID("Crisp")))
			configPointer->Write("/Main/Equalization", "Crisp");
		if (menubarPointer->IsChecked(XRCID("Default")))
			configPointer->Write("/Main/Equalization", "Default");
		if (menubarPointer->IsChecked(XRCID("TV Speaker")))
			configPointer->Write("/Main/Equalization", "TV Speaker");
		if (menubarPointer->IsChecked(XRCID("Handheld")))
			configPointer->Write("/Main/Equalization", "Handheld");
	}
	if (!mode_.portable)
		regPointer->Write("/DataDir", dataDir_);
	configPointer->Write("/Main/Save_Debug_File", saveDebugFile_);
	configPointer->Write("/Main/Save_On_Exit", saveOnExit_);
	configPointer->Write("/Main/Check_For_Update", checkForUpdate_);
	configPointer->Write("/Main/Floating_Point_Zoom", fullScreenFloat_);
	configPointer->Write("/Main/Use_Exit_Key", useExitKey_);
	configPointer->Write("/Main/Exit_Key", functionKey_[0]);
	configPointer->Write("/Main/Help_Key", functionKey_[1]);
	configPointer->Write("/Main/Activate_Main_Key", functionKey_[2]);
	configPointer->Write("/Main/Full_Screen_Key", functionKey_[3]);
	configPointer->Write("/Main/Printer_Window_Key", functionKey_[4]);
	configPointer->Write("/Main/Video_Dump_Key", functionKey_[5]);
	configPointer->Write("/Main/Debug_Mode_Key", functionKey_[6]);
	configPointer->Write("/Main/Menu_Key", functionKey_[7]);
	configPointer->Write("/Main/Start_Reset_Key", functionKey_[12]);
	configPointer->Write("/Main/Psave_Volume", psaveData_[0]);
	configPointer->Write("/Main/Psave_Bit_Rate", psaveData_[1]);
	configPointer->Write("/Main/Psave_Bits_Per_Sample", psaveData_[2]);
	configPointer->Write("/Main/Wav_Conversion_Type", psaveData_[3]);
	configPointer->Write("/Main/Cassette_Input_Channel", psaveData_[4]);
	configPointer->Write("/Main/Cassette_Playback_Input", psaveData_[5]);
	configPointer->Write("/Main/Cassette_Reversed_Polarity", psaveData_[6]);
	configPointer->Write("/Main/Cassette_Conversion_Type", psaveData_[7]);
	configPointer->Write("/Main/Window_Positions_Fixed", mode_.window_position_fixed);

	writeDebugConfig();
	writeComxConfig();
	writeElf2KConfig();
	writeCosmicosConfig();
	writeVipConfig();
	writeVipIIConfig();
	writeElfConfig(ELF, "Elf");
	writeElfConfig(ELFII, "ElfII");
	writeElfConfig(SUPERELF, "SuperElf");
	writeMembershipConfig();
	writeStudioConfig();
	writeVisicomConfig();
	writeVictoryConfig();
	writeCidelsaConfig();
	writeTelmacConfig();
	writeTMC2000Config();
	writeTMC1800Config();
	writeNanoConfig();
	writePecomConfig();
	writeEtiConfig();
}

void Main::readConfig()
{
	wxMenuBar *menubarPointer = GetMenuBar();
	Byte brightness [8] = { 0, 28, 77, 105, 150, 194, 227, 0xff };

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMGL__)
	ubuntuOffsetX_ = 36;
#else
	ubuntuOffsetX_ = 0;
#endif

	mainWindowX_ = configPointer->Read("/Main/Window_Position_X", 30 + ubuntuOffsetX_);
	mainWindowY_ = configPointer->Read("/Main/Window_Position_Y", 30);

	percentageClock_ = 1;

	wxString colour[66];
	int borderX[10];
	int borderY[10];

	for (int i=0; i<8; i++)
	{
		colour[i*8].Printf("#%02X%02X%02X", (brightness[i]^0xff)&0xff, (brightness[i]^0xff)&0xff, (brightness[i]^0xff)&0xff);
		colour[i*8+1].Printf("#%02X%02X%02X", 0, brightness[i], 0);
		colour[i*8+2].Printf("#%02X%02X%02X", 0, 0, brightness[i]);
		colour[i*8+3].Printf("#%02X%02X%02X", 0, brightness[i], brightness[i]);
		colour[i*8+4].Printf("#%02X%02X%02X", brightness[i], 0, 0);
		colour[i*8+5].Printf("#%02X%02X%02X", brightness[i], brightness[i], 0);
		colour[i*8+6].Printf("#%02X%02X%02X", brightness[i], 0, brightness[i]);
		colour[i*8+7].Printf("#%02X%02X%02X", brightness[i], brightness[i], brightness[i]);
	}
	colour[64] = "#00ff00";	// foreground 80 Column
	colour[65] = "#004000";	// background 80 Column

	borderX[VIDEO1870] = 0;
	borderY[VIDEO1870] = 0; // CDP 1870
	borderX[VIDEO80COL] = 0;
	borderY[VIDEO80COL] = 0;  // 80 Column

	setScreenInfo(COMX, 0, 66, colour, 3, borderX, borderY);
	setComputerInfo(COMX, "Comx", "COMX-35", "comx");

	setScreenInfo(CIDELSA, 56, 64, colour, 1, borderX, borderY);
	setComputerInfo(CIDELSA, "Cidelsa", "Cidelsa", "");

	setScreenInfo(TMC600, 56, 64, colour, 1, borderX, borderY);
	setComputerInfo(TMC600, "Tmc600", "Telmac 600", "tmc600");

	setScreenInfo(PECOM, 56, 64, colour, 1, borderX, borderY);
	setComputerInfo(PECOM, "Pecom", "Pecom 64", "pecom");

	borderX[VIDEOVT] = 0;
	borderY[VIDEOVT] = 0;  //Video Terminal
	borderX[VIDEOPIXIE] = 11;
	borderY[VIDEOPIXIE] = 33;  //Pixie
	borderX[VIDEO2KI8275] = 0;
	borderY[VIDEO2KI8275] = 0;  //i8275

	colour[0] = "#ffffff";	// foreground pixie
	colour[1] = "#000000";	// background pixie
	colour[2] = "#00ff00";	// foreground i8275
	colour[3] = "#004000";	// background i8275
	colour[4] = "#00ff00";	// highlight i8275
	setScreenInfo(ELF2K, 0, 5, colour,  3, borderX, borderY);
	setComputerInfo(ELF2K, "Elf2K", "Elf 2000", "");
	setScreenInfo(MEMBER, 0, 5, colour,  1, borderX, borderY);
	setComputerInfo(MEMBER, "Membership", "Membership Card", "");

	borderX[VIDEOPIXIE] = 8;
	borderY[VIDEOPIXIE] = 32;  //CDP1864

	setScreenInfo(COSMICOS, 0, 5, colour,  2, borderX, borderY);
	setComputerInfo(COSMICOS, "Cosmicos", "Cosmicos", "");

	colour[5] = "#000000";	// background mc6847
	colour[6] = "#00ff00";	// text green
	colour[7] = "#ffc418";	// text orange
	colour[8] = "#00ff00";	// graphic Green
	colour[9] = "#ffff00";	// graphic Yellow 
	colour[10] = "#0000ff";	// graphic Blue
	colour[11] = "#ff0000";	// graphic Red
	colour[12] = "#ffffff";	// graphic Buff
	colour[13] = "#00ffff";	// graphic Cyan
	colour[14] = "#ff00ff";	// graphic Magenta
	colour[15] = "#ffc418";	// graphic Orange
	colour[16] = "#000000";
	colour[17] = "#000000";
	colour[18] = "#007f00";
	colour[19] = "#00ff00";
	colour[20] = "#00003f";
	colour[21] = "#0000ff";
	colour[22] = "#3f0000";
	colour[23] = "#007f7f";
	colour[24] = "#7f0000";
	colour[25] = "#ff0000";
	colour[26] = "#7f7f00";
	colour[27] = "#ffff00";
	colour[28] = "#003f00";
	colour[29] = "#7f007f";
	colour[30] = "#7f7f7f";
	colour[31] = "#ffffff";

	borderX[VIDEO6845] = 0;
	borderY[VIDEO6845] = 0;  //6845
	borderX[VIDEO6847] = 25;
	borderY[VIDEO6847] = 25;  //6847
	borderX[VIDEOTMS] = 32;
	borderY[VIDEOTMS] = 24;  //TMS
	borderX[VIDEOI8275] = 0;
	borderY[VIDEOI8275] = 0;  //i8275
	borderX[VIDEOPIXIE] = 11;
	borderY[VIDEOPIXIE] = 33;  //Pixie

	setScreenInfo(ELF, 0, 32, colour, 6, borderX, borderY);
	setComputerInfo(ELF, "Elf", "Cosmac Elf", "");

	setScreenInfo(ELFII, 0, 32, colour, 6, borderX, borderY);
	setComputerInfo(ELFII, "ElfII", "Netronics Elf II", "super");

	setScreenInfo(SUPERELF, 0, 32, colour, 6, borderX, borderY);
	setComputerInfo(SUPERELF, "SuperElf", "Quest Super Elf", "super");

	setScreenInfo(STUDIO, 0, 2, colour, 2, borderX, borderY);
	setComputerInfo(STUDIO, "Studio2", "Studio II", "");

	setScreenInfo(TMC1800, 0, 2, colour, 2, borderX, borderY);
	setComputerInfo(TMC1800, "TMC1800", "Telmac 1800", "");

	borderX[VIDEOPIXIE] = 8;
	borderY[VIDEOPIXIE] = 32;  //CDP1864

	setScreenInfo(NANO, 0, 2, colour, 2, borderX, borderY);
	setComputerInfo(NANO, "Nano", "Telmac Nano", "");

	borderX[VIDEOPIXIE] = 11;
	borderY[VIDEOPIXIE] = 33;  //Pixie

	colour[0] = "#004000";
	colour[1] = "#70d0ff";
	colour[2] = "#d0ff70";
	colour[3] = "#ff7070";
	setScreenInfo(VISICOM, 0, 4, colour, 2, borderX, borderY);
	setComputerInfo(VISICOM, "Visicom", "Visicom COM-100", "");

	colour[0] = "#141414";
	colour[1] = "#ff0000";
	colour[2] = "#0000ff";
	colour[3] = "#ff00ff";
	colour[4] = "#00ff00";
	colour[5] = "#ffff00";
	colour[6] = "#00ffff";
	colour[7] = "#ffffff";
	colour[8] = "#000080";
	colour[9] = "#000000";
	colour[10] = "#008000";
	colour[11] = "#800000";
	setScreenInfo(VIP, 0, 12, colour, 2, borderX, borderY);
	setComputerInfo(VIP, "Vip", "Cosmac VIP", "");

	setScreenInfo(VIPII, 0, 12, colour, 2, borderX, borderY);
	setComputerInfo(VIPII, "VipII", "Cosmac VIP II", "fpb");

	borderX[VIDEOPIXIE] = 8;
	borderY[VIDEOPIXIE] = 32;  //CDP1864

	setScreenInfo(ETI, 0, 12, colour, 2, borderX, borderY);
	setComputerInfo(ETI, "Eti", "ETI 660", "");

	colour[0] = "#ffffff";
	colour[1] = "#ff00ff";
	colour[2] = "#00ffff";
	colour[3] = "#0000ff";
	colour[4] = "#ffff00";
	colour[5] = "#ff0000";
	colour[6] = "#00ff00";
	colour[7] = "#141414";
	setScreenInfo(TMC2000, 0, 12, colour, 2, borderX, borderY);
	setComputerInfo(TMC2000, "TMC2000", "Telmac 2000", "");

	colour[0] = "#141414"; // Black
	colour[1] = "#ff4040"; // Red
	colour[2] = "#4040ff"; // Blue
	colour[3] = "#ff40ff"; // Pink
	colour[4] = "#40ff40"; // Green
	colour[5] = "#ffff40"; // Yellow
	colour[6] = "#40ffff"; // Cyan
	colour[7] = "#ffffff"; // white
	colour[8] = "#000080";
	colour[9] = "#000000";
	colour[10] = "#008000";
	colour[11] = "#800000";
	colour[12] = "#141414"; // Black
	colour[13] = "#AC0324"; // Red
	colour[14] = "#221354"; // Blue
	colour[15] = "#A16976"; // Pink
	colour[16] = "#375E01"; // Green
	colour[17] = "#99B348"; // Yellow
	colour[18] = "#8580C0"; // Cyan
	colour[19] = "#ffffff"; // white
	colour[20] = "#110247";
	colour[21] = "#000000";
	colour[22] = "#284C02";
	colour[23] = "#800000";

	setScreenInfo(VICTORY, 0, 24, colour, 2, borderX, borderY);
	setComputerInfo(VICTORY, "Victory", "Victory MPT-02", "");

	wxFont smallFont(6, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
#if defined(__WXMAC__)
	wxFont defaultFont(9, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
#else
	wxFont defaultFont(8, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
#endif
	if (mode_.gui)
	{
		for (int computer=0; computer<NO_COMPUTER; computer++)
		{
			switch (computer)
			{
				case COMX:
				case PECOM:
				case CIDELSA:
				case ETI:
#if defined(__WXMAC__)
					clockText[computer] = new wxStaticText(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), wxID_ANY, "Clock:", wxPoint(windowInfo.RegularClockX, windowInfo.RegularClockY+3));
					clockTextCtrl[computer] = new FloatEdit(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), GUI_CLOCK_TEXTCTRL+computer, "", wxPoint(windowInfo.RegularClockX+35, windowInfo.RegularClockY+2), wxSize(45, 19));
					mhzText[computer] = new wxStaticText(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), wxID_ANY, "MHz", wxPoint(windowInfo.RegularClockX+81, windowInfo.RegularClockY+3));
					startButton[computer] = new wxButton(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), GUI_START_BUTTON +computer, "Start", wxPoint(windowInfo.RegularClockX+109, windowInfo.RegularClockY-7), wxSize(80, 25));
#else
					clockText[computer] = new wxStaticText(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), wxID_ANY, "Clock:", wxPoint(windowInfo.RegularClockX, windowInfo.RegularClockY+3));
					clockTextCtrl[computer] = new FloatEdit(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), GUI_CLOCK_TEXTCTRL+computer, "", wxPoint(windowInfo.RegularClockX+32, windowInfo.RegularClockY), wxSize(45, 23));
					mhzText[computer] = new wxStaticText(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), wxID_ANY, "MHz", wxPoint(windowInfo.RegularClockX+81, windowInfo.RegularClockY+3));
					startButton[computer] = new wxButton(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), GUI_START_BUTTON +computer, "Start", wxPoint(windowInfo.RegularClockX+109, windowInfo.RegularClockY-1), wxSize(80, 25));
#endif
					break;

				default:
#if defined(__WXMAC__)
					clockText[computer] = new wxStaticText(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), wxID_ANY, "Clock:", wxPoint(windowInfo.ChoiceClockX, windowInfo.ChoiceClockY+3));
					clockTextCtrl[computer] = new FloatEdit(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), GUI_CLOCK_TEXTCTRL+computer, "", wxPoint(windowInfo.ChoiceClockX+35, windowInfo.ChoiceClockY+2), wxSize(45, 19));
					mhzText[computer] = new wxStaticText(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), wxID_ANY, "MHz", wxPoint(windowInfo.ChoiceClockX+81, windowInfo.ChoiceClockY+3));
					startButton[computer] = new wxButton(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), GUI_START_BUTTON +computer, "Start", wxPoint(windowInfo.ChoiceClockX+109, windowInfo.ChoiceClockY-7), wxSize(80, 25));
#else
					clockText[computer] = new wxStaticText(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), wxID_ANY, "Clock:", wxPoint(windowInfo.ChoiceClockX, windowInfo.ChoiceClockY+3));
					clockTextCtrl[computer] = new FloatEdit(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), GUI_CLOCK_TEXTCTRL+computer, "", wxPoint(windowInfo.ChoiceClockX+32, windowInfo.ChoiceClockY), wxSize(45, 23));
					mhzText[computer] = new wxStaticText(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), wxID_ANY, "MHz", wxPoint(windowInfo.ChoiceClockX+81, windowInfo.ChoiceClockY+3));
					startButton[computer] = new wxButton(XRCCTRL(*this, "Panel"+computerInfo[computer].gui, wxPanel), GUI_START_BUTTON +computer, "Start", wxPoint(windowInfo.ChoiceClockX+109, windowInfo.ChoiceClockY-1), wxSize(80, 25));
#endif
				break;
			}
#if defined(__WXMAC__)
			clockText[computer]->SetFont(defaultFont);
			clockTextCtrl[computer]->SetFont(defaultFont);
			mhzText[computer]->SetFont(defaultFont);
			startButton[computer]->SetFont(defaultFont);
#endif
			this->Connect(GUI_CLOCK_TEXTCTRL+computer, wxEVT_COMMAND_TEXT_UPDATED , wxCommandEventHandler(GuiMain::onClock) );
			this->Connect(GUI_START_BUTTON+computer, wxEVT_COMMAND_BUTTON_CLICKED , wxCommandEventHandler(Main::onStart) );
		}
	}

	readDebugConfig();		
	readComxConfig();		
	readElf2KConfig();		
	readCosmicosConfig();	
	readVipConfig();		
	readVipIIConfig();		
	readElfConfig(ELF, "Elf");
	readElfConfig(ELFII, "ElfII");
	readElfConfig(SUPERELF, "SuperElf");
	readMembershipConfig();
	readStudioConfig();		
	readVisicomConfig();	
	readVictoryConfig();	
	readCidelsaConfig();
	readTelmacConfig();
	readTMC1800Config();
	readTMC2000Config();
	readNanoConfig();
	readPecomConfig();
	readEtiConfig();

	if (mode_.window_position_fixed)
		configPointer->Read("/Main/Window_Positions_Fixed", &mode_.window_position_fixed, true);
	else
		nonFixedWindowPosition();

	configPointer->Read("/Main/Save_Debug_File", &saveDebugFile_, true);
	configPointer->Read("/Main/Save_On_Exit", &saveOnExit_, true);
	configPointer->Read("/Main/Check_For_Update", &checkForUpdate_, true);
	configPointer->Read("/Main/Floating_Point_Zoom", &fullScreenFloat_, true);
	configPointer->Read("/Main/Use_Exit_Key", &useExitKey_, false);
	runPressed_ = false;
	functionKey_[0] = configPointer->Read("/Main/Exit_Key", (long)WXK_ESCAPE);
	functionKey_[1] = configPointer->Read("/Main/Help_Key", (long)WXK_F1);
	functionKey_[2] = configPointer->Read("/Main/Activate_Main_Key", (long)WXK_F2);
	functionKey_[3] = configPointer->Read("/Main/Full_Screen_Key", (long)WXK_F3);
	functionKey_[4] = configPointer->Read("/Main/Printer_Window_Key", (long)WXK_F4);
	functionKey_[5] = configPointer->Read("/Main/Video_Dump_Key", (long)WXK_F5);
	functionKey_[6] = configPointer->Read("/Main/Debug_Mode_Key", (long)WXK_F6);
#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
	functionKey_[7] = configPointer->Read("/Main/Menu_Key", (long)WXK_MENU);
#else
	functionKey_[7] = configPointer->Read("/Main/Menu_Key", (long)WXK_WINDOWS_MENU);
#endif
	functionKey_[12] = configPointer->Read("/Main/Start_Reset_Key", (long)WXK_F12);

	if (mode_.gui)
	{
		XRCCTRL(*this, "AssSaveDebugFile", wxCheckBox)->SetValue(saveDebugFile_);
		menubarPointer->Check(XRCID(GUISAVEONEXIT), saveOnExit_);
		menubarPointer->Check(XRCID("MI_UpdateCheck"), checkForUpdate_);
		menubarPointer->Check(XRCID("MI_FullScreenFloat"), fullScreenFloat_);
		menubarPointer->Check(XRCID("MI_FixedWindowPosition"), mode_.window_position_fixed);
		menubarPointer->Check(XRCID(configPointer->Read("/Main/Equalization", "TV Speaker")), true);
		menubarPointer->Check(XRCID(configPointer->Read("/Main/Cpu_Type", "CDP1805")), true);
		menubarPointer->SetFont(defaultFont);

	}
	if (configPointer->Read("/Main/Cpu_Type") == "CDP1802")
		cpuType_ = CPU1802;
	if (configPointer->Read("/Main/Cpu_Type") == "CDP1804")
		cpuType_ = CPU1804;
	if (configPointer->Read("/Main/Cpu_Type") == "CDP1805")
		cpuType_ = CPU1805;

	if (configPointer->Read("/Main/Equalization") == "Flat")
	{
		bass_ = 1;
		treble_ = 0;
	}

	if (configPointer->Read("/Main/Equalization") == "Crisp")
	{
		bass_ = 1;
		treble_ = 5;
	}

	if (configPointer->Read("/Main/Equalization") == "Default")
	{
		bass_ = 16;
		treble_ = -8;
	}

	if (configPointer->Read("/Main/Equalization") == "TV Speaker")
	{
		bass_ = 180;
		treble_ = -8;
	}

	if (configPointer->Read("/Main/Equalization") == "Handheld")
	{
		bass_ = 2000;
		treble_ = -47;
	}

	if (mode_.gui)
	{
//		XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(COMXTAB);
//		XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(DEBUGGERTAB);

		XRCCTRL(*this, "StudioChoiceBook", wxChoicebook)->SetSelection(configPointer->Read("/Main/Selected_Studio_Tab", 0l));
		XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetSelection(configPointer->Read("/Main/Selected_Cosmac_Tab", 0l));
		XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->SetSelection(configPointer->Read("/Main/Selected_Telmac_Tab", 0l));
		XRCCTRL(*this, "DebuggerChoiceBook", wxChoicebook)->SetSelection(configPointer->Read("/Main/Selected_Debugger_Tab", 0l));
#if defined(__WXMAC__)
		XRCCTRL(*this, "StudioChoiceBook", wxChoicebook)->SetFont(smallFont);
		XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetFont(smallFont);
		XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->SetFont(smallFont);
		XRCCTRL(*this, "DebuggerChoiceBook", wxChoicebook)->SetFont(smallFont);
		XRCCTRL(*this, "ExpRamSlotComx", wxSpinCtrl)->SetFont(smallFont);
		XRCCTRL(*this, "StudioChoiceBook", wxChoicebook)->SetFont(defaultFont);
		XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetFont(defaultFont);
		XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->SetFont(defaultFont);
		XRCCTRL(*this, "DebuggerChoiceBook", wxChoicebook)->SetFont(defaultFont);
		XRCCTRL(*this, "ExpRamSlotComx", wxSpinCtrl)->SetFont(defaultFont);
		eventDisableControls();
#endif

		XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(configPointer->Read("/Main/Selected_Tab", 0l));
		eventChangeNoteBook();
		
#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
		if (windowInfo.operatingSystem == OS_LINUX_OPENSUSE_GNOME || windowInfo.operatingSystem == OS_LINUX_UBUNTU_11_04)
		{
			XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetClientSize(windowInfo.mainwX-windowInfo.xBorder - 6, windowInfo.mainwY-windowInfo.yBorder);
			XRCCTRL(*this, "StudioChoiceBook", wxChoicebook)->SetClientSize(windowInfo.mainwX-windowInfo.xBorder -6, windowInfo.mainwY-windowInfo.yBorder);
			XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->SetClientSize(windowInfo.mainwX-windowInfo.xBorder -6, windowInfo.mainwY-windowInfo.yBorder);
			XRCCTRL(*this, "DebuggerChoiceBook", wxChoicebook)->SetClientSize(windowInfo.mainwX-windowInfo.xBorder -6, windowInfo.mainwY-windowInfo.yBorder);
		}
		else
		{
			XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetClientSize(windowInfo.mainwX-windowInfo.xBorder, windowInfo.mainwY-windowInfo.yBorder); // 537 406
			XRCCTRL(*this, "StudioChoiceBook", wxChoicebook)->SetClientSize(windowInfo.mainwX-windowInfo.xBorder, windowInfo.mainwY-windowInfo.yBorder);
			XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->SetClientSize(windowInfo.mainwX-windowInfo.xBorder, windowInfo.mainwY-windowInfo.yBorder);
			XRCCTRL(*this, "DebuggerChoiceBook", wxChoicebook)->SetClientSize(windowInfo.mainwX-windowInfo.xBorder, windowInfo.mainwY-windowInfo.yBorder);
		}
#else
		if (windowInfo.operatingSystem != OS_WINDOWS_2000 )		
		{
			XRCCTRL(*this, "PanelElf2K", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelVip", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelCosmicos", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelElf", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelElfII", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelSuperElf", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelMembership", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelStudio2", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelVisicom", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelVictory", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelTmc600", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelTMC1800", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelTMC2000", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelNano", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelTrace", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
			XRCCTRL(*this, "PanelMemory", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
//			XRCCTRL(*this, "PanelAssembler", wxPanel)->SetBackgroundColour(wxColour(255,255,255));
		}
#endif
	}

	psaveData_[0] = configPointer->Read("/Main/Psave_Volume", 15l);
	psaveData_[1] = configPointer->Read("/Main/Psave_Bit_Rate", 1l);
	psaveData_[2] = configPointer->Read("/Main/Psave_Bits_Per_Sample", 1l);
	psaveData_[3] = configPointer->Read("/Main/Wav_Conversion_Type", 0l);
	psaveData_[4] = configPointer->Read("/Main/Cassette_Input_Channel", 0l);
	psaveData_[5] = configPointer->Read("/Main/Cassette_Playback_Input", 0l);
	psaveData_[6] = configPointer->Read("/Main/Cassette_Reversed_Polarity", 0l);
	psaveData_[7] = configPointer->Read("/Main/Cassette_Conversion_Type", 1l);
}

void Main::onHelp(wxCommandEvent& WXUNUSED(event))
{
	wxSetWorkingDirectory(p_Main->getApplicationDir());
	help_->DisplayContents();
}

wxString Main::downloadString(wxString url)
{
	wxFileSystem fs; 
	wxFSFile *file= fs.OpenFile(url); 
	wxString returnString = "";
 
	if (file)   
	{ 
		wxInputStream *in_stream = file->GetStream(); 

		if (in_stream)
		{
			wxStringOutputStream html_stream(&returnString);
			in_stream->Read(html_stream);
		}
		delete file;
	}
	return returnString;
}

bool Main::checkUpdateEmma()
{
	wxString version = configPointer->Read("/Main/Version", EMMA_VERSION);

	latestVersion_ = downloadString("http://www.emma02.hobby-site.com/Emma_02_version.txt");
	
	if (latestVersion_ == "")
		return false;

	int urlStart=latestVersion_.Find("HREF=");
	if (urlStart != wxNOT_FOUND)
	{	
		urlStart+=6;
		latestVersion_ = latestVersion_.Mid(urlStart);
		int urlEnd=latestVersion_.Find((char)34);
		latestVersion_ = latestVersion_.Mid(0, urlEnd);
		latestVersion_ = downloadString(latestVersion_);
	}

	double latestVersionDouble;
	double versionDouble;

	if (latestVersion_.ToDouble(&latestVersionDouble))
	{
		version.ToDouble(&versionDouble);
	}
	else
	{
		latestVersion_.Replace(".",",");
		version.Replace(".",",");
		latestVersion_.ToDouble(&latestVersionDouble);
		version.ToDouble(&versionDouble);
	}

	latestVersionDouble = (int)(ceil(latestVersionDouble*100));
	versionDouble = (int)(ceil(versionDouble*100));


	if (versionDouble >= latestVersionDouble || latestVersion_ == "")
		return false;
	else
		return true;
}

bool Main::updateEmma()
{
	int answer = wxMessageBox( "Emma 02 V" + latestVersion_ + " is available, download now?\n",
							   "Emma 02", wxICON_QUESTION  | wxYES_DEFAULT | wxYES_NO);

	if (answer == wxYES)
	{
#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMGL__)
		wxLinuxDistributionInfo linuxDistro;
		linuxDistro = ::wxGetLinuxDistributionInfo();
		if (linuxDistro.Id == "Ubuntu")
		{
			if (wxIsPlatform64Bit())
				::wxLaunchDefaultBrowser("http://www.emma02.hobby-site.com/ccount/click.php?id=6"); // 64 Bit
			else
				::wxLaunchDefaultBrowser("http://www.emma02.hobby-site.com/ccount/click.php?id=5"); // 32 Bit
		}
		else
		{
			if (wxIsPlatform64Bit())
				::wxLaunchDefaultBrowser("http://www.emma02.hobby-site.com/ccount/click.php?id=8"); // 64 Bit
			else
				::wxLaunchDefaultBrowser("http://www.emma02.hobby-site.com/ccount/click.php?id=7"); // 32 Bit
		}
		return true;
#endif
#if defined(__WXMAC__)
		if (wxIsPlatform64Bit())
			::wxLaunchDefaultBrowser("http://www.emma02.hobby-site.com/ccount/click.php?id=10"); // 64 Bit
		else
			::wxLaunchDefaultBrowser("http://www.emma02.hobby-site.com/ccount/click.php?id=9"); // 32 Bit
		return true;
#endif
		::wxLaunchDefaultBrowser("http://www.emma02.hobby-site.com/ccount/click.php?id=1");
		return true;
	}
	return false;
}

void Main::onQuit(wxCommandEvent&WXUNUSED(event))
{
	stopComputer();
	if (!computerRunning_)
		Destroy();
	else
		emmaClosing_ = true;
	//	Destroy();
}

void Main::onSaveOnExit(wxCommandEvent&event)
{
	saveOnExit_ = event.IsChecked();
}

void Main::onSaveConfig(wxCommandEvent&WXUNUSED(event))
{
	writeConfig();
}

void Main::onClose(wxCloseEvent&event)
{
	stopComputer();
	if (!computerRunning_)
		Destroy();
	else
	{
		event.Veto();
		emmaClosing_ = true;
	}
//	Destroy();
}

void Main::onAbout(wxCommandEvent&WXUNUSED(event))
{
	MyAboutDialog MyAboutDialog(this);
 	MyAboutDialog.ShowModal();
}

void Main::onDataDir(wxCommandEvent&WXUNUSED(event))
{
	DatadirDialog dataDialog(this);
 	dataDialog.ShowModal();
}

void Main::onFunctionKeys(wxCommandEvent&WXUNUSED(event))
{
	FunctionKeyMapDialog functionKeyMapDialog(this);
 	functionKeyMapDialog.ShowModal();
}

void Main::onHome(wxCommandEvent&WXUNUSED(event))
{
	::wxLaunchDefaultBrowser("http://www.emma02.hobby-site.com/");
}

void Main::onHomeSb(wxCommandEvent&WXUNUSED(event))
{
	::wxLaunchDefaultBrowser("http://www.comx35.com/superboard.html");
}

void Main::onHomeSbHs(wxCommandEvent&WXUNUSED(event))
{
	::wxLaunchDefaultBrowser("http://www.comx35.com/highscores.php");
}

void Main::onUpdateCheck(wxCommandEvent&event)
{
	checkForUpdate_ = event.IsChecked();
}

void Main::onUpdateEmma(wxCommandEvent&WXUNUSED(event))
{
	if (!checkUpdateEmma())
	{
		(void)wxMessageBox( "No Emma 02 update found\n",
							"Emma 02", wxOK );
	}
	else
	{
		if (updateEmma())
			Destroy();
	}
}

void Main::onDefaultSettings(wxCommandEvent&WXUNUSED(event))
{
	mode_.window_position_fixed = true;
	setDefaultSettings();
}

void Main::setDefaultSettings()
{
	for (int i=0; i<5; i++)
	{
		delete baudTextT[i];
		delete baudChoiceT[i];
		delete baudTextR[i];
		delete baudChoiceR[i];
	}
	configPointer->DeleteAll();

	configPointer->Write("/Comx/PlayerName", sbPlayer_);
	configPointer->Write("/Comx/PlayerLocation", sbLocation_);
	configPointer->Write("/Comx/Email", sbEmail_);

	wxString aliasStr, aliasEmailStr;
	for (size_t i=0; i<numberOfAlias_; i++)
	{
		aliasStr.Printf("/Comx/Alias%d", i);
		aliasEmailStr.Printf("/Comx/AliasEmail%d", i);

		configPointer->Write(aliasStr, alias[i]);
		configPointer->Write(aliasEmailStr, aliasEmail[i]);
	}
	configPointer->Write("/Comx/AliasNumberOf", numberOfAlias_);

	readConfig();
}

void Main::on1802(wxCommandEvent&WXUNUSED(event))
{
	cpuType_ = CPU1802;
}

void Main::on1804(wxCommandEvent&WXUNUSED(event))
{
	cpuType_ = CPU1804;
}

void Main::on1805(wxCommandEvent&WXUNUSED(event))
{
	cpuType_ = CPU1805;
}

void Main::onFlat(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 1;
	treble_ = 0;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onCrisp(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 1;
	treble_ = 5;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onDefault(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 16;
	treble_ = -8;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onTvSpeaker(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 180;
	treble_ = -8;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onHandheld(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 2000;
	treble_ = -47;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onChar(wxKeyEvent& event)
{
	if (computerRunning_)
		p_Computer->charEvent(event.GetKeyCode());
}

void Main::onKeyDown(wxKeyEvent& event)
{
	int key = event.GetKeyCode();
	if (key == WXK_UP)
	{
		if (computerRunning_ && selectedComputer_ == DEBUGGER && debuggerChoice_ == DIRECTASSTAB)
		{
			if (event.GetModifiers() == wxMOD_SHIFT)
				onAssSpinPageUp();
			else
			{
				assSpinUp();
				directAss();
			}
			return;
		}
	}

	if (key == WXK_DOWN)
	{
		if (computerRunning_ && selectedComputer_ == DEBUGGER && debuggerChoice_ == DIRECTASSTAB)
		{
			if (event.GetModifiers() == wxMOD_SHIFT)
				onAssSpinPageDown();
			else
			{
				assSpinDown();
				directAss();
			}
			return;
		}
	}

	if (!checkFunctionKey(event))
		event.Skip();
}

void Main::onWheel(wxMouseEvent& event)
{
	int rot = event.GetWheelRotation ();
	if (rot > 0)
	{
		if (computerRunning_ && selectedComputer_ == DEBUGGER && debuggerChoice_ == DIRECTASSTAB)
		{
			if (event.GetModifiers() == wxMOD_SHIFT)
				onAssSpinPageUp();
			else
			{
				assSpinUp();
				directAss();
			}
			return;
		}
	}

	if (rot < 0)
	{
		if (computerRunning_ && selectedComputer_ == DEBUGGER && debuggerChoice_ == DIRECTASSTAB)
		{
			if (event.GetModifiers() == wxMOD_SHIFT)
				onAssSpinPageDown();
			else
			{
				assSpinDown();
				directAss();
			}
			return;
		}
	}

	event.Skip();
}

bool Main::checkFunctionKey(wxKeyEvent& event)
{
	if (event.GetModifiers() == wxMOD_SHIFT)
		return false;

	int key = event.GetKeyCode();

	if (key == functionKey_[0] && computerRunning_ && useExitKey_)
	{
		p_Main->stopComputer();
		return true;
	}

	if (key == functionKey_[1])
	{
		wxSetWorkingDirectory(p_Main->getApplicationDir());
		help_->DisplayContents();
		return true;
	}

	if (key == functionKey_[2])
	{
		activateMainWindow();
		return true;
	}

	if (key == functionKey_[3])
	{
		fullScreenMenu();
		return true;
	}

	if (key == functionKey_[4])
	{
		if (computerRunning_)
		{
			switch (runningComputer_)
			{
				case COMX:
					p_Main->onComxF4();
				break;
				case TMC600:
				case PECOM:
					p_Main->onF4();
				break;
				case ELF:
				case ELFII:
				case SUPERELF:
				case VIP:
					if (conf[runningComputer_].printerOn_)
						p_Main->onF4();
				break;
			}
		}
		return true;
	}

	if (key == functionKey_[5])
	{
		if (computerRunning_)
		{
			if (p_Video != NULL)
				p_Video->onF5();
			if (p_Vt100 != NULL)
				p_Vt100->onF5();
		}
		return true;
	}

	if (key == functionKey_[6])
	{
		p_Main->onFxDebugMode();
		return true;
	}

	if (key == functionKey_[7])
	{
		if (computerRunning_)
			p_Main->popUp();
		return true;
	}

	if (key == functionKey_[12])
	{
		runPressed_ = true;
		if (runningComputer_ == VIPII)
			p_Vip2->runPressed();
		return true;
	}

	if (computerRunning_)
	{
		if (key == p_Computer->getInKey())
		{
			p_Computer->onInButtonPress();
			return true;
		}
	}

	return false;
}	

void Main::onActivateMainWindow(wxCommandEvent& WXUNUSED(event))
{
	activateMainWindow();
}

void Main::activateMainWindow()
{
	if (computerRunning_)
	{
		if (p_Vt100 != NULL)
			p_Vt100->activateMainWindow();
		else if (p_Video != NULL)
			p_Video->activateMainWindow();
		else p_Computer->activateMainWindow();
	}
}

void Main::onFullScreenMenu(wxCommandEvent& WXUNUSED(event))
{
	fullScreenMenu();
}

void Main::fullScreenMenu()
{
	if (computerRunning_)
	{
		if ((p_Video != NULL) && (p_Vt100 != NULL))
		{
			if (!p_Video->isFullScreenSet() && !p_Vt100->isFullScreenSet())
				p_Vt100->onF3();
			else if (p_Vt100->isFullScreenSet())
			{
				p_Vt100->onF3();
				while (p_Vt100->isFullScreenSet()) 
				{
					wxSleep(1);
				}
				p_Video->onF3();
			}
			else
			{
				p_Video->onF3();
			}
		}
		else
		{
			if (p_Video != NULL)
				p_Video->onF3();
			if (p_Vt100 != NULL)
				p_Vt100->onF3();
		}
	}
}

void Main::popUp()
{
	if (runningComputer_ == STUDIO || runningComputer_ == VICTORY || runningComputer_ == VISICOM || runningComputer_ == CIDELSA)
		return;

	if (popupDialog_ == NULL)
		popupDialog_ = new PopupDialog(this);
	popupDialog_->init();
	popupDialog_->Show(true);
}

void Main::onKeyUp(wxKeyEvent& event)
{
	int key = event.GetKeyCode();
	if (computerRunning_)
	{
		if (key == p_Computer->getInKey())
		{
			p_Computer->onInButtonRelease();
			return;
		}
	}
	if (key == functionKey_[12])
	{
		runPressed_ = false;
		if (computerRunning_)
			p_Computer->onRun();
		else
			onStart(selectedComputer_);
		return;
	}
	event.Skip();
}

void Main::connectKeyEvent(wxWindow* pclComponent)
{
  if(pclComponent)
  {
    pclComponent->Connect(wxID_ANY,
                          wxEVT_KEY_DOWN,
                          wxKeyEventHandler(Main::onKeyDown),
                          (wxObject*) NULL,
                          this);
    pclComponent->Connect(wxID_ANY,
                          wxEVT_KEY_UP,
                          wxKeyEventHandler(Main::onKeyUp),
                          (wxObject*) NULL,
                          this);

	wxWindowListNode* pclNode = pclComponent->GetChildren().GetFirst();
    while(pclNode)
    {
      wxWindow* pclChild = pclNode->GetData();
      this->connectKeyEvent(pclChild);
     
      pclNode = pclNode->GetNext();
    }
  }
}

void Main::onDefaultWindowPosition(wxCommandEvent&WXUNUSED(event))
{
	fixedWindowPosition();

	this->Move(mainWindowX_, mainWindowY_);
	switch (runningComputer_)
	{
		case COMX:
			p_Comx->Move(conf[COMX].mainX_, conf[COMX].mainY_);
		break;

		case CIDELSA:
			p_Cidelsa->Move(conf[CIDELSA].mainX_, conf[CIDELSA].mainY_);
		break;

		case TMC600:
			p_Tmc600->Move(conf[TMC600].mainX_, conf[TMC600].mainY_);
		break;

		case TMC2000:
			p_Tmc2000->Move(conf[TMC2000].mainX_, conf[TMC2000].mainY_);
		break;

		case TMC1800:
			p_Tmc1800->Move(conf[TMC1800].mainX_, conf[TMC1800].mainY_);
		break;

		case ETI:
			p_Eti->Move(conf[ETI].mainX_, conf[ETI].mainY_);
		break;

		case NANO:
			p_Nano->Move(conf[NANO].mainX_, conf[NANO].mainY_);
		break;

		case PECOM:
			p_Pecom->Move(conf[PECOM].mainX_, conf[PECOM].mainY_);
		break;

		case STUDIO:
			p_Studio2->Move(conf[STUDIO].mainX_, conf[STUDIO].mainY_);
		break;

		case VISICOM:
			p_Visicom->Move(conf[VISICOM].mainX_, conf[VISICOM].mainY_);
		break;

		case VICTORY:
			p_Victory->Move(conf[VICTORY].mainX_, conf[VICTORY].mainY_);
		break;

		case VIP:
			p_Vip->Move(conf[VIP].mainX_, conf[VIP].mainY_);
		break;

		case VIPII:
			p_Vip2->Move(conf[VIPII].mainX_, conf[VIPII].mainY_);
		break;

		case MEMBER:
			p_Membership->moveWindows();
			p_Membership->Move(conf[MEMBER].mainX_, conf[MEMBER].mainY_);
		break;

		case ELF2K:
			p_Elf2K->moveWindows();
			p_Elf2K->Move(conf[ELF2K].mainX_, conf[ELF2K].mainY_);
		break;

		case COSMICOS:
			p_Cosmicos->moveWindows();
			p_Cosmicos->Move(conf[COSMICOS].mainX_, conf[COSMICOS].mainY_);
		break;

		case ELF:
			p_Elf->moveWindows();
			p_Elf->Move(conf[ELF].mainX_, conf[ELF].mainY_);
		break;

		case ELFII:
			p_Elf2->moveWindows();
			p_Elf2->Move(conf[ELFII].mainX_, conf[ELFII].mainY_);
		break;

		case SUPERELF:
			p_Super->moveWindows();
			p_Super->Move(conf[SUPERELF].mainX_, conf[SUPERELF].mainY_);
		break;
	}
}

void Main::onFixedWindowPosition(wxCommandEvent&event)
{
	mode_.window_position_fixed = event.IsChecked();
	if (!mode_.window_position_fixed)
		nonFixedWindowPosition();
}

void Main::nonFixedWindowPosition()
{
	mainWindowX_ = -1;
	mainWindowY_ = -1;
	conf[COMX].mainX_ = -1;
	conf[COMX].mainY_ = -1;
	conf[CIDELSA].mainX_ = -1;
	conf[CIDELSA].mainY_ = -1;
	conf[TMC600].mainX_ = -1;
	conf[TMC600].mainY_ = -1;
	conf[VIP].mainX_ = -1;
	conf[VIP].mainY_ = -1;
	conf[VIPII].mainX_ = -1;
	conf[VIPII].mainY_ = -1;
	conf[TMC1800].mainX_ = -1;
	conf[TMC1800].mainY_ = -1;
	conf[TMC2000].mainX_ = -1;
	conf[TMC2000].mainY_ = -1;
	conf[ETI].mainX_ = -1;
	conf[ETI].mainY_ = -1;
	conf[NANO].mainX_ = -1;
	conf[NANO].mainY_ = -1;
	conf[PECOM].mainX_ = -1;
	conf[PECOM].mainY_ = -1;
	conf[STUDIO].mainX_ = -1;
	conf[STUDIO].mainY_ = -1;
	conf[VISICOM].mainX_ = -1;
	conf[VISICOM].mainY_ = -1;
	conf[VICTORY].mainX_ = -1;
	conf[VICTORY].mainY_ = -1;
	conf[MEMBER].mainX_ = -1;
	conf[MEMBER].mainY_ = -1;

	for (int i=0; i<5; i++)
	{
		conf[i].pixieX_ = -1;
		conf[i].pixieY_ = -1;
		conf[i].tmsX_ = -1;
		conf[i].tmsY_ = -1;
		conf[i].mc6845X_ = -1;
		conf[i].mc6845Y_ = -1;
		conf[i].mc6847X_ = -1;
		conf[i].mc6847Y_ = -1;
		conf[i].i8275X_ = -1;
		conf[i].i8275Y_ = -1;
		conf[i].vtX_ = -1;
		conf[i].vtY_ = -1;

		conf[i].mainX_ = -1;
		conf[i].mainY_ = -1;
	}

	conf[ELF2K].keypadX_ = -1;
	conf[ELF2K].keypadY_ = -1;
	conf[COSMICOS].keypadX_ = -1;
	conf[COSMICOS].keypadY_ = -1;
	conf[ELF].keypadX_ = -1;
	conf[ELF].keypadY_ = -1;
	ledModuleX_ = -1;
	ledModuleY_ = -1;
	switchX_ = -1;
	switchY_ = -1;
}

void Main::fixedWindowPosition()
{
	mainWindowX_ = 30 + ubuntuOffsetX_;
	mainWindowY_ = 30;
	conf[COMX].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[COMX].mainY_ = mainWindowY_;
	conf[CIDELSA].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[CIDELSA].mainY_ = mainWindowY_;
	conf[TMC600].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[TMC600].mainY_ = mainWindowY_;
	conf[VIP].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[VIP].mainY_ = mainWindowY_;
	conf[VIPII].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[VIPII].mainY_ = mainWindowY_;
	conf[TMC1800].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[TMC1800].mainY_ = mainWindowY_;
	conf[TMC2000].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[TMC2000].mainY_ = mainWindowY_;
	conf[ETI].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[ETI].mainY_ = mainWindowY_;
	conf[NANO].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[NANO].mainY_ = mainWindowY_;
	conf[PECOM].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[PECOM].mainY_ = mainWindowY_;
	conf[STUDIO].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[STUDIO].mainY_ = mainWindowY_;
	conf[VISICOM].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[VISICOM].mainY_ = mainWindowY_;
	conf[VICTORY].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[VICTORY].mainY_ = mainWindowY_;
	conf[MEMBER].mainX_ = mainWindowX_;
	conf[MEMBER].mainY_ = mainWindowY_+windowInfo.mainwY+windowInfo.yBorder;

	for (int i=0; i<5; i++)
	{
		conf[i].pixieX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].pixieY_ = mainWindowY_;
		conf[i].tmsX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].tmsY_ = mainWindowY_;
		conf[i].mc6845X_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].mc6845Y_ = mainWindowY_;
		conf[i].mc6847X_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].mc6847Y_ = mainWindowY_;
		conf[i].i8275X_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].i8275Y_ = mainWindowY_;
		conf[i].vtX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].vtY_ = mainWindowY_;

		conf[i].mainX_ = mainWindowX_;
		conf[i].mainY_ = mainWindowY_+windowInfo.mainwY+windowInfo.yBorder;
	}

	conf[ELF2K].keypadX_ = mainWindowX_+507+windowInfo.xBorder2;
	conf[ELF2K].keypadY_ = mainWindowY_+478+windowInfo.yBorder2;
	conf[COSMICOS].keypadX_ = mainWindowX_+333+windowInfo.xBorder2;
	conf[COSMICOS].keypadY_ = mainWindowY_+windowInfo.mainwY+windowInfo.yBorder;
	conf[ELF].keypadX_ = mainWindowX_+346+windowInfo.xBorder2;
	conf[ELF].keypadY_ = mainWindowY_+windowInfo.mainwY+windowInfo.yBorder;
	ledModuleX_ = mainWindowX_+346+windowInfo.xBorder2;
	ledModuleY_ = mainWindowY_+windowInfo.mainwY+229+windowInfo.yBorder2;
	switchX_ = mainWindowX_+507+windowInfo.xBorder2;
	switchY_ = mainWindowY_+478+windowInfo.yBorder2;
}

void Main::onStart(wxCommandEvent&WXUNUSED(event))
{
	if (computerRunning_)
	{
		p_Computer->onReset();
		return;
	}
	onStart(selectedComputer_);
}

void Main::onStart(int computer)
{
	double zoom, xScale;
	long ms;
	int comxy;
	int stereo = 1;
	int toneChannels = 1;

	updateAssPage_ = true;
	updateMemoryPage_ = true;
	emuClosing_ = false;
	thermalEf_ = false;
	statusLedUpdate_ = true;
	slotLedUpdate_ = true;
	chip8Steps_ = -1;
	performChip8Step_ = false;
	additionalChip8Details_ = false;

	p_Video = NULL;
	p_Vt100 = NULL;

	runningComputer_ = computer;
	selectedComputer_ = computer;
	wxSetWorkingDirectory(workingDir_);
	setClock(runningComputer_);
	conf[runningComputer_].zoom_.ToDouble(&zoom);
	conf[runningComputer_].xScale_.ToDouble(&xScale);

	if (!fullScreenFloat_)
		zoom = (int) zoom;

	if (runningComputer_ < 6 || runningComputer_ == VIPII)
	{
		conf[runningComputer_].ledTime_.ToLong(&ms);
		conf[runningComputer_].ledTimeMs_ = ms;
		if (ms == 0)
			ledPointer->Stop();
		else
			ledPointer->Start(ms, wxTIMER_CONTINUOUS);
	}
	if (mode_.gui)
	{
		XRCCTRL(*this, "Message_Window", wxTextCtrl)->Clear();
		vuPointer->Start(100, wxTIMER_CONTINUOUS);
		cpuPointer->Start(1000, wxTIMER_CONTINUOUS);
	}

	switch (runningComputer_)
	{
		case COMX:
			p_Main->setComxExpLedOn (false);
			if (conf[COMX].videoMode_ == PAL)
				comxy = 216;
			else
				comxy = 192;
			p_Comx = new Comx(computerInfo[COMX].name, wxPoint(conf[COMX].mainX_, conf[COMX].mainY_), wxSize(240 * zoom, comxy * zoom), zoom, COMX, conf[COMX].clockSpeed_);
			p_Video = p_Comx;
			p_Computer = p_Comx;
		break;

		case MEMBER:
			p_Membership = new Membership(computerInfo[MEMBER].name, wxPoint(conf[MEMBER].mainX_, conf[MEMBER].mainY_), wxSize(483, 297), conf[MEMBER].clockSpeed_, elfConfiguration[MEMBER]);
			p_Computer = p_Membership;
		break;

		case ELF:
			p_Elf = new Elf(computerInfo[ELF].name, wxPoint(conf[ELF].mainX_, conf[ELF].mainY_), wxSize(346, 464), conf[ELF].clockSpeed_, elfConfiguration[ELF]);
			p_Computer = p_Elf;
		break;

		case ELFII:
			p_Elf2 = new Elf2(computerInfo[ELFII].name, wxPoint(conf[ELFII].mainX_, conf[ELFII].mainY_), wxSize(534, 386), conf[ELFII].clockSpeed_, elfConfiguration[ELFII]);
			p_Computer = p_Elf2;
		break;

		case SUPERELF:
			p_Super = new Super(computerInfo[SUPERELF].name, wxPoint(conf[SUPERELF].mainX_, conf[SUPERELF].mainY_), wxSize(534, 386), selectedComputer_, conf[SUPERELF].clockSpeed_, elfConfiguration[SUPERELF]);
			p_Computer = p_Super;
		break;

		case ELF2K:
			p_Elf2K = new Elf2K(computerInfo[ELF2K].name, wxPoint(conf[ELF2K].mainX_, conf[ELF2K].mainY_), wxSize(507, 459), conf[ELF2K].clockSpeed_, elfConfiguration[ELF2K]);
			p_Computer = p_Elf2K;
		break;

		case COSMICOS:
			p_Cosmicos = new Cosmicos(computerInfo[COSMICOS].name, wxPoint(conf[COSMICOS].mainX_, conf[COSMICOS].mainY_), wxSize(333, 160), conf[COSMICOS].clockSpeed_, elfConfiguration[COSMICOS]);
			p_Computer = p_Cosmicos;
		break;

		case STUDIO:
			p_Studio2 = new Studio2(computerInfo[STUDIO].name, wxPoint(conf[STUDIO].mainX_, conf[STUDIO].mainY_), wxSize(64*zoom*xScale, 128*zoom), zoom, xScale, STUDIO);
			p_Video = p_Studio2;
			p_Computer = p_Studio2;
		break;

		case VISICOM:
			p_Visicom = new Visicom(computerInfo[VISICOM].name, wxPoint(conf[VISICOM].mainX_, conf[VISICOM].mainY_), wxSize(64*zoom*xScale, 128*zoom), zoom, xScale, VISICOM);
			p_Video = p_Visicom;
			p_Computer = p_Visicom;
		break;

		case VICTORY:
			p_Victory = new Victory(computerInfo[VICTORY].name, wxPoint(conf[VICTORY].mainX_, conf[VICTORY].mainY_), wxSize(64*zoom*xScale, 192*zoom), zoom, xScale, VICTORY);
			p_Video = p_Victory;
			p_Computer = p_Victory;
		break;

		case VIP:
			p_Vip = new Vip(computerInfo[VIP].name, wxPoint(conf[VIP].mainX_, conf[VIP].mainY_), wxSize(64*zoom*xScale, 128*zoom), zoom, xScale, VIP, conf[VIP].clockSpeed_, conf[VIP].tempo_, elfConfiguration[VIP]);
			p_Video = p_Vip;
			p_Computer = p_Vip;
			if (getVipStereo())
				stereo = 2;
			if (conf[VIP].soundType_ == VIP_SUPER2)
				toneChannels = 2;
			if (conf[VIP].soundType_ == VIP_SUPER4)
				toneChannels = 4;
		break;

		case VIPII:
			p_Vip2 = new VipII(computerInfo[VIPII].name, wxPoint(conf[VIPII].mainX_, conf[VIPII].mainY_), wxSize(64*zoom*xScale, 128*zoom), zoom, xScale, VIPII, conf[VIPII].clockSpeed_, conf[VIPII].tempo_);
			p_Video = p_Vip2;
			p_Computer = p_Vip2;
		break;

		case TMC1800:
			p_Tmc1800 = new Tmc1800(computerInfo[TMC1800].name, wxPoint(conf[TMC1800].mainX_, conf[TMC1800].mainY_), wxSize(64*zoom*xScale, 128*zoom), zoom, xScale, TMC1800);
			p_Video = p_Tmc1800;
			p_Computer = p_Tmc1800;
		break;

		case TMC2000:
			p_Tmc2000 = new Tmc2000(computerInfo[TMC2000].name, wxPoint(conf[TMC2000].mainX_, conf[TMC2000].mainY_), wxSize(64*zoom*xScale, 192*zoom), zoom, xScale, TMC2000);
			p_Video = p_Tmc2000;
			p_Computer = p_Tmc2000;
		break;

		case ETI:
			p_Eti = new Eti(computerInfo[ETI].name, wxPoint(conf[ETI].mainX_, conf[ETI].mainY_), wxSize(64*zoom*xScale, 192*zoom), zoom, xScale, ETI);
			p_Video = p_Eti;
			p_Computer = p_Eti;
		break;

		case NANO:
			p_Nano = new Nano(computerInfo[NANO].name, wxPoint(conf[NANO].mainX_, conf[NANO].mainY_), wxSize(64*zoom*xScale, 192*zoom), zoom, xScale, NANO);
			p_Video = p_Nano;
			p_Computer = p_Nano;
		break;

		case CIDELSA:
			p_Cidelsa = new Cidelsa(computerInfo[CIDELSA].name, wxPoint(conf[CIDELSA].mainX_, conf[CIDELSA].mainY_), wxSize(200*zoom, 240*zoom), zoom, CIDELSA, conf[CIDELSA].clockSpeed_);
			p_Video = p_Cidelsa;
			p_Computer = p_Cidelsa;
		break;

		case TMC600:
			p_Tmc600 = new Tmc600(computerInfo[TMC600].name, wxPoint(conf[TMC600].mainX_, conf[TMC600].mainY_), wxSize(240*zoom, 216*zoom), zoom, TMC600, conf[TMC600].clockSpeed_);
			p_Video = p_Tmc600;
			p_Computer = p_Tmc600;
		break;

		case PECOM:
			p_Pecom = new Pecom(computerInfo[PECOM].name, wxPoint(conf[PECOM].mainX_, conf[PECOM].mainY_), wxSize(240*zoom, 216*zoom), zoom, PECOM, conf[PECOM].clockSpeed_);
			p_Video = p_Pecom;
			p_Computer = p_Pecom;
		break;
	}
	enableGui(false);
	computerRunning_ = true;
	p_Computer->initCpu(selectedComputer_);
	p_Computer->configureComputer();
	if (!debugMode_)  percentageClock_ = 1;
	p_Computer->initSound(conf[runningComputer_].clockSpeed_, percentageClock_, runningComputer_, conf[runningComputer_].volume_, bass_, treble_, toneChannels, stereo, conf[runningComputer_].realCassetteLoad_, conf[runningComputer_].beepFrequency_);
	p_Computer->initComputer();
	AssInitConfig();

	if (mode_.gui)
	{
		p_Main->resetDisplay();
#if wxCHECK_VERSION(2, 9, 0)
		XRCCTRL(*this, "RunningComputer", wxStaticText)->SetLabelText("Running computer: "+computerInfo[runningComputer_].name);
#else
		XRCCTRL(*this, "RunningComputer", wxStaticText)->SetLabel("Running computer: "+computerInfo[runningComputer_].name);
#endif
	}
	p_Computer->startComputer();
	if (!mode_.gui)
	{
		if (runningComputer_ < 6)
			if (elfConfiguration[runningComputer_].vtType == VTNONE)
				p_Main->eventVideoSetFullScreen(mode_.full_screen);
			else
				p_Main->eventVtSetFullScreen(mode_.full_screen);
		else	
			p_Main->eventVideoSetFullScreen(mode_.full_screen);
	}
}

void Main::stopComputer()
{ 
	stopAssLog();

	if (emuClosing_)  return;
	emuClosing_ = true;
	if (popupDialog_ != NULL)
		delete popupDialog_;
	popupDialog_ = NULL;
	ledPointer->Stop();
	if (mode_.gui)
	{
		vuPointer->Stop();
		cpuPointer->Stop();
		switch (runningComputer_)
		{
			case COMX:
				setComxStatusLedOn (false);
				vuSet("Vu"+computerInfo[runningComputer_].gui, 0);
			break;
			case ELF:
			case ELFII:
			case SUPERELF:
				enableMemAccessGui(false);
				vuSet("Vu"+computerInfo[runningComputer_].gui, 0);
			break;
			case VIP:
			case VIPII:
			case COSMICOS: 
			case TMC600:
			case TMC1800:
			case TMC2000:
			case NANO:
			case PECOM:
			case ETI:
				vuSet("Vu"+computerInfo[runningComputer_].gui, 0);
			break;
			case NO_COMPUTER:
				return;
			break;
		}
#if wxCHECK_VERSION(2, 9, 0)
		XRCCTRL(*this, "RunningComputer", wxStaticText)->SetLabelText("Last executed computer: "+computerInfo[runningComputer_].name);
#else
		XRCCTRL(*this, "RunningComputer", wxStaticText)->SetLabel("Last executed computer: "+computerInfo[runningComputer_].name);
#endif
		showTime();
	}
}

void Main::killComputer(wxCommandEvent&WXUNUSED(event))
{
	if (saveDebugFile_)
		saveAll();

	delete p_Computer;
	p_Computer = NULL;
	p_Video = NULL;
	p_Vt100 = NULL;
	computerRunning_ = false;
	enableGui(true);
	runningComputer_ = NO_COMPUTER;
	if (emmaClosing_ || !mode_.gui)
		Destroy();
}

void Main::onComputer(wxNotebookEvent&event)
{
	switch(event.GetSelection())
	{
		case COMXTAB:
			selectedComputer_ = COMX;
		break;

		case COSMACTAB:
			switch(XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->GetSelection())
			{
				case ELF2KTAB:
					elfChoice_ = ELF2K;
				break;

				case VIPTAB:
					elfChoice_ = VIP;
				break;

				case VIPIITAB:
					elfChoice_ = VIPII;
				break;

				case COSMICOSTAB:
					elfChoice_ = COSMICOS; 
				break;

				case ELFTAB:
					elfChoice_ = ELF; 
				break;

				case ELFIITAB:
					elfChoice_ = ELFII;
				break;

				case SUPERELFTAB:
					elfChoice_ = SUPERELF;
				break;

				case MEMBERTAB:
					elfChoice_ = MEMBER;
				break;
			}
			selectedComputer_ = elfChoice_;
		break;

		case STUDIOTAB:
			switch(XRCCTRL(*this, "StudioChoiceBook", wxChoicebook)->GetSelection())
			{
				case STUDIOIITAB:
					studioChoice_ = STUDIO;
				break;

				case VISICOMTAB:
					studioChoice_ = VISICOM;
				break;

				case VICTORYTAB:
					studioChoice_ = VICTORY;
				break;

				default:
					studioChoice_ = STUDIO;
				break;
			}
			selectedComputer_ = studioChoice_;
		break;

		case CIDELSATAB:
			selectedComputer_ = CIDELSA;
		break;

		case TELMACTAB:
			switch(XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->GetSelection())
			{
				case TMC600TAB:
					telmacChoice_ = TMC600;
				break;

				case TMC1800TAB:
					telmacChoice_ = TMC1800;
				break;

				case TMC2000TAB:
					telmacChoice_ = TMC2000;
				break;

				case NANOTAB:
					telmacChoice_ = NANO;
				break;
			}
			selectedComputer_ = telmacChoice_;
		break;

		case PECOMTAB:
			selectedComputer_ = PECOM;
		break;

		case ETITAB:
			selectedComputer_ = ETI;
		break;

		case DEBUGGERTAB:
			switch(XRCCTRL(*this, "DebuggerChoiceBook", wxChoicebook)->GetSelection())
			{
				case MESSAGETAB:
					debuggerChoice_ = MESSAGETAB;
				break;

				case TRACETAB:
					debuggerChoice_ = TRACETAB;
				break;

				case CHIP8TAB:
					debuggerChoice_ = CHIP8TAB;
				break;

				case MEMORYTAB:
					debuggerChoice_ = MEMORYTAB;
					memoryDisplay();
				break;

				case ASSTAB:
					debuggerChoice_ = ASSTAB;
				break;

				case DIRECTASSTAB:
					debuggerChoice_ = DIRECTASSTAB;
					directAss();
				break;

			}
			selectedComputer_ = DEBUGGER;
		break;
	}
	enableElfConfig(selectedComputer_ < 3);
}

void Main::onStudioChoiceBook(wxChoicebookEvent&event)
{
	switch(event.GetSelection())
	{
		case STUDIOIITAB:
			studioChoice_ = STUDIO;
		break;

		case VISICOMTAB:
			studioChoice_ = VISICOM;
		break;

		case VICTORYTAB:
			studioChoice_ = VICTORY;
		break;
	}
	selectedComputer_ = studioChoice_;
}

void Main::onTelmacChoiceBook(wxChoicebookEvent&event)
{
	switch(event.GetSelection())
	{
		case TMC600TAB:
			telmacChoice_ = TMC600;
		break;

		case TMC1800TAB:
			telmacChoice_ = TMC1800;
		break;

		case TMC2000TAB:
			telmacChoice_ = TMC2000;
		break;

		case NANOTAB:
			telmacChoice_ = NANO;
		break;
	}
	selectedComputer_ = telmacChoice_;
}

void Main::onCosmacChoiceBook(wxChoicebookEvent&event)
{
	switch(event.GetSelection())
	{
		case ELF2KTAB:
			elfChoice_ = ELF2K;
		break;

		case VIPTAB:
			elfChoice_ = VIP;
		break;

		case VIPIITAB:
			elfChoice_ = VIPII;
		break;

		case COSMICOSTAB:
			elfChoice_ = COSMICOS; 
		break;

		case ELFTAB:
			elfChoice_ = ELF; 
		break;

		case ELFIITAB:
			elfChoice_ = ELFII;
		break;

		case SUPERELFTAB:
			elfChoice_ = SUPERELF;
		break;

		case MEMBERTAB:
			elfChoice_ = MEMBER;
		break;
	}
	selectedComputer_ = elfChoice_;
	enableElfConfig(selectedComputer_ < 3);
}

void Main::onDebuggerChoiceBook(wxChoicebookEvent&event)
{
	switch(event.GetSelection())
	{
		case MESSAGETAB:
			debuggerChoice_ = MESSAGETAB;
		break;

		case TRACETAB:
			debuggerChoice_ = TRACETAB;
		break;

		case CHIP8TAB:
			debuggerChoice_ = CHIP8TAB;
		break;

		case MEMORYTAB:
			debuggerChoice_ = MEMORYTAB;
			memoryDisplay();
		break;

		case ASSTAB:
			debuggerChoice_ = ASSTAB;
		break;

		case DIRECTASSTAB:
			debuggerChoice_ = DIRECTASSTAB;
			directAss();
		break;

	}
}

void Main::setNoteBook()
{
	if (!mode_.gui || runningComputer_ == selectedComputer_)
		return;

	switch (runningComputer_)
	{
		case COMX:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(COMXTAB);
		break;

		case ELF2K:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(COSMACTAB);
			XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetSelection(ELF2KTAB);
		break;

		case VIP:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(COSMACTAB);
			XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetSelection(VIPTAB);
		break;

		case VIPII:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(COSMACTAB);
			XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetSelection(VIPIITAB);
		break;

		case COSMICOS:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(COSMACTAB);
			XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetSelection(COSMICOSTAB);
		break;

		case ELF:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(COSMACTAB);
			XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetSelection(ELFTAB);
		break;

		case ELFII:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(COSMACTAB);
			XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetSelection(ELFIITAB);
		break;

		case SUPERELF:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(COSMACTAB);
			XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetSelection(SUPERELFTAB);
		break;

		case MEMBER:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(COSMACTAB);
			XRCCTRL(*this, "CosmacChoiceBook", wxChoicebook)->SetSelection(MEMBERTAB);
		break;

		case STUDIO:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(STUDIOTAB);
			XRCCTRL(*this, "StudioChoiceBook", wxChoicebook)->SetSelection(STUDIOIITAB);
		break;

		case VISICOM:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(STUDIOTAB);
			XRCCTRL(*this, "StudioChoiceBook", wxChoicebook)->SetSelection(VISICOMTAB);
		break;

		case VICTORY:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(STUDIOTAB);
			XRCCTRL(*this, "StudioChoiceBook", wxChoicebook)->SetSelection(VICTORYTAB);
		break;

		case CIDELSA:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(CIDELSATAB);
		break;

		case TMC600:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(TELMACTAB);
			XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->SetSelection(TMC600TAB);
		break;

		case TMC1800:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(TELMACTAB);
			XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->SetSelection(TMC1800TAB);
		break;

		case TMC2000:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(TELMACTAB);
			XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->SetSelection(TMC2000TAB);
		break;

		case NANO:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(TELMACTAB);
			XRCCTRL(*this, "TelmacChoiceBook", wxChoicebook)->SetSelection(NANOTAB);
		break;

		case PECOM:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(PECOMTAB);
		break;

		case ETI:
			XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(ETITAB);
		break;
	}
}

void Main::enableElfConfig(bool status)
{
	wxMenuBar *menubarPointer = GetMenuBar();

	menubarPointer->Enable(XRCID("MI_GameMode"), status);
	menubarPointer->Enable(XRCID("MI_GiantBoard"), status);
	menubarPointer->Enable(XRCID("MI_QuestLoader"), status);
	menubarPointer->Enable(XRCID("MI_SuperBasic"), status);
	menubarPointer->Enable(XRCID("MI_SuperBasic3"), status);
	menubarPointer->Enable(XRCID("MI_SuperBasic5"), status);
	menubarPointer->Enable(XRCID("MI_SuperBasic6"), status);
	menubarPointer->Enable(XRCID("MI_SuperBasicSerial"), status);
	menubarPointer->Enable(XRCID("MI_RcaBasic"), status);
	menubarPointer->Enable(XRCID("MI_RcaBasicSerial"), status);
	menubarPointer->Enable(XRCID("MI_RcaBasicPixie"), status);
	menubarPointer->Enable(XRCID("MI_RcaBasicElfOsInstall"), status);
	menubarPointer->Enable(XRCID("MI_Music"), status);
	menubarPointer->Enable(XRCID("MI_SuperGoldMonitor"), status);
	menubarPointer->Enable(XRCID("MI_MonitorBasic"), status);
	menubarPointer->Enable(XRCID("MI_FigForth"), status);
	menubarPointer->Enable(XRCID("MI_TinyBasicPixie"), status);
	menubarPointer->Enable(XRCID("MI_TinyBasicSerial"), status);
	menubarPointer->Enable(XRCID("MI_TinyBasic6847"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsInstallConfig"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsConfig"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsInstallConfig25"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsConfig25"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoInstallConfigPixie"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoConfigPixie"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoInstallConfig6845"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoConfig6845"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoInstallConfig6847"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoConfig6847"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoInstallConfigTms"), status);
	menubarPointer->Enable(XRCID("MI_SetElfOsIoConfigTms"), status);
}

void Main::enableGui(bool status)
{
	if (!mode_.gui)
		return;
	wxMenuBar *menubarPointer = GetMenuBar();

	menubarPointer->Enable(XRCID(GUIDEFAULT), status);
	menubarPointer->Enable(XRCID("MI_ActivateMain"), !status);
	menubarPointer->Enable(XRCID("MI_FullScreen"), !status);
	menubarPointer->Enable(XRCID("CDP1802"), status);
	menubarPointer->Enable(XRCID("CDP1804"), status);
	menubarPointer->Enable(XRCID("CDP1805"), status);

	if (runningComputer_ == COMX)
	{
		chip8ProtectedMode_= false;
		XRCCTRL(*this,"Chip8TraceButton", wxToggleButton)->SetValue(false);
		XRCCTRL(*this,"Chip8DebugMode", wxCheckBox)->SetValue(false); 
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"EpromComx", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomComx", wxComboBox)->Enable(status&!conf[COMX].sbActive_);
		XRCCTRL(*this,"RomButtonComx", wxButton)->Enable(status&!conf[COMX].sbActive_);
		XRCCTRL(*this,"ExpRomComx", wxComboBox)->Enable(status&!conf[COMX].sbActive_);
		XRCCTRL(*this,"ExpRomButtonComx", wxButton)->Enable(status&!conf[COMX].sbActive_);
		XRCCTRL(*this, "Cart1RomComx", wxComboBox)->Enable(status);
		XRCCTRL(*this, "Cart1RomButtonComx", wxButton)->Enable(status);
		if (expansionRomLoaded_ || conf[COMX].sbActive_)
		{
			XRCCTRL(*this,"Cart2RomComx", wxComboBox)->Enable(status);
			XRCCTRL(*this,"Cart2RomButtonComx", wxButton)->Enable(status);
			XRCCTRL(*this,"Cart3RomComx", wxComboBox)->Enable(status);
			XRCCTRL(*this,"Cart3RomButtonComx", wxButton)->Enable(status);
			XRCCTRL(*this,"Cart4RomComx", wxComboBox)->Enable(status&!conf[COMX].sbActive_);
			XRCCTRL(*this,"Cart4RomButtonComx", wxButton)->Enable(status&!conf[COMX].sbActive_);
		}
		XRCCTRL(*this,"VidModeComx", wxChoice)->Enable(status);
		XRCCTRL(*this,"VidModeTextComx", wxStaticText)->Enable(status);
		XRCCTRL(*this,"PrintButtonComx", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Comx", wxButton)->Enable(!status);
		XRCCTRL(*this,"FullScreenF3Comx", wxButton)->Enable(!status);
		XRCCTRL(*this,"ExpRamComx", wxCheckBox)->Enable(status);
		XRCCTRL(*this,"SbActiveComx", wxCheckBox)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
		enableDiskRomGui(diskRomLoaded_);
		enableComxGui(status);
	}
	if (runningComputer_ == CIDELSA)
	{
		chip8ProtectedMode_= false;
		XRCCTRL(*this,"Chip8TraceButton", wxToggleButton)->SetValue(false);
		XRCCTRL(*this,"Chip8DebugMode", wxCheckBox)->SetValue(false);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomCidelsa", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ScreenDumpF5Cidelsa", wxButton)->Enable(!status);
		XRCCTRL(*this,"FullScreenF3Cidelsa", wxButton)->Enable(!status);
	}
	if (runningComputer_ == TMC600)
	{
		chip8ProtectedMode_= false;
		XRCCTRL(*this,"Chip8TraceButton", wxToggleButton)->SetValue(false);
		XRCCTRL(*this,"Chip8DebugMode", wxCheckBox)->SetValue(false);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"PrintButtonTmc600", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Tmc600", wxButton)->Enable(!status);
		XRCCTRL(*this,"FullScreenF3Tmc600", wxButton)->Enable(!status);
		XRCCTRL(*this,"MainRomTmc600", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ExpRomTmc600", wxComboBox)->Enable(status);
		XRCCTRL(*this,"ExpRomButtonTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"CharRomTmc600", wxComboBox)->Enable(status);
		XRCCTRL(*this,"CharRomButtonTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"RamTmc600", wxChoice)->Enable(status);
		XRCCTRL(*this,"RamTextTmc600", wxStaticText)->Enable(status);
		if (status == true)
		{
			XRCCTRL(*this,"AdiInputText", wxStaticText)->Enable(!status);
			XRCCTRL(*this,"AdiChannel", wxSpinCtrl)->Enable(!status);
			XRCCTRL(*this,"AdiVolt", wxSpinCtrl)->Enable(!status);
			XRCCTRL(*this,"AdiVoltText", wxStaticText)->Enable(!status);
			XRCCTRL(*this,"AdsInputText", wxStaticText)->Enable(!status);
			XRCCTRL(*this,"AdsChannel", wxSpinCtrl)->Enable(!status);
			XRCCTRL(*this,"AdsVolt", wxSpinCtrl)->Enable(!status);
			XRCCTRL(*this,"AdsVoltText", wxStaticText)->Enable(!status);
		}
		XRCCTRL(*this,"RealTimeClockTmc600", wxCheckBox)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == PECOM)
	{
		chip8ProtectedMode_= false;
		XRCCTRL(*this,"Chip8TraceButton", wxToggleButton)->SetValue(false);
		XRCCTRL(*this,"Chip8DebugMode", wxCheckBox)->SetValue(false);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"PrintButtonPecom", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Pecom", wxButton)->Enable(!status);
		XRCCTRL(*this,"FullScreenF3Pecom", wxButton)->Enable(!status);
		XRCCTRL(*this,"MainRomPecom", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonPecom", wxButton)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == VIP)
	{
		enableChip8DebugGui(!status);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"HighResVip", wxCheckBox)->Enable(status);
		XRCCTRL(*this,"MainRomVip", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonVip", wxButton)->Enable(status);
		XRCCTRL(*this,"RamSWVip", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RamSWButtonVip", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWVip", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"Chip8SWButtonVip", wxButton)->Enable(status);
		XRCCTRL(*this,"EjectChip8SWVip", wxButton)->Enable(status);
		XRCCTRL(*this,"VP580",wxCheckBox)->Enable(status);
		XRCCTRL(*this,"VP590",wxCheckBox)->Enable(status);
		XRCCTRL(*this,"KeyboardVip",wxCheckBox)->Enable(status);
		XRCCTRL(*this,"SoundVip",wxChoice)->Enable(status);
		XRCCTRL(*this,"StereoVip",wxCheckBox)->Enable(status);
		XRCCTRL(*this,"FullScreenF3Vip", wxButton)->Enable(!status);
		XRCCTRL(*this,"RamVip", wxSpinCtrl)->Enable(status);
		XRCCTRL(*this,"RamTextVip", wxStaticText)->Enable(status);
		XRCCTRL(*this,"RamKbVip", wxStaticText)->Enable(status);
		XRCCTRL(*this,"VP570", wxSpinCtrl)->Enable(status);
		XRCCTRL(*this,"VP570Text", wxStaticText)->Enable(status);
		XRCCTRL(*this,"RamKbVip", wxStaticText)->Enable(status);
		if (!status)
		{
			XRCCTRL(*this,"PrintButtonVip", wxBitmapButton)->Enable(conf[VIP].printerOn_);
			XRCCTRL(*this,"PrintButtonVip", wxBitmapButton)->SetToolTip("Open printer window (F4)");
		}
		else
		{
			XRCCTRL(*this,"PrintButtonVip", wxBitmapButton)->Enable(true);
			if (conf[VIP].printerOn_)
				XRCCTRL(*this,"PrintButtonVip", wxBitmapButton)->SetToolTip("Disable printer support");
			else
				XRCCTRL(*this,"PrintButtonVip", wxBitmapButton)->SetToolTip("Enable printer support");
		}
		XRCCTRL(*this, "VTTypeVip", wxChoice)->Enable(status);
		if (XRCCTRL(*this,"VTTypeVip",wxChoice)->GetSelection() != VTNONE)
		{
			if (elfConfiguration[VIP].useUart)
			{
				baudTextR[VIP]->Enable(status);
				baudChoiceR[VIP]->Enable(status);
			}
			baudTextT[VIP]->Enable(status);
			baudChoiceT[VIP]->Enable(status);
			XRCCTRL(*this, "VTTextVip", wxStaticText)->Enable(status);
			XRCCTRL(*this,"VtSetupVip", wxButton)->Enable(status);
		}

		XRCCTRL(*this,"ScreenDumpF5Vip", wxButton)->Enable(!status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == VIPII)
	{
		enableChip8DebugGui(!status);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomVipII", wxComboBox)->Enable(status);
		XRCCTRL(*this,"MainRom2VipII", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"RomButton2VipII", wxButton)->Enable(status);
		XRCCTRL(*this,"RamSWVipII", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RamSWButtonVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWVipII", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"Chip8SWButtonVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"EjectChip8SWVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3VipII", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5VipII", wxButton)->Enable(!status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == STUDIO)
	{
		enableChip8DebugGui(!status);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomStudio2", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"CartRomStudio2", wxComboBox)->Enable(status);
		XRCCTRL(*this,"CartRomButtonStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3Studio2", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Studio2", wxButton)->Enable(!status);
	}
	if (runningComputer_ == VISICOM)
	{
		enableChip8DebugGui(!status);
		XRCCTRL(*this,"MainRomVisicom", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"CartRomVisicom", wxComboBox)->Enable(status);
		XRCCTRL(*this,"CartRomButtonVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3Visicom", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Visicom", wxButton)->Enable(!status);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
	}
	if (runningComputer_ == VICTORY)
	{
		enableChip8DebugGui(!status);
		XRCCTRL(*this,"MainRomVictory", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"CartRomVictory", wxComboBox)->Enable(status);
		XRCCTRL(*this,"CartRomButtonVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3Victory", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Victory", wxButton)->Enable(!status);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
	}
	if (runningComputer_ == TMC2000)
	{
		enableChip8DebugGui(!status);
		XRCCTRL(*this,"MainRomTMC2000", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"RamSWTMC2000", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RamSWButtonTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWTMC2000", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"EjectChip8SWTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWButtonTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3TMC2000", wxButton)->Enable(!status);
		XRCCTRL(*this,"RamTMC2000", wxChoice)->Enable(status);
		XRCCTRL(*this,"RamTextTMC2000", wxStaticText)->Enable(status);
		XRCCTRL(*this,"ScreenDumpF5TMC2000", wxButton)->Enable(!status);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == TMC1800)
	{
		enableChip8DebugGui(!status);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomTMC1800", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"RamSWTMC1800", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RamSWButtonTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWTMC1800", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"EjectChip8SWTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWButtonTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3TMC1800", wxButton)->Enable(!status);
		XRCCTRL(*this,"RamTMC1800", wxChoice)->Enable(status);
		XRCCTRL(*this,"RamTextTMC1800", wxStaticText)->Enable(status);
		XRCCTRL(*this,"ScreenDumpF5TMC1800", wxButton)->Enable(!status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == ETI)
	{
		enableChip8DebugGui(!status);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomEti", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonEti", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWEti", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"EjectChip8SWEti", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWButtonEti", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3Eti", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Eti", wxButton)->Enable(!status);
		XRCCTRL(*this,"RamEti", wxChoice)->Enable(status);
		XRCCTRL(*this,"RamTextEti", wxStaticText)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}
	if (runningComputer_ == NANO)
	{
		enableChip8DebugGui(!status);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomNano", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonNano", wxButton)->Enable(status);
		XRCCTRL(*this,"RamSWNano", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RamSWButtonNano", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWNano", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"EjectChip8SWNano", wxButton)->Enable(status);
		XRCCTRL(*this,"Chip8SWButtonNano", wxButton)->Enable(status);
		XRCCTRL(*this,"FullScreenF3Nano", wxButton)->Enable(!status);
		XRCCTRL(*this,"ScreenDumpF5Nano", wxButton)->Enable(!status);
		XRCCTRL(*this,"SoundNano", wxChoice)->Enable(status);
		XRCCTRL(*this,"SoundTextNano", wxStaticText)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
	}

	if (runningComputer_ == ELF || runningComputer_ == ELFII || runningComputer_ == SUPERELF)
	{
		chip8ProtectedMode_= false;
		XRCCTRL(*this,"Chip8TraceButton", wxToggleButton)->SetValue(false);
		XRCCTRL(*this,"Chip8DebugMode", wxCheckBox)->SetValue(false);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		wxString elfTypeStr;
		switch (runningComputer_)
		{
			case ELF:
				XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
				XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
				XRCCTRL(*this,"UseLedModule", wxCheckBox)->Enable(status);
				elfTypeStr = "Elf";
			break;
			case ELFII:
				XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
				XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
				elfTypeStr = "ElfII";
			break;
			case SUPERELF:
				XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
				XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
				elfTypeStr = "SuperElf";
			break;
		}
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
		enableElfConfig(status);
		XRCCTRL(*this,"Tape"+elfTypeStr, wxBitmapButton)->Enable(status);
		XRCCTRL(*this,"MainRom"+elfTypeStr, wxComboBox)->Enable(status);
		XRCCTRL(*this,"MainRom2"+elfTypeStr, wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButton"+elfTypeStr, wxButton)->Enable(status);
		XRCCTRL(*this,"Rom1"+elfTypeStr, wxButton)->Enable(status);
		XRCCTRL(*this,"RomButton2"+elfTypeStr, wxButton)->Enable(status);
		XRCCTRL(*this,"Rom2"+elfTypeStr, wxButton)->Enable(status);
		XRCCTRL(*this,"DP_Button"+elfTypeStr, wxButton)->Enable(status);
		if (elfConfiguration[runningComputer_].ideEnabled)
		{
			XRCCTRL(*this,"IDE_Button"+elfTypeStr, wxButton)->Enable(status);
			XRCCTRL(*this,"IdeFile"+elfTypeStr, wxTextCtrl)->Enable(status);
			XRCCTRL(*this,"Eject_IDE"+elfTypeStr, wxButton)->Enable(status);
		}
		if (!status)
		{
			XRCCTRL(*this,"PrintButton"+elfTypeStr, wxBitmapButton)->Enable(conf[runningComputer_].printerOn_);
			XRCCTRL(*this,"PrintButton"+elfTypeStr, wxBitmapButton)->SetToolTip("Open printer window (F4)");
		}
		else
		{
			XRCCTRL(*this,"PrintButton"+elfTypeStr, wxBitmapButton)->Enable(true);
			if (conf[runningComputer_].printerOn_)
				XRCCTRL(*this,"PrintButton"+elfTypeStr, wxBitmapButton)->SetToolTip("Disable printer support");
			else
				XRCCTRL(*this,"PrintButton"+elfTypeStr, wxBitmapButton)->SetToolTip("Enable printer support");
		}
		XRCCTRL(*this,"Memory"+elfTypeStr, wxChoice)->Enable(status);
		XRCCTRL(*this,"MemoryText"+elfTypeStr,wxStaticText)->Enable(status);
		if (elfConfiguration[runningComputer_].usePager)
			XRCCTRL(*this,"PortExt"+elfTypeStr, wxCheckBox)->Enable(false);
		else
			XRCCTRL(*this,"PortExt"+elfTypeStr, wxCheckBox)->Enable(status);

		if (elfConfiguration[runningComputer_].usePager || elfConfiguration[runningComputer_].useEms)
		{
			XRCCTRL(*this, "StartRamText"+computerInfo[runningComputer_].gui, wxStaticText)->Enable(false);
			XRCCTRL(*this, "StartRam"+computerInfo[runningComputer_].gui, wxTextCtrl)->Enable(false);
			XRCCTRL(*this, "EndRamText"+computerInfo[runningComputer_].gui, wxStaticText)->Enable(false);
			XRCCTRL(*this, "EndRam"+computerInfo[runningComputer_].gui, wxTextCtrl)->Enable(false);
		}
		else
		{
			XRCCTRL(*this, "StartRamText"+computerInfo[runningComputer_].gui, wxStaticText)->Enable(status);
			XRCCTRL(*this, "StartRam"+computerInfo[runningComputer_].gui, wxTextCtrl)->Enable(status);
			XRCCTRL(*this, "EndRamText"+computerInfo[runningComputer_].gui, wxStaticText)->Enable(status);
			XRCCTRL(*this, "EndRam"+computerInfo[runningComputer_].gui, wxTextCtrl)->Enable(status);
		}
		XRCCTRL(*this,"VTType"+elfTypeStr,wxChoice)->Enable(status);
		if (XRCCTRL(*this,"VTType"+elfTypeStr,wxChoice)->GetSelection() != VTNONE)
		{
			if (elfConfiguration[runningComputer_].useUart)
			{
				baudTextR[runningComputer_]->Enable(status);
				baudChoiceR[runningComputer_]->Enable(status);
			}
			baudTextT[runningComputer_]->Enable(status);
			baudChoiceT[runningComputer_]->Enable(status);
			XRCCTRL(*this,"VtSetup"+elfTypeStr, wxButton)->Enable(status);
			XRCCTRL(*this,"VTText"+elfTypeStr,wxStaticText)->Enable(status);
		}
		XRCCTRL(*this,"VideoType"+elfTypeStr,wxChoice)->Enable(status);
		XRCCTRL(*this,"VideoTypeText"+elfTypeStr,wxStaticText)->Enable(status);
		XRCCTRL(*this,"DiskType"+elfTypeStr,wxChoice)->Enable(status);
		XRCCTRL(*this,"Keyboard"+elfTypeStr,wxChoice)->Enable(status);
		XRCCTRL(*this,"KeyboardText"+elfTypeStr,wxStaticText)->Enable(status);
		XRCCTRL(*this,"CharRomButton"+elfTypeStr, wxButton)->Enable(status&(elfConfiguration[runningComputer_].use6847||elfConfiguration[runningComputer_].use8275||elfConfiguration[runningComputer_].use6845||elfConfiguration[runningComputer_].useS100));
		XRCCTRL(*this,"VtCharRomButton"+elfTypeStr, wxButton)->Enable(status&(elfConfiguration[runningComputer_].vtType != VTNONE));
		XRCCTRL(*this,"VtCharRom"+elfTypeStr, wxComboBox)->Enable(elfConfiguration[runningComputer_].vtType != VTNONE);
		XRCCTRL(*this,"CharRom"+elfTypeStr, wxComboBox)->Enable(status&(elfConfiguration[runningComputer_].use6847||elfConfiguration[runningComputer_].use8275||elfConfiguration[runningComputer_].use6845||elfConfiguration[runningComputer_].useS100));
		XRCCTRL(*this,"FullScreenF3"+elfTypeStr, wxButton)->Enable(!status&(elfConfiguration[runningComputer_].usePixie||elfConfiguration[runningComputer_].useTMS9918||elfConfiguration[runningComputer_].use6847||elfConfiguration[runningComputer_].use6845||elfConfiguration[runningComputer_].use8275||elfConfiguration[runningComputer_].useS100||(elfConfiguration[runningComputer_].vtType != VTNONE)));
		XRCCTRL(*this,"ScreenDumpF5"+elfTypeStr, wxButton)->Enable(!status&(elfConfiguration[runningComputer_].usePixie||elfConfiguration[runningComputer_].useTMS9918||elfConfiguration[runningComputer_].use6847||elfConfiguration[runningComputer_].use6845||elfConfiguration[runningComputer_].use8275||elfConfiguration[runningComputer_].useS100||(elfConfiguration[runningComputer_].vtType != VTNONE)));
		enableMemAccessGui(!status);
	}
	if (runningComputer_ == ELF2K)
	{
		chip8ProtectedMode_= false;
		XRCCTRL(*this,"Chip8TraceButton", wxToggleButton)->SetValue(false);
		XRCCTRL(*this,"Chip8DebugMode", wxCheckBox)->SetValue(false);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomElf2K", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"IDE_ButtonElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"IdeFileElf2K", wxTextCtrl)->Enable(status);
		XRCCTRL(*this,"Eject_IDEElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"DP_ButtonElf2K", wxButton)->Enable(status);
		enableMemAccessGui(!status);
		if (!elfConfiguration[ELF2K].use8275)
		{
			XRCCTRL(*this, "VTTypeElf2K", wxChoice)->Enable(status);
			if (XRCCTRL(*this,"VTTypeElf2K",wxChoice)->GetSelection() != VTNONE)
			{
				if (elfConfiguration[ELF2K].useUart)
				{
					baudTextR[ELF2K]->Enable(status);
					baudChoiceR[ELF2K]->Enable(status);
				}
				baudTextT[ELF2K]->Enable(status);
				baudChoiceT[ELF2K]->Enable(status);
				XRCCTRL(*this, "VTTextElf2K", wxStaticText)->Enable(status);
				XRCCTRL(*this,"VtSetupElf2K", wxButton)->Enable(status);
			}
		}
		XRCCTRL(*this,"Elf2KVideoType",wxChoice)->Enable(status);
		XRCCTRL(*this,"Elf2KVideoType_Text",wxStaticText)->Enable(status);
		XRCCTRL(*this,"Elf2KKeyboard",wxChoice)->Enable(status);
		XRCCTRL(*this,"Elf2KKeyboard_Text",wxStaticText)->Enable(status);
		XRCCTRL(*this,"CharRomButtonElf2K", wxButton)->Enable(status&elfConfiguration[ELF2K].use8275);
		XRCCTRL(*this,"VtCharRomButtonElf2K", wxButton)->Enable(status&(elfConfiguration[ELF2K].vtType != VTNONE));
		XRCCTRL(*this,"VtCharRomElf2K", wxComboBox)->Enable(status&(elfConfiguration[ELF2K].vtType != VTNONE));
		XRCCTRL(*this,"CharRomElf2K", wxComboBox)->Enable(status&elfConfiguration[ELF2K].use8275);
		XRCCTRL(*this,"FullScreenF3Elf2K", wxButton)->Enable(!status&(elfConfiguration[ELF2K].usePixie||elfConfiguration[ELF2K].use8275||(elfConfiguration[ELF2K].vtType != VTNONE)));
		XRCCTRL(*this,"ScreenDumpF5Elf2K", wxButton)->Enable(!status&(elfConfiguration[ELF2K].usePixie||elfConfiguration[ELF2K].use8275||(elfConfiguration[ELF2K].vtType != VTNONE)));
		XRCCTRL(*this,"Elf2KRtc", wxCheckBox)->Enable(status);
	}
	if (runningComputer_ == COSMICOS)
	{
		chip8ProtectedMode_= false;
		XRCCTRL(*this,"Chip8TraceButton", wxToggleButton)->SetValue(false);
		XRCCTRL(*this,"Chip8DebugMode", wxCheckBox)->SetValue(false);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomCosmicos", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomButtonCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"RamCosmicos", wxSpinCtrl)->Enable(status);
		XRCCTRL(*this,"RamTextCosmicos", wxStaticText)->Enable(status);
		XRCCTRL(*this,"RamKbCosmicos", wxStaticText)->Enable(status);
		enableLoadGui(!status);
		setRealCas2(runningComputer_);
		enableMemAccessGui(!status);

		XRCCTRL(*this, "VTTypeCosmicos", wxChoice)->Enable(status);
		if (XRCCTRL(*this,"VTTypeCosmicos",wxChoice)->GetSelection() != VTNONE)
		{
			if (elfConfiguration[COSMICOS].useUart)
			{
				baudTextR[COSMICOS]->Enable(status);
				baudChoiceR[COSMICOS]->Enable(status);
			}
			baudTextT[COSMICOS]->Enable(status);
			baudChoiceT[COSMICOS]->Enable(status);
			XRCCTRL(*this, "VTTextCosmicos", wxStaticText)->Enable(status);
			XRCCTRL(*this,"VtSetupCosmicos", wxButton)->Enable(status);
		}

		XRCCTRL(*this,"VideoTypeCosmicos",wxChoice)->Enable(status);
		XRCCTRL(*this,"VideoType_TextCosmicos",wxStaticText)->Enable(status);
		XRCCTRL(*this,"KeyboardCosmicos",wxChoice)->Enable(status);
		XRCCTRL(*this,"Keyboard_TextCosmicos",wxStaticText)->Enable(status);
		XRCCTRL(*this,"VtCharRomButtonCosmicos", wxButton)->Enable(status&(elfConfiguration[COSMICOS].vtType != VTNONE));
		XRCCTRL(*this,"VtCharRomCosmicos", wxComboBox)->Enable(status&(elfConfiguration[COSMICOS].vtType != VTNONE));
		XRCCTRL(*this,"FullScreenF3Cosmicos", wxButton)->Enable(!status&(elfConfiguration[COSMICOS].usePixie||(elfConfiguration[COSMICOS].vtType != VTNONE)));
		XRCCTRL(*this,"ScreenDumpF5Cosmicos", wxButton)->Enable(!status&(elfConfiguration[COSMICOS].usePixie||(elfConfiguration[COSMICOS].vtType != VTNONE)));
	}
	if (runningComputer_ == MEMBER)
	{
		chip8ProtectedMode_= false;
		XRCCTRL(*this,"Chip8TraceButton", wxToggleButton)->SetValue(false);
		XRCCTRL(*this,"Chip8DebugMode", wxCheckBox)->SetValue(false);
		XRCCTRL(*this,"ColoursComx", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVip", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVipII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElfII", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursElf2K", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursSuperElf", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursStudio2", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVisicom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursVictory", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCidelsa", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTmc600", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC1800", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursTMC2000", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursNano", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursPecom", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursEti", wxButton)->Enable(status);
		XRCCTRL(*this,"ColoursCosmicos", wxButton)->Enable(status);
		XRCCTRL(*this,"MainRomMembership", wxComboBox)->Enable(status);
		XRCCTRL(*this,"RomMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"RomButtonMembership", wxButton)->Enable(status);
		XRCCTRL(*this,"RamMembership", wxChoice)->Enable(status);
		XRCCTRL(*this,"RamTextMembership", wxStaticText)->Enable(status);
		enableMemAccessGui(!status);

		XRCCTRL(*this, "VTTypeMembership", wxChoice)->Enable(status);
		if (XRCCTRL(*this,"VTTypeMembership",wxChoice)->GetSelection() != VTNONE)
		{
			baudTextT[MEMBER]->Enable(status);
			baudChoiceT[MEMBER]->Enable(status);
			XRCCTRL(*this, "VTTextMembership", wxStaticText)->Enable(status);
			XRCCTRL(*this,"VtSetupMembership", wxButton)->Enable(status);
		}

		XRCCTRL(*this,"VtCharRomButtonMembership", wxButton)->Enable(status&(elfConfiguration[MEMBER].vtType != VTNONE));
		XRCCTRL(*this,"VtCharRomMembership", wxComboBox)->Enable(status&(elfConfiguration[MEMBER].vtType != VTNONE));
		XRCCTRL(*this,"FullScreenF3Membership", wxButton)->Enable(elfConfiguration[MEMBER].vtType != VTNONE);
		XRCCTRL(*this,"ScreenDumpF5Membership", wxButton)->Enable(elfConfiguration[MEMBER].vtType != VTNONE);
	}
	enableDebugGui(!status);

/*	if (status == true)
	{
		XRCCTRL(*this,"AssProgramSlot",wxTextCtrl)->ChangeValue("");
		XRCCTRL(*this,"AssProgramStart",wxTextCtrl)->ChangeValue("");
		XRCCTRL(*this,"AssCodeEnd",wxTextCtrl)->ChangeValue("");
		XRCCTRL(*this,"AssProgramEnd",wxTextCtrl)->ChangeValue("");
		XRCCTRL(*this,"AssRangeNumber",wxStaticText)->SetLabel("0:");
		XRCCTRL(*this,"AssFileName",wxTextCtrl)->ChangeValue("");
		XRCCTRL(*this,"AssStore",wxButton)->Enable(false);
		XRCCTRL(*this, "AssStore", wxButton)->SetForegroundColour(*wxBLACK);
	}*/

	assNew(0);

	if (status)
	{
		XRCCTRL(*this, "AssStore", wxButton)->Enable(false);
		XRCCTRL(*this, "AssStore", wxButton)->SetForegroundColour(*wxBLACK);
	}

	XRCCTRL(*this, "AssInsert", wxButton)->Enable(false);
	XRCCTRL(*this, "AssDelete", wxButton)->Enable(false);
	XRCCTRL(*this, "AssSaveAll", wxButton)->Enable(false);
	XRCCTRL(*this, "AssFrom", wxButton)->Enable(false);
	XRCCTRL(*this, "AssFromL", wxButton)->Enable(false);
	XRCCTRL(*this, "AssFromV", wxButton)->Enable(false);
	XRCCTRL(*this, "AssRangeSpin", wxSpinButton)->Enable(false);
	enableStartButtonGui(status);
}

void Main::message(wxString buffer)
{
	if (!mode_.gui)
	{
		if (mode_.verbose) 
		{
			buffer = buffer + "\n"; 
			wxMessageOutput::Get()->Printf("%s", buffer.mb_str());
		}
	} 
	else
	{
		XRCCTRL(*this,"Message_Window",wxTextCtrl)->AppendText(buffer);
		XRCCTRL(*this,"Message_Window",wxTextCtrl)->AppendText("\n");
	}
}

void Main::messageInt(int value)
{
	wxString buffer;

	buffer.Printf("%d", value);
	message(buffer);
}

void Main::messageHex(int value)
{
	wxString buffer;

	buffer.Printf("%04X", value);
	message(buffer);
}

wxString Main::getApplicationDir()
{
	return applicationDirectory_;
}

wxChar Main::getPathSep()
{
	return pathSeparator_;
}

int Main::setFdcStepRate(int rate)
{
	switch(rate)
	{
		case 0: return conf[runningComputer_].fdcCpms_ * 6;
		case 1: return conf[runningComputer_].fdcCpms_ * 12;
		case 2: return conf[runningComputer_].fdcCpms_ * 20;
		case 3: return conf[runningComputer_].fdcCpms_ * 30;
	}
	return conf[runningComputer_].fdcCpms_ * 12;
}

int Main::getPsaveData(int item)
{
	return psaveData_[item];
}

void Main::setPsaveData(int item, int data)
{
	psaveData_[item] = data;
	if (computerRunning_)
		p_Computer->setPsaveSettings();
}

int Main::getFunctionKey(int item)
{
	return functionKey_[item];
}

void Main::setFunctionKey(int item, int value)
{
	functionKey_[item] = value;
}

void Main::zoomEvent(double zoom)
{
	if (!mode_.gui)
		return;
	if (zoomTextValueChanged_)
		zoomTextValueChanged_ = false;
	else
	{
		wxString zoomStr;
		zoomStr.Printf("%2.2f", zoom);
		XRCCTRL(*this, "ZoomValue"+computerInfo[runningComputer_].gui, wxTextCtrl)->ChangeValue(zoomStr);
	}
}

void Main::zoomEventVt(double zoom)
{
	if (!mode_.gui)
		return;
	if (zoomTextValueChanged_)
		zoomTextValueChanged_ = false;
	else
	{
		wxString zoomStr;
		zoomStr.Printf("%2.2f", zoom);
		XRCCTRL(*this, "ZoomValueVt"+computerInfo[runningComputer_].gui, wxTextCtrl)->ChangeValue(zoomStr);
	}
}

void Main::vuTimeout(wxTimerEvent&WXUNUSED(event))
{
	switch (runningComputer_)
	{
		case COSMICOS: 
		case ELF: 
		case ELFII:
		case SUPERELF:
		case COMX:
		case VIP: 
		case VIPII: 
		case TMC600:
		case TMC1800:
		case TMC2000:
		case PECOM:
		case ETI:
		case NANO:
			vuSet("Vu"+computerInfo[runningComputer_].gui, p_Computer->getGaugeValue());
		break;
	}

	if (selectedComputer_ == DEBUGGER)
	{
		switch (debuggerChoice_)
		{
			case TRACETAB:
				if (percentageClock_ == 1)
					p_Main->updateWindow();
			break;

			case DIRECTASSTAB:
				if (updateAssPage_)
				{
					directAss();
					updateAssPage_ = false;
				}
			break;

			case MEMORYTAB:
				if (updateMemoryPage_)
				{
					memoryDisplay();
					updateMemoryPage_ = false;
				}

				if (updateSlotinfo_)
				{
					wxString slotValue;
					switch (runningComputer_)
					{
						case COMX:
							XRCCTRL(*this, "DebugExpansionSlot", SlotEdit)->changeNumber(p_Comx->getComxExpansionSlot()+1);
							if (p_Comx->isRamCardActive())
								XRCCTRL(*this, "DebugExpansionRam", SlotEdit)->changeNumber(p_Comx->getComxExpansionRamBank());
							if (p_Comx->isEpromBoardLoaded())
								XRCCTRL(*this, "DebugExpansionEprom", SlotEdit)->changeNumber(p_Comx->getComxExpansionEpromBank());
						break;
						case ELF:
						case ELFII:
						case SUPERELF:
							if (elfConfiguration[runningComputer_].usePager)
							{
								XRCCTRL(*this, "DebugPager", HexEdit)->changeNumber(p_Computer->getPager(portExtender_));
								XRCCTRL(*this, "DebugPortExtender", HexEdit)->changeNumber(portExtender_);
							}
							if (elfConfiguration[runningComputer_].useEms)
								XRCCTRL(*this, "DebugEmsPage", HexEdit)->changeNumber(p_Computer->getEmsPage());
						break;
					}
					updateSlotinfo_ = false;
				}

				if (updateMemory_ && memoryDisplay_ != CPU_TYPE)
				{
					updateMemory_ = false;
					wxString idReference, valueStr;
					for (int y=0; y<16; y++)
					{
						if (rowChanged_[y])
						{
							rowChanged_[y] = false;
							ShowCharacters(memoryStart_+(y*16), y);
							for (int x=0; x<16; x++)
							{
								if (memoryChanged_[x][y])
								{
									memoryChanged_[x][y] = false;
									idReference.Printf("MEM%01X%01X", y, x);

									if (memoryDisplay_ == V_6847_RAM)
									{
										if (elfConfiguration[runningComputer_].use6847)
										{
											if (memoryStart_ <= getAddressMask())
												XRCCTRL(*this, idReference, MemEdit)->changeNumber2X(debugReadMem(memoryStart_+y*16+x));
											else
												XRCCTRL(*this, idReference, MemEdit)->changeNumber1X(debugReadMem(memoryStart_+y*16+x));
										}
										else
											XRCCTRL(*this, idReference, MemEdit)->changeNumber2X(0);
									}
									else
										XRCCTRL(*this, idReference, MemEdit)->changeNumber2X(debugReadMem(memoryStart_+y*16+x));
								}
							}
						}
					}
				}
			break;
		}
	}
}

void Main::updateMemoryTab()
{
	updateMemoryPage_ = true;
}

void Main::updateAssTab()
{
	updateAssPage_ = true;
}

void Main::updateSlotInfo()
{
	updateSlotinfo_ = true;
	updateMemoryTab();
	updateAssTab();
}

void Main::ledTimeout(wxTimerEvent&WXUNUSED(event))
{
	p_Computer->ledTimeout();
}

void Main::updateCheckTimeout(wxTimerEvent&WXUNUSED(event))
{
	bool checkForUpdate;
	configPointer->Read("/Main/Check_For_Update", &checkForUpdate, true);

	if (checkForUpdate)
	{
		if (p_Main->checkUpdateEmma())
		{
			if (p_Main->updateEmma())
				Destroy();
		}
	}
}

void Main::cpuTimeout(wxTimerEvent&WXUNUSED(event))
{
	if (selectedComputer_ == DEBUGGER && debuggerChoice_ == MESSAGETAB)
		showTime();

}

void Main::startTime()
{
	startTime_ = wxGetLocalTime();
}

void Main::showTime()
{
	wxString print_buffer;
	int h,m,s;
	double f1,f2;
	float videoFreq;
	time_t endTime;

	long cpuCycles = p_Computer->getCpuCycles();
	if (cpuCycles != 0)
	{
		endTime = wxGetLocalTime();
		s = endTime - startTime_;
		h = s / 3600;
		s -= (h * 3600);
		m = s / 60;
		s -= (m * 60);
		f2 = endTime - startTime_;
		f1 = cpuCycles;
		f1 /= f2;
		f1 = f1 / 1000000 * 8;

		print_buffer.Printf("%ld", cpuCycles);
#if wxCHECK_VERSION(2, 9, 0)
		XRCCTRL(*this, "CpuCycles", wxStaticText)->SetLabelText(print_buffer);
#else
		XRCCTRL(*this, "CpuCycles", wxStaticText)->SetLabel(print_buffer);
#endif

		print_buffer.Printf("%02d:%02d:%02d",h,m,s);
#if wxCHECK_VERSION(2, 9, 0)
		XRCCTRL(*this, "RunTime", wxStaticText)->SetLabelText(print_buffer);
#else
		XRCCTRL(*this, "RunTime", wxStaticText)->SetLabel(print_buffer);
#endif

		print_buffer.Printf("%6.3f MHz",f1);
#if wxCHECK_VERSION(2, 9, 0)
		XRCCTRL(*this, "EffectiveClock", wxStaticText)->SetLabelText(print_buffer);
#else
		XRCCTRL(*this, "EffectiveClock", wxStaticText)->SetLabel(print_buffer);
#endif

		if (p_Video != NULL)
		{
			int videoSyncCount = p_Video->getVideoSyncCount();
			if (videoSyncCount != 0)
			{
				videoFreq = (float) (videoSyncCount / f2);
				print_buffer.Printf("%2.1f Hz",videoFreq);
			}
		}
		else
			print_buffer = "---";
#if wxCHECK_VERSION(2, 9, 0)
		XRCCTRL(*this, "VideoFrequency", wxStaticText)->SetLabelText(print_buffer);
#else
		XRCCTRL(*this, "VideoFrequency", wxStaticText)->SetLabel(print_buffer);
#endif
	}
}

void Main::vuSet(wxString item, int gaugeValue)
{
	if (gaugeValue == oldGauge_)
		return;

	oldGauge_ = gaugeValue;

	wxBitmap vu(100, VU_HI, 24);
	wxMemoryDC dcVu;

	dcVu.SelectObject(vu);
	dcVu.SetPen(wxPen(wxColour(0, 0xc0, 0)));
	dcVu.SetBrush(wxBrush(wxColour(0, 0xc0, 0)));

	int gaugeGreen = gaugeValue / 100;
	if (gaugeGreen > VU_RED)  gaugeGreen = VU_RED;
	dcVu.DrawRectangle(0, 0, gaugeGreen, VU_HI);

	if (gaugeGreen < VU_RED)
	{
		dcVu.SetPen(wxPen(wxColour(0, 0x22, 0)));
		dcVu.SetBrush(wxBrush(wxColour(0, 0x22, 0)));
		dcVu.DrawRectangle(gaugeGreen, 0, VU_RED-gaugeGreen, VU_HI);
	}

	dcVu.SetPen(wxPen(wxColour(0xc0, 0, 0)));
	dcVu.SetBrush(wxBrush(wxColour(0xc0, 0, 0)));

	int gaugeRed = gaugeValue / 100;
	if (gaugeRed > VU_MAX)  gaugeRed = VU_MAX;
	if (gaugeRed < VU_RED)  gaugeRed = VU_RED;
	dcVu.DrawRectangle(VU_RED, 0, gaugeRed-VU_RED, VU_HI);

	if (gaugeRed < VU_MAX)
	{
		dcVu.SetPen(wxPen(wxColour(0x22, 0, 0)));
		dcVu.SetBrush(wxBrush(wxColour(0x22, 0, 0)));
		dcVu.DrawRectangle(gaugeRed, 0, VU_MAX-gaugeRed, VU_HI);
	}
	dcVu.SelectObject(wxNullBitmap);
	XRCCTRL(*this, item, wxStaticBitmap)->SetBitmap(vu);
}

void Main::errorMessageEvent(wxErrorMsgEvent&event)
{
    wxString message = event.GetMsg();
	(void)wxMessageBox( message,
					    "Emma 02", wxICON_ERROR | wxOK );
}

void Main::errorMessage(wxString msg)
{
    wxErrorMsgEvent event( wxEVT_ERROR_MSG, GetId() );
    event.SetEventObject( p_Main );
    event.SetMsg( msg );
	GetEventHandler()->AddPendingEvent( event );
}

wxErrorMsgEvent::wxErrorMsgEvent( wxEventType commandType, int id )
: wxNotifyEvent( commandType, id )
{
    message = "";
}

void Main::setLocationEvent(guiEvent&WXUNUSED(event))
{
	wxString printBuffer;

	if (popupDialog_ != NULL)
		popupDialog_->setLocation(conf[runningComputer_].useLoadLocation_, conf[runningComputer_].saveStartString_, conf[runningComputer_].saveEndString_, conf[runningComputer_].saveExecString_);
	if (!mode_.gui)
		return;

	if (conf[runningComputer_].useLoadLocation_)
	{
		XRCCTRL(*this,"SaveStart"+computerInfo[runningComputer_].gui, wxTextCtrl)->ChangeValue(conf[runningComputer_].saveStartString_);
		XRCCTRL(*this,"SaveEnd"+computerInfo[runningComputer_].gui, wxTextCtrl)->ChangeValue(conf[runningComputer_].saveEndString_);
		XRCCTRL(*this,"SaveExec"+computerInfo[runningComputer_].gui, wxTextCtrl)->ChangeValue(conf[runningComputer_].saveExecString_);
	}
	else
	{
		XRCCTRL(*this,"SaveStart"+computerInfo[runningComputer_].gui, wxTextCtrl)->ChangeValue("");
		XRCCTRL(*this,"SaveEnd"+computerInfo[runningComputer_].gui, wxTextCtrl)->ChangeValue("");
		XRCCTRL(*this,"SaveExec"+computerInfo[runningComputer_].gui, wxTextCtrl)->ChangeValue("");
	}
	XRCCTRL(*this, "UseLocation"+computerInfo[runningComputer_].gui, wxCheckBox)->SetValue(conf[runningComputer_].useLoadLocation_);
	enableLocationGui();
}

void Main::eventSetLocation(bool state, Word saveStart, Word saveEnd, Word saveExec)
{
 	wxString printBuffer;
	guiEvent event(GUI_MSG, SET_LOCATION);
    event.SetEventObject( p_Main );

 	conf[runningComputer_].useLoadLocation_ = state;
    conf[runningComputer_].saveStart_ = saveStart;
	conf[runningComputer_].saveEnd_ = saveEnd;
    conf[runningComputer_].saveExec_ = saveExec;

	printBuffer.Printf("%04X",saveStart);
 	conf[runningComputer_].saveStartString_ = printBuffer;
	printBuffer.Printf("%04X",saveEnd);
 	conf[runningComputer_].saveEndString_ = printBuffer;
	printBuffer.Printf("%04X",saveExec);
 	conf[runningComputer_].saveExecString_ = printBuffer;

	GetEventHandler()->AddPendingEvent(event);
}

void Main::eventSetLocation(bool state)
{
    guiEvent event(GUI_MSG, SET_LOCATION);
    event.SetEventObject( p_Main );

 	conf[runningComputer_].useLoadLocation_ = state;
    conf[runningComputer_].saveExec_ = 0;

	GetEventHandler()->AddPendingEvent(event);
}

void Main::setSaveStartEvent(guiEvent&WXUNUSED(event))
{
	if (popupDialog_ != NULL)
		popupDialog_->setStartLocation(conf[runningComputer_].saveStartString_);
	if (!mode_.gui)
		return;

	XRCCTRL(*this,"SaveStart"+computerInfo[runningComputer_].gui, wxTextCtrl)->SetValue(conf[runningComputer_].saveStartString_);
}

void Main::eventSaveStart(Word saveStart)
{
    guiEvent event(GUI_MSG, SET_SAVE_START);
    event.SetEventObject( p_Main );

    conf[runningComputer_].saveStart_ = saveStart;
	conf[runningComputer_].saveStartString_.Printf("%04X",saveStart);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::setSaveEndEvent(guiEvent&WXUNUSED(event))
{
	if (popupDialog_ != NULL)
		popupDialog_->setEndLocation(conf[runningComputer_].saveEndString_);
	if (!mode_.gui)
		return;

	XRCCTRL(*this,"SaveEnd"+computerInfo[runningComputer_].gui, wxTextCtrl)->SetValue(conf[runningComputer_].saveEndString_);
}

void Main::eventSaveEnd(Word saveEnd)
{
    guiEvent event(GUI_MSG, SET_SAVE_END);
    event.SetEventObject( p_Main );

    conf[runningComputer_].saveEnd_ = saveEnd;
	conf[runningComputer_].saveEndString_.Printf("%04X",saveEnd);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::setSwNameEvent(guiEvent&event)
{
	wxString name = event.GetString();

	setSwName(name);
}

void Main::eventSetSwName(wxString swName)
{
    guiEvent event(GUI_MSG, SET_SW_NAME);
    event.SetEventObject( p_Main );

    event.SetString(swName);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::setTapeStateEvent(guiEvent&event)
{
    int tapeState = event.GetInt();

	setTapeState(tapeState);
}

void Main::eventSetTapeState(int tapeState)
{
    guiEvent event(GUI_MSG, SET_TAPE_STATE);
    event.SetEventObject( p_Main );

    event.SetInt(tapeState);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::setTextValueEvent(guiEvent&event)
{
    wxString info = event.GetString();
    wxString value = event.GetStringValue2();

	XRCCTRL(*this, info, wxTextCtrl)->SetValue(value); 
}

void Main::eventSetTextValue(wxString info, wxString value)
{
	if (!mode_.gui)
		return;

	guiEvent event(GUI_MSG, SET_TEXT_VALUE);
    event.SetEventObject( p_Main );

    event.SetString(info);
    event.SetStringValue2(value);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::setCheckBoxEvent(guiEvent&event)
{
    wxString info = event.GetString();
    bool status = event.GetBoolValue();

	setCheckBox(info, status);
}
 
void Main::eventSetCheckBox(wxString info, bool state)
{
	if (!mode_.gui)
		return;
    guiEvent event(GUI_MSG, SET_CHECK_BOX);
    event.SetEventObject( p_Main );

    event.SetString(info);
    event.SetBoolValue(state);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::printDefaultEvent(guiEvent&event)
{
    Byte value = event.GetByteValue1();

    p_Printer->printerOut(value);
}

void Main::eventPrintDefault(Byte value)
{
    guiEvent event(GUI_MSG, PRINT_DEFAULT);
    event.SetEventObject( p_Main );

    event.SetByteValue1(value);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::printParallelEvent(guiEvent&event)
{
    Byte value = event.GetByteValue1();

    p_PrinterParallel->outParallel(value);
	if (statusLedUpdate_)
		p_Main->statusLedOffDirect();
}

void Main::eventPrintParallel(Byte value)
{
	if (statusLedUpdate_)
		p_Main->statusLedOnEvent();
    guiEvent event(GUI_MSG, PRINT_PARALLEL);
    event.SetEventObject( p_Main );

    event.SetByteValue1(value);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::printParallelFinishedEvent(guiEvent&WXUNUSED(event))
{
    p_PrinterParallel->printFinished();
}

void Main::eventPrintParallelFinished()
{
    guiEvent event(GUI_MSG, PRINT_PARALLEL_FINISHED);
    event.SetEventObject( p_Main );

	GetEventHandler()->AddPendingEvent(event);
}

void Main::printThermalEvent(guiEvent&event)
{
    Byte value = event.GetByteValue1();
    Byte Qflag = event.GetByteValue2();

    p_PrinterThermal->outThermal(value, Qflag);
	thermalEf_ = false;
	if (statusLedUpdate_)
		p_Main->statusLedOffDirect();
}

void Main::eventPrintThermal(Byte value, Byte Qflag)
{
	if (statusLedUpdate_)
		p_Main->statusLedOnEvent();
	guiEvent event(GUI_MSG, PRINT_THERMAL);
    event.SetEventObject( p_Main );

    event.SetByteValue1(value);
    event.SetByteValue2(Qflag);

	thermalEf_ = true;
	GetEventHandler()->AddPendingEvent(event);
}

void Main::printThermalFinishedEvent(guiEvent&WXUNUSED(event))
{
	p_PrinterThermal->printFinished();
	thermalEf_ = false;
}

void Main::eventPrintThermalFinished()
{
    guiEvent event(GUI_MSG, PRINT_THERMAL_FINISHED);
    event.SetEventObject( p_Main );

	GetEventHandler()->AddPendingEvent(event);
}

void Main::printSerialEvent(guiEvent&event)
{
    Byte value = event.GetByteValue1();

    p_PrinterSerial->outSerial(value);
	if (statusLedUpdate_)
		p_Main->statusLedOffDirect();
}

void Main::eventPrintSerial(Byte value)
{
	if (statusLedUpdate_)
		p_Main->statusLedOnEvent();
	guiEvent event(GUI_MSG, PRINT_SERIAL);
    event.SetEventObject( p_Main );

    event.SetByteValue1(value);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::printSerialFinishedEvent(guiEvent&WXUNUSED(event))
{
	p_PrinterSerial->printFinished();
}

void Main::eventPrintSerialFinished()
{
    guiEvent event(GUI_MSG, PRINT_SERIAL_FINISHED);
    event.SetEventObject( p_Main );

	GetEventHandler()->AddPendingEvent(event);
}

void Main::printPecomEvent(guiEvent&event)
{
    Byte value = event.GetByteValue1();

    p_Printer->outBitPecom(value);
}

void Main::eventPrintPecom(Byte value)
{
    guiEvent event(GUI_MSG, PRINT_PECOM);
    event.SetEventObject( p_Main );

    event.SetByteValue1(value);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::updateDebugMemory(Word address)
{
	if (selectedComputer_ == DEBUGGER)
	{
		if (debuggerChoice_ == MEMORYTAB)
		{
			updateMemory_ = true;

			int x, y;

			x = (address-memoryStart_) & 0xf;
			y = ((address-memoryStart_)  >> 4) & 0xf;

			rowChanged_[y] = true;
			memoryChanged_[x][y] = true;
		}
	}
}

void Main::showChip8Register(int variable, int value)
{
	wxString idReference;
	idReference.Printf("V%01X", variable);

	wxString valueStr;
	valueStr.Printf("%02X", value);

	XRCCTRL(*this, idReference, wxTextCtrl)->ChangeValue(valueStr);
}

void Main::setFandMBasicGuiEvent(guiEvent&WXUNUSED(event))
{
    setFandMBasicGui();
}

void Main::eventSetFandMBasicGui()
{
 	if (!mode_.gui)
		return;
	guiEvent event(GUI_MSG, SET_FM_GUI);
    event.SetEventObject( p_Main );

	GetEventHandler()->AddPendingEvent(event);
}

void Main::enableMemAccesEvent(guiEvent&event)
{
    bool status = event.GetBoolValue();

	enableMemAccessGui(status);
	if (popupDialog_ != NULL)
		popupDialog_->enableMemAccessGui(status);
}

void Main::eventEnableMemAccess(bool state)
{
	if (!mode_.gui)
		return;
    guiEvent event(GUI_MSG, ENABLE_MEM_ACCESS);
    event.SetEventObject( p_Main );

    event.SetBoolValue(state);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::setVideoFullScreenEvent(guiEvent&event)
{
    bool status = event.GetBoolValue();
	if (p_Video != NULL)
		p_Video->setFullScreen(status);
}

void Main::eventVideoSetFullScreen(bool state)
{
    guiEvent event(GUI_MSG, SET_VIDEO_FULLSCREEN);
    event.SetEventObject( p_Main );

    event.SetBoolValue(state);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::setVtFullScreenEvent(guiEvent&event)
{
    bool status = event.GetBoolValue();
	if (p_Vt100 != NULL)
		p_Vt100->setFullScreen(status);
}

void Main::eventVtSetFullScreen(bool state)
{
    guiEvent event(GUI_MSG, SET_VT_FULLSCREEN);
    event.SetEventObject( p_Main );

    event.SetBoolValue(state);

	GetEventHandler()->AddPendingEvent(event);
}

void Main::setChangeNoteBookEvent(guiEvent& WXUNUSED(event))
{
	XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(COMXTAB);
	XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(DEBUGGERTAB);
	XRCCTRL(*this, GUICOMPUTERNOTEBOOK, wxNotebook)->SetSelection(configPointer->Read("/Main/Selected_Tab", 0l));
}

void Main::eventChangeNoteBook()
{
    guiEvent event(GUI_MSG, CHANGE_NOTEBOOK);
    event.SetEventObject( p_Main );

	GetEventHandler()->AddPendingEvent(event);
}

void Main::setDisableControlsEvent(guiEvent& WXUNUSED(event))
{
	XRCCTRL(*this, "TextStartComx", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartComx", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndComx", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndComx", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextExecComx", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextExecComx", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartElf2K", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartElf2K", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndElf2K", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndElf2K", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartVip", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartVip", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndVip", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndVip", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartCosmicos", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartCosmicos", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndCosmicos", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndCosmicos", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartElf", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartElf", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndElf", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndElf", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextExecElf", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextExecElf", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartElfII", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartElfII", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndElfII", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndElfII", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextExecElfII", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextExecElfII", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartSuperElf", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartSuperElf", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndSuperElf", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndSuperElf", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextExecSuperElf", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextExecSuperElf", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartMembership", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartMembership", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndMembership", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndMembership", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartTmc600", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartTmc600", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndTmc600", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndTmc600", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextExecTmc600", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextExecTmc600", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartTMC1800", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartTMC1800", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndTMC1800", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndTMC1800", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartTMC2000", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartTMC2000", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndTMC2000", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndTMC2000", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartNano", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartNano", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndNano", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndNano", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartPecom", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartPecom", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndPecom", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndPecom", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextExecPecom", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextExecPecom", wxStaticText)->Enable(false);

	XRCCTRL(*this, "TextStartEti", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextStartEti", wxStaticText)->Enable(false);
	XRCCTRL(*this, "TextEndEti", wxStaticText)->Enable(true);
	XRCCTRL(*this, "TextEndEti", wxStaticText)->Enable(false);
}

void Main::eventDisableControls()
{
    guiEvent event(GUI_MSG, DISABLE_CONTROLS);
    event.SetEventObject( p_Main );

	GetEventHandler()->AddPendingEvent(event);
}

void Main::setUpdateTitle(guiEvent& WXUNUSED(event))
{
	updateTitle();
}

void Main::eventUpdateTitle()
{
    guiEvent event(GUI_MSG, UPDATE_TITLE);
    event.SetEventObject( p_Main );

	GetEventHandler()->AddPendingEvent(event);
}

void Main::loadKeyDefinition(wxString findFile1, wxString findFile2, int hexKeysA[], int hexKeysB[])
{
	wxTextFile keyDefinitionFile;
	wxString gameName;

	bool valid1 = true;
	bool valid2 = true;
	if (findFile1 == "")
		valid1 = false;
	if (findFile2 == "")
		valid2 = false;
	if (keyDefinitionFile.Open(dataDir_ + "keydefinition.txt"))
	{
		for (gameName=keyDefinitionFile.GetFirstLine(); !keyDefinitionFile.Eof(); gameName=keyDefinitionFile.GetNextLine())
		{
			if (((gameName == findFile1) && valid1) || ((gameName == findFile2) && valid2))
			{
				if (keyDefinitionFile.Eof())
					return;
				wxString HexKeyValues=keyDefinitionFile.GetNextLine();
				if (HexKeyValues.BeforeFirst(':') != "Hex_keys")
					return;
				HexKeyValues = HexKeyValues.AfterFirst(':');

				wxString nextValue = HexKeyValues.BeforeFirst(',');
				long value;
				int i=0;
				while (nextValue.ToLong(&value, 16) && i<10)
				{
					if (value <17)
					{
						if (i < 5)
							hexKeysA[i] = value;
						else
							hexKeysB[i-5] = value;
					}
					i++;
					HexKeyValues = HexKeyValues.AfterFirst(',');
					nextValue = HexKeyValues.BeforeFirst(',');
				}
/*				if (keyDefinitionFile.Eof())
					return;
				wxString PCKeyValues=keyDefinitionFile.GetNextLine();
				if (PCKeyValues.BeforeFirst(':') != "PC_keys")
					return;
				PCKeyValues = PCKeyValues.AfterFirst(':');

				nextValue = PCKeyValues.BeforeFirst(',');
				i=0;
				while (nextValue.ToLong(&value, 10) && i<10)
				{
					if (i < 5)
						pcKeysA[i] = value;
					else
						pcKeysB[i-5] = value;
					i++;
					PCKeyValues = PCKeyValues.AfterFirst(',');
					nextValue = PCKeyValues.BeforeFirst(',');
				}
				return;*/
			}
		}
	}
}

int Main::getDefaultInKey(wxString computerStr)
{
	return configPointer->Read(computerStr+"/InButton", WXK_INSERT);
}

void Main::getDefaultGameKeys(wxString computerStr, wxString player, int keysValue[], int keysHex[])
{
	if (player == "A")
	{
		keysValue[HEX_UP] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Up", WXK_UP);
		keysValue[HEX_LEFT] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Left", WXK_LEFT);
		keysValue[HEX_RIGHT] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Right", WXK_RIGHT);
		keysValue[HEX_DOWN] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Down", WXK_DOWN);
		keysValue[HEX_FIRE] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Fire", WXK_SPACE);

		keysHex[HEX_UP] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Up", 2);
		keysHex[HEX_LEFT] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Left", 4);
		keysHex[HEX_RIGHT] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Right", 6);
		keysHex[HEX_DOWN] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Down", 8);
		keysHex[HEX_FIRE] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Fire", 5);
	}
	else
	{
		keysValue[HEX_UP] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Up", WXK_NUMPAD_UP);
		keysValue[HEX_LEFT] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Left", WXK_NUMPAD_LEFT);
		keysValue[HEX_RIGHT] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Right", WXK_NUMPAD_RIGHT);
		keysValue[HEX_DOWN] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Down", WXK_NUMPAD_DOWN);
		keysValue[HEX_FIRE] = configPointer->Read(computerStr+"/KeyGameValue"+player+"Fire", WXK_NUMPAD_ENTER );

		if (computerStr == "Studio2" || computerStr == "Victory" || computerStr == "Visicom")
		{
			keysHex[HEX_UP] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Up", 2);
			keysHex[HEX_LEFT] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Left", 4);
			keysHex[HEX_RIGHT] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Right", 6);
			keysHex[HEX_DOWN] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Down", 8);
			keysHex[HEX_FIRE] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Fire", 5);
		}
		else
		{
			keysHex[HEX_UP] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Up", 0xc);
			keysHex[HEX_LEFT] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Left", 7);
			keysHex[HEX_RIGHT] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Right", 9);
			keysHex[HEX_DOWN] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Down", 0xd);
			keysHex[HEX_FIRE] = configPointer->Read(computerStr+"/KeyGameHex"+player+"Fire", 0l);
		}
	}

}

void Main::storeDefaultGameKeys(wxString computerStr, wxString player, int keysValue[], int keysHex[])
{
	configPointer->Write(computerStr+"/KeyGameValue"+player+"Up", keysValue[HEX_UP]);
	configPointer->Write(computerStr+"/KeyGameValue"+player+"Left", keysValue[HEX_LEFT]);
	configPointer->Write(computerStr+"/KeyGameValue"+player+"Right", keysValue[HEX_RIGHT]);
	configPointer->Write(computerStr+"/KeyGameValue"+player+"Down", keysValue[HEX_DOWN]);
	configPointer->Write(computerStr+"/KeyGameValue"+player+"Fire", keysValue[HEX_FIRE]);

	configPointer->Write(computerStr+"/KeyGameHex"+player+"Up", keysHex[HEX_UP]);
	configPointer->Write(computerStr+"/KeyGameHex"+player+"Left", keysHex[HEX_LEFT]);
	configPointer->Write(computerStr+"/KeyGameHex"+player+"Right", keysHex[HEX_RIGHT]);
	configPointer->Write(computerStr+"/KeyGameHex"+player+"Down", keysHex[HEX_DOWN]);
	configPointer->Write(computerStr+"/KeyGameHex"+player+"Fire", keysHex[HEX_FIRE]);
}

void Main::getDefaultHexKeys(wxString computerStr, wxString player, int keysHex[])
{
	if (player == "A")
	{
		keysHex[0] = configPointer->Read(computerStr+"/HexKeyA0", 48);
		keysHex[1] = configPointer->Read(computerStr+"/HexKeyA1", 49);
		keysHex[2] = configPointer->Read(computerStr+"/HexKeyA2", 50);
		keysHex[3] = configPointer->Read(computerStr+"/HexKeyA3", 51);
		keysHex[4] = configPointer->Read(computerStr+"/HexKeyA4", 52);
		keysHex[5] = configPointer->Read(computerStr+"/HexKeyA5", 53);
		keysHex[6] = configPointer->Read(computerStr+"/HexKeyA6", 54);
		keysHex[7] = configPointer->Read(computerStr+"/HexKeyA7", 55);
		keysHex[8] = configPointer->Read(computerStr+"/HexKeyA8", 56);
		keysHex[9] = configPointer->Read(computerStr+"/HexKeyA9", 57);
		keysHex[10] = configPointer->Read(computerStr+"/HexKeyAA", 65);
		keysHex[11] = configPointer->Read(computerStr+"/HexKeyAB", 66);
		keysHex[12] = configPointer->Read(computerStr+"/HexKeyAC", 67);
		keysHex[13] = configPointer->Read(computerStr+"/HexKeyAD", 68);
		keysHex[14] = configPointer->Read(computerStr+"/HexKeyAE", 69);
		keysHex[15] = configPointer->Read(computerStr+"/HexKeyAF", 70);
	}
	else
	{
		keysHex[0] = configPointer->Read(computerStr+"/HexKeyB0", WXK_NUMPAD0);
		keysHex[1] = configPointer->Read(computerStr+"/HexKeyB1", WXK_NUMPAD1);
		keysHex[2] = configPointer->Read(computerStr+"/HexKeyB2", WXK_NUMPAD2);
		keysHex[3] = configPointer->Read(computerStr+"/HexKeyB3", WXK_NUMPAD3);
		keysHex[4] = configPointer->Read(computerStr+"/HexKeyB4", WXK_NUMPAD4);
		keysHex[5] = configPointer->Read(computerStr+"/HexKeyB5", WXK_NUMPAD5);
		keysHex[6] = configPointer->Read(computerStr+"/HexKeyB6", WXK_NUMPAD6);
		keysHex[7] = configPointer->Read(computerStr+"/HexKeyB7", WXK_NUMPAD7);
		keysHex[8] = configPointer->Read(computerStr+"/HexKeyB8", WXK_NUMPAD8);
		keysHex[9] = configPointer->Read(computerStr+"/HexKeyB9", WXK_NUMPAD9);
		keysHex[10] = configPointer->Read(computerStr+"/HexKeyBA", WXK_HOME);
		keysHex[11] = configPointer->Read(computerStr+"/HexKeyBB", WXK_END);
		keysHex[12] = configPointer->Read(computerStr+"/HexKeyBC", WXK_PAGEUP);
		keysHex[13] = configPointer->Read(computerStr+"/HexKeyBD", WXK_PAGEDOWN);
		keysHex[14] = configPointer->Read(computerStr+"/HexKeyBE", WXK_NUMPAD_DIVIDE);
		keysHex[15] = configPointer->Read(computerStr+"/HexKeyBF", WXK_NUMPAD_MULTIPLY);
	}
}

