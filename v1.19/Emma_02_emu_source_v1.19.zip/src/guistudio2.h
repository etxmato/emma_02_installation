#ifndef GUISTUDIO2_H
#define GUISTUDIO2_H

#include "guivip.h"

class GuiStudio2: public GuiVip
{
public:

	GuiStudio2(const wxString& title, const wxPoint& pos, const wxSize& size, Mode mode, wxString dataDir);
	~GuiStudio2() {};

	void readStudioConfig();
	void writeStudioConfig();
	void readVisicomConfig();
	void writeVisicomConfig();
	void readVictoryConfig();
	void writeVictoryConfig();

	void onSt2Rom(wxCommandEvent& event);
	void onSt2RomEject(wxCommandEvent& event);

private:
	wxString studio2St2RomDir_;

	DECLARE_EVENT_TABLE()
};

#endif // GUISTUDIO2_H
