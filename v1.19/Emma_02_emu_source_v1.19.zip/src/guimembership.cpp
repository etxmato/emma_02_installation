/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guielf2k.h"

BEGIN_EVENT_TABLE(GuiMembership, GuiStudio2)

	EVT_TEXT(XRCID("MainRomMembership"), GuiMain::onMainRom1Text)
	EVT_COMBOBOX(XRCID("MainRomMembership"), GuiMain::onMainRom1Text)
	EVT_BUTTON(XRCID("RomButtonMembership"), GuiMain::onMainRom1)

	EVT_TEXT(XRCID("VtCharRomMembership"), GuiMain::onVtCharRomText)
	EVT_COMBOBOX(XRCID("VtCharRomMembership"), GuiMain::onVtCharRomText)
	EVT_BUTTON(XRCID("RomMembership"), GuiMembership::onRomEvent)

	EVT_BUTTON(XRCID("VtCharRomButtonMembership"), GuiMain::onVtCharRom)
	EVT_CHOICE(XRCID("VTTypeMembership"), GuiMain::onVT100)
	EVT_SPIN_UP(XRCID("ZoomSpinVtMembership"), GuiMain::onZoomUpVt)
	EVT_SPIN_DOWN(XRCID("ZoomSpinVtMembership"), GuiMain::onZoomDownVt)
	EVT_TEXT(XRCID("ZoomValueVtMembership"), GuiMain::onZoomValueVt)
	EVT_BUTTON(XRCID("FullScreenF3Membership"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("ColoursMembership"), Main::onColoursDef)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeMembership"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeMembership"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonMembership"), GuiMain::onScreenDumpFile)
	EVT_TEXT(XRCID("ScreenDumpFileMembership"), GuiMain::onScreenDumpFileText)
	EVT_COMBOBOX(XRCID("ScreenDumpFileMembership"), GuiMain::onScreenDumpFileText)
	EVT_BUTTON(XRCID("ScreenDumpF5Membership"), GuiMain::onScreenDump)
	EVT_BUTTON(XRCID("DP_ButtonMembership"), GuiMain::onDp)
	EVT_BUTTON(XRCID("SaveButtonMembership"), GuiMain::onSaveButton)
	EVT_BUTTON(XRCID("LoadButtonMembership"), GuiMain::onLoadButton)
	EVT_CHECKBOX(XRCID("StretchDotMembership"), GuiMain::onStretchDot)
	EVT_BUTTON(XRCID("KeyMapMembership"), Main::onHexKeyDef)
	EVT_CHECKBOX(XRCID("AutoBootMembership"), GuiElf::onAutoBoot)
	EVT_BUTTON(XRCID("VtSetupMembership"), GuiMain::onVtSetup)
	EVT_TEXT(XRCID("ShowAddressMembership"), GuiMain::onLedTimer)
	EVT_CHECKBOX(XRCID("ClearRamMembership"), GuiMain::onClearRam)
	EVT_TEXT(XRCID("BootAddressMembership"), GuiElf::onBootAddress)

	EVT_TEXT(XRCID("SaveStartMembership"), GuiMain::onSaveStart)
	EVT_TEXT(XRCID("SaveEndMembership"), GuiMain::onSaveEnd)

	EVT_CHECKBOX(XRCID("ForceUCMembership"), GuiMembership::onMembershipForceUpperCase)
	EVT_CHECKBOX(XRCID("ControlWindowsMembership"), GuiMembership::onMembershipControlWindows)
	EVT_CHOICE(XRCID("RamMembership"), GuiMembership::onRam)
	EVT_CHECKBOX(XRCID("NvrMembership"), GuiMembership::onNvrMembership)

END_EVENT_TABLE()

GuiMembership::GuiMembership(const wxString& title, const wxPoint& pos, const wxSize& size, Mode mode, wxString dataDir)
: GuiStudio2(title, pos, size, mode, dataDir)
{
	conf[MEMBER].saveStartString_ = "";
	conf[MEMBER].saveEndString_ = "";
}

void GuiMembership::readMembershipConfig()
{
	bool romMode;
	selectedComputer_ = MEMBER;

	getConfigBool("/Membership/SerialLog", false);
	getConfigBool("/Membership/VtEf", false);
	elfConfiguration[MEMBER].useUart = false;

	conf[MEMBER].mainDir_ = configPointer->Read("Dir/Membership/Main", dataDir_ + "Membership" + pathSeparator_);
	conf[MEMBER].romDir_[MAINROM1] = configPointer->Read("Dir/Membership/Main_Rom_File", dataDir_ + "Membership" + pathSeparator_);
	conf[MEMBER].vtCharRomDir_ = configPointer->Read("Dir/Membership/Vt_Font_Rom_File", dataDir_ + "Membership" + pathSeparator_);
	conf[MEMBER].ramDir_ = configPointer->Read("Dir/Membership/Software_File", dataDir_ + "Membership" + pathSeparator_);
	conf[MEMBER].screenDumpFileDir_ = configPointer->Read("Dir/Membership/Video_Dump_File", dataDir_ + "Membership" + pathSeparator_);

	elfConfiguration[MEMBER].vtType = configPointer->Read("/Membership/VT_Type", 0l);

	configPointer->Read("/Membership/Load_Mode_Rom", &romMode, false);
	if (romMode)
		loadromMode_ = RAM;
	else
		loadromMode_ = ROM;
	onRom();

	long value; 
	wxString bootAddress = configPointer->Read("/Membership/Boot_Address", "0000");
	if (!bootAddress.ToLong(&value, 16))
		value = 0;
	conf[MEMBER].bootAddress_ = value;
	conf[MEMBER].ramType_ = configPointer->Read("/Membership/Ram_Type", 03);

	conf[MEMBER].rom_[MAINROM1] = configPointer->Read("/Membership/Main_Rom_File", "program3.bin");
	conf[MEMBER].screenDumpFile_ = configPointer->Read("/Membership/Video_Dump_File", "screendump.png");
	conf[MEMBER].volume_ = configPointer->Read("/Membership/Volume", 25l);

	elfConfiguration[MEMBER].clearRam = false;
	elfConfiguration[MEMBER].baudR = configPointer->Read("/Membership/Vt_Baud_Receive", 5l);
	elfConfiguration[MEMBER].baudT = configPointer->Read("/Membership/Vt_Baud_Transmit", 5l);

	configPointer->Read("/Membership/Open_Control_Windows", &elfConfiguration[MEMBER].useElfControlWindows, true);
	configPointer->Read("/Membership/Force_Uppercase", &elfConfiguration[MEMBER].forceUpperCase, true);
	configPointer->Read("/Membership/Enable_Auto_Boot", &elfConfiguration[MEMBER].autoBoot, true);
	configPointer->Read("/Membership/Enable_Vt_Stretch_Dot", &conf[MEMBER].stretchDot_, false);
	configPointer->Read("/Membership/Use_Non_Volatile_Ram", &elfConfiguration[MEMBER].nvr, true);

	wxString defaultZoom;
	defaultZoom.Printf("%2.2f", 1.0);
	conf[MEMBER].zoomVt_ = configPointer->Read("/Membership/Vt_Zoom", defaultZoom);
	wxString defaultClock;
	defaultClock.Printf("%1.2f", 1.75);
	wxString defaultTimer;
	defaultTimer.Printf("%d", 100);
	conf[MEMBER].ledTime_ = configPointer->Read("/Membership/Led_Update_Frequency", defaultTimer);

	conf[MEMBER].clock_ = configPointer->Read("/Membership/Clock_Speed", defaultClock);
	conf[MEMBER].vtX_ = configPointer->Read("/Membership/Window_Position_Vt_X", mainWindowX_+windowInfo.mainwX);
	conf[MEMBER].vtY_ = configPointer->Read("/Membership/Window_Position_Vt_Y", mainWindowY_);
	conf[MEMBER].mainX_ = configPointer->Read("/Membership/Window_Position_X", mainWindowX_);
	conf[MEMBER].mainY_ = configPointer->Read("/Membership/Window_Position_Y", mainWindowY_+windowInfo.mainwY);

	if (mode_.gui)
		setBaudChoiceMembership();

	setVtType("Membership", MEMBER, elfConfiguration[MEMBER].vtType);
	conf[MEMBER].vtCharRom_ = configPointer->Read("/Membership/Vt_Font_Rom_File", "vt52.a.bin");

	if (mode_.gui)
	{
		XRCCTRL(*this, "MainRomMembership", wxComboBox)->SetValue(conf[MEMBER].rom_[MAINROM1]);
		XRCCTRL(*this, "VtCharRomMembership", wxComboBox)->SetValue(conf[MEMBER].vtCharRom_);
		XRCCTRL(*this, "ScreenDumpFileMembership", wxComboBox)->SetValue(conf[MEMBER].screenDumpFile_);

		XRCCTRL(*this, "VTTypeMembership", wxChoice)->SetSelection(elfConfiguration[MEMBER].vtType);

		baudChoiceR[MEMBER]->SetSelection(elfConfiguration[MEMBER].baudR);
		baudChoiceT[MEMBER]->SetSelection(elfConfiguration[MEMBER].baudT);
		baudTextR[MEMBER]->Enable((elfConfiguration[MEMBER].vtType != VTNONE) && elfConfiguration[MEMBER].useUart);
		baudChoiceR[MEMBER]->Enable((elfConfiguration[MEMBER].vtType != VTNONE) && elfConfiguration[MEMBER].useUart);
		baudTextT[MEMBER]->Enable(elfConfiguration[MEMBER].vtType != VTNONE);
		baudChoiceT[MEMBER]->Enable(elfConfiguration[MEMBER].vtType != VTNONE);

		XRCCTRL(*this, "ForceUCMembership", wxCheckBox)->SetValue(elfConfiguration[MEMBER].forceUpperCase);
		XRCCTRL(*this, "VtCharRomButtonMembership", wxButton)->Enable(elfConfiguration[MEMBER].vtType != VTNONE);
		XRCCTRL(*this, "VtCharRomMembership", wxComboBox)->Enable(elfConfiguration[MEMBER].vtType != VTNONE);
		XRCCTRL(*this, "VtSetupMembership", wxButton)->Enable(elfConfiguration[MEMBER].vtType != VTNONE);
		XRCCTRL(*this, "AutoBootMembership", wxCheckBox)->SetValue(elfConfiguration[MEMBER].autoBoot);
		XRCCTRL(*this, "BootAddressMembership", wxTextCtrl)->SetValue(bootAddress);
		XRCCTRL(*this, "ZoomValueVtMembership", wxTextCtrl)->ChangeValue(conf[MEMBER].zoomVt_);
		XRCCTRL(*this, "ControlWindowsMembership", wxCheckBox)->SetValue(elfConfiguration[MEMBER].useElfControlWindows);
		XRCCTRL(*this, "StretchDotMembership", wxCheckBox)->SetValue(conf[MEMBER].stretchDot_);
		XRCCTRL(*this, "RamMembership", wxChoice)->SetSelection(conf[MEMBER].ramType_);
		XRCCTRL(*this, "VolumeMembership", wxSlider)->SetValue(conf[MEMBER].volume_);
		clockTextCtrl[MEMBER]->ChangeValue(conf[MEMBER].clock_);
		XRCCTRL(*this, "NvrMembership", wxCheckBox)->SetValue(elfConfiguration[MEMBER].nvr);
		XRCCTRL(*this, "ClearRamMembership", wxCheckBox)->Enable(elfConfiguration[MEMBER].nvr);
		XRCCTRL(*this, "ClearRamMembership", wxCheckBox)->SetValue(elfConfiguration[MEMBER].clearRam);
		XRCCTRL(*this, "ShowAddressMembership", wxTextCtrl)->ChangeValue(conf[MEMBER].ledTime_);
		XRCCTRL(*this,"ShowAddressMembership",wxTextCtrl)->Enable(elfConfiguration[MEMBER].useElfControlWindows);
		XRCCTRL(*this,"AddressText1Membership",wxStaticText)->Enable(elfConfiguration[MEMBER].useElfControlWindows);
		XRCCTRL(*this,"AddressText2Membership",wxStaticText)->Enable(elfConfiguration[MEMBER].useElfControlWindows);
	}

	elfConfiguration[MEMBER].usePortExtender = false;
	elfConfiguration[MEMBER].ideEnabled = false;
	elfConfiguration[MEMBER].fdcEnabled = false;
	elfConfiguration[MEMBER].useLedModule = false;
	elfConfiguration[MEMBER].useTape = false;
}

void GuiMembership::writeMembershipConfig()
{
	wxString buffer;

	configPointer->Write("Dir/Membership/Main", conf[MEMBER].mainDir_);
	configPointer->Write("Dir/Membership/Main_Rom_File", conf[MEMBER].romDir_[MAINROM1]);
	configPointer->Write("Dir/Membership/Software_File", conf[MEMBER].ramDir_);
	configPointer->Write("Dir/Membership/Vt_Font_Rom_File", conf[MEMBER].vtCharRomDir_);
	configPointer->Write("Dir/Membership/Video_Dump_File", conf[MEMBER].screenDumpFileDir_);

	configPointer->Write("/Membership/Main_Rom_File", conf[MEMBER].rom_[MAINROM1]);
	configPointer->Write("/Membership/Vt_Font_Rom_File", conf[MEMBER].vtCharRom_);
	configPointer->Write("/Membership/Video_Dump_File", conf[MEMBER].screenDumpFile_);

	configPointer->Write("/Membership/Load_Mode_Rom", (loadromMode_ == ROM));
	configPointer->Write("/Membership/VT_Type", elfConfiguration[MEMBER].vtType);
	configPointer->Write("/Membership/Vt_Baud_Receive", elfConfiguration[MEMBER].baudR);
	configPointer->Write("/Membership/Vt_Baud_Transmit", elfConfiguration[MEMBER].baudT);
	configPointer->Write("/Membership/Enable_Auto_Boot", elfConfiguration[MEMBER].autoBoot);
	buffer.Printf("%04X", (unsigned int)conf[MEMBER].bootAddress_);
	configPointer->Write("/Membership/Boot_Address", buffer);
	configPointer->Write("/Membership/Zoom", conf[MEMBER].zoom_);
	configPointer->Write("/Membership/Vt_Zoom", conf[MEMBER].zoomVt_);
	configPointer->Write("/Membership/Force_Uppercase", elfConfiguration[MEMBER].forceUpperCase);
	configPointer->Write("/Membership/Open_Control_Windows", elfConfiguration[MEMBER].useElfControlWindows);
	configPointer->Write("/Membership/Enable_Vt_Stretch_Dot", conf[MEMBER].stretchDot_);
	configPointer->Write("/Membership/Ram_Type", conf[MEMBER].ramType_);
	configPointer->Write("/Membership/Volume", conf[MEMBER].volume_);
	configPointer->Write("/Membership/Use_Non_Volatile_Ram", elfConfiguration[MEMBER].nvr);
	configPointer->Write("/Membership/Led_Update_Frequency", conf[MEMBER].ledTime_);

	if (conf[MEMBER].vtX_ > 0)
		configPointer->Write("/Membership/Window_Position_Vt_X", conf[MEMBER].vtX_);
	if (conf[MEMBER].vtY_ > 0)
		configPointer->Write("/Membership/Window_Position_Vt_Y", conf[MEMBER].vtY_);
	if (conf[MEMBER].mainX_ > 0)
		configPointer->Write("/Membership/Window_Position_X", conf[MEMBER].mainX_);
	if (conf[MEMBER].mainY_ > 0)
		configPointer->Write("/Membership/Window_Position_Y", conf[MEMBER].mainY_);

	configPointer->Write("/Membership/Clock_Speed", conf[MEMBER].clock_);

	if (mode_.gui)
	{
		delete baudChoiceR[MEMBER];
		delete baudChoiceT[MEMBER];
	}
}

void GuiMembership::onMembershipBaudR(wxCommandEvent&event)
{
	elfConfiguration[MEMBER].baudR = event.GetSelection();
}

void GuiMembership::onMembershipBaudT(wxCommandEvent&event)
{
	elfConfiguration[MEMBER].baudT = event.GetSelection();
	if (!elfConfiguration[MEMBER].useUart)
	{
		elfConfiguration[MEMBER].baudR = event.GetSelection();
		baudChoiceR[MEMBER]->SetSelection(elfConfiguration[MEMBER].baudR);
	}
}

void GuiMembership::onMembershipForceUpperCase(wxCommandEvent&event)
{
	elfConfiguration[MEMBER].forceUpperCase = event.IsChecked();
	if (runningComputer_ == MEMBER)
	{
		p_Membership->setForceUpperCase(event.IsChecked());
	}
}

void GuiMembership::onMembershipControlWindows(wxCommandEvent&event)
{
	elfConfiguration[MEMBER].useElfControlWindows = event.IsChecked();
	XRCCTRL(*this,"ShowAddressMembership",wxTextCtrl)->Enable(elfConfiguration[MEMBER].useElfControlWindows);
	XRCCTRL(*this,"AddressText1Membership",wxStaticText)->Enable(elfConfiguration[MEMBER].useElfControlWindows);
	XRCCTRL(*this,"AddressText2Membership",wxStaticText)->Enable(elfConfiguration[MEMBER].useElfControlWindows);
	if (runningComputer_ == MEMBER)
		p_Membership->Show(elfConfiguration[MEMBER].useElfControlWindows);
}

void GuiMembership::setBaudChoiceMembership()
{
	wxString choices[16];
	wxPoint position;
	position = XRCCTRL(*this, "ScreenDumpFileButtonMembership", wxButton)->GetPosition();

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMGL__)
	int offSetX = 13;
	int offSetY = 48;
	int choiseOffSetY = 45;
#else
#if defined(__WXMAC__)
	int offSetX = 13;
	int offSetY = 47;
	int choiseOffSetY = 43;
#else
	int offSetX = 9;
	int offSetY = 45;
	int choiseOffSetY = 45;
#endif
#endif

/*	if (elfConfiguration[MEMBER].useUart)
	{
		choices[0] = "19200";
		choices[1] = "9600";
		choices[2] = "4800";
		choices[3] = "3600";
		choices[4] = "2400";
		choices[5] = "2000";
		choices[6] = "1800";
		choices[7] = "1200";
		choices[8] = "600";
		choices[9] = "300";
		choices[10] = "200";
		choices[11] = "150";
		choices[12] = "134";
		choices[13] = "110";
		choices[14] = "75";
		choices[15] = "50";
		baudTextT[MEMBER] = new wxStaticText(XRCCTRL(*this, "PanelMembership", wxPanel), wxID_ANY, "T:", wxPoint(position.x+74+offSetX,position.y+4+offSetY));
		baudChoiceT[MEMBER] = new wxChoice(XRCCTRL(*this, "PanelMembership", wxPanel), GUI_MEMBER_BAUDT, wxPoint(position.x+84+offSetX,position.y+choiseOffSetY+choiseOffSetY), wxSize(54,23), 16, choices);
		baudTextR[MEMBER] = new wxStaticText(XRCCTRL(*this, "PanelMembership", wxPanel), wxID_ANY, "R:", wxPoint(position.x+142+offSetX,position.y+4+offSetY));
		baudChoiceR[MEMBER] = new wxChoice(XRCCTRL(*this, "PanelMembership", wxPanel), GUI_MEMBER_BAUDR, wxPoint(position.x+152+offSetX,position.y+choiseOffSetY+choiseOffSetY), wxSize(54,23), 16, choices);
	}
	else
	{*/
		choices[0] = "2400";
		choices[1] = "2000";
		choices[2] = "1800";
		choices[3] = "1200";
		choices[4] = "600";
		choices[5] = "300";
		baudTextT[MEMBER] = new wxStaticText(XRCCTRL(*this, "PanelMembership", wxPanel), wxID_ANY, "T/R:", wxPoint(position.x+64+offSetX,position.y+4+offSetY));
		baudChoiceT[MEMBER] = new wxChoice(XRCCTRL(*this, "PanelMembership", wxPanel), GUI_MEMBER_BAUDT, wxPoint(position.x+84+offSetX,position.y+choiseOffSetY), wxSize(54,23), 6, choices);
		baudTextR[MEMBER] = new wxStaticText(XRCCTRL(*this, "PanelMembership", wxPanel), wxID_ANY, "R:", wxPoint(position.x+142+offSetX,position.y+4+offSetY));
		baudChoiceR[MEMBER] = new wxChoice(XRCCTRL(*this, "PanelMembership", wxPanel), GUI_MEMBER_BAUDR, wxPoint(position.x+152+offSetX,position.y+choiseOffSetY), wxSize(54,23), 6, choices);
		baudTextR[MEMBER]->Hide();
		baudChoiceR[MEMBER]->Hide();
//	}
#if defined(__WXMAC__)
	wxFont defaultFont(9, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL);
	baudTextT[MEMBER]->SetFont(defaultFont);
	baudChoiceT[MEMBER]->SetFont(defaultFont);
	baudTextR[MEMBER]->SetFont(defaultFont);
	baudChoiceR[MEMBER]->SetFont(defaultFont);
#endif
//	this->Connect(GUI_MEMBER_BAUDR, wxEVT_COMMAND_CHOICE_SELECTED , wxCommandEventHandler(GuiMembership::onMembershipBaudR) );
	this->Connect(GUI_MEMBER_BAUDT, wxEVT_COMMAND_CHOICE_SELECTED , wxCommandEventHandler(GuiMembership::onMembershipBaudT) );
}

void GuiMembership::onRam(wxCommandEvent&event)
{
	conf[MEMBER].ramType_ = event.GetSelection();

	XRCCTRL(*this, "ClearRamMembership", wxCheckBox)->SetValue(true);
	elfConfiguration[MEMBER].clearRam = true;
}

void GuiMembership::onRomEvent(wxCommandEvent&WXUNUSED(event))
{
	onRom();
}

void GuiMembership::onRom()
{
	if (loadromMode_ == ROM)
	{
		loadromMode_ = RAM;
		if (mode_.gui)
		{
			XRCCTRL(*this, "RomButtonMembership", wxButton)->SetLabel("RAM");
			XRCCTRL(*this, "RomButtonMembership", wxButton)->SetToolTip("Browse for Membership Card RAM file");
		}
	}
	else
	{
		loadromMode_ = ROM;
		if (mode_.gui)
		{
			XRCCTRL(*this, "RomButtonMembership", wxButton)->SetLabel("ROM");
			XRCCTRL(*this, "RomButtonMembership", wxButton)->SetToolTip("Browse for Membership Card ROM file");
		}
	}
}

int GuiMembership::getLoadromModeMembership()
{
	return loadromMode_;
}

void GuiMembership::onNvrMembership(wxCommandEvent&event)
{
	elfConfiguration[MEMBER].nvr = event.IsChecked();
	XRCCTRL(*this, "ClearRamMembership", wxCheckBox)->Enable(event.IsChecked());
}

