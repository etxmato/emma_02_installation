#ifndef SOUND_H
#define SOUND_H

#include "waveWriter.h"
#include "waveReader.h"
#include "Blip_Buffer.h"
#include "Sync_Audio.h"
#include "SDL_audioin.h"

class Sound
{
public: 

	Sound();
	~Sound();

	void initSound(double clock, int computerType, int volume, int bass, int treble, int toneChannels, int stereo, bool realCasLoad);  
	void tone(short reg4);  
	void tone1864Latch(Byte audioLatch1864);
	void tone1864On();  
	void setVipSound (int vipSound){vipSound_ = vipSound;};
	void amplitudeSuper(int channel, int amplitude);
	void frequencySuper(int channel, int frequency);
	void octaveSuper(int channel, int octave);
	void toneSuper();  
	void beepOn();  
	void beepOff();  
	void toneElf2KOn();
	void toneElf2KOff();
	void noise(short reg5); 
	void soundCycle();

	void playSound();
	void playSoundBuffer();
	void psaveAmplitudeChange(int q);
	void playSaveLoad();
	void convertTo8Bit(const short* in, int count, unsigned char* out);
	void ploadStartTape(wxString fileName);
	void psaveStartTape(wxString fileName);
	void stopTape();
	void stopSaveLoad();
	void setVolume(int volume);
	void setClockRate(double clock);
	bool isSaving();
	bool isLoading();
	void setEqualization(int bass, int treble);
	void setSoundFollowQ(bool status) {followQ_ = status;};
	void record_pause(bool status);
	void wavFile();
	void setPsaveSettings();

protected:
	Byte flipFlopQ_;
	int vipSound_;
	bool realCassetteLoad_;

private:
	Blip_Buffer *soundBufferPointerLeft;
	Blip_Buffer *soundBufferPointerRight;
	Blip_Buffer *tapeBufferPointer;
	Blip_Synth<blip_high_quality,30> *toneSynthPointer[8];
	Blip_Synth<blip_high_quality,30> *noiseSynthPointer[2];
	Blip_Synth<blip_high_quality,30> *psaveSynthPointer[2];
	Blip_Synth<blip_high_quality,30> *tapeSynthPointer;
	Sync_Audio *audioPointer;

	WaveWriter *psaveWavePointer;
	WaveReader *ploadWavePointer;

	int computerType_;
	int soundTime_;
	float gain_;

	int tonePeriod_[8];
	int toneTime_[8];
	bool toneOn_[8];
	int toneAmplitude_[8];

	int noisePeriod_;
	int noiseTime_;
	bool noiseOn_;
	int noiseAmplitude_;
	int noiseSign_;

	bool stopTheTape_;
	bool psaveOn_;
	bool ploadOn_;
	int psaveAmplitude_;
	int psaveVolume_;
	int psaveBitRate_;
	int psaveBitsPerSample_;
	bool followQ_;
	int beepPeriod_;

	Byte audioLatch1864_;

	Byte frequencySuper_[8];
	int octaveSuper_[8];

	int toneChannels_;
	int stereo_;
	bool inputChannel_;
};

#endif  // SOUND_H