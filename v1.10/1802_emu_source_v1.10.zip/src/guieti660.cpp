/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guieti660.h"
#include "pixie.h"

#include "psave.h"

#include "play_black.xpm"
#include "play_green.xpm"
#include "rec_off.xpm"
#include "rec_on.xpm"

BEGIN_EVENT_TABLE(GuiEti, GuiNano)
	EVT_BUTTON(XRCID("RomButtonEti"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("Chip8SWButtonEti"), GuiMain::onChip8SW)
	EVT_BUTTON(XRCID("EjectChip8SWEti"), GuiMain::onEjectChip8SW)
	EVT_SPINCTRL(XRCID("ZoomEti"), GuiMain::onZoom)
	EVT_BUTTON(XRCID("FullScreenF3Eti"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("CasButtonEti"), GuiMain::onCassette)
	EVT_BUTTON(XRCID("EjectCasEti"), GuiMain::onCassetteEject)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonEti"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Eti"), GuiMain::onScreenDump)
	EVT_BUTTON(XRCID("RealCasLoadEti"), GuiMain::onRealCas)
	EVT_BUTTON(XRCID("CasLoadEti"), GuiMain::onCassetteLoad)
	EVT_BUTTON(XRCID("CasSaveEti"), GuiMain::onCassetteSave)
	EVT_BUTTON(XRCID("CasStopEti"), GuiMain::onCassetteStop)
	EVT_CHECKBOX(XRCID("TurboEti"), GuiMain::onTurbo)
	EVT_TEXT(XRCID("TurboClockEti"), GuiMain::onTurboClock)
	EVT_CHECKBOX(XRCID("AutoCasLoadEti"), GuiMain::onAutoLoad)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeEti"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeEti"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("SaveButtonEti"), GuiMain::onSaveButton)
	EVT_BUTTON(XRCID("LoadButtonEti"), GuiMain::onLoadButton)
	EVT_TEXT(XRCID(_T("ClockEti")), GuiMain::onClock)
	EVT_BUTTON(XRCID(_T("KeyMapEti")), Main::onHexKeyDef)
	EVT_BUTTON(XRCID(_T("ColoursEti")), Main::onColoursDef)

END_EVENT_TABLE()

GuiEti::GuiEti(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiNano(title, pos, size)
{
}

void GuiEti::readEtiConfig()
{
	bool turbo;
	selectedComputer_ = ETI;

	XRCCTRL(*this, "MainRomEti", wxComboBox)->SetValue(configPointer->Read(_T("/Eti/EtiMainRom"), "eti-660.bin"));
	XRCCTRL(*this, "Chip8SWEti", wxTextCtrl)->SetValue(configPointer->Read(_T("/Eti/EtiChip8SW"), "wipeout.c8"));
	XRCCTRL(*this, "ZoomEti", wxSpinCtrl)->SetValue(configPointer->Read(_T("/Eti/EtiZoom"), 2l));
	conf[ETI].romDir_[MAINROM] = configPointer->Read(_T("/Eti/EtiRomDir"), dataDir_ + "Eti"  + pathSeparator_);
	conf[ETI].ramDir_ = configPointer->Read(_T("/Eti/EtiRamDir"), dataDir_ + "Eti"  + pathSeparator_);
	conf[ETI].chip8SWDir_ = configPointer->Read(_T("/Eti/Chip8SWDir"), dataDir_ + "Eti"  + pathSeparator_);

	XRCCTRL(*this, "WavFileEti", wxTextCtrl)->SetValue(configPointer->Read(_T("/Eti/EtiWavFile"), ""));
	conf[ETI].wavFileDir_ = configPointer->Read(_T("/Eti/WavFileDir"), dataDir_ + "Eti" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileEti", wxTextCtrl)->SetValue(configPointer->Read(_T("/Eti/EtiScreenDumpFile"), "screendump.bmp"));
	conf[ETI].screenDumpFileDir_ = configPointer->Read(_T("/Eti/EtiScreenDumpFileDir"), dataDir_ + "Eti" + pathSeparator_);

	configPointer->Read(_T("/Eti/EtiTurbo"), &turbo, true);
	XRCCTRL(*this, "TurboEti", wxCheckBox)->SetValue(turbo);
	turboGui("Eti");
	conf[ETI].turboClock_ = configPointer->Read(_T("/Eti/EtiTurboClock"), "15");
	XRCCTRL(*this, "TurboClockEti", wxTextCtrl)->SetValue(conf[ETI].turboClock_);
	configPointer->Read(_T("/Eti/EtiAutoCasLoad"), &conf[ETI].autoCassetteLoad_, true);
	XRCCTRL(*this, "AutoCasLoadEti", wxCheckBox)->SetValue(conf[ETI].autoCassetteLoad_);
	configPointer->Read(_T("/Eti/RealCasLoad"), &conf[ETI].realCassetteLoad_, false);
	setRealCas(ETI);

	conf[ETI].volume_ = configPointer->Read(_T("/Eti/EtiVolume"), 25l);
	XRCCTRL(*this, "VolumeEti", wxSlider)->SetValue(conf[ETI].volume_);
	XRCCTRL(*this, "RamEti", wxChoice)->SetSelection(configPointer->Read(_T("/Eti/Memory"), 0l));

	conf[ETI].mainX_ = configPointer->Read(_T("/Eti/EtiX"), mainWindowX_+windowInfo.mainwX);
	conf[ETI].mainY_ = configPointer->Read(_T("/Eti/EtiY"), mainWindowY_);

	conf[ETI].clock_ = configPointer->Read(_T("/Eti/Clock"), "1.773");
	XRCCTRL(*this, _T("ClockEti"), wxTextCtrl)->ChangeValue(conf[ETI].clock_);
}

void GuiEti::writeEtiConfig()
{
	configPointer->Write(_T("/Eti/EtiMainRom"), XRCCTRL(*this, "MainRomEti", wxComboBox)->GetValue());
	configPointer->Write(_T("/Eti/EtiChip8SW"), XRCCTRL(*this, "Chip8SWEti", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Eti/EtiZoom"), XRCCTRL(*this, "ZoomEti", wxSpinCtrl)->GetValue());
	configPointer->Write(_T("/Eti/EtiRomDir"), conf[ETI].romDir_[MAINROM]);
	configPointer->Write(_T("/Eti/EtiRamDir"), conf[ETI].ramDir_);
	configPointer->Write(_T("/Eti/Chip8SWDir"), conf[ETI].chip8SWDir_);

	if (conf[ETI].mainX_ > 0)
		configPointer->Write(_T("/Eti/EtiX"), conf[ETI].mainX_);
	if (conf[ETI].mainY_ > 0)
		configPointer->Write(_T("/Eti/EtiY"), conf[ETI].mainY_);

	configPointer->Write(_T("/Eti/EtiWavFile"), XRCCTRL(*this, "WavFileEti", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Eti/WavFileDir"), conf[ETI].wavFileDir_);
	configPointer->Write(_T("/Eti/EtiScreenDumpFile"), XRCCTRL(*this, "ScreenDumpFileEti", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Eti/EtiScreenDumpFileDir"), conf[ETI].screenDumpFileDir_);
	configPointer->Write(_T("/Eti/EtiTurbo"), XRCCTRL(*this, "TurboEti", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Eti/EtiTurboClock"), conf[ETI].turboClock_);
	configPointer->Write(_T("/Eti/EtiAutoCasLoad"), XRCCTRL(*this, "AutoCasLoadEti", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Eti/RealCasLoad"), conf[ETI].realCassetteLoad_);
	configPointer->Write(_T("/Eti/EtiVolume"), XRCCTRL(*this, "VolumeEti", wxSlider)->GetValue());
	configPointer->Write(_T("/Eti/Memory"), XRCCTRL(*this, "RamEti", wxChoice)->GetSelection());

	configPointer->Write(_T("/Eti/Clock"), conf[ETI].clock_);
}
