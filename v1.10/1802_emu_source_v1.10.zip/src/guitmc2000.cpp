/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guitmc2000.h"
#include "pixie.h"

#include "psave.h"

#include "play_black.xpm"
#include "play_green.xpm"
#include "rec_off.xpm"
#include "rec_on.xpm"

BEGIN_EVENT_TABLE(GuiTMC2000, GuiEti)
	EVT_BUTTON(XRCID("RomButtonTMC2000"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("RamSWButtonTMC2000"), GuiMain::onRamSW)
	EVT_BUTTON(XRCID("Chip8SWButtonTMC2000"), GuiMain::onChip8SW)
	EVT_BUTTON(XRCID("EjectChip8SWTMC2000"), GuiMain::onEjectChip8SW)
	EVT_SPINCTRL(XRCID("ZoomTMC2000"), GuiMain::onZoom)
	EVT_BUTTON(XRCID("FullScreenF3TMC2000"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("CasButtonTMC2000"), GuiMain::onCassette)
	EVT_BUTTON(XRCID("EjectCasTMC2000"), GuiMain::onCassetteEject)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonTMC2000"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5TMC2000"), GuiMain::onScreenDump)
	EVT_BUTTON(XRCID("RealCasLoadTMC2000"), GuiMain::onRealCas)
	EVT_BUTTON(XRCID("CasLoadTMC2000"), GuiMain::onCassetteLoad)
	EVT_BUTTON(XRCID("CasSaveTMC2000"), GuiMain::onCassetteSave)
	EVT_BUTTON(XRCID("CasStopTMC2000"), GuiMain::onCassetteStop)
	EVT_CHECKBOX(XRCID("TurboTMC2000"), GuiMain::onTurbo)
	EVT_TEXT(XRCID("TurboClockTMC2000"), GuiMain::onTurboClock)
	EVT_CHECKBOX(XRCID("AutoCasLoadTMC2000"), GuiMain::onAutoLoad)
	EVT_BUTTON(XRCID("SaveButtonTMC2000"), GuiMain::onSaveButton)
	EVT_BUTTON(XRCID("LoadButtonTMC2000"), GuiMain::onLoadButton)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeTMC2000"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeTMC2000"), GuiMain::onVolume)
	EVT_TEXT(XRCID(_T("ClockTMC2000")), GuiMain::onClock)
	EVT_BUTTON(XRCID(_T("KeyMapTMC2000")), Main::onHexKeyDef)
	EVT_CHECKBOX(XRCID("KeyboardTMC2000"), GuiMain::onKeyboard)
	EVT_BUTTON(XRCID(_T("ColoursTMC2000")), Main::onColoursDef)

	EVT_BUTTON(XRCID("RomButtonTMC1800"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("RamSWButtonTMC1800"), GuiMain::onRamSW)
	EVT_BUTTON(XRCID("Chip8SWButtonTMC1800"), GuiMain::onChip8SW)
	EVT_BUTTON(XRCID("EjectChip8SWTMC1800"), GuiMain::onEjectChip8SW)
	EVT_SPINCTRL(XRCID("ZoomTMC1800"), GuiMain::onZoom)
	EVT_BUTTON(XRCID("FullScreenF3TMC1800"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("CasButtonTMC1800"), GuiMain::onCassette)
	EVT_BUTTON(XRCID("EjectCasTMC1800"), GuiMain::onCassetteEject)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonTMC1800"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5TMC1800"), GuiMain::onScreenDump)
	EVT_BUTTON(XRCID("RealCasLoadTMC1800"), GuiMain::onRealCas)
	EVT_BUTTON(XRCID("CasLoadTMC1800"), GuiMain::onCassetteLoad)
	EVT_BUTTON(XRCID("CasSaveTMC1800"), GuiMain::onCassetteSave)
	EVT_BUTTON(XRCID("CasStopTMC1800"), GuiMain::onCassetteStop)
	EVT_CHECKBOX(XRCID("TurboTMC1800"), GuiMain::onTurbo)
	EVT_TEXT(XRCID("TurboClockTMC1800"), GuiMain::onTurboClock)
	EVT_CHECKBOX(XRCID("AutoCasLoadTMC1800"), GuiMain::onAutoLoad)
	EVT_BUTTON(XRCID("SaveButtonTMC1800"), GuiMain::onSaveButton)
	EVT_BUTTON(XRCID("LoadButtonTMC1800"), GuiMain::onLoadButton)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeTMC1800"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeTMC1800"), GuiMain::onVolume)
	EVT_TEXT(XRCID(_T("ClockTMC1800")), GuiMain::onClock)
	EVT_BUTTON(XRCID(_T("KeyMapTMC1800")), Main::onHexKeyDef)
	EVT_CHECKBOX(XRCID("KeyboardTMC1800"), GuiMain::onKeyboard)

END_EVENT_TABLE()

GuiTMC2000::GuiTMC2000(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiEti(title, pos, size)
{
}

void GuiTMC2000::readTMC2000Config()
{
	bool turbo, keyboard;
	selectedComputer_ = TMC2000;

	XRCCTRL(*this, "MainRomTMC2000", wxComboBox)->SetValue(configPointer->Read(_T("/TMC2000/TMC2000MainRom"), "telmac2000.rom"));
	XRCCTRL(*this, "RamSWTMC2000", wxComboBox)->SetValue(configPointer->Read(_T("/TMC2000/TMC2000RamSW"), "chip8.ram"));
	XRCCTRL(*this, "Chip8SWTMC2000", wxTextCtrl)->SetValue(configPointer->Read(_T("/TMC2000/TMC2000Chip8SW"), "Pong2.c8"));
	XRCCTRL(*this, "ZoomTMC2000", wxSpinCtrl)->SetValue(configPointer->Read(_T("/TMC2000/TMC2000Zoom"), 2l));
	conf[TMC2000].romDir_[MAINROM] = configPointer->Read(_T("/TMC2000/TMC2000RomDir"), dataDir_ + "TMC2000"  + pathSeparator_);
	conf[TMC2000].ramDir_ = configPointer->Read(_T("/TMC2000/TMC2000RamDir"), dataDir_ + "TMC2000"  + pathSeparator_);
	conf[TMC2000].chip8SWDir_ = configPointer->Read(_T("/TMC2000/Chip8SWDir"), dataDir_ + "Chip-8"  + pathSeparator_);

	XRCCTRL(*this, "WavFileTMC2000", wxTextCtrl)->SetValue(configPointer->Read(_T("/TMC2000/TMC2000WavFile"), ""));
	conf[TMC2000].wavFileDir_ = configPointer->Read(_T("/TMC2000/WavFileDir"), dataDir_ + "TMC2000" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileTMC2000", wxTextCtrl)->SetValue(configPointer->Read(_T("/TMC2000/TMC2000ScreenDumpFile"), "screendump.bmp"));
	conf[TMC2000].screenDumpFileDir_ = configPointer->Read(_T("/TMC2000/TMC2000ScreenDumpFileDir"), dataDir_ + "TMC2000" + pathSeparator_);

	configPointer->Read(_T("/TMC2000/TMC2000Turbo"), &turbo, true);
	XRCCTRL(*this, "TurboTMC2000", wxCheckBox)->SetValue(turbo);
	turboGui("TMC2000");
	conf[TMC2000].turboClock_ = configPointer->Read(_T("/TMC2000/TMC2000TurboClock"), "15");
	XRCCTRL(*this, "TurboClockTMC2000", wxTextCtrl)->SetValue(conf[TMC2000].turboClock_);
	configPointer->Read(_T("/TMC2000/TMC2000AutoCasLoad"), &conf[TMC2000].autoCassetteLoad_, true);
	XRCCTRL(*this, "AutoCasLoadTMC2000", wxCheckBox)->SetValue(conf[TMC2000].autoCassetteLoad_);
	configPointer->Read(_T("/TMC2000/RealCasLoad"), &conf[TMC2000].realCassetteLoad_, false);
	setRealCas(TMC2000);

	conf[TMC2000].volume_ = configPointer->Read(_T("/TMC2000/TMC2000Volume"), 25l);
	XRCCTRL(*this, "VolumeTMC2000", wxSlider)->SetValue(conf[TMC2000].volume_);
	XRCCTRL(*this, "RamTMC2000", wxChoice)->SetSelection(configPointer->Read(_T("/TMC2000/TMC2000Ram"), 02));

	conf[TMC2000].mainX_ = configPointer->Read(_T("/TMC2000/TMC2000X"), mainWindowX_+windowInfo.mainwX);
	conf[TMC2000].mainY_ = configPointer->Read(_T("/TMC2000/TMC2000Y"), mainWindowY_);

	conf[TMC2000].clock_ = configPointer->Read(_T("/TMC2000/Clock"), "1.75");
	XRCCTRL(*this, _T("ClockTMC2000"), wxTextCtrl)->ChangeValue(conf[TMC2000].clock_);

	configPointer->Read(_T("/TMC2000/Keyboard"), &keyboard, false);
	XRCCTRL(*this, "KeyboardTMC2000", wxCheckBox)->SetValue(keyboard);
	XRCCTRL(*this, "KeyMapTMC2000", wxButton)->Enable(!keyboard);
}

void GuiTMC2000::writeTMC2000Config()
{
	configPointer->Write(_T("/TMC2000/TMC2000MainRom"), XRCCTRL(*this, "MainRomTMC2000", wxComboBox)->GetValue());
	configPointer->Write(_T("/TMC2000/TMC2000RamSW"), XRCCTRL(*this, "RamSWTMC2000", wxComboBox)->GetValue());
	configPointer->Write(_T("/TMC2000/TMC2000Chip8SW"), XRCCTRL(*this, "Chip8SWTMC2000", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/TMC2000/TMC2000Zoom"), XRCCTRL(*this, "ZoomTMC2000", wxSpinCtrl)->GetValue());
	configPointer->Write(_T("/TMC2000/TMC2000RomDir"), conf[TMC2000].romDir_[MAINROM]);
	configPointer->Write(_T("/TMC2000/TMC2000RamDir"), conf[TMC2000].ramDir_);
	configPointer->Write(_T("/TMC2000/Chip8SWDir"), conf[TMC2000].chip8SWDir_);

	if (conf[TMC2000].mainX_ > 0)
		configPointer->Write(_T("/TMC2000/TMC2000X"), conf[TMC2000].mainX_);
	if (conf[TMC2000].mainY_ > 0)
		configPointer->Write(_T("/TMC2000/TMC2000Y"), conf[TMC2000].mainY_);

	configPointer->Write(_T("/TMC2000/TMC2000WavFile"), XRCCTRL(*this, "WavFileTMC2000", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/TMC2000/WavFileDir"), conf[TMC2000].wavFileDir_);
	configPointer->Write(_T("/TMC2000/TMC2000ScreenDumpFile"), XRCCTRL(*this, "ScreenDumpFileTMC2000", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/TMC2000/TMC2000ScreenDumpFileDir"), conf[TMC2000].screenDumpFileDir_);
	configPointer->Write(_T("/TMC2000/TMC2000Turbo"), XRCCTRL(*this, "TurboTMC2000", wxCheckBox)->GetValue());
	configPointer->Write(_T("/TMC2000/TMC2000TurboClock"), conf[TMC2000].turboClock_);
	configPointer->Write(_T("/TMC2000/TMC2000AutoCasLoad"), XRCCTRL(*this, "AutoCasLoadTMC2000", wxCheckBox)->GetValue());
	configPointer->Write(_T("/TMC2000/RealCasLoad"), conf[TMC2000].realCassetteLoad_);
	configPointer->Write(_T("/TMC2000/TMC2000Volume"), XRCCTRL(*this, "VolumeTMC2000", wxSlider)->GetValue());
	configPointer->Write(_T("/TMC2000/TMC2000Ram"), XRCCTRL(*this, "RamTMC2000", wxChoice)->GetSelection());

	configPointer->Write(_T("/TMC2000/Clock"), conf[TMC2000].clock_);

	configPointer->Write(_T("/TMC2000/Keyboard"), XRCCTRL(*this, "KeyboardTMC2000", wxCheckBox)->GetValue());
}

void GuiTMC2000::readTMC1800Config()
{
	bool turbo, keyboard;
	selectedComputer_ = TMC1800;

	XRCCTRL(*this, "MainRomTMC1800", wxComboBox)->SetValue(configPointer->Read(_T("/TMC1800/TMC1800MainRom"), "telmac1800.rom"));
	XRCCTRL(*this, "RamSWTMC1800", wxComboBox)->SetValue(configPointer->Read(_T("/TMC1800/TMC1800RamSW"), "chip8.ram"));
	XRCCTRL(*this, "Chip8SWTMC1800", wxTextCtrl)->SetValue(configPointer->Read(_T("/TMC1800/TMC1800Chip8SW"), "Pong2.c8"));
	XRCCTRL(*this, "ZoomTMC1800", wxSpinCtrl)->SetValue(configPointer->Read(_T("/TMC1800/TMC1800Zoom"), 2l));
	conf[TMC1800].romDir_[MAINROM] = configPointer->Read(_T("/TMC1800/TMC1800RomDir"), dataDir_ + "TMC1800"  + pathSeparator_);
	conf[TMC1800].ramDir_ = configPointer->Read(_T("/TMC1800/TMC1800RamDir"), dataDir_ + "TMC1800"  + pathSeparator_);
	conf[TMC1800].chip8SWDir_ = configPointer->Read(_T("/TMC1800/Chip8SWDir"), dataDir_ + "Chip-8"  + pathSeparator_);

	XRCCTRL(*this, "WavFileTMC1800", wxTextCtrl)->SetValue(configPointer->Read(_T("/TMC1800/TMC1800WavFile"), ""));
	conf[TMC1800].wavFileDir_ = configPointer->Read(_T("/TMC1800/WavFileDir"), dataDir_ + "TMC1800" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileTMC1800", wxTextCtrl)->SetValue(configPointer->Read(_T("/TMC1800/TMC1800ScreenDumpFile"), "screendump.bmp"));
	conf[TMC1800].screenDumpFileDir_ = configPointer->Read(_T("/TMC1800/TMC1800ScreenDumpFileDir"), dataDir_ + "TMC1800" + pathSeparator_);

	configPointer->Read(_T("/TMC1800/TMC1800Turbo"), &turbo, true);
	XRCCTRL(*this, "TurboTMC1800", wxCheckBox)->SetValue(turbo);
	turboGui("TMC1800");
	conf[TMC1800].turboClock_ = configPointer->Read(_T("/TMC1800/TMC1800TurboClock"), "15");
	XRCCTRL(*this, "TurboClockTMC1800", wxTextCtrl)->SetValue(conf[TMC1800].turboClock_);
	configPointer->Read(_T("/TMC1800/TMC1800AutoCasLoad"), &conf[TMC1800].autoCassetteLoad_, true);
	XRCCTRL(*this, "AutoCasLoadTMC1800", wxCheckBox)->SetValue(conf[TMC1800].autoCassetteLoad_);
	configPointer->Read(_T("/TMC1800/RealCasLoad"), &conf[TMC1800].realCassetteLoad_, false);
	setRealCas(TMC1800);

	conf[TMC1800].volume_ = configPointer->Read(_T("/TMC1800/TMC1800Volume"), 25l);
	XRCCTRL(*this, "VolumeTMC1800", wxSlider)->SetValue(conf[TMC1800].volume_);
	XRCCTRL(*this, "RamTMC1800", wxChoice)->SetSelection(configPointer->Read(_T("/TMC1800/TMC1800Ram"), 02));

	conf[TMC1800].mainX_ = configPointer->Read(_T("/TMC1800/TMC1800X"), mainWindowX_+windowInfo.mainwX);
	conf[TMC1800].mainY_ = configPointer->Read(_T("/TMC1800/TMC1800Y"), mainWindowY_);

	conf[TMC1800].clock_ = configPointer->Read(_T("/TMC1800/Clock"), "1.75");
	XRCCTRL(*this, _T("ClockTMC1800"), wxTextCtrl)->ChangeValue(conf[TMC1800].clock_);

	configPointer->Read(_T("/TMC1800/Keyboard"), &keyboard, false);
	XRCCTRL(*this, "KeyboardTMC1800", wxCheckBox)->SetValue(keyboard);
	XRCCTRL(*this, "KeyMapTMC1800", wxButton)->Enable(!keyboard);
}

void GuiTMC2000::writeTMC1800Config()
{
	configPointer->Write(_T("/TMC1800/TMC1800MainRom"), XRCCTRL(*this, "MainRomTMC1800", wxComboBox)->GetValue());
	configPointer->Write(_T("/TMC1800/TMC1800RamSW"), XRCCTRL(*this, "RamSWTMC1800", wxComboBox)->GetValue());
	configPointer->Write(_T("/TMC1800/TMC1800Chip8SW"), XRCCTRL(*this, "Chip8SWTMC1800", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/TMC1800/TMC1800Zoom"), XRCCTRL(*this, "ZoomTMC1800", wxSpinCtrl)->GetValue());
	configPointer->Write(_T("/TMC1800/TMC1800RomDir"), conf[TMC1800].romDir_[MAINROM]);
	configPointer->Write(_T("/TMC1800/TMC1800RamDir"), conf[TMC1800].ramDir_);
	configPointer->Write(_T("/TMC1800/Chip8SWDir"), conf[TMC1800].chip8SWDir_);

	if (conf[TMC1800].mainX_ > 0)
		configPointer->Write(_T("/TMC1800/TMC1800X"), conf[TMC1800].mainX_);
	if (conf[TMC1800].mainY_ > 0)
		configPointer->Write(_T("/TMC1800/TMC1800Y"), conf[TMC1800].mainY_);

	configPointer->Write(_T("/TMC1800/TMC1800WavFile"), XRCCTRL(*this, "WavFileTMC1800", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/TMC1800/WavFileDir"), conf[TMC1800].wavFileDir_);
	configPointer->Write(_T("/TMC1800/TMC1800ScreenDumpFile"), XRCCTRL(*this, "ScreenDumpFileTMC1800", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/TMC1800/TMC1800ScreenDumpFileDir"), conf[TMC1800].screenDumpFileDir_);
	configPointer->Write(_T("/TMC1800/TMC1800Turbo"), XRCCTRL(*this, "TurboTMC1800", wxCheckBox)->GetValue());
	configPointer->Write(_T("/TMC1800/TMC1800TurboClock"), conf[TMC1800].turboClock_);
	configPointer->Write(_T("/TMC1800/TMC1800AutoCasLoad"), XRCCTRL(*this, "AutoCasLoadTMC1800", wxCheckBox)->GetValue());
	configPointer->Write(_T("/TMC1800/RealCasLoad"), conf[TMC1800].realCassetteLoad_);
	configPointer->Write(_T("/TMC1800/TMC1800Volume"), XRCCTRL(*this, "VolumeTMC1800", wxSlider)->GetValue());
	configPointer->Write(_T("/TMC1800/TMC1800Ram"), XRCCTRL(*this, "RamTMC1800", wxChoice)->GetSelection());

	configPointer->Write(_T("/TMC1800/Clock"), conf[TMC1800].clock_);
	configPointer->Write(_T("/TMC1800/Keyboard"), XRCCTRL(*this, "KeyboardTMC1800", wxCheckBox)->GetValue());
}
