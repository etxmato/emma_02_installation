/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guicidelsa.h"

int dracoCoin[] = 
{ 
	0x40, 0xe0, 0xc0, 0xa0, 0x80, 0x60, 0x20, 0
};

BEGIN_EVENT_TABLE(GuiCidelsa, GuiTelmac)

	EVT_BUTTON(XRCID("RomButtonCidelsa"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonCidelsa"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Cidelsa"), GuiMain::onScreenDump)
	EVT_SPINCTRL(XRCID("ZoomCidelsa"), GuiMain::onZoom)
	EVT_BUTTON(XRCID("FullScreenF3Cidelsa"), GuiMain::onFullScreen)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeCidelsa"), GuiMain::onVolume) 
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeCidelsa"), GuiMain::onVolume) 
	EVT_TEXT(XRCID(_T("ClockCidelsa")), GuiMain::onClock)
	EVT_BUTTON(XRCID(_T("ColoursCidelsa")), Main::onColoursDef)

	EVT_CHOICE(XRCID("CidelsaDifficulty"), GuiCidelsa::onCidelsaDifficulty)
	EVT_CHOICE(XRCID("CidelsaBonus"), GuiCidelsa::onCidelsaBonus)
	EVT_CHOICE(XRCID("CidelsaLives"), GuiCidelsa::onCidelsaLives)
	EVT_CHOICE(XRCID("CidelsaCoin"), GuiCidelsa::onCidelsaCoin)
	EVT_CHOICE(XRCID("CidelsaDifficultyDraco"), GuiCidelsa::onCidelsaDifficultyDraco)
	EVT_CHOICE(XRCID("CidelsaBonusDraco"), GuiCidelsa::onCidelsaBonusDraco)
	EVT_CHOICE(XRCID("CidelsaLivesDraco"), GuiCidelsa::onCidelsaLivesDraco)
	EVT_CHOICE(XRCID("CidelsaCoinDraco"), GuiCidelsa::onCidelsaCoinDraco)

END_EVENT_TABLE()

GuiCidelsa::GuiCidelsa(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiTelmac(title, pos, size)
{
}

void GuiCidelsa::readCidelsaConfig()
{
	selectedComputer_ = CIDELSA;

	XRCCTRL(*this, "MainRomCidelsa", wxComboBox)->SetValue(configPointer->Read(_T("/Cidelsa/CidelsaMainRom"), ""));
	XRCCTRL(*this, "ZoomCidelsa", wxSpinCtrl)->SetValue(configPointer->Read(_T("/Cidelsa/CidelsaZoom"), 2l));
	conf[CIDELSA].volume_ = configPointer->Read(_T("/Cidelsa/CidelsaVolume"), 25l);
	XRCCTRL(*this, "VolumeCidelsa", wxSlider)->SetValue(conf[CIDELSA].volume_);
	conf[CIDELSA].romDir_[MAINROM] = configPointer->Read(_T("/Cidelsa/CidelsaDir"), dataDir_ + "Cidelsa" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileCidelsa", wxTextCtrl)->SetValue(configPointer->Read(_T("/Cidelsa/CidelsaScreenDumpFile"), "screendump.bmp"));
	conf[CIDELSA].screenDumpFileDir_ = configPointer->Read(_T("/Cidelsa/CidelsaScreenDumpFileDir"), dataDir_ + "Cidelsa" + pathSeparator_); 

	in2Value_ = configPointer->Read(_T("/Cidelsa/CidelsaDifficulty"), 0l) ^ 0x3;
	XRCCTRL(*this, "CidelsaDifficulty", wxChoice)->SetSelection(configPointer->Read(_T("/Cidelsa/CidelsaDifficulty"), 0l));
	in2Value_ = (in2Value_ & 0xf3) | ((configPointer->Read(_T("/Cidelsa/CidelsaBonus"), 0l) << 2) ^ 0xc);
	XRCCTRL(*this, "CidelsaBonus", wxChoice)->SetSelection(configPointer->Read(_T("/Cidelsa/CidelsaBonus"), 0l));
	in2Value_ = (in2Value_ & 0xcf) | ((configPointer->Read(_T("/Cidelsa/CidelsaLives"), 3l) << 4) ^ 0x30);
	XRCCTRL(*this, "CidelsaLives", wxChoice)->SetSelection(configPointer->Read(_T("/Cidelsa/CidelsaLives"), 3l));
	in2Value_ = (in2Value_ & 0x3f) | ((configPointer->Read(_T("/Cidelsa/CidelsaCoin"), 3l) << 6) ^ 0xc0);
	XRCCTRL(*this, "CidelsaCoin", wxChoice)->SetSelection(configPointer->Read(_T("/Cidelsa/CidelsaCoin"), 3l));

	in2ValueDraco_ = (configPointer->Read(_T("/Cidelsa/CidelsaDifficultyDraco"), 0l) + 1) ^ 0x3;
	XRCCTRL(*this, "CidelsaDifficultyDraco", wxChoice)->SetSelection(configPointer->Read(_T("/Cidelsa/CidelsaDifficultyDraco"), 0l));
	in2ValueDraco_ = (in2ValueDraco_ & 0xf3) | ((configPointer->Read(_T("/Cidelsa/CidelsaBonusDraco"), 0l) << 2) ^ 0xc);
	XRCCTRL(*this, "CidelsaBonusDraco", wxChoice)->SetSelection(configPointer->Read(_T("/Cidelsa/CidelsaBonusDraco"), 0l));
	in2ValueDraco_ = (in2ValueDraco_ & 0x0f) | ((configPointer->Read(_T("/Cidelsa/CidelsaLivesDraco"), 1l) << 4) ^ 0x10);
	XRCCTRL(*this, "CidelsaLivesDraco", wxChoice)->SetSelection(configPointer->Read(_T("/Cidelsa/CidelsaLivesDraco"), 1l));
	in2ValueDraco_ = (in2ValueDraco_ & 0x1f) | dracoCoin[configPointer->Read(_T("/Cidelsa/CidelsaCoinDraco"), 7l)];
	XRCCTRL(*this, "CidelsaCoinDraco", wxChoice)->SetSelection(configPointer->Read(_T("/Cidelsa/CidelsaCoinDraco"), 7l));

	conf[CIDELSA].mainX_ = configPointer->Read(_T("/Cidelsa/CidelsaX"), mainWindowX_+windowInfo.mainwX); 
	conf[CIDELSA].mainY_ = configPointer->Read(_T("/Cidelsa/CidelsaY"), mainWindowY_); 

	conf[CIDELSA].clock_ = configPointer->Read(_T("/Cidelsa/Clock"), "3.579");
	XRCCTRL(*this, _T("ClockCidelsa"), wxTextCtrl)->ChangeValue(conf[CIDELSA].clock_);
	conf[CIDELSA].realCassetteLoad_ = false;
}

void GuiCidelsa::writeCidelsaConfig()
{
	configPointer->Write(_T("/Cidelsa/CidelsaMainRom"), XRCCTRL(*this, "MainRomCidelsa", wxComboBox)->GetValue());
	configPointer->Write(_T("/Cidelsa/CidelsaZoom"), XRCCTRL(*this, "ZoomCidelsa", wxSpinCtrl)->GetValue());
	configPointer->Write(_T("/Cidelsa/CidelsaVolume"), XRCCTRL(*this, "VolumeCidelsa", wxSlider)->GetValue());
	configPointer->Write(_T("/Cidelsa/CidelsaDir"), conf[CIDELSA].romDir_[MAINROM]);
	configPointer->Write(_T("/Cidelsa/CidelsaScreenDumpFile"), XRCCTRL(*this, "ScreenDumpFileCidelsa", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Cidelsa/CidelsaScreenDumpFileDir"), conf[CIDELSA].screenDumpFileDir_);
	configPointer->Write(_T("/Cidelsa/CidelsaDifficulty"), XRCCTRL(*this, "CidelsaDifficulty", wxChoice)->GetSelection());
	configPointer->Write(_T("/Cidelsa/CidelsaBonus"), XRCCTRL(*this, "CidelsaBonus", wxChoice)->GetSelection());
	configPointer->Write(_T("/Cidelsa/CidelsaLives"), XRCCTRL(*this, "CidelsaLives", wxChoice)->GetSelection());
	configPointer->Write(_T("/Cidelsa/CidelsaCoin"), XRCCTRL(*this, "CidelsaCoin", wxChoice)->GetSelection());
	configPointer->Write(_T("/Cidelsa/CidelsaDifficultyDraco"), XRCCTRL(*this, "CidelsaDifficultyDraco", wxChoice)->GetSelection());
	configPointer->Write(_T("/Cidelsa/CidelsaBonusDraco"), XRCCTRL(*this, "CidelsaBonusDraco", wxChoice)->GetSelection());
	configPointer->Write(_T("/Cidelsa/CidelsaLivesDraco"), XRCCTRL(*this, "CidelsaLivesDraco", wxChoice)->GetSelection());
	configPointer->Write(_T("/Cidelsa/CidelsaCoinDraco"), XRCCTRL(*this, "CidelsaCoinDraco", wxChoice)->GetSelection());

	if (conf[CIDELSA].mainX_ > 0)
		configPointer->Write(_T("/Cidelsa/CidelsaX"), conf[CIDELSA].mainX_);
	if (conf[CIDELSA].mainY_ > 0)
		configPointer->Write(_T("/Cidelsa/CidelsaY"), conf[CIDELSA].mainY_);

	configPointer->Write(_T("/Cidelsa/Clock"), conf[CIDELSA].clock_);
}

void GuiCidelsa::onCidelsaDifficulty(wxCommandEvent&event)
{
	in2Value_ = (in2Value_ & 0xfc) | (event.GetSelection() ^ 0x3); 
	if (runningComputer_ == CIDELSA)
		p_Cidelsa->setIn2Value(in2Value_);
}

void GuiCidelsa::onCidelsaBonus(wxCommandEvent&event)
{
	in2Value_ = (in2Value_ & 0xf3) | ((event.GetSelection() << 2) ^ 0xc); 
	if (runningComputer_ == CIDELSA)
		p_Cidelsa->setIn2Value(in2Value_);
}

void GuiCidelsa::onCidelsaLives(wxCommandEvent&event)
{
	in2Value_ = (in2Value_ & 0xcf) | ((event.GetSelection() << 4) ^ 0x30); 
	if (runningComputer_ == CIDELSA)
		p_Cidelsa->setIn2Value(in2Value_);
}

void GuiCidelsa::onCidelsaCoin(wxCommandEvent&event)
{
	in2Value_ = (in2Value_ & 0x3f) | ((event.GetSelection() << 6) ^ 0xc0); 
	if (runningComputer_ == CIDELSA)
		p_Cidelsa->setIn2Value(in2Value_);
}

void GuiCidelsa::onCidelsaDifficultyDraco(wxCommandEvent&event)
{
	in2ValueDraco_ = (in2ValueDraco_ & 0xfc) | ((event.GetSelection() + 1) ^ 0x3); 
	if (runningComputer_ == CIDELSA)
		p_Cidelsa->setIn2ValueDraco(in2ValueDraco_);
}

void GuiCidelsa::onCidelsaBonusDraco(wxCommandEvent&event)
{
	in2ValueDraco_ = (in2ValueDraco_ & 0xf3) | ((event.GetSelection() << 2) ^ 0xc); 
	if (runningComputer_ == CIDELSA)
		p_Cidelsa->setIn2ValueDraco(in2ValueDraco_);
}

void GuiCidelsa::onCidelsaLivesDraco(wxCommandEvent&event)
{
	in2ValueDraco_ = (in2ValueDraco_ & 0xef) | ((event.GetSelection() << 4) ^ 0x10); 
	if (runningComputer_ == CIDELSA)
		p_Cidelsa->setIn2ValueDraco(in2ValueDraco_);
}

void GuiCidelsa::onCidelsaCoinDraco(wxCommandEvent&event)
{
	in2ValueDraco_ = (in2ValueDraco_ & 0x1f) | dracoCoin[event.GetSelection()]; 
	if (runningComputer_ == CIDELSA)
		p_Cidelsa->setIn2ValueDraco(in2ValueDraco_);
}

