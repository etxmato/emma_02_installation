/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "main.h"
#include "ports.h"

#include "wx/xrc/xmlres.h"             
#include "wx/spinctrl.h"
#include "elfconfiguration.h"

BEGIN_EVENT_TABLE(DevicePortsDialog, wxDialog)
    EVT_BUTTON(XRCID(_T("DevicePorts_Save")), DevicePortsDialog::onSaveButton)
	EVT_CHOICE(XRCID("MC6847-B7"), DevicePortsDialog::onMC6847B7)
	EVT_CHOICE(XRCID("MC6847-B6"), DevicePortsDialog::onMC6847B6)
	EVT_CHOICE(XRCID("MC6847-B5"), DevicePortsDialog::onMC6847B5)
	EVT_CHOICE(XRCID("MC6847-B4"), DevicePortsDialog::onMC6847B4)
	EVT_CHOICE(XRCID("MC6847-B3"), DevicePortsDialog::onMC6847B3)
	EVT_CHOICE(XRCID("MC6847-B2"), DevicePortsDialog::onMC6847B2)
	EVT_CHOICE(XRCID("MC6847-B1"), DevicePortsDialog::onMC6847B1)
	EVT_CHOICE(XRCID("MC6847-B0"), DevicePortsDialog::onMC6847B0)
	EVT_CHOICE(XRCID("MC6847-DD7"), DevicePortsDialog::onMC6847DD7)
	EVT_CHOICE(XRCID("MC6847-DD6"), DevicePortsDialog::onMC6847DD6)
END_EVENT_TABLE()

DevicePortsDialog::DevicePortsDialog(wxWindow* parent)
{
	wxXmlResource::Get()->LoadDialog(this, parent, _T("DevicePorts"));
	ElfConfiguration elfConfiguration = p_Main->getElfConfiguration();
	elfTypeStr_ = p_Main->getSelectedComputerStr();
	this->SetTitle(_T("Device Ports Definition "+p_Main->getSelectedComputerText()));

	XRCCTRL(*this, _T("PixieInput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/PixieInput"), 1l));
	XRCCTRL(*this, _T("PixieOutput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/PixieOutput"), 1l));
	XRCCTRL(*this, _T("PixieEF"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/PixieEF"), 1l));
	if (!elfConfiguration.usePixie)
	{
		XRCCTRL(*this, _T("PixieInput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("PixieOutput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("PixieEF"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("PixieInputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("PixieOutputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("PixieEfText"), wxStaticText)->Enable(false);
	}	

	XRCCTRL(*this, _T("PortExtenderSelectOutput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/PortExtenderSelectOutput"), 5l));
	XRCCTRL(*this, _T("PortExtenderWriteOutput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/PortExtenderWriteOutput"), 6l));
	XRCCTRL(*this, _T("PortExtenderInput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/PortExtenderInput"), 6l));
	if (!elfConfiguration.usePortExtender)
	{
		XRCCTRL(*this, _T("PortExtenderSelectOutput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("PortExtenderWriteOutput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("PortExtenderInput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("PortExtenderSelectOutputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("PortExtenderWriteOutputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("PortExtenderInputText"), wxStaticText)->Enable(false);
	}	

	XRCCTRL(*this, _T("IdeSelectOutput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/IdeSelectOutput"), 2l));
	XRCCTRL(*this, _T("IdeWriteOutput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/IdeWriteOutput"), 3l));
	XRCCTRL(*this, _T("IdeStatus"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/IdeStatus"), 2l));
	XRCCTRL(*this, _T("IdeInput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/IdeInput"), 3l));
	XRCCTRL(*this, _T("IdeTracks"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/IdeTracks"), 512l));
	XRCCTRL(*this, _T("IdeHeads"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/IdeHeads"), 4l));
	XRCCTRL(*this, _T("IdeSectors"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/IdeSectors"), 26l));
	if (!elfConfiguration.ideEnabled)
	{
		XRCCTRL(*this, _T("IdeSelectOutput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("IdeWriteOutput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("IdeInput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("IdeStatus"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("IdeTracks"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("IdeHeads"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("IdeSectors"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("IdeSelectOutputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("IdeWriteOutputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("IdeInputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("IdeStatusText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("text_tr"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("text_hd"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("text_sc"), wxStaticText)->Enable(false);
	}	
	if (elfTypeStr_ != "Elf2K")
	{
		XRCCTRL(*this, _T("IdeStatus"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("IdeStatusText"), wxStaticText)->Enable(false);
	}

	XRCCTRL(*this, _T("FdcSelectOutput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/FdcSelectOutput"), 2l));
	XRCCTRL(*this, _T("FdcWriteOutput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/FdcWriteOutput"), 3l));
	XRCCTRL(*this, _T("FdcInput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/FdcInput"), 3l));
	XRCCTRL(*this, _T("FdcEf"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/FdcEf"), 2l));
	if (!elfConfiguration.fdcEnabled)
	{
		XRCCTRL(*this, _T("FdcSelectOutput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("FdcWriteOutput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("FdcInput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("FdcEf"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("FdcSelectOutputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("FdcWriteOutputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("FdcInputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("FdcEfText"), wxStaticText)->Enable(false);
	}	

	XRCCTRL(*this, _T("KeyboardInput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/KeyboardInput"), 7l));
	XRCCTRL(*this, _T("KeyboardEf"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/KeyboardEf"), 3l));
	if (!elfConfiguration.useKeyboard && !elfConfiguration.usePs2gpio)
	{
		XRCCTRL(*this, _T("KeyboardInput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("KeyboardEf"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("KeyboardInputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("KeyboardEfText"), wxStaticText)->Enable(false);
	}	

	XRCCTRL(*this, _T("Ps2KeyboardInput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/Ps2KeyboardInput"), 7l));
	XRCCTRL(*this, _T("Ps2KeyboardOutput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/Ps2KeyboardOutput"), 7l));
	XRCCTRL(*this, _T("Ps2KeyboardEf"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/Ps2KeyboardEf"), 3l));
	if (!elfConfiguration.UsePS2)
	{
		XRCCTRL(*this, _T("Ps2KeyboardInput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("Ps2KeyboardOutput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("Ps2KeyboardEf"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("Ps2KeyboardInputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("Ps2KeyboardOutputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("Ps2KeyboardEfText"), wxStaticText)->Enable(false);
	}	

	XRCCTRL(*this, _T("PrinterOutput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/PrinterOutput"), 7l));
	if (!elfConfiguration.usePrinter)
	{
		XRCCTRL(*this, _T("PrinterOutput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("PrinterOutputText"), wxStaticText)->Enable(false);
	}	

	XRCCTRL(*this, _T("Vt100Output"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/Vt100Output"), 7l));
	if (elfTypeStr_ != "Elf2K")
	{
		XRCCTRL(*this, _T("Vt100Ef"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/Vt100Ef"), 2l));
	}
	else
	{
		XRCCTRL(*this, _T("Vt100Ef"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/Vt100Ef"), 3l));
		XRCCTRL(*this, _T("Vt100Output"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("Vt100OutputText"), wxStaticText)->Enable(false);
	}
	XRCCTRL(*this, _T("Vt100ReverseEf"), wxCheckBox)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/Vt100ReverseEf"), 1l) != 1);
	XRCCTRL(*this, _T("Vt100ReverseQ"), wxCheckBox)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/Vt100ReverseQ"), 0l) != 0);
	if ((elfConfiguration.vtType == VTNONE) || elfConfiguration.useUart)
	{
		XRCCTRL(*this, _T("Vt100Q"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("Vt100Output"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("Vt100Ef"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("Vt100ReverseQText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("Vt100OutputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("Vt100EfText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("Vt100ReverseEf"), wxCheckBox)->Enable(false);
		XRCCTRL(*this, _T("Vt100ReverseQ"), wxCheckBox)->Enable(false);
	}	

	XRCCTRL(*this, _T("UartOut"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/UartOut"), 2l));
	XRCCTRL(*this, _T("UartIn"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/UartIn"), 2l));
	XRCCTRL(*this, _T("UartControl"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/UartControl"), 3l));
	XRCCTRL(*this, _T("UartStatus"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/UartStatus"), 3l));
	if (!elfConfiguration.useUart || (elfTypeStr_ == "Elf2K"))
	{
		XRCCTRL(*this, _T("UartOutText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("UartOut"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("UartInText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("UartIn"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("UartControlText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("UartControl"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("UartStatusText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("UartStatus"), wxSpinCtrl)->Enable(false);
	}	

	XRCCTRL(*this, _T("TmsModeHighOutput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/TmsModeHighOutput"), 5l));
	XRCCTRL(*this, _T("TmsModeLowOutput"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/TmsModeLowOutput"), 6l));
	if (!elfConfiguration.useTMS9918)
	{
		XRCCTRL(*this, _T("TmsModeHighOutput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("TmsModeLowOutput"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("TmsModeHighOutputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("TmsModeLowOutputText"), wxStaticText)->Enable(false);
	}	


	XRCCTRL(*this, _T("I8275WriteCommand"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/I8275WriteCommand"), 5l));
	XRCCTRL(*this, _T("I8275ReadStatus"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/I8275ReadStatus"), 5l));
	XRCCTRL(*this, _T("I8275WriteParameter"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/I8275WriteParameter"), 1l));
	XRCCTRL(*this, _T("I8275ReadParameter"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/I8275ReadParameter"), 1l));
	XRCCTRL(*this, _T("I8275VerticalRetrace"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/I8275VerticalRetrace"), 1l));
	if (!elfConfiguration.use8275)
	{
		XRCCTRL(*this, _T("I8275WriteCommand"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("I8275ReadStatus"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("I8275WriteParameter"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("I8275ReadParameter"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("I8275VerticalRetrace"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("I8275WriteCommandText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("I8275ReadStatusText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("I8275WriteParameterText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("I8275ReadParameterText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("I8275VerticalRetraceText"), wxStaticText)->Enable(false);
	}	

	XRCCTRL(*this, _T("Led_Module_Output"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/Led_Module_Output"), 4l));
	if (!elfConfiguration.useLedModule)
	{
		XRCCTRL(*this, _T("Led_Module_Output"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("Led_Module_Output_Text"), wxStaticText)->Enable(false);
	}	

	XRCCTRL(*this, _T("MC6847Output"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/MC6847Output"), 5l));
	XRCCTRL(*this, _T("MC6847-B7"), wxChoice)->SetSelection(p_Main->getConfigItem(_T(elfTypeStr_+"/MC6847-B7"), 0l));
	XRCCTRL(*this, _T("MC6847-B6"), wxChoice)->SetSelection(p_Main->getConfigItem(_T(elfTypeStr_+"/MC6847-B6"), 0l));
	XRCCTRL(*this, _T("MC6847-B5"), wxChoice)->SetSelection(p_Main->getConfigItem(_T(elfTypeStr_+"/MC6847-B5"), 0l));
	XRCCTRL(*this, _T("MC6847-B4"), wxChoice)->SetSelection(p_Main->getConfigItem(_T(elfTypeStr_+"/MC6847-B4"), 0l));
	XRCCTRL(*this, _T("MC6847-B3"), wxChoice)->SetSelection(p_Main->getConfigItem(_T(elfTypeStr_+"/MC6847-B3"), 3l));
	XRCCTRL(*this, _T("MC6847-B2"), wxChoice)->SetSelection(p_Main->getConfigItem(_T(elfTypeStr_+"/MC6847-B2"), 4l));
	XRCCTRL(*this, _T("MC6847-B1"), wxChoice)->SetSelection(p_Main->getConfigItem(_T(elfTypeStr_+"/MC6847-B1"), 6l));
	XRCCTRL(*this, _T("MC6847-B0"), wxChoice)->SetSelection(p_Main->getConfigItem(_T(elfTypeStr_+"/MC6847-B0"), 5l));
	XRCCTRL(*this, _T("MC6847-DD7"), wxChoice)->SetSelection(p_Main->getConfigItem(_T(elfTypeStr_+"/MC6847-DD7"), 1l));
	XRCCTRL(*this, _T("MC6847-DD6"), wxChoice)->SetSelection(p_Main->getConfigItem(_T(elfTypeStr_+"/MC6847-DD6"), 0l));

	int start = p_Main->getConfigItem(_T(elfTypeStr_+"/mc6847StartRam"), 0xe000l);
	int sel = (start - 0x8000)/0x1000;
	XRCCTRL(*this, _T("MC6847StartRam"), wxChoice)->SetSelection(sel);

	int end = p_Main->getConfigItem(_T(elfTypeStr_+"/mc6847EndRam"), 0xe3ffl);
	int size = end - start;
	sel = 0;
	if (size <= 1024)
		sel = 0;
	else if (size <= 1536)
		sel = 1;
	else if (size <= 2048)
		sel = 2;
	else if (size <= 3072)
		sel = 3;
	else if (size <= 6144)
		sel = 4;
	XRCCTRL(*this, _T("MC6847SizeRam"), wxChoice)->SetSelection(sel);

	if (!elfConfiguration.use6847)
	{
		XRCCTRL(*this, _T("MC6847Output"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("MC6847OutputText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B7Text"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B6Text"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B5Text"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B4Text"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B3Text"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B2Text"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B1Text"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B0Text"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6847-DD7Text"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6847-DD6Text"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B7"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B6"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B5"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B4"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B3"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B2"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B1"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6847-B0"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6847-DD7"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6847-DD6"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6847StartRam"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6847StartRamText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6847SizeRam"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6847SizeRamText"), wxStaticText)->Enable(false);
	}	

	start = p_Main->getConfigItem(_T(elfTypeStr_+"/mc6845StartRam"), 0xe000l);
	sel = start/0x1000;
	XRCCTRL(*this, _T("MC6845StartRam"), wxChoice)->SetSelection(sel);

	end = p_Main->getConfigItem(_T(elfTypeStr_+"/mc6845EndRam"), 0xe7ffl);
	size = end - start;
	sel = 0;
	if (size <= 1024)
		sel = 0;
	else if (size <= 2048)
		sel = 1;
	else if (size <= 4096)
		sel = 2;
	else if (size <= 8192)
		sel = 3;
	else if (size <= 16384)
		sel = 4;
	XRCCTRL(*this, _T("MC6845SizeRam"), wxChoice)->SetSelection(sel);

	int addr = p_Main->getConfigItem(_T(elfTypeStr_+"/mc6845Address"), 0xe800l);
	wxString addrStr;
	addrStr.Printf("%04X", addr);
	XRCCTRL(*this, _T("MC6845Address"), wxTextCtrl)->SetValue(addrStr);
	int data = p_Main->getConfigItem(_T(elfTypeStr_+"/mc6845Data"), 0xe801l);
	wxString dataStr;
	dataStr.Printf("%04X", data);
	XRCCTRL(*this, _T("MC6845Data"), wxTextCtrl)->SetValue(dataStr);
	XRCCTRL(*this, _T("MC6845EF"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/mc6845Ef"), 2l));

	if (!elfConfiguration.use6845)
	{
		XRCCTRL(*this, _T("MC6845StartRam"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6845StartRamText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6845SizeRam"), wxChoice)->Enable(false);
		XRCCTRL(*this, _T("MC6845SizeRamText"), wxStaticText)->Enable(false);

		XRCCTRL(*this, _T("MC6845AddressText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6845Address"), wxTextCtrl)->Enable(false);
		XRCCTRL(*this, _T("MC6845DataText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6845Data"), wxTextCtrl)->Enable(false);

		XRCCTRL(*this, _T("MC6845EfText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("MC6845EF"), wxSpinCtrl)->Enable(false);
	}	

	if (elfConfiguration.useS100)
	{
		XRCCTRL(*this, _T("MC6845StartRam"), wxChoice)->Enable(true);
		XRCCTRL(*this, _T("MC6845StartRamText"), wxStaticText)->Enable(true);
		XRCCTRL(*this, _T("MC6845SizeRam"), wxChoice)->Enable(true);
		XRCCTRL(*this, _T("MC6845SizeRamText"), wxStaticText)->Enable(true);
	}	

	if (elfConfiguration.useHexKeyboardEf3)
	{
		XRCCTRL(*this, _T("KeyboardEf"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/HexEf"), 3l));
		XRCCTRL(*this, _T("KeyboardInput"), wxSpinCtrl)->SetValue(4);
		XRCCTRL(*this, _T("KeyboardInputText"), wxStaticText)->Enable(true);
		XRCCTRL(*this, _T("KeyboardEf"), wxSpinCtrl)->Enable(true);
		XRCCTRL(*this, _T("KeyboardEfText"), wxStaticText)->Enable(true);
	}

	XRCCTRL(*this, _T("TapeEf"), wxSpinCtrl)->SetValue(p_Main->getConfigItem(_T(elfTypeStr_+"/TapeEf"), 2l));
	if (!elfConfiguration.useTape)
	{
		XRCCTRL(*this, _T("TapeEf"), wxSpinCtrl)->Enable(false);
		XRCCTRL(*this, _T("TapeEfText"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("TapeQ"), wxStaticText)->Enable(false);
		XRCCTRL(*this, _T("TapeQText"), wxStaticText)->Enable(false);
	}
}

void DevicePortsDialog::onSaveButton( wxCommandEvent& WXUNUSED(event) )
{
	int addr = p_Main->get16BitValue("MC6845Address");
	if (addr == -1)  return;
	int data = p_Main->get16BitValue("MC6845Data");
	if (data == -1)  return;

	p_Main->setConfigItem(_T(elfTypeStr_+"/mc6845Address"), addr);
	p_Main->setConfigItem(_T(elfTypeStr_+"/mc6845Data"), data);

	p_Main->setConfigItem(_T(elfTypeStr_+"/PixieInput"), XRCCTRL(*this, _T("PixieInput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/PixieOutput"), XRCCTRL(*this, _T("PixieOutput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/PixieEF"), XRCCTRL(*this, _T("PixieEF"), wxSpinCtrl)->GetValue());

	p_Main->setConfigItem(_T(elfTypeStr_+"/PortExtenderSelectOutput"), XRCCTRL(*this, _T("PortExtenderSelectOutput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/PortExtenderWriteOutput"), XRCCTRL(*this, _T("PortExtenderWriteOutput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/PortExtenderInput"), XRCCTRL(*this, _T("PortExtenderInput"), wxSpinCtrl)->GetValue());

	p_Main->setConfigItem(_T(elfTypeStr_+"/IdeSelectOutput"), XRCCTRL(*this, _T("IdeSelectOutput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/IdeWriteOutput"), XRCCTRL(*this, _T("IdeWriteOutput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/IdeInput"), XRCCTRL(*this, _T("IdeInput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/IdeTracks"), XRCCTRL(*this, "IdeTracks", wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/IdeHeads"), XRCCTRL(*this, "IdeHeads", wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/IdeSectors"), XRCCTRL(*this, "IdeSectors", wxSpinCtrl)->GetValue());

	p_Main->setConfigItem(_T(elfTypeStr_+"/FdcSelectOutput"), XRCCTRL(*this, _T("FdcSelectOutput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/FdcWriteOutput"), XRCCTRL(*this, _T("FdcWriteOutput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/FdcInput"), XRCCTRL(*this, _T("FdcInput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/FdcEf"), XRCCTRL(*this, _T("FdcEf"), wxSpinCtrl)->GetValue());

	p_Main->setConfigItem(_T(elfTypeStr_+"/KeyboardInput"), XRCCTRL(*this, _T("KeyboardInput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/KeyboardEf"), XRCCTRL(*this, _T("KeyboardEf"), wxSpinCtrl)->GetValue());

	p_Main->setConfigItem(_T(elfTypeStr_+"/Ps2KeyboardInput"), XRCCTRL(*this, _T("Ps2KeyboardInput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/Ps2KeyboardOutput"), XRCCTRL(*this, _T("Ps2KeyboardOutput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/Ps2KeyboardEf"), XRCCTRL(*this, _T("Ps2KeyboardEf"), wxSpinCtrl)->GetValue());

	p_Main->setConfigItem(_T(elfTypeStr_+"/I8275WriteCommand"), XRCCTRL(*this, _T("I8275WriteCommand"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/I8275ReadStatus"), XRCCTRL(*this, _T("I8275ReadStatus"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/I8275WriteParameter"), XRCCTRL(*this, _T("I8275WriteParameter"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/I8275ReadParameter"), XRCCTRL(*this, _T("I8275ReadParameter"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/I8275VerticalRetrace"), XRCCTRL(*this, _T("I8275VerticalRetrace"), wxSpinCtrl)->GetValue());

	p_Main->setConfigItem(_T(elfTypeStr_+"/PrinterOutput"), XRCCTRL(*this, _T("PrinterOutput"), wxSpinCtrl)->GetValue());

	p_Main->setConfigItem(_T(elfTypeStr_+"/Vt100Output"), XRCCTRL(*this, _T("Vt100Output"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/Vt100Ef"), XRCCTRL(*this, _T("Vt100Ef"), wxSpinCtrl)->GetValue());

	if (XRCCTRL(*this, _T("Vt100ReverseEf"), wxCheckBox)->IsChecked())
		p_Main->setConfigItem(_T(elfTypeStr_+"/Vt100ReverseEf"), 0); 
	else
		p_Main->setConfigItem(_T(elfTypeStr_+"/Vt100ReverseEf"), 1); 

	if (XRCCTRL(*this, _T("Vt100ReverseQ"), wxCheckBox)->IsChecked())
		p_Main->setConfigItem(_T(elfTypeStr_+"/Vt100ReverseQ"), 1); 
	else
		p_Main->setConfigItem(_T(elfTypeStr_+"/Vt100ReverseQ"), 0); 

	p_Main->setConfigItem(_T(elfTypeStr_+"/UartOut"), XRCCTRL(*this, _T("UartOut"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/UartIn"), XRCCTRL(*this, _T("UartIn"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/UartControl"), XRCCTRL(*this, _T("UartControl"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/UartStatus"), XRCCTRL(*this, _T("UartStatus"), wxSpinCtrl)->GetValue());

	p_Main->setConfigItem(_T(elfTypeStr_+"/TmsModeHighOutput"), XRCCTRL(*this, _T("TmsModeHighOutput"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/TmsModeLowOutput"), XRCCTRL(*this, _T("TmsModeLowOutput"), wxSpinCtrl)->GetValue());

	p_Main->setConfigItem(_T(elfTypeStr_+"/Led_Module_Output"), XRCCTRL(*this, _T("Led_Module_Output"), wxSpinCtrl)->GetValue());

	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6847Output"), XRCCTRL(*this, _T("MC6847Output"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6847-B7"), XRCCTRL(*this, _T("MC6847-B7"), wxChoice)->GetCurrentSelection());
	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6847-B6"), XRCCTRL(*this, _T("MC6847-B6"), wxChoice)->GetCurrentSelection());
	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6847-B5"), XRCCTRL(*this, _T("MC6847-B5"), wxChoice)->GetCurrentSelection());
	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6847-B4"), XRCCTRL(*this, _T("MC6847-B4"), wxChoice)->GetCurrentSelection());
	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6847-B3"), XRCCTRL(*this, _T("MC6847-B3"), wxChoice)->GetCurrentSelection());
	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6847-B2"), XRCCTRL(*this, _T("MC6847-B2"), wxChoice)->GetCurrentSelection());
	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6847-B1"), XRCCTRL(*this, _T("MC6847-B1"), wxChoice)->GetCurrentSelection());
	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6847-B0"), XRCCTRL(*this, _T("MC6847-B0"), wxChoice)->GetCurrentSelection());
	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6847-DD7"), XRCCTRL(*this, _T("MC6847-DD7"), wxChoice)->GetCurrentSelection());
	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6847-DD6"), XRCCTRL(*this, _T("MC6847-DD6"), wxChoice)->GetCurrentSelection());

	int sel = XRCCTRL(*this, _T("MC6847StartRam"), wxChoice)->GetCurrentSelection();
	int start = (sel * 0x1000) + 0x8000;
	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6847StartRam"), start);

	int size = 0x3ff;
	sel = XRCCTRL(*this, _T("MC6847SizeRam"), wxChoice)->GetCurrentSelection();
	switch (sel)
	{
		case 0:
			size = 0x3ff;
		break;
		case 1:
			size = 0x5ff;
		break;
		case 2:
			size = 0x7ff;
		break;
		case 3:
			size = 0xbff;
		break;
		case 4:
			size = 0x17ff;
		break;
	}
	int end = start + size;
	if (end > 0xffff)  end = 0xffff;
	p_Main->setConfigItem(_T(elfTypeStr_+"/mc6847EndRam"), end);

	sel = XRCCTRL(*this, _T("MC6845StartRam"), wxChoice)->GetCurrentSelection();
	start = sel * 0x1000;
	p_Main->setConfigItem(_T(elfTypeStr_+"/MC6845StartRam"), start);

	size = 0x3ff;
	sel = XRCCTRL(*this, _T("MC6845SizeRam"), wxChoice)->GetCurrentSelection();
	switch (sel)
	{
		case 0:
			size = 0x3ff;
		break;
		case 1:
			size = 0x7ff;
		break;
		case 2:
			size = 0xfff;
		break;
		case 3:
			size = 0x1fff;
		break;
		case 4:
			size = 0x3fff;
		break;
	}
	end = start + size;
	if (end > 0xffff)  end = 0xffff;
	p_Main->setConfigItem(_T(elfTypeStr_+"/mc6845EndRam"), end);
	p_Main->setConfigItem(_T(elfTypeStr_+"/mc6845Ef"), XRCCTRL(*this, _T("MC6845EF"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/HexEf"), XRCCTRL(*this, _T("KeyboardEf"), wxSpinCtrl)->GetValue());
	p_Main->setConfigItem(_T(elfTypeStr_+"/TapeEf"), XRCCTRL(*this, _T("TapeEf"), wxSpinCtrl)->GetValue());

	EndModal(wxID_OK);
}

void DevicePortsDialog::reset6847Item(int dontCheck, int num)
{
	if ((XRCCTRL(*this, _T("MC6847-B7"), wxChoice)->GetCurrentSelection() == num) && (dontCheck != 10))
		XRCCTRL(*this, _T("MC6847-B7"), wxChoice)->SetSelection(0);
	if ((XRCCTRL(*this, _T("MC6847-B6"), wxChoice)->GetCurrentSelection() == num) && (dontCheck != 9))
		XRCCTRL(*this, _T("MC6847-B6"), wxChoice)->SetSelection(0);
	if ((XRCCTRL(*this, _T("MC6847-B5"), wxChoice)->GetCurrentSelection() == num) && (dontCheck != 8))
		XRCCTRL(*this, _T("MC6847-B5"), wxChoice)->SetSelection(0);
	if ((XRCCTRL(*this, _T("MC6847-B4"), wxChoice)->GetCurrentSelection() == num) && (dontCheck != 7))
		XRCCTRL(*this, _T("MC6847-B4"), wxChoice)->SetSelection(0);
	if ((XRCCTRL(*this, _T("MC6847-B3"), wxChoice)->GetCurrentSelection() == num) && (dontCheck != 6))
		XRCCTRL(*this, _T("MC6847-B3"), wxChoice)->SetSelection(0);
	if ((XRCCTRL(*this, _T("MC6847-B2"), wxChoice)->GetCurrentSelection() == num) && (dontCheck != 5))
		XRCCTRL(*this, _T("MC6847-B2"), wxChoice)->SetSelection(0);
	if ((XRCCTRL(*this, _T("MC6847-B1"), wxChoice)->GetCurrentSelection() == num) && (dontCheck != 4))
		XRCCTRL(*this, _T("MC6847-B1"), wxChoice)->SetSelection(0);
	if ((XRCCTRL(*this, _T("MC6847-B0"), wxChoice)->GetCurrentSelection() == num) && (dontCheck != 3))
		XRCCTRL(*this, _T("MC6847-B0"), wxChoice)->SetSelection(0);
	if ((XRCCTRL(*this, _T("MC6847-DD7"), wxChoice)->GetCurrentSelection() == num) && (dontCheck != 2))
		XRCCTRL(*this, _T("MC6847-DD7"), wxChoice)->SetSelection(0);
	if ((XRCCTRL(*this, _T("MC6847-DD6"), wxChoice)->GetCurrentSelection() == num) && (dontCheck != 1))
		XRCCTRL(*this, _T("MC6847-DD6"), wxChoice)->SetSelection(0);
}

void DevicePortsDialog::onMC6847DD6(wxCommandEvent&event)
{
	reset6847Item(1, event.GetSelection()); 
}

void DevicePortsDialog::onMC6847DD7(wxCommandEvent&event)
{
	reset6847Item(2, event.GetSelection()); 
}

void DevicePortsDialog::onMC6847B0(wxCommandEvent&event)
{
	reset6847Item(3, event.GetSelection()); 
}

void DevicePortsDialog::onMC6847B1(wxCommandEvent&event)
{
	reset6847Item(4, event.GetSelection()); 
}

void DevicePortsDialog::onMC6847B2(wxCommandEvent&event)
{
	reset6847Item(5, event.GetSelection()); 
}

void DevicePortsDialog::onMC6847B3(wxCommandEvent&event)
{
	reset6847Item(6, event.GetSelection()); 
}

void DevicePortsDialog::onMC6847B4(wxCommandEvent&event)
{
	reset6847Item(7, event.GetSelection()); 
}

void DevicePortsDialog::onMC6847B5(wxCommandEvent&event)
{
	reset6847Item(8, event.GetSelection()); 
}

void DevicePortsDialog::onMC6847B6(wxCommandEvent&event)
{
	reset6847Item(9, event.GetSelection()); 
}

void DevicePortsDialog::onMC6847B7(wxCommandEvent&event)
{
	reset6847Item(10, event.GetSelection()); 
}
