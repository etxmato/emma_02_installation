/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

/*
 *******************************************************************
 *** This software is copyright 2006 by Michael H Riley          ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "main.h"
#include "studio2.h"

Studio2::Studio2(const wxString& title, const wxPoint& pos, const wxSize& size, int zoom, int computerType)
:Pixie(title, pos, size, zoom, computerType)
{
	threadPointer = new RunStudio();
	if ( threadPointer->Create() != wxTHREAD_NO_ERROR )
	{
		p_Main->message("Can't create thread");
	}
	threadPointer->SetPriority(WXTHREAD_MAX_PRIORITY);
}

Studio2::~Studio2()
{
	p_Main->setMainPos(STUDIO, GetPosition());
}

void Studio2::stopComputer()
{
	threadPointer->Delete();
}

void Studio2::configureComputer()
{
	outType_[1] = STUDIOOUT;
	studioKeyPort_ = 0;
	efType_[3] = STUDIOEF3;
	efType_[4] = STUDIOEF4;

	for (int j=0; j<2; j++) for (int i=0; i<10; i++)
		studioKeyState_[j][i] = 0;

	p_Main->message("Configuring Studio II");
	p_Main->message("	Output 2: select port, EF 3: read selected port 1, EF4: read selected port 2\n");

	keyDefA_[0] = p_Main->getConfigItem(_T("/Studio2/HexKeyA0"), 88);
	keyDefA_[1] = p_Main->getConfigItem(_T("/Studio2/HexKeyA1"), 49);
	keyDefA_[2] = p_Main->getConfigItem(_T("/Studio2/HexKeyA2"), 50);
	keyDefA_[3] = p_Main->getConfigItem(_T("/Studio2/HexKeyA3"), 51);
	keyDefA_[4] = p_Main->getConfigItem(_T("/Studio2/HexKeyA4"), 81);
	keyDefA_[5] = p_Main->getConfigItem(_T("/Studio2/HexKeyA5"), 87);
	keyDefA_[6] = p_Main->getConfigItem(_T("/Studio2/HexKeyA6"), 69);
	keyDefA_[7] = p_Main->getConfigItem(_T("/Studio2/HexKeyA7"), 65);
	keyDefA_[8] = p_Main->getConfigItem(_T("/Studio2/HexKeyA8"), 83);
	keyDefA_[9] = p_Main->getConfigItem(_T("/Studio2/HexKeyA9"), 68);

	keyDefB_[0] = p_Main->getConfigItem(_T("/Studio2/HexKeyB0"), WXK_NUMPAD0);
	keyDefB_[1] = p_Main->getConfigItem(_T("/Studio2/HexKeyB1"), WXK_NUMPAD7);
	keyDefB_[2] = p_Main->getConfigItem(_T("/Studio2/HexKeyB2"), WXK_NUMPAD8);
	keyDefB_[3] = p_Main->getConfigItem(_T("/Studio2/HexKeyB3"), WXK_NUMPAD9);
	keyDefB_[4] = p_Main->getConfigItem(_T("/Studio2/HexKeyB4"), WXK_NUMPAD4);
	keyDefB_[5] = p_Main->getConfigItem(_T("/Studio2/HexKeyB5"), WXK_NUMPAD5);
	keyDefB_[6] = p_Main->getConfigItem(_T("/Studio2/HexKeyB6"), WXK_NUMPAD6);
	keyDefB_[7] = p_Main->getConfigItem(_T("/Studio2/HexKeyB7"), WXK_NUMPAD1);
	keyDefB_[8] = p_Main->getConfigItem(_T("/Studio2/HexKeyB8"), WXK_NUMPAD2);
	keyDefB_[9] = p_Main->getConfigItem(_T("/Studio2/HexKeyB9"), WXK_NUMPAD3);

	for (int i=0; i<512; i++)
	{
		keyDefinition[i].defined = false;
	}
	for (int i=0; i<10; i++)
	{
		keyDefinition[keyDefA_[i]].defined = true;
		keyDefinition[keyDefA_[i]].player = 0;
		keyDefinition[keyDefA_[i]].key = i;

		keyDefinition[keyDefB_[i]].defined = true;
		keyDefinition[keyDefB_[i]].player = 1;
		keyDefinition[keyDefB_[i]].key = i;
	}

	resetCpu();
}

void Studio2::keyDown(int keycode)
{
	wxString buffer;
	if (keycode == WXK_TAB)
	{
		setWait(1);
		setClear(0);
		setWait(1);
		setClear(1);
		initPixie();
	}

	if (keyDefinition[keycode].defined)
		studioKeyState_[keyDefinition[keycode].player][keyDefinition[keycode].key] = 1;
}

void Studio2::keyUp(int keycode)
{
	if (keyDefinition[keycode].defined)
		studioKeyState_[keyDefinition[keycode].player][keyDefinition[keycode].key] = 0;
}

Byte Studio2::ef(int flag)
{
	switch(efType_[flag])
	{
		case 0:
			return 1;
		break;

		case PIXIEEF:
			return efPixie();
		break;

		case STUDIOEF3:
			return ef3();
		break;

		case STUDIOEF4:
			return ef4();
		break;

		default:
			return 1;
	}
}

Byte Studio2::ef3()
{
	if (studioKeyPort_<0 || studioKeyPort_>9)
		return 1;
	return(studioKeyState_[0][studioKeyPort_]) ? 0 : 1;
}

Byte Studio2::ef4()
{
	if (studioKeyPort_<0 || studioKeyPort_>9)
		return 1;
	return(studioKeyState_[1][studioKeyPort_]) ? 0 : 1;
}

Byte Studio2::in(Byte port, Word WXUNUSED(address))
{
	Byte ret;

	switch(inType_[port-1])
	{
		case 0:
			ret = 255;
		break;

		case PIXIEIN:
			ret = inPixie();
		break;

		default:
			ret = 255;
	}
	inValues_[port] = ret;
	return ret;
}

void Studio2::out(Byte port, Word WXUNUSED(address), Byte value)
{
	outValues_[port] = value;

	switch(outType_[port-1])
	{
		case 0:
			return;
		break;

		case PIXIEOUT:
			outPixie();
		break;

		case STUDIOOUT:
			outStudio(value);
		break;
	}
}

void Studio2::outStudio(Byte value)
{
//	while(value >= 0x10) value -= 0x10;
	studioKeyPort_ = value & 0xf;
}

void Studio2::cycle(int type)
{
	switch(cycleType_[type])
	{
		case 0:
			return;
		break;

		case PIXIECYCLE:
			cyclePixie();
		break;
	}
}

void Studio2::startComputer()
{
	resetPressed_ = false;

	p_Main->setSwName("");
	p_Main->updateTitle();

	for (int i=0xc00; i<0xff00; i+=0x400)
	{
		defineMemoryType(i, MAPPEDRAM);
		defineMemoryType(i+0x100, MAPPEDRAM);
	}
	readProgramCombo(p_Main->getRomDir(STUDIO, MAINROM), "MainRomStudio2", ROM, 0, NONAME);
	readSt2Program("CartRomStudio2");
	defineMemoryType(0x800, 0x9ff, RAM);
	int	zoom = p_Main->getSpinValue("ZoomStudio2");

	configurePixieStudio2();
	setZoom(zoom);
	initPixie();
	Show(true);
	setWait(1);
	setClear(0);
	setWait(1);
	setClear(1);

	p_Main->updateTitle();

	cpuCycles_ = 0;
	startTime_ = wxGetLocalTime();

	threadPointer->Run();
}

Byte Studio2::readMem(Word addr)
{
	address_ = addr;

	switch (memoryType_[addr/256])
	{
		case UNDEFINED:
			return 255;
		break;

		case MAPPEDRAM:
			addr = (addr & 0x1ff) | 0x800;
		break;
	}

	return mainMemory_[addr];
}

void Studio2::writeMem(Word addr, Byte value, bool writeRom)
{
	address_ = addr;

	switch (memoryType_[addr/256])
	{
		case RAM:
			mainMemory_[addr]=value;
		break;

		case MAPPEDRAM:
			addr = (addr & 0x1ff) | 0x800;
			mainMemory_[addr]=value;
		break;

		default:
			if (writeRom)
				mainMemory_[addr]=value;
		break;
	}
}

void Studio2::cpuInstruction()
{
	if (debugMode_)
		p_Main->updateWindow();
	if (cpuMode_ == RUN)
	{
		if (steps_ != 0)
		{
			cycle0_=0;
			machineCycle();
			if (cycle0_ == 0) machineCycle();
			if (cycle0_ == 0 && steps_ != 0)
			{
				cpuCycle();
				cpuCycles_ += 2;
			}
		}
		else
			soundCycle();

		if (resetPressed_)
		{
			resetCpu();
			resetPressed_ = false;
			setWait(1);
			setClear(0);
			setWait(1);
			setClear(1);
			initPixie();
		}
		if (debugMode_)
			p_Main->cycleDebug();
	}
	else
	{
		initPixie();;
		cpuCycles_ = 0;
		startTime_ = wxGetLocalTime();
	}
}

void Studio2::readSt2Program(wxString fileReference)
{
	wxString fileName, file;
	wxFFile inFile;
	struct
	{
		char header[4];
		Byte numBlocks;
		Byte format;
		Byte video;
		Byte notUsed1;
		char author[2];
		char dumper[2];
		Byte notUsed2[4];
		char catalogue[10];
		Byte notUsed3[6];
		char title[32];
		Byte offsets[64];
		Byte notUsed4[128];
	} st2Header;

	fileName = p_Main->getRomDir(STUDIO, CARTROM);
	file = p_Main->getComboValue(fileReference);
	fileName.operator += (file);

	if (file.Len() != 0)
	{
		if (wxFile::Exists(fileName))
		{
			if (inFile.Open(fileName, "rb"))
			{
				inFile.Read(&st2Header, 256);
				for (int i=1; i<st2Header.numBlocks; i++)
				{
					inFile.Read((&mainMemory_[st2Header.offsets[i-1] << 8]),256);
					defineMemoryType(st2Header.offsets[i-1] << 8, CARTRIDGEROM);
				}
				inFile.Close();
				wxFileName swFullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
				p_Main->setSwName (swFullPath.GetName());
			}
			else
			{
				(void)wxMessageBox( _T("Error reading " + fileName),  // Works correct, via p_Main->errorMessage it will NOT
								    _T("1802 Emulator"), wxICON_ERROR | wxOK );
			}
		}
		else
		{
			(void)wxMessageBox( _T("File " + fileName + " not found"), // Works correct, via p_Main->errorMessage it will NOT
							    _T("1802 Emulator"), wxICON_ERROR | wxOK );
		}
	}
}

void Studio2::onReset()
{
	resetPressed_ = true;
}

void Studio2::onRun()
{
	resetPressed_ = true;
}

void *RunStudio::Entry()
{
	while(!TestDestroy())
	{
		p_Computer->cpuInstruction();
	}
	return NULL;
}
