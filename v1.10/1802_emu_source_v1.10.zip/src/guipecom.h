#ifndef GUIPECOM_H
#define GUIPECOM_H

#include "guimain.h"

DECLARE_EVENT_TYPE(OPEN_PECOM_PRINTER_WINDOW, 810) 

class GuiPecom : public GuiMain
{
public:

	GuiPecom(const wxString& title, const wxPoint& pos, const wxSize& size);
	~GuiPecom() {};

	void readPecomConfig();
	void writePecomConfig();

	void onPecomPrintFileText(wxCommandEvent& event);
	void onPecomPrintButton(wxCommandEvent& event);
	void onPecomPrintMode(wxCommandEvent& event);
	void openPrinterFrame(wxCommandEvent &event);

	void onPecomF4();
	void setPecomPrintMode();
	int getPecomPrintMode();

private:
	int pecomPrintMode_;

	DECLARE_EVENT_TABLE()
};

#endif // GUIPECOM_H