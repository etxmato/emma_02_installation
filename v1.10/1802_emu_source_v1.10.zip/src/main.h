#ifndef MAIN_H
#define MAIN_H

//#ifdef  WIN32
typedef unsigned char Byte;
typedef unsigned short Word;
//#endif

#include "wx/file.h"
#include "wx/html/helpctrl.h"
#include "wx/spinctrl.h"
#include "wx/choicebk.h"

// code defining event

class wxErrorMsgEvent: public wxNotifyEvent
{
public:
    wxErrorMsgEvent( wxEventType commandType = wxEVT_NULL, int id = 0 );

    // accessors
    wxString GetMsg()
        { return message; }
	void SetMsg(wxString msg)
		{ message = msg;}
    // required for sending with wxPostEvent()
	wxEvent *Clone(void) const { return new wxErrorMsgEvent(*this); }

private:
    wxString   message;
};

DECLARE_EVENT_TYPE( wxEVT_ERROR_MSG, -1 )

typedef void (wxEvtHandler::*wxErrorMsgEventFunction)(wxErrorMsgEvent&);

#define EVT_ERROR_MSG(id, fn) \
    DECLARE_EVENT_TABLE_ENTRY( wxEVT_ERROR_MSG, id, -1, \
    (wxObjectEventFunction) (wxEventFunction) (wxCommandEventFunction) (wxNotifyEventFunction) \
    wxStaticCastEvent( wxErrorMsgEventFunction, & fn ), (wxObject *) NULL ),

class WindowInfo
{
public:
	int xBorder, yBorder;
	int xBorder2, yBorder2;
	int xPrint;
	int mainwX, mainwY;
};

class ScreenInfo
{
public:
	int start;
	int number;
	wxString defaultColour[66];
};

#include "cidelsa.h"
#include "comx35.h"
#include "hbelf.h"
#include "elf2.h"
#include "elf2k.h"
#include "cosmicos.h"
#include "super.h"
#include "studio2.h"
#include "visicom.h"
#include "victory.h"
#include "vip.h"
#include "pecom.h"
#include "tmc600.h"
#include "tmc1800.h"
#include "tmc2000.h"
#include "eti660.h"
#include "nano.h"
#include "guicomx.h"
#include "debug.h"
#include "video.h"

#define ELF 0
#define ELFII 1
#define SUPERELF 2
#define ELF2K 3
#define COSMICOS 4
#define ETI 5
#define COMX 6
#define STUDIO 7
#define VIP 8
#define CIDELSA 9
#define TMC600 10
#define TMC1800 11
#define TMC2000 12
#define NANO 13
#define PECOM 14
#define VISICOM 15
#define VICTORY 16
#define DEBUGGER 17
#define MESSAGE 18
#define TELMACPRINTER 0
#define PECOMPRINTER 3
#define COMXPRINTER 1
#define COMXTHPRINTER 2
#define COMXFLOP 3
#define COMX80COLUMN 4
#define COMXRAM 6
#define COMXJOY 16
#define COMXRS232 17
#define COMXEMPTY 255
#define PRINTWINDOW 3
#define PRINTFILE 0
#define COMXPRINTPLOTTER 1
#define COMXPRINTPRINTER 2
#define TIMERINTERVAL 50
#define PRINTER_PLOTTER 6000
#define PLOTTEREXTTEXT 6001
#define PLOTTEREXT 6002
#define PLOTTERROMTEXT 6003
#define PLOTTERROM 6004
#define PAL 0
#define NTSC 1
#define COMXTAB 0
#define ELFTAB 1
#define STUDIOTAB 2
#define CIDELSATAB 3
#define TELMACTAB 4
#define PECOMTAB 5
#define ETITAB 6
#define DEBUGGERTAB 7
#define MESSAGETAB 8
#define DISKNONE 0
#define DISKFDC 1
#define DISKIDE 2
#define VIDEONONE 0
#define VIDEO1870 0
#define VIDEOPIXIE 1
#define VIDEO2KI8275 2
#define VIDEO6845 2
#define VIDEO6847 3
#define VIDEOTMS 4
#define VIDEOI8275 5
#define VIDEOS100 6
#define ELFLED 0
#define ELFIILED 1
#define SUPERELFLED 2
#define ELF2KLED1 3
#define ELF2KLED2 4
#define ELF2KLED3 5
#define COSMICOSLED 6

#define KEYBOARDNONE 0
#define KEYBOARDPS2 1
#define KEYBOARDPS2INT 2
#define KEYBOARDASCII 3
#define KEYBOARDHEXEF3 4
#define KEYBOARDHEX 5

#define KEYBOARD2KPS2GPIOJP4 2
#define KEYBOARDELF2KHEX 3

#define KEYBOARDHEXCOSMICOS 1

#define COMXPARALLEL 0
#define COMXSERIAL 1
#define COMXTHERMAL 2

#define UNDEFINED 0
#define RAM 1
#define ROM 2
#define PAGER 3
#define CRAM1870 5
#define PRAM1870 6
#define COMXEXPROM 7
#define COPYCOMXEXPROM 8
#define RAMBANK 9
#define MC6845RAM 11
#define MC6845REGISTERS 12
#define COPYFLOPROM 13
#define EMSMEMORY 15
#define COMXEXPBOX 16
#define MC6847RAM 18
#define CARTRIDGEROM 19
#define MAPPEDRAM 20
#define COLOURRAM 21
#define VP570RAM 22 
#define NOCHANGE 30

#define MC6845CHARW 8
#define SHOWNAME true
#define NONAME false

#define NOPROGRAM 0
#define SUPERBASICV1 1 // bit 0=1: .super/.rca load
#define SUPERBASICV5 3 
#define RCABASIC3 5
#define RCABASIC4 7

#define TINYBASIC 2
#define MINIMON 4
#define GOLDMON 6

#define NOOS 0
#define ELFOS 1

#define HEXMON 2
#define ASCIIMON 4

#define VTNONE 0
#define VT52 1
#define VT100 2

	// 1 Scroll - repeat - screen reverse - cursor block line
	// 2 bell - keyklick - ansi/vt52 - xon/xoff
	// 3 US - wrap - newline - interlace
	// 4 parity sense - parity - bits per char - 60/50Hz

#define VTSMOOTHSCROLL 15
#define VTREPEAT 14
#define VTREVERSESCREEN 13
#define VTCURSORBLOCK 12
#define VTBELL 11
#define VTKEYCLICK 10
#define VTANSI 9
#define VTAUTOXON 8
#define VTUSASCII 7
#define VTWRAPAROUND 6
#define VTNEWLINE 5
#define VTINTERLACE 4
#define VTPARITYSENSE 3
#define VTPARITY 2
#define VTBITS 1
#define VTPOWER 0

#define VIP_BEEP 0
#define VIP_1864 1
#define VIP_SUPER2 2
#define VIP_SUPER4 3

#define GUIQUIT "MI_Quit"
#define GUIABOUT "MI_About"
#define GUIHELP "MI_Help"
#define GUISAVEONEXIT "MI_SaveOnExit"
#define GUISAVECONFIG "MI_SaveConfig"
#define GUIDEFAULTWINDOWPOS "MI_DefaultWindowPosition"
#define GUIDEFAULT "MI_DefaultSettings"
#define GUIPROTECTEDMODE "ProtectedMode"

#define GUICOMPUTERNOTEBOOK "Computer"

#define RESETSTATE 0
#define BASICSTATE 1
#define RUNSTATE 2

#define LEFTCHANNEL false
#define RIGHTCHANNEL true

#define GUI_ELF2K_BAUDR 30000
#define GUI_ELF2K_BAUDT 30001
#define GUI_ELF_BAUDR 30002
#define GUI_ELF_BAUDT 30003
#define GUI_COSMICOS_BAUDR 30004
#define GUI_COSMICOS_BAUDT 30005
//#define GUI_ELFII_BAUDR 30004
//#define GUI_ELFII_BAUDT 30005
//#define GUI_SUPERELF_BAUDR 30006
//#define GUI_SUPERELF_BAUDT 30007


class Emu1802: public wxApp
{
	virtual bool OnInit();
	virtual int OnExit();
};

WindowInfo getWinSizeInfo();

class Main: public DebugWindow
{
public:

	Main(const wxString& title, const wxPoint& pos, const wxSize& size);
	~Main();

	void onClose(wxCloseEvent&event );

	void onQuit(wxCommandEvent& event);
	void onAbout(wxCommandEvent& event);
	void onHelp(wxCommandEvent& event);
	void onSaveConfig(wxCommandEvent& event);
	void onSaveOnExit(wxCommandEvent& event);
	void onDefaultWindowPosition(wxCommandEvent& event);
	void onDefaultSettings(wxCommandEvent& event);
	void onFlat(wxCommandEvent& event);
	void onCrisp(wxCommandEvent& event);
	void onDefault(wxCommandEvent& event);
	void onTvSpeaker(wxCommandEvent& event);
	void onHandheld(wxCommandEvent& event);

	void onComputer(wxNotebookEvent& event);
	void onStudioChoiceBook(wxChoicebookEvent& event);
	void onTelmacChoiceBook(wxChoicebookEvent& event);
	void onCosmacChoiceBook(wxChoicebookEvent& event);
	void onStart(wxCommandEvent& event);

	void stopComputer();
	void enableElfConfig(bool status);
	void enableGui(bool status);
	void message(wxString buffer);
	void messageInt(int value);
	void messageHex(int value);
	void readConfig();
	void writeConfig();

	wxString getApplicationDir();

	wxChar getPathSep();
	int setFdcStepRate(int rate);
	int getPsaveData(int item);
	void setPsaveData(int item, int data);
	void vuTimeout(wxTimerEvent& event);
	void vuSet(wxString Item, int value);
	void errorMessageEvent(wxErrorMsgEvent& event);
	void errorMessage(wxString msg);

private:
	wxHtmlHelpController helpController_;
	Sync_Audio *audioPointer;

	bool saveOnExit_;

	bool emuClosing_;
	int bass_;
	int treble_;
	wxTimer *vuPointer;

	wxString message_;

	DECLARE_EVENT_TABLE()
};

#endif // MAIN_H

#undef EXT
#define EXT extern

#ifdef MAIN
#undef EXT
#define EXT
#endif

EXT Main *p_Main;
EXT Video *p_Video;
EXT Video *p_Vt100;
EXT Cdp1802 *p_Computer;

EXT	Printer *p_PrinterParallel;
EXT	Printer *p_PrinterSerial;
EXT	Printer *p_PrinterThermal;
EXT	Printer *p_PrinterTelmac;
EXT	Printer *p_PrinterPecom;
EXT wxPrintData *PrintDataPointer;
EXT wxPageSetupDialogData *p_PageSetupData;
