/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "main.h"
#include "vip.h"

Vip::Vip(const wxString& title, const wxPoint& pos, const wxSize& size, double zoom, double zoomfactor, int computerType, double clock, int tempo)
:Pixie(title, pos, size, zoom, zoomfactor, computerType)
{
	clock_ = clock;
	p_Printer = new Printer();
	p_Printer->initVip(p_Printer);

	cycleSize_ = (int) (((clock_ * 1000000) / 8) / tempo);
}

Vip::~Vip()
{
	p_Printer->closeFrames();
	delete p_Printer;
	p_Main->setMainPos(VIP, GetPosition());
}

void Vip::setTempo(int tempo)
{
	cycleSize_ = (int) (((clock_ * 1000000) / 8) / tempo);
}

void Vip::configureComputer()
{
	outType_[1] = VIPKEYOUT;
	outType_[3] = VIPOUT4;
	efType_[2] = VIPEF2;
	efType_[3] = VIPKEYEF;

	vipSound_ = p_Main->getChoiceSelection("SoundVip");
	cdp1862_ = p_Main->getCheckBox("VP590");
	vp580_ = p_Main->getCheckBox("VP580");

	p_Main->message("Configuring Cosmac VIP");
	if (vipSound_ == VIP_1864)
	{
		outType_[2] = VIPOUT3;
		p_Main->message("	Output 2: hex key latch, output 3: tone latch, output 4: address latch");
	}
	else
		p_Main->message("	Output 2: hex key latch, output 4: address latch");

	if (vipSound_ == VIP_SUPER2 || vipSound_ == VIP_SUPER4)
		cycleType_[COMPUTERCYCLE] = VP550CYCLE;

	if (vp580_ || cdp1862_)
	{
		p_Main->message("	EF 2: cassette in, EF 3: hex keypad A, EF 4: hex keypad B\n");
		efType_[4] = VIPKEYEF4;
	}
	else
		p_Main->message("	EF 2: cassette in, EF 3: hex keypad\n");

	usePrinter_ = false;
	if (p_Main->getPrinterStatus())
	{
		outType_[2] = VIPOUT3;
		usePrinter_ = true;
		p_Main->message("Configuring Centronics P-1/PR-40 Printer");
		p_Main->message("	Output 3: latch, Q: strobe, EF 3: busy\n");
	}
	defineKeys();
	resetCpu();
}

void Vip::defineKeys()
{
	player2defined_ = false;
	p_Main->getDefaultHexKeys("Vip", "A", hexKeyDefA_);
	p_Main->getDefaultHexKeys("Vip", "B", hexKeyDefB_);
	p_Main->getDefaultGameKeys("Vip", "A", keyDefGameValueA_, keyDefGameHexA_);
	p_Main->getDefaultGameKeys("Vip", "B", keyDefGameValueB_, keyDefGameHexB_);

	if (p_Main->getConfigBool("/Vip/GameAuto", true))
	{
		p_Main->loadKeyDefinition(p_Main->getComboValue("RamSWVip"), p_Main->getTextValue("Chip8SWVip"), keyDefGameHexA_, keyDefGameHexB_);
		p_Main->storeDefaultGameKeys("Vip", "A", keyDefGameValueA_, keyDefGameHexA_);
		p_Main->storeDefaultGameKeys("Vip", "B", keyDefGameValueB_, keyDefGameHexB_);
	}
	
	for (int i=0; i<512; i++)
	{
		keyDefinition[i].defined = false;
	}
	for (int i=0; i<16; i++)
	{
		keyDefinition[hexKeyDefA_[i]].defined = true;
		keyDefinition[hexKeyDefA_[i]].player = 0;
		keyDefinition[hexKeyDefA_[i]].key = i;
		if (vp580_ || cdp1862_)
		{
			keyDefinition[hexKeyDefB_[i]].defined = true;
			keyDefinition[hexKeyDefB_[i]].player = 1;
			keyDefinition[hexKeyDefB_[i]].key = i;
		}
		else
			player2defined_ = true;
	}

	for (int i=0; i<5; i++)
	{
		keyDefinition[keyDefGameValueA_[i]].defined = true;
		keyDefinition[keyDefGameValueA_[i]].player = 0;
		keyDefinition[keyDefGameValueA_[i]].key = keyDefGameHexA_[i];

		keyDefinition[keyDefGameValueB_[i]].defined = true;
		keyDefinition[keyDefGameValueB_[i]].key = keyDefGameHexB_[i];
		if (player2defined_)
			keyDefinition[keyDefGameValueB_[i]].player = 0;
		else
			keyDefinition[keyDefGameValueB_[i]].player = 1;
	}
	redefineKeys_ = false;

}

void Vip::reDefineKeysA(int hexKeyDefA[], int keyDefGameValueA[], int keyDefGameHexA[])
{
	for (int i=0; i<512; i++)
	{
		keyDefinition[i].defined = false;
	}
	for (int i=0; i<16; i++)
	{
		hexKeyDefA_[i] = hexKeyDefA[i];
		keyDefinition[hexKeyDefA_[i]].defined = true;
		keyDefinition[hexKeyDefA_[i]].player = 0;
		keyDefinition[hexKeyDefA_[i]].key = i;
	}
	for (int i=0; i<5; i++)
	{
		keyDefGameValueA_[i] = keyDefGameValueA[i];
		keyDefGameHexA_[i] = keyDefGameHexA[i];
		keyDefinition[keyDefGameValueA_[i]].defined = true;
		keyDefinition[keyDefGameValueA_[i]].player = 0;
		keyDefinition[keyDefGameValueA_[i]].key = keyDefGameHexA_[i];
	}
}

void Vip::reDefineKeysB(int hexKeyDefB[], int keyDefGameValueB[], int keyDefGameHexB[])
{
	for (int i=0; i<16; i++)
	{
		hexKeyDefB_[i] = hexKeyDefB[i];
		keyDefinition[hexKeyDefB_[i]].defined = true;
		keyDefinition[hexKeyDefB_[i]].player = 1;
		keyDefinition[hexKeyDefB_[i]].key = i;
	}
	for (int i=0; i<5; i++)
	{
		keyDefGameValueB_[i] = keyDefGameValueB[i];
		keyDefGameHexB_[i] = keyDefGameHexB[i];
		keyDefinition[keyDefGameValueB_[i]].defined = true;
		keyDefinition[keyDefGameValueB_[i]].key = keyDefGameHexB_[i];
		if (player2defined_)
			keyDefinition[keyDefGameValueB_[i]].player = 0;
		else
			keyDefinition[keyDefGameValueB_[i]].player = 1;
	}
}

void Vip::configureKeyboard() 
{
	keyboardEf_ = 1;
	keyboardValue_ = 0;

	p_Computer->setInType(2, KEYBRDIN);
	p_Computer->setEfType(4, KEYBRDEF); 

	wxString printBuffer;
	p_Main->message("Configuring Ascii Keyboard");

	printBuffer.Printf("	Input 3: read data, EF 4: data ready flag\n");
	p_Main->message(printBuffer);
}

void Vip::initComputer()
{
	setClear(1);
	setWait(1);
	cassetteEf_ = 0;

	vipKeyPort_ = 0;
	for (int i=0; i<16; i++)
	{
		vipKeyState_[0][i] = 0;
		vipKeyState_[1][i] = 0;
	}

	addressLatch_ = 0x8000;
	runPressed_ = false;
	vp550IntOn_ = false;
	cycleValue_ = cycleSize_;
	colourMask_ = 0xff;
	stateQ_ = 0;
	printLatch_ = 0;
}

void Vip::charEvent(int keycode)
{
	if (useKeyboard_)
	{
		keyboardValue_ = keycode;
		keyboardEf_ = 0;
	}
}

void Vip::keyDown(int keycode)
{
/*	if (redefineKeys_)
	{
		defineKeys();
	}*/
	if (keyDefinition[keycode].defined)
		vipKeyState_[keyDefinition[keycode].player][keyDefinition[keycode].key] = 1;
}

void Vip::keyUp(int keycode)
{
	if (useKeyboard_)
		keyboardEf_ = 1;
	if (keyDefinition[keycode].defined)
		vipKeyState_[keyDefinition[keycode].player][keyDefinition[keycode].key] = 0;
}

void Vip::onRun()
{
	runPressed_ = true;
}

Byte Vip::ef(int flag)
{
	switch(efType_[flag])
	{
		case 0:
			return 1;
		break;

		case PIXIEEF:
			return efPixie();
		break;

		case KEYBRDEF:
			return keyboardEf_;
		break;

		case VIPEF2:
			return cassetteEf_;
		break;

		case VIPKEYEF:
			return ef3();
		break;

		case VIPKEYEF4:
			return ef4();
		break;

		default:
			return 1;
	}
}

Byte Vip::ef3()
{
	return (vipKeyState_[0][vipKeyPort_]) ? 0 : 1;
}

Byte Vip::ef4()
{
	return (vipKeyState_[1][vipKeyPort_]) ? 0 : 1;
}

Byte Vip::in(Byte port, Word WXUNUSED(address))
{
	Byte ret;

	switch(inType_[port-1])
	{
		case 0:
			ret = 255;
		break;

		case PIXIEIN:
			ret = inPixie();
		break;

		case KEYBRDIN:
			ret = keyboardValue_;
		break;

		default:
			ret = 255;
	}
	inValues_[port] = ret;
	return ret;
}

void Vip::out(Byte port, Word WXUNUSED(address), Byte value)
{
	outValues_[port] = value;

	switch(outType_[port-1])
	{
		case 0:
			return;
		break;

		case PIXIEOUT:
			outPixie();
		break;

		case PIXIEBACKGROUND:
			outPixieBackGround();
		break;

		case VIPKEYOUT:
			outVip(value);
		break;

		case VIPOUT3:
			printLatch_ = value;
			tone1864Latch(value);
		break;

		case VIPOUT4:
			addressLatch_ = 0;
		break;

		case VIPOUT5:
			outPixieBackGround();
		break;

	}
}

void Vip::outVip(Byte value)
{
	vipKeyPort_ = value&0xf;
}

void Vip::switchQ(int value)
{
	if (!usePrinter_)  return;

	if (value == 0 && stateQ_ == 1 && printLatch_ != 0)
		p_Main->eventPrintDefault(printLatch_);
	stateQ_ = value;
}

void Vip::cycle(int type)
{
	switch(cycleType_[type])
	{
		case 0:
			return;
		break;

		case PIXIECYCLE:
			cyclePixie();
		break;

		case VP550CYCLE:
			cycleVP550();
		break;
	}
}

void Vip::cycleVP550()
{
	if (vp550IntOn_)
	{
		cycleValue_--;
		if (cycleValue_ <= 0)
		{
			p_Computer->interrupt();
			cycleValue_ = cycleSize_;
		}
	}
}

void Vip::startComputer()
{
	resetPressed_ = false;

	p_Main->setSwName("");
	p_Main->updateTitle();

	ramMask_ = (p_Main->getSpinValue("RamVip") * 0x400) - 1;

	readFile(p_Main->getRomDir(VIP, MAINROM)+"cosmac.ram", RAM, ramMask_-0xff, 0x10000, NONAME);
	readProgramCombo(p_Main->getRomDir(VIP, MAINROM), "MainRomVip", ROM, 0x8000, NONAME);
	defineMemoryType(0x0, ramMask_, RAM);
	for (int i=0x1000; i<0x8000; i+=0x1000)
		defineMemoryType(i, i+ramMask_, MAPPEDRAM);
	for (int i=0; i<p_Main->getSpinValue("VP570"); i++)
		defineMemoryType((i+1)*0x1000, (i+1)*0x1000+0xfff, VP570RAM);
	if (cdp1862_)
		defineMemoryType(0xc000, 0xdfff, COLOURRAM);


	ramMask_ |= 0xfff;
	readProgramCombo(p_Main->getRamDir(VIP), "RamSWVip", NOCHANGE, 0, SHOWNAME);
	if (mainMemory_[0x100] ==  0 && mainMemory_[0x1b] == 0x96 && mainMemory_[0x1c] == 0xb7)
	{
		chip8type_ = CHIP8;
		readProgram(p_Main->getChip8Dir(VIP), "Chip8SWVip", NOCHANGE, 0x200, SHOWNAME);
	}
	else
	{
		if (mainMemory_[0x100] ==  0x33 && mainMemory_[0x1b] == 0x96 && mainMemory_[0x1c] == 0xb7)
		{
			chip8type_ = CHIP8X;
			readProgram(p_Main->getChip8Dir(VIP), "Chip8SWVip", NOCHANGE, 0x300, SHOWNAME);
		}
		else
			readProgram(p_Main->getChip8Dir(VIP), "Chip8SWVip", NOCHANGE, 0x200, SHOWNAME);
	}

	double zoom = p_Main->getZoom();

	useKeyboard_ = false;
	if (p_Main->getCheckBox("KeyboardVip"))
	{
		configureKeyboard();
		useKeyboard_ = true;
	}
	configurePixieVip();
	setZoom(zoom);
	Show(true);
	initPixie();
	setVipSound(vipSound_);

	p_Main->updateTitle();


	cpuCycles_ = 0;
	p_Main->startTime();

	threadPointer->Run();
}

Byte Vip::readMem(Word addr)
{
	if (addr < 0x8000)
		addr = (addr | addressLatch_);
	else
		addr = addr & 0x81ff;

	switch (memoryType_[addr/256])
	{
		case RAM:
		case MAPPEDRAM:
			return mainMemory_[addr & (ramMask_ | 0x8000)];
		break;

		case VP570RAM:
			return mainMemory_[addr];
		break;

		case UNDEFINED:
			return 255;
		break;
	}
	return mainMemory_[addr];
}

void Vip::writeMem(Word addr, Byte value, bool writeRom)
{
	if (vipSound_ == VIP_SUPER4)
	{
		switch (addr)
		{
			case 0x4001:
				frequencySuper(2, value);
			return;
			case 0x4002:
				frequencySuper(3, value);
			return;
			case 0x4003:
				if (value & 0x4)
					octaveSuper(3, value);
				else
					octaveSuper(2, value);
			return;
			case 0x4010:
				amplitudeSuper(2, value);
			return;
			case 0x4020:
				amplitudeSuper(3, value);
			return;
			case 0x4030:
				vp550IntOn_ = (value == 1);
			return;
		}
	}
	switch (memoryType_[addr/256])
	{
		case RAM:
		case MAPPEDRAM:
			if (mainMemory_[addr & ramMask_]==value)
				return;
			mainMemory_[addr & ramMask_]=value;
			if ((addr & ramMask_) >= (memoryStart_ & ramMask_) && (addr & ramMask_)<((memoryStart_ & ramMask_)+256))
				p_Main->updateDebugMemory(addr);
		break;

		case VP570RAM:
			mainMemory_[addr]=value;
			if (addr >= memoryStart_ && addr <(memoryStart_+256))
				p_Main->updateDebugMemory(addr);
		break;

		case COLOURRAM:
			if ((addr >= 0xc000) && (addr < 0xd000))
				colourMask_ = 0xe7;
			else
				colourMask_ = 0xff;
			colorMemory1864_[addr&colourMask_] = value & 0xf;
			if ((addr&colourMask_) >= memoryStart_ && (addr&colourMask_) <(memoryStart_+256))
				p_Main->updateDebugMemory(addr&colourMask_);
			useColour(colourMask_);
		break;

		default:
			if (writeRom)
				mainMemory_[addr]=value;
			else
			{
				if (vipSound_ == VIP_SUPER2 || vipSound_ == VIP_SUPER4)
				{
					switch (addr)
					{
						case 0x8001:
							frequencySuper(0, value);
						return;
						case 0x8002:
							frequencySuper(1, value);
						return;
						case 0x8003:
							if (value & 0x4)
								octaveSuper(1, value);
							else
								octaveSuper(0, value);
						return;
						case 0x8010:
							amplitudeSuper(0, value);
						return;
						case 0x8020:
							amplitudeSuper(1, value);
						return;
						case 0x8030:
							vp550IntOn_ = (value == 1);
						return;
					}
				}
			}
		break;
	}
}

Byte Vip::read1864ColorDirect(Word addr)
{
	return colorMemory1864_[addr] & 0xf;
}

void Vip::write1864ColorDirect(Word addr, Byte value)
{
	colorMemory1864_[addr] = value & 0xf;
}

void Vip::cpuInstruction()
{
	if (cpuMode_ == RUN)
	{
		if (steps_ != 0)
		{
			cycle0_=0;
			machineCycle();
			if (cycle0_ == 0) machineCycle();
			if (cycle0_ == 0 && steps_ != 0)
			{
				cpuCycle();
				cpuCycles_ += 2;
			}
			if (debugMode_)
				p_Main->showInstructionTrace();
		}
		else
			soundCycle();

		playSaveLoad();
		checkVipFunction();

		if (resetPressed_)
		{
			resetCpu();
			resetPressed_ = false;
			addressLatch_ = 0x8000;
			initPixie();
		}
		if (runPressed_)
		{
			setClear(0);
			p_Main->updateTitle();
			runPressed_ = false;
		}
		if (debugMode_)
			p_Main->cycleDebug();
		p_Main->cycleChip8Debug();
	}
	else
	{
		if (runPressed_)
		{
			setClear(1);
			p_Main->updateTitle();
			addressLatch_ = 0x8000;
			initPixie();
			runPressed_ = false;
		}
	}
}

void Vip::onReset()
{
	resetPressed_ = true;
}

void Vip::checkVipFunction()
{
	switch(scratchpadRegister_[programCounter_])
	{
		case 0x80c0:
			p_Main->stopCassette();
		break;

		case 0x80ed:
			p_Main->stopCassette();
		break;

		case 0x8091:	// SAVE
			p_Main->startCassetteSave();
		break;

		case 0x80c2:	// LOAD
			p_Main->startCassetteLoad();
		break;
	}
}

void Vip::sleepComputer(long ms)
{
	threadPointer->Sleep(ms);
}
