/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guieti660.h"
#include "pixie.h"

#include "psave.h"

BEGIN_EVENT_TABLE(GuiEti, GuiNano)
	EVT_BUTTON(XRCID("RomButtonEti"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("Chip8SWButtonEti"), GuiMain::onChip8SW)
	EVT_BUTTON(XRCID("EjectChip8SWEti"), GuiMain::onEjectChip8SW)
	EVT_SPIN_UP(XRCID("ZoomSpinEti"), GuiMain::onZoomUp)
	EVT_SPIN_DOWN(XRCID("ZoomSpinEti"), GuiMain::onZoomDown)
	EVT_TEXT(XRCID("ZoomValueEti"), GuiMain::onZoomValue)
	EVT_BUTTON(XRCID("FullScreenF3Eti"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("CasButtonEti"), GuiMain::onCassette)
	EVT_BUTTON(XRCID("EjectCasEti"), GuiMain::onCassetteEject)
	EVT_TEXT(XRCID("WavFileEti"), GuiMain::onCassetteText)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonEti"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Eti"), GuiMain::onScreenDump)
	EVT_BUTTON(XRCID("RealCasLoadEti"), GuiMain::onRealCas)
	EVT_BUTTON(XRCID("CasLoadEti"), GuiMain::onCassetteLoad)
	EVT_BUTTON(XRCID("CasSaveEti"), GuiMain::onCassetteSave)
	EVT_BUTTON(XRCID("CasStopEti"), GuiMain::onCassetteStop)
	EVT_CHECKBOX(XRCID("TurboEti"), GuiMain::onTurbo)
	EVT_TEXT(XRCID("TurboClockEti"), GuiMain::onTurboClock)
	EVT_CHECKBOX(XRCID("AutoCasLoadEti"), GuiMain::onAutoLoad)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeEti"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeEti"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("SaveButtonEti"), GuiMain::onSaveButton)
	EVT_BUTTON(XRCID("LoadButtonEti"), GuiMain::onLoadButton)
	EVT_TEXT(XRCID("ClockEti"), GuiMain::onClock)
	EVT_BUTTON(XRCID("KeyMapEti"), Main::onHexKeyDef)
	EVT_BUTTON(XRCID("ColoursEti"), Main::onColoursDef)

END_EVENT_TABLE()

GuiEti::GuiEti(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiNano(title, pos, size)
{
}

void GuiEti::readEtiConfig()
{
	bool turbo;
	selectedComputer_ = ETI;

	XRCCTRL(*this, "MainRomEti", wxComboBox)->SetValue(configPointer->Read("/Eti/EtiMainRom", "eti-660.bin"));
	XRCCTRL(*this, "Chip8SWEti", wxTextCtrl)->SetValue(configPointer->Read("/Eti/EtiChip8SW", "Wipeout (ETI660 hybrid) [W.F. Kreykes, 1982].ch8"));
	wxString defaultZoom;
	defaultZoom.Printf("%2.2f", 2.0);
	conf[ETI].zoom_ = configPointer->Read("/Eti/Zoom", defaultZoom);
	XRCCTRL(*this, "ZoomValueEti", wxTextCtrl)->ChangeValue(conf[ETI].zoom_);
	wxString defaultScale;
	defaultScale.Printf("%i", 4);
	conf[ETI].xScale_ = configPointer->Read("/Eti/xScale", defaultScale);
	conf[ETI].romDir_[MAINROM] = configPointer->Read("/Eti/EtiRomDir", dataDir_ + "Eti"  + pathSeparator_);
	conf[ETI].ramDir_ = configPointer->Read("/Eti/EtiRamDir", dataDir_ + "Eti"  + pathSeparator_);
	conf[ETI].chip8SWDir_ = configPointer->Read("/Eti/Chip8SWDir", dataDir_ + "Chip-8"  + pathSeparator_ + "Chip-8 ETI660 Hybrids"  + pathSeparator_);

	conf[ETI].wavFile_ = configPointer->Read("/Eti/WavFile", "");
	XRCCTRL(*this, "WavFileEti", wxTextCtrl)->SetValue(conf[ETI].wavFile_);
	conf[ETI].wavFileDir_ = configPointer->Read("/Eti/WavFileDir", dataDir_ + "Eti" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileEti", wxComboBox)->SetValue(configPointer->Read("/Eti/EtiScreenDumpFile", "screendump.png"));
	conf[ETI].screenDumpFileDir_ = configPointer->Read("/Eti/EtiScreenDumpFileDir", dataDir_ + "Eti" + pathSeparator_);

	configPointer->Read("/Eti/EtiTurbo", &turbo, true);
	XRCCTRL(*this, "TurboEti", wxCheckBox)->SetValue(turbo);
	turboGui("Eti");
	conf[ETI].turboClock_ = configPointer->Read("/Eti/EtiTurboClock", "15");
	XRCCTRL(*this, "TurboClockEti", wxTextCtrl)->SetValue(conf[ETI].turboClock_);
	configPointer->Read("/Eti/EtiAutoCasLoad", &conf[ETI].autoCassetteLoad_, true);
	XRCCTRL(*this, "AutoCasLoadEti", wxCheckBox)->SetValue(conf[ETI].autoCassetteLoad_);
	configPointer->Read("/Eti/RealCasLoad", &conf[ETI].realCassetteLoad_, false);
	setRealCas(ETI);

	conf[ETI].volume_ = configPointer->Read("/Eti/EtiVolume", 25l);
	XRCCTRL(*this, "VolumeEti", wxSlider)->SetValue(conf[ETI].volume_);
	XRCCTRL(*this, "RamEti", wxChoice)->SetSelection(configPointer->Read("/Eti/Memory", 0l));

	conf[ETI].mainX_ = configPointer->Read("/Eti/EtiX", mainWindowX_+windowInfo.mainwX);
	conf[ETI].mainY_ = configPointer->Read("/Eti/EtiY", mainWindowY_);

	wxString defaultClock;
	defaultClock.Printf("%1.3f", 1.773);
	conf[ETI].clock_ = configPointer->Read("/Eti/Clock", defaultClock);
	XRCCTRL(*this, "ClockEti", wxTextCtrl)->ChangeValue(conf[ETI].clock_);
}

void GuiEti::writeEtiConfig()
{
	configPointer->Write("/Eti/EtiMainRom", XRCCTRL(*this, "MainRomEti", wxComboBox)->GetValue());
	configPointer->Write("/Eti/EtiChip8SW", XRCCTRL(*this, "Chip8SWEti", wxTextCtrl)->GetValue());
	configPointer->Write("/Eti/Zoom", conf[ETI].zoom_);
	configPointer->Write("/Eti/EtiRomDir", conf[ETI].romDir_[MAINROM]);
	configPointer->Write("/Eti/EtiRamDir", conf[ETI].ramDir_);
	configPointer->Write("/Eti/Chip8SWDir", conf[ETI].chip8SWDir_);

	if (conf[ETI].mainX_ > 0)
		configPointer->Write("/Eti/EtiX", conf[ETI].mainX_);
	if (conf[ETI].mainY_ > 0)
		configPointer->Write("/Eti/EtiY", conf[ETI].mainY_);

	configPointer->Write("/Eti/EtiWavFile", XRCCTRL(*this, "WavFileEti", wxTextCtrl)->GetValue());
	configPointer->Write("/Eti/WavFileDir", conf[ETI].wavFileDir_);
	configPointer->Write("/Eti/EtiScreenDumpFile", XRCCTRL(*this, "ScreenDumpFileEti", wxComboBox)->GetValue());
	configPointer->Write("/Eti/EtiScreenDumpFileDir", conf[ETI].screenDumpFileDir_);
	configPointer->Write("/Eti/EtiTurbo", XRCCTRL(*this, "TurboEti", wxCheckBox)->GetValue());
	configPointer->Write("/Eti/EtiTurboClock", conf[ETI].turboClock_);
	configPointer->Write("/Eti/EtiAutoCasLoad", XRCCTRL(*this, "AutoCasLoadEti", wxCheckBox)->GetValue());
	configPointer->Write("/Eti/RealCasLoad", conf[ETI].realCassetteLoad_);
	configPointer->Write("/Eti/EtiVolume", XRCCTRL(*this, "VolumeEti", wxSlider)->GetValue());
	configPointer->Write("/Eti/Memory", XRCCTRL(*this, "RamEti", wxChoice)->GetSelection());

	configPointer->Write("/Eti/Clock", conf[ETI].clock_);
}
