/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guielf2k.h"

BEGIN_EVENT_TABLE(GuiCosmicos, GuiMembership)

	EVT_BUTTON(XRCID("RomButtonCosmicos"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("VtCharRomButtonCosmicos"), GuiMain::onVtCharRom)
	EVT_CHOICE(XRCID("VTTypeCosmicos"), GuiMain::onVT100)
	EVT_SPIN_UP(XRCID("ZoomSpinCosmicos"), GuiMain::onZoomUp)
	EVT_SPIN_DOWN(XRCID("ZoomSpinCosmicos"), GuiMain::onZoomDown)
	EVT_TEXT(XRCID("ZoomValueCosmicos"), GuiMain::onZoomValue)
	EVT_SPIN_UP(XRCID("ZoomSpinVtCosmicos"), GuiMain::onZoomUpVt)
	EVT_SPIN_DOWN(XRCID("ZoomSpinVtCosmicos"), GuiMain::onZoomDownVt)
	EVT_TEXT(XRCID("ZoomValueVtCosmicos"), GuiMain::onZoomValueVt)
	EVT_BUTTON(XRCID("FullScreenF3Cosmicos"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("ColoursCosmicos"), Main::onColoursDef)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeCosmicos"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeCosmicos"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonCosmicos"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Cosmicos"), GuiMain::onScreenDump)
	EVT_BUTTON(XRCID("DP_ButtonCosmicos"), GuiMain::onDp)
	EVT_BUTTON(XRCID("SaveButtonCosmicos"), GuiMain::onSaveButton)
	EVT_BUTTON(XRCID("LoadButtonCosmicos"), GuiMain::onLoadButton)
	EVT_TEXT(XRCID("ClockCosmicos"), GuiMain::onClock)
	EVT_CHECKBOX(XRCID("StretchDotCosmicos"), GuiMain::onStretchDot)
	EVT_BUTTON(XRCID("KeyMapCosmicos"), Main::onHexKeyDef)
	EVT_CHECKBOX(XRCID("AutoBootCosmicos"), GuiElf::onAutoBoot)
	EVT_BUTTON(XRCID("VtSetupCosmicos"), GuiMain::onVtSetup)

	EVT_CHOICE(XRCID("VideoTypeCosmicos"), GuiCosmicos::onCosmicosVideoType)
	EVT_CHOICE(XRCID("KeyboardCosmicos"), GuiCosmicos::onCosmicosKeyboard)
	EVT_CHECKBOX(XRCID("ForceUCCosmicos"), GuiCosmicos::onCosmicosForceUpperCase)
	EVT_CHECKBOX(XRCID("ControlWindowsCosmicos"), GuiCosmicos::onCosmicosControlWindows)
	EVT_CHECKBOX(XRCID("HexCosmicos"), GuiCosmicos::onCosmicosHex)
	EVT_SPINCTRL(XRCID("RamCosmicos"), GuiCosmicos::onRam)

	EVT_BUTTON(XRCID("CasButtonCosmicos"), GuiMain::onCassette)
	EVT_BUTTON(XRCID("EjectCasCosmicos"), GuiMain::onCassetteEject)
	EVT_TEXT(XRCID("WavFileCosmicos"), GuiMain::onCassetteText)
	EVT_BUTTON(XRCID("RealCasLoadCosmicos"), GuiMain::onRealCas)
	EVT_BUTTON(XRCID("CasLoadCosmicos"), GuiMain::onCassetteLoad)
	EVT_BUTTON(XRCID("CasSaveCosmicos"), GuiMain::onCassetteSave)
	EVT_BUTTON(XRCID("CasStopCosmicos"), GuiMain::onCassetteStop)
	EVT_CHECKBOX(XRCID("TurboCosmicos"), GuiMain::onTurbo)
	EVT_TEXT(XRCID("TurboClockCosmicos"), GuiMain::onTurboClock)
	EVT_CHECKBOX(XRCID("AutoCasLoadCosmicos"), GuiMain::onAutoLoad)

	EVT_TEXT(XRCID("ShowAddressCosmicos"), GuiMain::onLedTimer)

END_EVENT_TABLE()

GuiCosmicos::GuiCosmicos(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiMembership(title, pos, size)
{
}

void GuiCosmicos::readCosmicosConfig()
{
	bool turbo, forceUpperCase, stretchDot;
	selectedComputer_ = COSMICOS;

	getConfigBool("/Cosmicos/SerialLog", false);
	getConfigBool("/Cosmicos/VtEf", false);
	elfConfiguration[COSMICOS].useUart = false;
	conf[COSMICOS].romDir_[MAINROM] = configPointer->Read("/Cosmicos/RomDir", dataDir_ + "Cosmicos" + pathSeparator_);
	conf[COSMICOS].ramDir_ = configPointer->Read("/Cosmicos/RamDir", dataDir_ + "Cosmicos" + pathSeparator_);
	conf[COSMICOS].mainDir_ = configPointer->Read("/Cosmicos/Dir", dataDir_ + "Cosmicos" + pathSeparator_);
	conf[COSMICOS].vtCharRomDir_ = configPointer->Read("/Cosmicos/VtCharRomDir", dataDir_ + "Cosmicos" + pathSeparator_);
	XRCCTRL(*this, "VTTypeCosmicos", wxChoice)->SetSelection(configPointer->Read("/Cosmicos/VTType", 0l));
	setBaudChoiceCosmicos();
	elfConfiguration[COSMICOS].baudR = configPointer->Read("/Cosmicos/BaudR", 5l);
	baudChoiceR[COSMICOS]->SetSelection(elfConfiguration[COSMICOS].baudR);
	elfConfiguration[COSMICOS].baudT = configPointer->Read("/Cosmicos/BaudT", 5l);
	baudChoiceT[COSMICOS]->SetSelection(elfConfiguration[COSMICOS].baudT);
	setVtType("Cosmicos", COSMICOS, XRCCTRL(*this, "VTTypeCosmicos", wxChoice)->GetSelection());
	baudTextR[COSMICOS]->Enable((elfConfiguration[COSMICOS].vtType != VTNONE) && elfConfiguration[COSMICOS].useUart);
	baudChoiceR[COSMICOS]->Enable((elfConfiguration[COSMICOS].vtType != VTNONE) && elfConfiguration[COSMICOS].useUart);
	baudTextT[COSMICOS]->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
	baudChoiceT[COSMICOS]->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
	configPointer->Read("/Cosmicos/ForceUC", &forceUpperCase, true);
	XRCCTRL(*this, "ForceUCCosmicos", wxCheckBox)->SetValue(forceUpperCase);
	XRCCTRL(*this, "MainRomCosmicos", wxComboBox)->SetValue(configPointer->Read("/Cosmicos/MainRom", "hex.and.UT4.monitor.bin"));
	XRCCTRL(*this, "VtCharRomCosmicos", wxComboBox)->SetValue(configPointer->Read("/Cosmicos/VtCharRom", "vt52.a.bin"));
	XRCCTRL(*this, "VtCharRomButtonCosmicos", wxButton)->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
	XRCCTRL(*this, "VtCharRomCosmicos", wxComboBox)->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
	XRCCTRL(*this, "VtSetupCosmicos", wxButton)->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
	XRCCTRL(*this, "VideoTypeCosmicos", wxChoice)->SetSelection(configPointer->Read("/Cosmicos/VideoType", 0l));
	setCosmicosVideoType(XRCCTRL(*this, "VideoTypeCosmicos", wxChoice)->GetSelection());
	configPointer->Read("/Cosmicos/AutoBoot", &elfConfiguration[COSMICOS].autoBoot, true);
	XRCCTRL(*this, "AutoBootCosmicos", wxCheckBox)->SetValue(elfConfiguration[COSMICOS].autoBoot);
	XRCCTRL(*this, "KeyboardCosmicos", wxChoice)->SetSelection(configPointer->Read("/Cosmicos/Keyboard", 0l));
	setCosmicosKeyboard(XRCCTRL(*this, "KeyboardCosmicos", wxChoice)->GetSelection());
	wxString defaultZoom;
	defaultZoom.Printf("%2.2f", 2.0);
	conf[COSMICOS].zoom_ = configPointer->Read("/Cosmicos/Zoom", defaultZoom);
	XRCCTRL(*this, "ZoomValueCosmicos", wxTextCtrl)->ChangeValue(conf[COSMICOS].zoom_);
	defaultZoom.Printf("%2.2f", 1.0);
	conf[COSMICOS].zoomVt_ = configPointer->Read("/Cosmicos/ZoomVt", defaultZoom);
	XRCCTRL(*this, "ZoomValueVtCosmicos", wxTextCtrl)->ChangeValue(conf[COSMICOS].zoomVt_);
	wxString defaultScale;
	defaultScale.Printf("%i", 4);
	conf[COSMICOS].xScale_ = configPointer->Read("/Cosmicos/xScale", defaultScale);

	configPointer->Read("/Cosmicos/ControlWindows", &elfConfiguration[COSMICOS].useElfControlWindows, true);
	XRCCTRL(*this, "ControlWindowsCosmicos", wxCheckBox)->SetValue(elfConfiguration[COSMICOS].useElfControlWindows);
	configPointer->Read("/Cosmicos/StretchDot", &stretchDot, false);
	XRCCTRL(*this, "StretchDotCosmicos", wxCheckBox)->SetValue(stretchDot);
	XRCCTRL(*this, "RamCosmicos", wxSpinCtrl)->SetValue(configPointer->Read("/Cosmicos/Ram", 48l));

	configPointer->Read("/Cosmicos/Hex", &elfConfiguration[COSMICOS].useHex, true);
	XRCCTRL(*this, "HexCosmicos", wxCheckBox)->SetValue(elfConfiguration[COSMICOS].useHex);

	XRCCTRL(*this, "ScreenDumpFileCosmicos", wxComboBox)->SetValue(configPointer->Read("/Cosmicos/ScreenDumpFile", "screendump.png"));
	conf[COSMICOS].screenDumpFileDir_ = configPointer->Read("/Cosmicos/ScreenDumpFileDir", dataDir_ + "Cosmicos" + pathSeparator_);

	conf[COSMICOS].wavFile_ = configPointer->Read("/Cosmicos/WavFile", "");
	XRCCTRL(*this, "WavFileCosmicos", wxTextCtrl)->SetValue(conf[COSMICOS].wavFile_);
	conf[COSMICOS].wavFileDir_ = configPointer->Read("/Cosmicos/WavFileDir", dataDir_ + "Cosmicos" + pathSeparator_);
	configPointer->Read("/Cosmicos/Turbo", &turbo, true);
	XRCCTRL(*this, "TurboCosmicos", wxCheckBox)->SetValue(turbo);
	turboGui("Cosmicos");
	conf[COSMICOS].turboClock_ = configPointer->Read("/Cosmicos/TurboClock", "15");
	XRCCTRL(*this, "TurboClockCosmicos", wxTextCtrl)->SetValue(conf[COSMICOS].turboClock_);
	configPointer->Read("/Cosmicos/AutoCasLoad", &conf[COSMICOS].autoCassetteLoad_, true);
	XRCCTRL(*this, "AutoCasLoadCosmicos", wxCheckBox)->SetValue(conf[COSMICOS].autoCassetteLoad_);

	configPointer->Read("/Cosmicos/RealCasLoad", &conf[COSMICOS].realCassetteLoad_, false);
	setRealCas(COSMICOS);

	conf[COSMICOS].volume_ = configPointer->Read("/Cosmicos/Volume", 25l);
	XRCCTRL(*this, "VolumeCosmicos", wxSlider)->SetValue(conf[COSMICOS].volume_);

	conf[COSMICOS].pixieX_ = configPointer->Read("/Cosmicos/PixieX", mainWindowX_+windowInfo.mainwX);
	conf[COSMICOS].pixieY_ = configPointer->Read("/Cosmicos/PixieY", mainWindowY_);
	conf[COSMICOS].vtX_ = configPointer->Read("/Cosmicos/VtX", mainWindowX_+windowInfo.mainwX);
	conf[COSMICOS].vtY_ = configPointer->Read("/Cosmicos/VtY", mainWindowY_);
	conf[COSMICOS].mainX_ = configPointer->Read("/Cosmicos/CosmicosX", mainWindowX_);
	conf[COSMICOS].mainY_ = configPointer->Read("/Cosmicos/CosmicosY", mainWindowY_+windowInfo.mainwY);
	conf[COSMICOS].keypadX_ = configPointer->Read("/Cosmicos/HexX", mainWindowX_+333+windowInfo.xBorder2);
	conf[COSMICOS].keypadY_ = configPointer->Read("/Cosmicos/HexY", mainWindowY_+windowInfo.mainwY+windowInfo.yBorder);

	wxString defaultClock;
	defaultClock.Printf("%1.2f", 1.75);
	conf[COSMICOS].clock_ = configPointer->Read("/Cosmicos/Clock", defaultClock);
	XRCCTRL(*this, "ClockCosmicos", wxTextCtrl)->ChangeValue(conf[COSMICOS].clock_);

	wxString defaultTimer;
	defaultTimer.Printf("%d", 100);
	elfConfiguration[COSMICOS].ledTime = configPointer->Read("/Cosmicos/ShowAddressMs", defaultTimer);
	XRCCTRL(*this, "ShowAddressCosmicos", wxTextCtrl)->ChangeValue(elfConfiguration[COSMICOS].ledTime);

	elfConfiguration[COSMICOS].usePortExtender = false;
	elfConfiguration[COSMICOS].ideEnabled = false;
	elfConfiguration[COSMICOS].fdcEnabled = false;
	elfConfiguration[COSMICOS].useLedModule = false;
	elfConfiguration[COSMICOS].useTape = true;
}

void GuiCosmicos::writeCosmicosConfig()
{
	configPointer->Write("/Cosmicos/RomDir", conf[COSMICOS].romDir_[MAINROM]);
	configPointer->Write("/Cosmicos/RamDir", conf[COSMICOS].ramDir_);
	configPointer->Write("/Cosmicos/Dir", conf[COSMICOS].mainDir_);
	configPointer->Write("/Cosmicos/VtCharRomDir", conf[COSMICOS].vtCharRomDir_);
	configPointer->Write("/Cosmicos/MainRom", XRCCTRL(*this, "MainRomCosmicos", wxComboBox)->GetValue());
	configPointer->Write("/Cosmicos/VtCharRom", XRCCTRL(*this, "VtCharRomCosmicos", wxComboBox)->GetValue());
	configPointer->Write("/Cosmicos/VTType", XRCCTRL(*this, "VTTypeCosmicos", wxChoice)->GetSelection());
	configPointer->Write("/Cosmicos/BaudR", baudChoiceR[COSMICOS]->GetSelection());
	configPointer->Write("/Cosmicos/BaudT", baudChoiceT[COSMICOS]->GetSelection());
	configPointer->Write("/Cosmicos/AutoBoot", XRCCTRL(*this, "AutoBootCosmicos", wxCheckBox)->GetValue());
	configPointer->Write("/Cosmicos/VideoType", XRCCTRL(*this, "VideoTypeCosmicos", wxChoice)->GetSelection());
	configPointer->Write("/Cosmicos/Keyboard", XRCCTRL(*this, "KeyboardCosmicos", wxChoice)->GetSelection());
	configPointer->Write("/Cosmicos/Zoom", conf[COSMICOS].zoom_);
	configPointer->Write("/Cosmicos/ForceUC", XRCCTRL(*this, "ForceUCCosmicos", wxCheckBox)->GetValue());
	configPointer->Write("/Cosmicos/Hex", XRCCTRL(*this, "HexCosmicos", wxCheckBox)->GetValue());
	configPointer->Write("/Cosmicos/ControlWindows", XRCCTRL(*this, "ControlWindowsCosmicos", wxCheckBox)->GetValue());
	configPointer->Write("/Cosmicos/StretchDot", XRCCTRL(*this, "StretchDotCosmicos", wxCheckBox)->GetValue());
	configPointer->Write("/Cosmicos/Ram", XRCCTRL(*this, "RamCosmicos", wxSpinCtrl)->GetValue());
	configPointer->Write("/Cosmicos/ScreenDumpFile", XRCCTRL(*this, "ScreenDumpFileCosmicos", wxComboBox)->GetValue());
	configPointer->Write("/Cosmicos/ScreenDumpFileDir", conf[COSMICOS].screenDumpFileDir_);
	configPointer->Write("/Cosmicos/WavFile", XRCCTRL(*this, "WavFileCosmicos", wxTextCtrl)->GetValue());
	configPointer->Write("/Cosmicos/WavFileDir", conf[COSMICOS].wavFileDir_);
	configPointer->Write("/Cosmicos/Turbo", XRCCTRL(*this, "TurboCosmicos", wxCheckBox)->GetValue());
	configPointer->Write("/Cosmicos/TurboClock", conf[COSMICOS].turboClock_);
	configPointer->Write("/Cosmicos/AutoCasLoad", XRCCTRL(*this, "AutoCasLoadCosmicos", wxCheckBox)->GetValue());
	configPointer->Write("/Cosmicos/RealCasLoad", conf[COSMICOS].realCassetteLoad_);
	configPointer->Write("/Cosmicos/Volume", XRCCTRL(*this, "VolumeCosmicos", wxSlider)->GetValue());
	configPointer->Write("/Cosmicos/ShowAddressMs", elfConfiguration[COSMICOS].ledTime);

	if (conf[COSMICOS].pixieX_ > 0)
		configPointer->Write("/Cosmicos/PixieX", conf[COSMICOS].pixieX_);
	if (conf[COSMICOS].pixieY_ > 0)
		configPointer->Write("/Cosmicos/PixieY", conf[COSMICOS].pixieY_);
	if (conf[COSMICOS].vtX_ > 0)
		configPointer->Write("/Cosmicos/VtX", conf[COSMICOS].vtX_);
	if (conf[COSMICOS].vtY_ > 0)
		configPointer->Write("/Cosmicos/VtY", conf[COSMICOS].vtY_);
	if (conf[COSMICOS].keypadX_ > 0)
		configPointer->Write("/Cosmicos/HexX", conf[COSMICOS].keypadX_);
	if (conf[COSMICOS].keypadY_ > 0)
		configPointer->Write("/Cosmicos/HexY", conf[COSMICOS].keypadY_);
	if (conf[COSMICOS].mainX_ > 0)
		configPointer->Write("/Cosmicos/CosmicosX", conf[COSMICOS].mainX_);
	if (conf[COSMICOS].mainY_ > 0)
		configPointer->Write("/Cosmicos/CosmicosY", conf[COSMICOS].mainY_);

	configPointer->Write("/Cosmicos/Clock", conf[COSMICOS].clock_);

	delete baudChoiceR[COSMICOS];
	delete baudChoiceT[COSMICOS];
}

void GuiCosmicos::onCosmicosVideoType(wxCommandEvent&event)
{
	setCosmicosVideoType(event.GetSelection());
}

void GuiCosmicos::onCosmicosKeyboard(wxCommandEvent&event)
{
	setCosmicosKeyboard(event.GetSelection());
}

void GuiCosmicos::onCosmicosBaudR(wxCommandEvent&event)
{
	elfConfiguration[COSMICOS].baudR = event.GetSelection();
}

void GuiCosmicos::onCosmicosBaudT(wxCommandEvent&event)
{
	elfConfiguration[COSMICOS].baudT = event.GetSelection();
	if (!elfConfiguration[COSMICOS].useUart)
	{
		elfConfiguration[COSMICOS].baudR = event.GetSelection();
		baudChoiceR[COSMICOS]->SetSelection(elfConfiguration[COSMICOS].baudR);
	}
}

void GuiCosmicos::onCosmicosForceUpperCase(wxCommandEvent&event)
{
	if (runningComputer_ == COSMICOS)
	{
		p_Cosmicos->setForceUpperCase(event.IsChecked());
	}
}

void GuiCosmicos::onCosmicosControlWindows(wxCommandEvent&event)
{
	elfConfiguration[COSMICOS].useElfControlWindows = event.IsChecked();
	XRCCTRL(*this,"ShowAddressCosmicos",wxTextCtrl)->Enable(elfConfiguration[COSMICOS].useElfControlWindows);
	XRCCTRL(*this,"AddressText1Cosmicos",wxStaticText)->Enable(elfConfiguration[COSMICOS].useElfControlWindows);
	XRCCTRL(*this,"AddressText2Cosmicos",wxStaticText)->Enable(elfConfiguration[COSMICOS].useElfControlWindows);
	if (runningComputer_ == COSMICOS)
		p_Cosmicos->Show(elfConfiguration[COSMICOS].useElfControlWindows);
}

void GuiCosmicos::setCosmicosKeyboard(int Selection)
{
	switch(Selection)
	{
		case KEYBOARDNONE:
			elfConfiguration[COSMICOS].useHexKeyboardEf3 = false;
			elfConfiguration[COSMICOS].useKeyboard = false;
			elfConfiguration[COSMICOS].UsePS2 = false;
			elfConfiguration[COSMICOS].usePs2gpio = false;
			XRCCTRL(*this,"KeyMapCosmicos", wxButton)->Enable(false);
		break;
		case KEYBOARDHEXCOSMICOS:
			elfConfiguration[COSMICOS].useHexKeyboardEf3 = true;
			elfConfiguration[COSMICOS].useKeyboard = false;
			elfConfiguration[COSMICOS].UsePS2 = false;
			elfConfiguration[COSMICOS].usePs2gpio = false;
			XRCCTRL(*this,"KeyMapCosmicos", wxButton)->Enable(true);
		break;
	}
}

void GuiCosmicos::setCosmicosVideoType(int Selection)
{
	switch(Selection)
	{
		case VIDEONONE:
			elfConfiguration[COSMICOS].usePixie = false;
			elfConfiguration[COSMICOS].use6845 = false;
			elfConfiguration[COSMICOS].useS100 = false;
			elfConfiguration[COSMICOS].use6847 = false;
			elfConfiguration[COSMICOS].useTMS9918 = false;
			elfConfiguration[COSMICOS].use8275 = false;
			XRCCTRL(*this, "VTTypeCosmicos", wxChoice)->Enable(true);
			XRCCTRL(*this, "VTTextCosmicos", wxStaticText)->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
			baudTextR[COSMICOS]->Enable((elfConfiguration[COSMICOS].vtType != VTNONE) && elfConfiguration[COSMICOS].useUart);
			baudChoiceR[COSMICOS]->Enable((elfConfiguration[COSMICOS].vtType != VTNONE) && elfConfiguration[COSMICOS].useUart);
			baudTextT[COSMICOS]->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
			baudChoiceT[COSMICOS]->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
			XRCCTRL(*this, "VtSetupCosmicos", wxButton)->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
			XRCCTRL(*this, "ZoomValueCosmicos", wxTextCtrl)->Enable(false);
			XRCCTRL(*this, "ZoomSpinCosmicos", wxSpinButton)->Enable(false);
			XRCCTRL(*this, "ZoomTextCosmicos", wxStaticText)->Enable(false);
		break;

		case VIDEOPIXIE:
			elfConfiguration[COSMICOS].usePixie = true;
			elfConfiguration[COSMICOS].use6845 = false;
			elfConfiguration[COSMICOS].useS100 = false;
			elfConfiguration[COSMICOS].use6847 = false;
			elfConfiguration[COSMICOS].useTMS9918 = false;
			elfConfiguration[COSMICOS].use8275 = false;
			XRCCTRL(*this, "VTTypeCosmicos", wxChoice)->Enable(true);
			XRCCTRL(*this, "VTTextCosmicos", wxStaticText)->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
			baudTextR[COSMICOS]->Enable((elfConfiguration[COSMICOS].vtType != VTNONE) && elfConfiguration[COSMICOS].useUart);
			baudChoiceR[COSMICOS]->Enable((elfConfiguration[COSMICOS].vtType != VTNONE) && elfConfiguration[COSMICOS].useUart);
			baudTextT[COSMICOS]->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
			baudChoiceT[COSMICOS]->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
			XRCCTRL(*this, "VtSetupCosmicos", wxButton)->Enable(elfConfiguration[COSMICOS].vtType != VTNONE);
			XRCCTRL(*this, "ZoomValueCosmicos", wxTextCtrl)->Enable(true);
			XRCCTRL(*this, "ZoomSpinCosmicos", wxSpinButton)->Enable(true);
			XRCCTRL(*this, "ZoomTextCosmicos", wxStaticText)->Enable(true);
		break;
	}
}

void GuiCosmicos::onCosmicosHex(wxCommandEvent&event)
{
	elfConfiguration[COSMICOS].useHex = event.IsChecked();
	if (runningComputer_ == COSMICOS)
		p_Cosmicos->showModules(elfConfiguration[COSMICOS].useHex);
}

void GuiCosmicos::setBaudChoiceCosmicos()
{
	wxString choices[16];
	wxPoint position;
	position = XRCCTRL(*this, "VTTypeCosmicos", wxChoice)->GetPosition();

#if defined(__WXGTK__)
	int offSetX = 8;
	int offSetY = 3;
#else
	int offSetX = 4;
	int offSetY = 0;
#endif

	if (elfConfiguration[COSMICOS].useUart)
	{
		choices[0] = "19200";
		choices[1] = "9600";
		choices[2] = "4800";
		choices[3] = "3600";
		choices[4] = "2400";
		choices[5] = "2000";
		choices[6] = "1800";
		choices[7] = "1200";
		choices[8] = "600";
		choices[9] = "300";
		choices[10] = "200";
		choices[11] = "150";
		choices[12] = "134";
		choices[13] = "110";
		choices[14] = "75";
		choices[15] = "50";
		baudTextT[COSMICOS] = new wxStaticText(XRCCTRL(*this, "PanelCosmicos", wxPanel), wxID_ANY, "T:", wxPoint(position.x+74+offSetX,position.y+4+offSetY));
		baudChoiceT[COSMICOS] = new wxChoice(XRCCTRL(*this, "PanelCosmicos", wxPanel), GUI_COSMICOS_BAUDT, wxPoint(position.x+84+offSetX,position.y), wxSize(54,23), 16, choices);
		baudTextR[COSMICOS] = new wxStaticText(XRCCTRL(*this, "PanelCosmicos", wxPanel), wxID_ANY, "R:", wxPoint(position.x+142+offSetX,position.y+4+offSetY));
		baudChoiceR[COSMICOS] = new wxChoice(XRCCTRL(*this, "PanelCosmicos", wxPanel), GUI_COSMICOS_BAUDR, wxPoint(position.x+152+offSetX,position.y), wxSize(54,23), 16, choices);
	}
	else
	{
		choices[0] = "2400";
		choices[1] = "2000";
		choices[2] = "1800";
		choices[3] = "1200";
		choices[4] = "600";
		choices[5] = "300";
		baudTextT[COSMICOS] = new wxStaticText(XRCCTRL(*this, "PanelCosmicos", wxPanel), wxID_ANY, "T/R:", wxPoint(position.x+64+offSetX,position.y+4+offSetY));
		baudChoiceT[COSMICOS] = new wxChoice(XRCCTRL(*this, "PanelCosmicos", wxPanel), GUI_COSMICOS_BAUDT, wxPoint(position.x+84+offSetX,position.y), wxSize(54,23), 6, choices);
		baudTextR[COSMICOS] = new wxStaticText(XRCCTRL(*this, "PanelCosmicos", wxPanel), wxID_ANY, "R:", wxPoint(position.x+142+offSetX,position.y+4+offSetY));
		baudChoiceR[COSMICOS] = new wxChoice(XRCCTRL(*this, "PanelCosmicos", wxPanel), GUI_COSMICOS_BAUDR, wxPoint(position.x+152+offSetX,position.y), wxSize(54,23), 6, choices);
		baudTextR[COSMICOS]->Enable(false);
		baudChoiceR[COSMICOS]->Enable(false);
	}
	this->Connect(GUI_COSMICOS_BAUDR, wxEVT_COMMAND_CHOICE_SELECTED , wxCommandEventHandler(GuiCosmicos::onCosmicosBaudR) );
	this->Connect(GUI_COSMICOS_BAUDT, wxEVT_COMMAND_CHOICE_SELECTED , wxCommandEventHandler(GuiCosmicos::onCosmicosBaudT) );
}

void GuiCosmicos::onRam(wxSpinEvent&event)
{
	int ram = event.GetPosition();

	switch (ram&0x3)
	{
		case 0:
			return;
		break;

		case 1:
			ram += 3;
		break;

		case 2:
			ram += 2;
		break;

		case 3:
			ram -= 3;
		break;
	}

	if (ram < 0)
		ram = 0;
	if (ram > 48)
		ram = 48;

	XRCCTRL(*this, "RamCosmicos", wxSpinCtrl)->SetValue(ram);
}
