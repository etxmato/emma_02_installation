/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guielf2k.h"

BEGIN_EVENT_TABLE(GuiMembership, GuiStudio2)

	EVT_BUTTON(XRCID("RomButtonMembership"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("RomMembership"), GuiMembership::onRomEvent)
	EVT_BUTTON(XRCID("VtCharRomButtonMembership"), GuiMain::onVtCharRom)
	EVT_CHOICE(XRCID("VTTypeMembership"), GuiMain::onVT100)
	EVT_SPIN_UP(XRCID("ZoomSpinVtMembership"), GuiMain::onZoomUpVt)
	EVT_SPIN_DOWN(XRCID("ZoomSpinVtMembership"), GuiMain::onZoomDownVt)
	EVT_TEXT(XRCID("ZoomValueVtMembership"), GuiMain::onZoomValueVt)
	EVT_BUTTON(XRCID("FullScreenF3Membership"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("ColoursMembership"), Main::onColoursDef)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeMembership"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeMembership"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonMembership"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Membership"), GuiMain::onScreenDump)
	EVT_BUTTON(XRCID("DP_ButtonMembership"), GuiMain::onDp)
	EVT_BUTTON(XRCID("SaveButtonMembership"), GuiMain::onSaveButton)
	EVT_BUTTON(XRCID("LoadButtonMembership"), GuiMain::onLoadButton)
	EVT_TEXT(XRCID("ClockMembership"), GuiMain::onClock)
	EVT_CHECKBOX(XRCID("StretchDotMembership"), GuiMain::onStretchDot)
	EVT_BUTTON(XRCID("KeyMapMembership"), Main::onHexKeyDef)
	EVT_CHECKBOX(XRCID("AutoBootMembership"), GuiElf::onAutoBoot)
	EVT_BUTTON(XRCID("VtSetupMembership"), GuiMain::onVtSetup)
	EVT_TEXT(XRCID("ShowAddressMembership"), GuiMain::onLedTimer)
	EVT_CHECKBOX(XRCID("ClearRamMembership"), GuiMain::onClearRam)

	EVT_CHECKBOX(XRCID("ForceUCMembership"), GuiMembership::onMembershipForceUpperCase)
	EVT_CHECKBOX(XRCID("ControlWindowsMembership"), GuiMembership::onMembershipControlWindows)
	EVT_CHOICE(XRCID("RamMembership"), GuiMembership::onRam)
	EVT_CHECKBOX(XRCID("NvrMembership"), GuiMembership::onNvrMembership)

END_EVENT_TABLE()

GuiMembership::GuiMembership(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiStudio2(title, pos, size)
{
}

void GuiMembership::readMembershipConfig()
{
	bool forceUpperCase, stretchDot, romMode;
	selectedComputer_ = MEMBER;

	getConfigBool("/Membership/SerialLog", false);
	getConfigBool("/Membership/VtEf", false);
	elfConfiguration[MEMBER].useUart = false;
	conf[MEMBER].romDir_[MAINROM] = configPointer->Read("/Membership/RomDir", dataDir_ + "Membership" + pathSeparator_);

	configPointer->Read("/Membership/LoadromMode", &romMode, false);
	if (romMode)
		loadromMode_ = RAM;
	else
		loadromMode_ = ROM;
	onRom();

	conf[MEMBER].ramDir_ = configPointer->Read("/Membership/RamDir", dataDir_ + "Membership" + pathSeparator_);
	conf[MEMBER].mainDir_ = configPointer->Read("/Membership/Dir", dataDir_ + "Membership" + pathSeparator_);
	conf[MEMBER].vtCharRomDir_ = configPointer->Read("/Membership/VtCharRomDir", dataDir_ + "Membership" + pathSeparator_);
	XRCCTRL(*this, "VTTypeMembership", wxChoice)->SetSelection(configPointer->Read("/Membership/VTType", 0l));
	setBaudChoiceMembership();
	elfConfiguration[MEMBER].baudR = configPointer->Read("/Membership/BaudR", 5l);
	baudChoiceR[MEMBER]->SetSelection(elfConfiguration[MEMBER].baudR);
	elfConfiguration[MEMBER].baudT = configPointer->Read("/Membership/BaudT", 5l);
	baudChoiceT[MEMBER]->SetSelection(elfConfiguration[MEMBER].baudT);
	setVtType("Membership", MEMBER, XRCCTRL(*this, "VTTypeMembership", wxChoice)->GetSelection());
	baudTextR[MEMBER]->Enable((elfConfiguration[MEMBER].vtType != VTNONE) && elfConfiguration[MEMBER].useUart);
	baudChoiceR[MEMBER]->Enable((elfConfiguration[MEMBER].vtType != VTNONE) && elfConfiguration[MEMBER].useUart);
	baudTextT[MEMBER]->Enable(elfConfiguration[MEMBER].vtType != VTNONE);
	baudChoiceT[MEMBER]->Enable(elfConfiguration[MEMBER].vtType != VTNONE);
	configPointer->Read("/Membership/ForceUC", &forceUpperCase, true);
	XRCCTRL(*this, "ForceUCMembership", wxCheckBox)->SetValue(forceUpperCase);
	XRCCTRL(*this, "MainRomMembership", wxComboBox)->SetValue(configPointer->Read("/Membership/MainRom", "program3.bin"));
	XRCCTRL(*this, "VtCharRomMembership", wxComboBox)->SetValue(configPointer->Read("/Membership/VtCharRom", "vt52.a.bin"));
	XRCCTRL(*this, "VtCharRomButtonMembership", wxButton)->Enable(elfConfiguration[MEMBER].vtType != VTNONE);
	XRCCTRL(*this, "VtCharRomMembership", wxComboBox)->Enable(elfConfiguration[MEMBER].vtType != VTNONE);
	XRCCTRL(*this, "VtSetupMembership", wxButton)->Enable(elfConfiguration[MEMBER].vtType != VTNONE);
	configPointer->Read("/Membership/AutoBoot", &elfConfiguration[MEMBER].autoBoot, true);
	XRCCTRL(*this, "AutoBootMembership", wxCheckBox)->SetValue(elfConfiguration[MEMBER].autoBoot);
	XRCCTRL(*this, "BootAddressMembership", wxTextCtrl)->SetValue(configPointer->Read("/Membership/BootAddress", "0000"));

	wxString defaultZoom;
	defaultZoom.Printf("%2.2f", 1.0);
	conf[MEMBER].zoomVt_ = configPointer->Read("/Membership/ZoomVt", defaultZoom);
	XRCCTRL(*this, "ZoomValueVtMembership", wxTextCtrl)->ChangeValue(conf[MEMBER].zoomVt_);

	configPointer->Read("/Membership/ControlWindows", &elfConfiguration[MEMBER].useElfControlWindows, true);
	XRCCTRL(*this, "ControlWindowsMembership", wxCheckBox)->SetValue(elfConfiguration[MEMBER].useElfControlWindows);
	configPointer->Read("/Membership/StretchDot", &stretchDot, false);
	XRCCTRL(*this, "StretchDotMembership", wxCheckBox)->SetValue(stretchDot);
	XRCCTRL(*this, "RamMembership", wxChoice)->SetSelection(configPointer->Read("/Membership/Ram", 03));

	XRCCTRL(*this, "ScreenDumpFileMembership", wxComboBox)->SetValue(configPointer->Read("/Membership/ScreenDumpFile", "screendump.png"));
	conf[MEMBER].screenDumpFileDir_ = configPointer->Read("/Membership/ScreenDumpFileDir", dataDir_ + "Membership" + pathSeparator_);

	conf[MEMBER].volume_ = configPointer->Read("/Membership/Volume", 25l);
	XRCCTRL(*this, "VolumeMembership", wxSlider)->SetValue(conf[MEMBER].volume_);

	conf[MEMBER].vtX_ = configPointer->Read("/Membership/VtX", mainWindowX_+windowInfo.mainwX);
	conf[MEMBER].vtY_ = configPointer->Read("/Membership/VtY", mainWindowY_);
	conf[MEMBER].mainX_ = configPointer->Read("/Membership/MembershipX", mainWindowX_);
	conf[MEMBER].mainY_ = configPointer->Read("/Membership/MembershipY", mainWindowY_+windowInfo.mainwY);

	wxString defaultClock;
	defaultClock.Printf("%1.2f", 1.75);
	conf[MEMBER].clock_ = configPointer->Read("/Membership/Clock", defaultClock);
	XRCCTRL(*this, "ClockMembership", wxTextCtrl)->ChangeValue(conf[MEMBER].clock_);

	configPointer->Read("/Membership/Nvr", &elfConfiguration[MEMBER].nvr, true);
	XRCCTRL(*this, "NvrMembership", wxCheckBox)->SetValue(elfConfiguration[MEMBER].nvr);
	XRCCTRL(*this, "ClearRamMembership", wxCheckBox)->Enable(elfConfiguration[MEMBER].nvr);
	elfConfiguration[MEMBER].clearRam = false;
	XRCCTRL(*this, "ClearRamMembership", wxCheckBox)->SetValue(elfConfiguration[MEMBER].clearRam);

	wxString defaultTimer;
	defaultTimer.Printf("%d", 100);
	elfConfiguration[MEMBER].ledTime = configPointer->Read("/Membership/ShowAddressMs", defaultTimer);
	XRCCTRL(*this, "ShowAddressMembership", wxTextCtrl)->ChangeValue(elfConfiguration[MEMBER].ledTime);

	elfConfiguration[MEMBER].usePortExtender = false;
	elfConfiguration[MEMBER].ideEnabled = false;
	elfConfiguration[MEMBER].fdcEnabled = false;
	elfConfiguration[MEMBER].useLedModule = false;
	elfConfiguration[MEMBER].useTape = false;
}

void GuiMembership::writeMembershipConfig()
{
	configPointer->Write("/Membership/RomDir", conf[MEMBER].romDir_[MAINROM]);
	configPointer->Write("/Membership/LoadromMode", (loadromMode_ == ROM));
	configPointer->Write("/Membership/RamDir", conf[MEMBER].ramDir_);
	configPointer->Write("/Membership/Dir", conf[MEMBER].mainDir_);
	configPointer->Write("/Membership/VtCharRomDir", conf[MEMBER].vtCharRomDir_);
	configPointer->Write("/Membership/MainRom", XRCCTRL(*this, "MainRomMembership", wxComboBox)->GetValue());
	configPointer->Write("/Membership/VtCharRom", XRCCTRL(*this, "VtCharRomMembership", wxComboBox)->GetValue());
	configPointer->Write("/Membership/VTType", XRCCTRL(*this, "VTTypeMembership", wxChoice)->GetSelection());
	configPointer->Write("/Membership/BaudR", baudChoiceR[MEMBER]->GetSelection());
	configPointer->Write("/Membership/BaudT", baudChoiceT[MEMBER]->GetSelection());
	configPointer->Write("/Membership/AutoBoot", XRCCTRL(*this, "AutoBootMembership", wxCheckBox)->GetValue());
	configPointer->Write("/Membership/BootAddress", XRCCTRL(*this, "BootAddressMembership", wxTextCtrl)->GetValue());
	configPointer->Write("/Membership/Zoom", conf[MEMBER].zoom_);
	configPointer->Write("/Membership/ForceUC", XRCCTRL(*this, "ForceUCMembership", wxCheckBox)->GetValue());
	configPointer->Write("/Membership/ControlWindows", XRCCTRL(*this, "ControlWindowsMembership", wxCheckBox)->GetValue());
	configPointer->Write("/Membership/StretchDot", XRCCTRL(*this, "StretchDotMembership", wxCheckBox)->GetValue());
	configPointer->Write("/Membership/Ram", XRCCTRL(*this, "RamMembership", wxChoice)->GetSelection());
	configPointer->Write("/Membership/ScreenDumpFile", XRCCTRL(*this, "ScreenDumpFileMembership", wxComboBox)->GetValue());
	configPointer->Write("/Membership/ScreenDumpFileDir", conf[MEMBER].screenDumpFileDir_);
	configPointer->Write("/Membership/Volume", XRCCTRL(*this, "VolumeMembership", wxSlider)->GetValue());
	configPointer->Write("/Membership/Nvr", XRCCTRL(*this, "NvrMembership", wxCheckBox)->GetValue());
	configPointer->Write("/Membership/ShowAddressMs", elfConfiguration[MEMBER].ledTime);

	if (conf[MEMBER].vtX_ > 0)
		configPointer->Write("/Membership/VtX", conf[MEMBER].vtX_);
	if (conf[MEMBER].vtY_ > 0)
		configPointer->Write("/Membership/VtY", conf[MEMBER].vtY_);
	if (conf[MEMBER].mainX_ > 0)
		configPointer->Write("/Membership/MembershipX", conf[MEMBER].mainX_);
	if (conf[MEMBER].mainY_ > 0)
		configPointer->Write("/Membership/MembershipY", conf[MEMBER].mainY_);

	configPointer->Write("/Membership/Clock", conf[MEMBER].clock_);

	delete baudChoiceR[MEMBER];
	delete baudChoiceT[MEMBER];
}

void GuiMembership::onMembershipBaudR(wxCommandEvent&event)
{
	elfConfiguration[MEMBER].baudR = event.GetSelection();
}

void GuiMembership::onMembershipBaudT(wxCommandEvent&event)
{
	elfConfiguration[MEMBER].baudT = event.GetSelection();
	if (!elfConfiguration[MEMBER].useUart)
	{
		elfConfiguration[MEMBER].baudR = event.GetSelection();
		baudChoiceR[MEMBER]->SetSelection(elfConfiguration[MEMBER].baudR);
	}
}

void GuiMembership::onMembershipForceUpperCase(wxCommandEvent&event)
{
	if (runningComputer_ == MEMBER)
	{
		p_Membership->setForceUpperCase(event.IsChecked());
	}
}

void GuiMembership::onMembershipControlWindows(wxCommandEvent&event)
{
	elfConfiguration[MEMBER].useElfControlWindows = event.IsChecked();
	XRCCTRL(*this,"ShowAddressMembership",wxTextCtrl)->Enable(elfConfiguration[MEMBER].useElfControlWindows);
	XRCCTRL(*this,"AddressText1Membership",wxStaticText)->Enable(elfConfiguration[MEMBER].useElfControlWindows);
	XRCCTRL(*this,"AddressText2Membership",wxStaticText)->Enable(elfConfiguration[MEMBER].useElfControlWindows);
	if (runningComputer_ == MEMBER)
		p_Membership->Show(elfConfiguration[MEMBER].useElfControlWindows);
}

void GuiMembership::setBaudChoiceMembership()
{
	wxString choices[16];
	wxPoint position;
	position = XRCCTRL(*this, "VTTypeMembership", wxChoice)->GetPosition();

#if defined(__WXGTK__)
	int offSetX = 8;
	int offSetY = 3;
#else
	int offSetX = 4;
	int offSetY = 0;
#endif

	if (elfConfiguration[MEMBER].useUart)
	{
		choices[0] = "19200";
		choices[1] = "9600";
		choices[2] = "4800";
		choices[3] = "3600";
		choices[4] = "2400";
		choices[5] = "2000";
		choices[6] = "1800";
		choices[7] = "1200";
		choices[8] = "600";
		choices[9] = "300";
		choices[10] = "200";
		choices[11] = "150";
		choices[12] = "134";
		choices[13] = "110";
		choices[14] = "75";
		choices[15] = "50";
		baudTextT[MEMBER] = new wxStaticText(XRCCTRL(*this, "PanelMembership", wxPanel), wxID_ANY, "T:", wxPoint(position.x+74+offSetX,position.y+4+offSetY));
		baudChoiceT[MEMBER] = new wxChoice(XRCCTRL(*this, "PanelMembership", wxPanel), GUI_MEMBER_BAUDT, wxPoint(position.x+84+offSetX,position.y), wxSize(54,23), 16, choices);
		baudTextR[MEMBER] = new wxStaticText(XRCCTRL(*this, "PanelMembership", wxPanel), wxID_ANY, "R:", wxPoint(position.x+142+offSetX,position.y+4+offSetY));
		baudChoiceR[MEMBER] = new wxChoice(XRCCTRL(*this, "PanelMembership", wxPanel), GUI_MEMBER_BAUDR, wxPoint(position.x+152+offSetX,position.y), wxSize(54,23), 16, choices);
	}
	else
	{
		choices[0] = "2400";
		choices[1] = "2000";
		choices[2] = "1800";
		choices[3] = "1200";
		choices[4] = "600";
		choices[5] = "300";
		baudTextT[MEMBER] = new wxStaticText(XRCCTRL(*this, "PanelMembership", wxPanel), wxID_ANY, "T/R:", wxPoint(position.x+64+offSetX,position.y+4+offSetY));
		baudChoiceT[MEMBER] = new wxChoice(XRCCTRL(*this, "PanelMembership", wxPanel), GUI_MEMBER_BAUDT, wxPoint(position.x+84+offSetX,position.y), wxSize(54,23), 6, choices);
		baudTextR[MEMBER] = new wxStaticText(XRCCTRL(*this, "PanelMembership", wxPanel), wxID_ANY, "R:", wxPoint(position.x+142+offSetX,position.y+4+offSetY));
		baudChoiceR[MEMBER] = new wxChoice(XRCCTRL(*this, "PanelMembership", wxPanel), GUI_MEMBER_BAUDR, wxPoint(position.x+152+offSetX,position.y), wxSize(54,23), 6, choices);
		baudTextR[MEMBER]->Enable(false);
		baudChoiceR[MEMBER]->Enable(false);
	}
	this->Connect(GUI_MEMBER_BAUDR, wxEVT_COMMAND_CHOICE_SELECTED , wxCommandEventHandler(GuiMembership::onMembershipBaudR) );
	this->Connect(GUI_MEMBER_BAUDT, wxEVT_COMMAND_CHOICE_SELECTED , wxCommandEventHandler(GuiMembership::onMembershipBaudT) );
}

void GuiMembership::onRam(wxCommandEvent&WXUNUSED(event))
{
	XRCCTRL(*this, "ClearRamMembership", wxCheckBox)->SetValue(true);
	elfConfiguration[MEMBER].clearRam = true;
}

void GuiMembership::onRomEvent(wxCommandEvent&WXUNUSED(event))
{
	onRom();
}

void GuiMembership::onRom()
{
	if (loadromMode_ == ROM)
	{
		loadromMode_ = RAM;
		XRCCTRL(*this, "RomButtonMembership", wxButton)->SetLabel("RAM");
		XRCCTRL(*this, "RomButtonMembership", wxButton)->SetToolTip("Browse for Membership Card RAM file");
	}
	else
	{
		loadromMode_ = ROM;
		XRCCTRL(*this, "RomButtonMembership", wxButton)->SetLabel("ROM");
		XRCCTRL(*this, "RomButtonMembership", wxButton)->SetToolTip("Browse for Membership Card ROM file");
	}
}

int GuiMembership::getLoadromModeMembership()
{
	return loadromMode_;
}

void GuiMembership::onNvrMembership(wxCommandEvent&event)
{
	elfConfiguration[MEMBER].nvr = event.IsChecked();
	XRCCTRL(*this, "ClearRamMembership", wxCheckBox)->Enable(event.IsChecked());
}

