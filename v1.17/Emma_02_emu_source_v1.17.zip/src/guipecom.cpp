/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guipecom.h"
#include "psave.h"

BEGIN_EVENT_TABLE(GuiPecom, GuiMain)

	EVT_BUTTON(XRCID("RomButtonPecom"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonPecom"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Pecom"), GuiMain::onScreenDump)
	EVT_SPIN_UP(XRCID("ZoomSpinPecom"), GuiMain::onZoomUp)
	EVT_SPIN_DOWN(XRCID("ZoomSpinPecom"), GuiMain::onZoomDown)
	EVT_TEXT(XRCID("ZoomValuePecom"), GuiMain::onZoomValue)
	EVT_BUTTON(XRCID("FullScreenF3Pecom"), GuiMain::onFullScreen)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumePecom"), GuiMain::onVolume) 
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumePecom"), GuiMain::onVolume) 
	EVT_TEXT(XRCID("ClockPecom"), GuiMain::onClock)
	EVT_BUTTON(XRCID("CasButtonPecom"), GuiMain::onCassette)
	EVT_BUTTON(XRCID("EjectCasPecom"), GuiMain::onCassetteEject)
	EVT_TEXT(XRCID("WavFilePecom"), GuiMain::onCassetteText)
	EVT_BUTTON(XRCID("RealCasLoadPecom"), GuiMain::onRealCas)
	EVT_BUTTON(XRCID("CasLoadPecom"), GuiMain::onCassetteLoad)
	EVT_BUTTON(XRCID("CasSavePecom"), GuiMain::onCassetteSave)
	EVT_BUTTON(XRCID("CasStopPecom"), GuiMain::onCassetteStop)
	EVT_CHECKBOX(XRCID("TurboPecom"), GuiMain::onTurbo)
	EVT_TEXT(XRCID("TurboClockPecom"), GuiMain::onTurboClock)
	EVT_CHECKBOX(XRCID("AutoCasLoadPecom"), GuiMain::onAutoLoad)
	EVT_BUTTON(XRCID("PrintFileButtonPecom"), GuiMain::onPrintFile)
	EVT_TEXT(XRCID("PrintFilePecom"), GuiMain::onPrintFileText)
	EVT_BUTTON(XRCID("PrintButtonPecom"), GuiMain::onPrintButton)
	EVT_CHOICE(XRCID("PrintModePecom"), GuiMain::onPrintMode)
	EVT_BUTTON(XRCID("KeyFileButtonPecom"), GuiMain::onKeyFile)
	EVT_BUTTON(XRCID("EjectKeyFilePecom"), GuiMain::onKeyFileEject)
	EVT_CHECKBOX(XRCID("UseLocationPecom"), GuiMain::onUseLocation)
	EVT_BUTTON(XRCID("SaveButtonPecom"), GuiMain::onSaveButton) 
	EVT_BUTTON(XRCID("LoadButtonPecom"), GuiMain::onLoadButton)
	EVT_BUTTON(XRCID("RunButtonPecom"), GuiMain::onPloadRun)
	EVT_BUTTON(XRCID("DsaveButtonPecom"), GuiMain::onDsave)
	EVT_COMMAND(wxID_ANY, OPEN_PRINTER_WINDOW, GuiMain::openPrinterFrame) 
	EVT_BUTTON(XRCID("ColoursPecom"), Main::onColoursDef)

END_EVENT_TABLE()

GuiPecom::GuiPecom(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiMain(title, pos, size)
{
	conf[PECOM].loadFileNameFull_ = "";
	conf[PECOM].loadFileName_ = "";

	conf[PECOM].pLoadSaveName_[0] = 'P';
	conf[PECOM].pLoadSaveName_[1] = '-';
	conf[PECOM].pLoadSaveName_[2] = '6';
	conf[PECOM].pLoadSaveName_[3] = '4';

	conf[PECOM].defus_ = 0x81;
	conf[PECOM].eop_ = 0x83;
	conf[PECOM].string_ = 0x92;
	conf[PECOM].arrayValue_ = 0x94;
	conf[PECOM].eod_ = 0x99;
	conf[PECOM].basicRamAddress_ = 0x200;
}

void GuiPecom::readPecomConfig()
{
	bool turbo;
	selectedComputer_ = PECOM;

	XRCCTRL(*this, "MainRomPecom", wxComboBox)->SetValue(configPointer->Read("/Pecom/PecomMainRom", "pecom64.v4.bin"));
	wxString defaultZoom;
	defaultZoom.Printf("%2.2f", 2.0);
	conf[PECOM].zoom_ = configPointer->Read("/Pecom/Zoom", defaultZoom);
	XRCCTRL(*this, "ZoomValuePecom", wxTextCtrl)->ChangeValue(conf[PECOM].zoom_);
	conf[PECOM].volume_ = configPointer->Read("/Pecom/PecomVolume", 25l);
	XRCCTRL(*this, "VolumePecom", wxSlider)->SetValue(conf[PECOM].volume_);
	conf[PECOM].romDir_[MAINROM] = configPointer->Read("/Pecom/PecomRomDir", dataDir_ + "Pecom" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFilePecom", wxComboBox)->SetValue(configPointer->Read("/Pecom/PecomScreenDumpFile", "screendump.png"));
	conf[PECOM].screenDumpFileDir_ = configPointer->Read("/Pecom/PecomScreenDumpFileDir", dataDir_ + "Pecom" + pathSeparator_); 
	conf[PECOM].ramDir_ = configPointer->Read("/Pecom/PecomSWDir", dataDir_ + "Pecom" + pathSeparator_); 

	conf[PECOM].mainX_ = configPointer->Read("/Pecom/PecomX", mainWindowX_+windowInfo.mainwX); 
	conf[PECOM].mainY_ = configPointer->Read("/Pecom/PecomY", mainWindowY_); 

	wxString defaultClock;
	defaultClock.Printf("%1.3f", 2.813);
	conf[PECOM].clock_ = configPointer->Read("/Pecom/Clock", defaultClock);
	XRCCTRL(*this, "ClockPecom", wxTextCtrl)->ChangeValue(conf[PECOM].clock_);
	conf[PECOM].wavFile_ = configPointer->Read("/Pecom/WavFile", "");
	XRCCTRL(*this, "WavFilePecom", wxTextCtrl)->SetValue(conf[PECOM].wavFile_);
	conf[PECOM].wavFileDir_ = configPointer->Read("/Pecom/WavFileDir", dataDir_ + "Pecom" + pathSeparator_); 
	configPointer->Read("/Pecom/PecomTurbo", &turbo, true);
	XRCCTRL(*this, "TurboPecom", wxCheckBox)->SetValue(turbo);
	turboGui("Pecom");
	conf[PECOM].turboClock_ = configPointer->Read("/Pecom/PecomTurboClock", "15"); 
	XRCCTRL(*this, "TurboClockPecom", wxTextCtrl)->SetValue(conf[PECOM].turboClock_);
	configPointer->Read("/Pecom/PecomAutoCasLoad", &conf[PECOM].autoCassetteLoad_, true);
	XRCCTRL(*this, "AutoCasLoadPecom", wxCheckBox)->SetValue(conf[PECOM].autoCassetteLoad_);
	configPointer->Read("/Pecom/RealCasLoad", &conf[PECOM].realCassetteLoad_, false);
	setRealCas(PECOM);

	XRCCTRL(*this, "PrintFilePecom", wxTextCtrl)->SetValue(configPointer->Read("/Pecom/PecomPrintFile", "printerout.txt"));
	conf[PECOM].printFileDir_ = configPointer->Read("/Pecom/PecomPrintFileDir", dataDir_ + "Pecom" + pathSeparator_); 
	XRCCTRL(*this, "PrintModePecom", wxChoice)->SetSelection(configPointer->Read("/Pecom/PecomPrintMode", 1l));
	conf[PECOM].printMode_ = configPointer->Read("/Pecom/PecomPrintMode", 1l);
	setPrintMode();
	conf[PECOM].keyFileDir_ = configPointer->Read("/Pecom/PecomKeyFileDir", dataDir_ + "Pecom" + pathSeparator_);
	conf[PECOM].keyFile_ = configPointer->Read("/Pecom/PecomKeyFile", "");
	XRCCTRL(*this, "KeyFilePecom", wxTextCtrl)->SetValue(conf[PECOM].keyFile_);
	XRCCTRL(*this, "UseLocationPecom", wxCheckBox)->SetValue(false);
	conf[PECOM].useLoadLocation_ = false;
}

void GuiPecom::writePecomConfig()
{
	configPointer->Write("/Pecom/PecomMainRom", XRCCTRL(*this, "MainRomPecom", wxComboBox)->GetValue());
	configPointer->Write("/Pecom/Zoom", conf[PECOM].zoom_);
	configPointer->Write("/Pecom/PecomVolume", XRCCTRL(*this, "VolumePecom", wxSlider)->GetValue());
	configPointer->Write("/Pecom/PecomRomDir", conf[PECOM].romDir_[MAINROM]);
	configPointer->Write("/Pecom/PecomScreenDumpFile", XRCCTRL(*this, "ScreenDumpFilePecom", wxComboBox)->GetValue());
	configPointer->Write("/Pecom/PecomScreenDumpFileDir", conf[PECOM].screenDumpFileDir_);
	configPointer->Write("/Pecom/PecomSWDir", conf[PECOM].ramDir_);

	if (conf[PECOM].mainX_ > 0)
		configPointer->Write("/Pecom/PecomX", conf[PECOM].mainX_);
	if (conf[PECOM].mainY_ > 0)
		configPointer->Write("/Pecom/PecomY", conf[PECOM].mainY_);

	configPointer->Write("/Pecom/Clock", conf[PECOM].clock_);
	configPointer->Write("/Pecom/PecomWavFile", XRCCTRL(*this, "WavFilePecom", wxTextCtrl)->GetValue());
	configPointer->Write("/Pecom/WavFileDir", conf[PECOM].wavFileDir_);
	configPointer->Write("/Pecom/PecomTurbo", XRCCTRL(*this, "TurboPecom", wxCheckBox)->GetValue());
	configPointer->Write("/Pecom/PecomTurboClock", conf[PECOM].turboClock_); 
	configPointer->Write("/Pecom/PecomAutoCasLoad", XRCCTRL(*this, "AutoCasLoadPecom", wxCheckBox)->GetValue());
	configPointer->Write("/Pecom/RealCasLoad", conf[PECOM].realCassetteLoad_);
	configPointer->Write("/Pecom/PecomPrintFileDir", conf[PECOM].printFileDir_);
	configPointer->Write("/Pecom/PecomPrintMode", conf[PECOM].printMode_);
	configPointer->Write("/Pecom/PecomKeyFileDir", conf[PECOM].keyFileDir_);
	configPointer->Write("/Pecom/PecomKeyFile", XRCCTRL(*this, "KeyFilePecom", wxTextCtrl)->GetValue());
	configPointer->Write("/Pecom/PecomPrintFile", XRCCTRL(*this, "PrintFilePecom", wxTextCtrl)->GetValue());
}