/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "main.h"
#include "victory.h"

Victory::Victory(const wxString& title, const wxPoint& pos, const wxSize& size, double zoom, double zoomfactor, int computerType)
:Pixie(title, pos, size, zoom, zoomfactor, computerType)
{
}

Victory::~Victory()
{
	p_Main->setMainPos(VICTORY, GetPosition());
}

void Victory::configureComputer()
{
	chip8baseVar_ = 0x8c0;
	chip8mainLoop_ = 0x6b;
	chip8type_ = CHIPST2;

	outType_[1] = STUDIOOUT;
	outType_[3] = VIPOUT4;
	victoryKeyPort_ = 0;
	efType_[3] = STUDIOEF3;
	efType_[4] = STUDIOEF4;

	for (int j=0; j<2; j++) for (int i=0; i<10; i++)
		victoryKeyState_[j][i] = 0;

	p_Main->message("Configuring Victory MPT-02");
	p_Main->message("	Output 2: select port, EF 3: read selected port 1, EF4: read selected port 2\n");

	keyDefA_[0] = p_Main->getConfigItem("/Victory/HexKeyA0", 88);
	keyDefA_[1] = p_Main->getConfigItem("/Victory/HexKeyA1", 49);
	keyDefA_[2] = p_Main->getConfigItem("/Victory/HexKeyA2", 50);
	keyDefA_[3] = p_Main->getConfigItem("/Victory/HexKeyA3", 51);
	keyDefA_[4] = p_Main->getConfigItem("/Victory/HexKeyA4", 81);
	keyDefA_[5] = p_Main->getConfigItem("/Victory/HexKeyA5", 87);
	keyDefA_[6] = p_Main->getConfigItem("/Victory/HexKeyA6", 69);
	keyDefA_[7] = p_Main->getConfigItem("/Victory/HexKeyA7", 65);
	keyDefA_[8] = p_Main->getConfigItem("/Victory/HexKeyA8", 83);
	keyDefA_[9] = p_Main->getConfigItem("/Victory/HexKeyA9", 68);

	keyDefB_[0] = p_Main->getConfigItem("/Victory/HexKeyB0", WXK_NUMPAD0);
	keyDefB_[1] = p_Main->getConfigItem("/Victory/HexKeyB1", WXK_NUMPAD7);
	keyDefB_[2] = p_Main->getConfigItem("/Victory/HexKeyB2", WXK_NUMPAD8);
	keyDefB_[3] = p_Main->getConfigItem("/Victory/HexKeyB3", WXK_NUMPAD9);
	keyDefB_[4] = p_Main->getConfigItem("/Victory/HexKeyB4", WXK_NUMPAD4);
	keyDefB_[5] = p_Main->getConfigItem("/Victory/HexKeyB5", WXK_NUMPAD5);
	keyDefB_[6] = p_Main->getConfigItem("/Victory/HexKeyB6", WXK_NUMPAD6);
	keyDefB_[7] = p_Main->getConfigItem("/Victory/HexKeyB7", WXK_NUMPAD1);
	keyDefB_[8] = p_Main->getConfigItem("/Victory/HexKeyB8", WXK_NUMPAD2);
	keyDefB_[9] = p_Main->getConfigItem("/Victory/HexKeyB9", WXK_NUMPAD3);

	p_Main->getDefaultGameKeys("Victory", "A", keyDefGameValueA_, keyDefGameHexA_);
	p_Main->getDefaultGameKeys("Victory", "B", keyDefGameValueB_, keyDefGameHexB_);

	if (p_Main->getConfigBool("/Victory/GameAuto", true))
	{
		p_Main->loadKeyDefinition("xxxx", p_Main->getComboValue("CartRomVictory"), keyDefGameHexA_, keyDefGameHexB_);
		p_Main->storeDefaultGameKeys("Victory", "A", keyDefGameValueA_, keyDefGameHexA_);
		p_Main->storeDefaultGameKeys("Victory", "B", keyDefGameValueB_, keyDefGameHexB_);
	}

	for (int i=0; i<512; i++)
	{
		keyDefinition[i].defined = false;
	}
	for (int i=0; i<10; i++)
	{
		keyDefinition[keyDefA_[i]].defined = true;
		keyDefinition[keyDefA_[i]].player = 0;
		keyDefinition[keyDefA_[i]].key = i;

		keyDefinition[keyDefB_[i]].defined = true;
		keyDefinition[keyDefB_[i]].player = 1;
		keyDefinition[keyDefB_[i]].key = i;
	}
	for (int i=0; i<5; i++)
	{
		keyDefinition[keyDefGameValueA_[i]].defined = true;
		keyDefinition[keyDefGameValueA_[i]].player = 0;
		keyDefinition[keyDefGameValueA_[i]].key = keyDefGameHexA_[i];

		keyDefinition[keyDefGameValueB_[i]].defined = true;
		keyDefinition[keyDefGameValueB_[i]].player = 1;
		keyDefinition[keyDefGameValueB_[i]].key = keyDefGameHexB_[i];
	}

	resetCpu();
}

void Victory::reDefineKeysA(int hexKeyDefA[], int keyDefGameValueA[], int keyDefGameHexA[])
{
	for (int i=0; i<512; i++)
	{
		keyDefinition[i].defined = false;
	}
	for (int i=0; i<10; i++)
	{
		keyDefA_[i] = hexKeyDefA[i];
		keyDefinition[keyDefA_[i]].defined = true;
		keyDefinition[keyDefA_[i]].player = 0;
		keyDefinition[keyDefA_[i]].key = i;
	}
	for (int i=0; i<5; i++)
	{
		keyDefGameValueA_[i] = keyDefGameValueA[i];
		keyDefGameHexA_[i] = keyDefGameHexA[i];
		keyDefinition[keyDefGameValueA_[i]].defined = true;
		keyDefinition[keyDefGameValueA_[i]].player = 0;
		keyDefinition[keyDefGameValueA_[i]].key = keyDefGameHexA_[i];
	}
}

void Victory::reDefineKeysB(int hexKeyDefB[], int keyDefGameValueB[], int keyDefGameHexB[])
{
	for (int i=0; i<10; i++)
	{
		keyDefB_[i] = hexKeyDefB[i];
		keyDefinition[keyDefB_[i]].defined = true;
		keyDefinition[keyDefB_[i]].player = 1;
		keyDefinition[keyDefB_[i]].key = i;
	}
	for (int i=0; i<5; i++)
	{
		keyDefGameValueB_[i] = keyDefGameValueB[i];
		keyDefGameHexB_[i] = keyDefGameHexB[i];
		keyDefinition[keyDefGameValueB_[i]].defined = true;
		keyDefinition[keyDefGameValueB_[i]].player = 1;
		keyDefinition[keyDefGameValueB_[i]].key = keyDefGameHexB_[i];
	}
}

void Victory::keyDown(int keycode)
{
	if (keyDefinition[keycode].defined)
		victoryKeyState_[keyDefinition[keycode].player][keyDefinition[keycode].key] = 1;
}

void Victory::keyUp(int keycode)
{
	if (keyDefinition[keycode].defined)
		victoryKeyState_[keyDefinition[keycode].player][keyDefinition[keycode].key] = 0;
}

Byte Victory::ef(int flag)
{
	switch(efType_[flag])
	{
		case 0:
			return 1;
		break;

		case PIXIEEF:
			return efPixie();
		break;

		case STUDIOEF3:
			return ef3();
		break;

		case STUDIOEF4:
			return ef4();
		break;

		default:
			return 1;
	}
}

Byte Victory::ef3()
{
	if (victoryKeyPort_<0 || victoryKeyPort_>9)
		return 1;
	return(victoryKeyState_[0][victoryKeyPort_]) ? 0 : 1;
}

Byte Victory::ef4()
{
	if (victoryKeyPort_<0 || victoryKeyPort_>9)
		return 1;
	return(victoryKeyState_[1][victoryKeyPort_]) ? 0 : 1;
}

Byte Victory::in(Byte port, Word WXUNUSED(address))
{
	Byte ret;

	switch(inType_[port-1])
	{
		case 0:
			ret = 255;
		break;

		case PIXIEIN:
			ret = inPixie();
		break;

		default:
			ret = 255;
	}
	inValues_[port] = ret;
	return ret;
}

void Victory::out(Byte port, Word WXUNUSED(address), Byte value)
{
	outValues_[port] = value;

	switch(outType_[port-1])
	{
		case 0:
			return;
		break;

		case STUDIOOUT:
			outVictory(value);
		break;

		case VIPOUT4:
			tone1864Latch(value);
		break;
	}
}

void Victory::outVictory(Byte value)
{
	victoryKeyPort_ = value & 0xf;
}

void Victory::cycle(int type)
{
	switch(cycleType_[type])
	{
		case 0:
			return;
		break;

		case PIXIECYCLE:
			cyclePixieTelmac();
		break;
	}
}

void Victory::startComputer()
{
	resetPressed_ = false;

	p_Main->setSwName("");
	p_Main->updateTitle();

	for (int i=0xc00; i<0xff00; i+=0x400)
	{
		defineMemoryType(i, MAPPEDRAM);
		defineMemoryType(i+0x100, MAPPEDRAM);
	}
	readProgramCombo(p_Main->getRomDir(VICTORY, MAINROM), "MainRomVictory", ROM, 0, NONAME);
	readSt2Program("CartRomVictory");
	defineMemoryType(0x800, 0x9ff, RAM);
	defineMemoryType(0xa00, 0);
	defineMemoryType(0xb00, COLOURRAM);
	double zoom = p_Main->getZoom();

	for (int i=0; i<64; i++)
		colorMemory1864_[i] = 4;

	configurePixieVictory();
	setZoom(zoom);
	initPixie();
	Show(true);
	setWait(1);
	setClear(0);
	setWait(1);
	setClear(1);

	p_Main->updateTitle();

	cpuCycles_ = 0;
	p_Main->startTime();

	threadPointer->Run();
}

Byte Victory::readMem(Word addr)
{
	address_ = addr;

	switch (memoryType_[addr/256])
	{
		case UNDEFINED:
			return 255;
		break;

		case MAPPEDRAM:
			addr = (addr & 0x1ff) | 0x800;
		break;
	}

	return mainMemory_[addr];
}

void Victory::writeMem(Word addr, Byte value, bool writeRom)
{
	address_ = addr;

	switch (memoryType_[addr/256])
	{
		case RAM:
			if (mainMemory_[addr]==value)
				return;
			mainMemory_[addr]=value;
			if (addr>= memoryStart_ && addr<(memoryStart_+256))
				p_Main->updateDebugMemory(addr);
		break;

		case COLOURRAM:
			colorMemory1864_[addr&0xff] = value &0xf;
			if ((addr&0xff) >= memoryStart_ && (addr&0xff) <(memoryStart_+256))
				p_Main->updateDebugMemory(addr&0xff);
		break;

		case MAPPEDRAM:
			addr = (addr & 0x1ff) | 0x800;
			if (mainMemory_[addr]==value)
				return;
			mainMemory_[addr]=value;
			if (addr>= memoryStart_ && addr<(memoryStart_+256))
				p_Main->updateDebugMemory(addr);
		break;

		default:
			if (writeRom)
				mainMemory_[addr]=value;
		break;
	}
}

void Victory::cpuInstruction()
{
	if (cpuMode_ == RUN)
	{
		if (steps_ != 0)
		{
			cycle0_=0;
			machineCycle();
			if (cycle0_ == 0) machineCycle();
			if (cycle0_ == 0 && steps_ != 0)
			{
				cpuCycle();
				cpuCycles_ += 2;
			}
			if (debugMode_)
				p_Main->showInstructionTrace();
		}
		else
			soundCycle();

		if (resetPressed_)
		{
			resetCpu();
			resetPressed_ = false;
			setWait(1);
			setClear(0);
			setWait(1);
			setClear(1);
			initPixie();
		}
		if (debugMode_)
			p_Main->cycleDebug();
		p_Main->cycleSt2Debug();
	}
	else
	{
		initPixie();;
		cpuCycles_ = 0;
		p_Main->startTime();
	}
}

void Victory::readSt2Program(wxString fileReference)
{
	wxString fileName, file;
	wxFFile inFile;
	struct
	{
		char header[4];
		Byte numBlocks;
		Byte format;
		Byte video;
		Byte notUsed1;
		char author[2];
		char dumper[2];
		Byte notUsed2[4];
		char catalogue[10];
		Byte notUsed3[6];
		char title[32];
		Byte offsets[64];
		Byte notUsed4[128];
	} st2Header;

	fileName = p_Main->getRomDir(VICTORY, CARTROM);
	file = p_Main->getComboValue(fileReference);
	fileName.operator += (file);

	if (file.Len() != 0)
	{
		if (wxFile::Exists(fileName))
		{
			if (inFile.Open(fileName, "rb"))
			{
				inFile.Read(&st2Header, 256);
				for (int i=1; i<st2Header.numBlocks; i++)
				{
					inFile.Read((&mainMemory_[st2Header.offsets[i-1] << 8]),256);
					defineMemoryType(st2Header.offsets[i-1] << 8, CARTRIDGEROM);
				}
				inFile.Close();
				wxFileName swFullPath = wxFileName(fileName, wxPATH_NATIVE);
				p_Main->setSwName (swFullPath.GetName());
			}
			else
			{
				(void)wxMessageBox( "Error reading " + fileName,  // Works correct, via p_Main->errorMessage it will NOT
								    "Emma 02", wxICON_ERROR | wxOK );
			}
		}
		else
		{
			(void)wxMessageBox( "File " + fileName + " not found",// Works correct, via p_Main->errorMessage it will NOT
							    "Emma 02", wxICON_ERROR | wxOK );
		}
	}
}

void Victory::onReset()
{
	resetPressed_ = true;
}
