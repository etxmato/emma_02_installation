#ifndef MAINELF_H
#define MAINELF_H

#include "cdp1802.h"
#include "fdc.h"
#include "ide.h"
#include "keyboard.h"
#include "ps2gpio.h"
#include "portext.h"
#include "printer.h"
#include "ps2.h"
#include "elfconfiguration.h"
#include "vt100.h"

class MainElf : public Cdp1802, public Fdc, public Ide, public Keyboard, public PortExt, public Ps2, public Ps2gpio
{			
public:
	MainElf();
	~MainElf() {};

	void checkElfFunction();

	void startComputerRun(bool load);
	int getRunState() {return elfRunState_;};
	bool isComputerRunning();

protected:
	ElfConfiguration elfConfiguration;
	Vt100 *vtPointer;

	int elfRunState_;

	Word ramStart_;
	int ramMask_;
private:

};

#endif  // MAINELF_H
