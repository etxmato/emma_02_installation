/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guinano.h"
#include "pixie.h"

#include "psave.h"

BEGIN_EVENT_TABLE(GuiNano, GuiCidelsa)

	EVT_BUTTON(XRCID("RomButtonNano"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("RamSWButtonNano"), GuiMain::onRamSW)
	EVT_BUTTON(XRCID("Chip8SWButtonNano"), GuiMain::onChip8SW)
	EVT_BUTTON(XRCID("EjectChip8SWNano"), GuiMain::onEjectChip8SW)
	EVT_SPIN_UP(XRCID("ZoomSpinNano"), GuiMain::onZoomUp)
	EVT_SPIN_DOWN(XRCID("ZoomSpinNano"), GuiMain::onZoomDown)
	EVT_TEXT(XRCID("ZoomValueNano"), GuiMain::onZoomValue)
	EVT_BUTTON(XRCID("FullScreenF3Nano"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonNano"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Nano"), GuiMain::onScreenDump)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeNano"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeNano"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("CasButtonNano"), GuiMain::onCassette)
	EVT_BUTTON(XRCID("EjectCasNano"), GuiMain::onCassetteEject)
	EVT_TEXT(XRCID("WavFileNano"), GuiMain::onCassetteText)
	EVT_BUTTON(XRCID("RealCasLoadNano"), GuiMain::onRealCas)
	EVT_CHECKBOX(XRCID("TurboNano"), GuiMain::onTurbo)
	EVT_TEXT(XRCID("TurboClockNano"), GuiMain::onTurboClock)
	EVT_CHECKBOX(XRCID("AutoCasLoadNano"), GuiMain::onAutoLoad)
	EVT_BUTTON(XRCID("CasLoadNano"), GuiMain::onCassetteLoad)
	EVT_BUTTON(XRCID("CasSaveNano"), GuiMain::onCassetteSave)
	EVT_BUTTON(XRCID("CasStopNano"), GuiMain::onCassetteStop)
	EVT_BUTTON(XRCID("SaveButtonNano"), GuiMain::onSaveButton)
	EVT_BUTTON(XRCID("LoadButtonNano"), GuiMain::onLoadButton)
	EVT_TEXT(XRCID("ClockNano"), GuiMain::onClock)
	EVT_BUTTON(XRCID("KeyMapNano"), Main::onHexKeyDef)
	EVT_BUTTON(XRCID("ColoursNano"), Main::onColoursDef)

END_EVENT_TABLE()

GuiNano::GuiNano(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiCidelsa(title, pos, size)
{
}

void GuiNano::readNanoConfig()
{
	bool turbo;
	selectedComputer_ = NANO;

	XRCCTRL(*this, "MainRomNano", wxComboBox)->SetValue(configPointer->Read("/Nano/NanoMainRom", "nano.rom"));
	XRCCTRL(*this, "RamSWNano", wxComboBox)->SetValue(configPointer->Read("/Nano/NanoRamSW", "chip8.ram"));
	XRCCTRL(*this, "Chip8SWNano", wxTextCtrl)->SetValue(configPointer->Read("/Nano/NanoChip8SW", "Breakout (Brix hack) [David Winter, 1997].ch8"));
	wxString defaultZoom;
	defaultZoom.Printf("%2.2f", 2.0);
	conf[NANO].zoom_ = configPointer->Read("/Nano/Zoom", defaultZoom);
	XRCCTRL(*this, "ZoomValueNano", wxTextCtrl)->ChangeValue(conf[NANO].zoom_);
	wxString defaultScale;
	defaultScale.Printf("%i", 4);
	conf[NANO].xScale_ = configPointer->Read("/Nano/xScale", defaultScale);
	conf[NANO].romDir_[MAINROM] = configPointer->Read("/Nano/NanoRomDir", dataDir_ + "Nano"  + pathSeparator_);
	conf[NANO].ramDir_ = configPointer->Read("/Nano/NanoRamDir", dataDir_ + "Nano"  + pathSeparator_);
	conf[NANO].chip8SWDir_ = configPointer->Read("/Nano/Chip8SWDir", dataDir_ + "Chip-8"  + pathSeparator_ + "Chip-8 Games"  + pathSeparator_);

	conf[NANO].wavFile_ = configPointer->Read("/Nano/WavFile", "");
	XRCCTRL(*this, "WavFileNano", wxTextCtrl)->SetValue(conf[NANO].wavFile_);
	conf[NANO].wavFileDir_ = configPointer->Read("/Nano/WavFileDir", dataDir_ + "Nano" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileNano", wxComboBox)->SetValue(configPointer->Read("/Nano/NanoScreenDumpFile", "screendump.png"));
	conf[NANO].screenDumpFileDir_ = configPointer->Read("/Nano/NanoScreenDumpFileDir", dataDir_ + "Nano" + pathSeparator_);

	configPointer->Read("/Nano/NanoTurbo", &turbo, true);
	XRCCTRL(*this, "TurboNano", wxCheckBox)->SetValue(turbo);
	turboGui("Nano");
	conf[NANO].turboClock_ = configPointer->Read("/Nano/NanoTurboClock", "15");
	XRCCTRL(*this, "TurboClockNano", wxTextCtrl)->SetValue(conf[NANO].turboClock_);
	configPointer->Read("/Nano/NanoAutoCasLoad", &conf[NANO].autoCassetteLoad_, true);
	XRCCTRL(*this, "AutoCasLoadNano", wxCheckBox)->SetValue(conf[NANO].autoCassetteLoad_);
	configPointer->Read("/Nano/RealCasLoad", &conf[NANO].realCassetteLoad_, false);
	setRealCas(NANO);

	conf[NANO].volume_ = configPointer->Read("/Nano/NanoVolume", 25l);
	XRCCTRL(*this, "VolumeNano", wxSlider)->SetValue(conf[NANO].volume_);

	conf[NANO].mainX_ = configPointer->Read("/Nano/NanoX", mainWindowX_+windowInfo.mainwX);
	conf[NANO].mainY_ = configPointer->Read("/Nano/NanoY", mainWindowY_);

	wxString defaultClock;
	defaultClock.Printf("%1.2f", 1.75);
	conf[NANO].clock_ = configPointer->Read("/Nano/Clock", defaultClock);
	XRCCTRL(*this, "ClockNano", wxTextCtrl)->ChangeValue(conf[NANO].clock_);

	XRCCTRL(*this, "SoundNano", wxChoice)->SetSelection(configPointer->Read("/Nano/Sound", 0l));
}

void GuiNano::writeNanoConfig()
{
	configPointer->Write("/Nano/NanoMainRom", XRCCTRL(*this, "MainRomNano", wxComboBox)->GetValue());
	configPointer->Write("/Nano/NanoRamSW", XRCCTRL(*this, "RamSWNano", wxComboBox)->GetValue());
	configPointer->Write("/Nano/NanoChip8SW", XRCCTRL(*this, "Chip8SWNano", wxTextCtrl)->GetValue());
	configPointer->Write("/Nano/Zoom", conf[NANO].zoom_);
	configPointer->Write("/Nano/NanoRomDir", conf[NANO].romDir_[MAINROM]);
	configPointer->Write("/Nano/NanoRamDir", conf[NANO].ramDir_);
	configPointer->Write("/Nano/Chip8SWDir", conf[NANO].chip8SWDir_);

	if (conf[NANO].mainX_ > 0)
		configPointer->Write("/Nano/NanoX", conf[NANO].mainX_);
	if (conf[NANO].mainY_ > 0)
		configPointer->Write("/Nano/NanoY", conf[NANO].mainY_);

	configPointer->Write("/Nano/NanoWavFile", XRCCTRL(*this, "WavFileNano", wxTextCtrl)->GetValue());
	configPointer->Write("/Nano/WavFileDir", conf[NANO].wavFileDir_);
	configPointer->Write("/Nano/NanoScreenDumpFile", XRCCTRL(*this, "ScreenDumpFileNano", wxComboBox)->GetValue());
	configPointer->Write("/Nano/NanoScreenDumpFileDir", conf[NANO].screenDumpFileDir_);
	configPointer->Write("/Nano/NanoTurbo", XRCCTRL(*this, "TurboNano", wxCheckBox)->GetValue());
	configPointer->Write("/Nano/NanoTurboClock", conf[NANO].turboClock_);
	configPointer->Write("/Nano/NanoAutoCasLoad", XRCCTRL(*this, "AutoCasLoadNano", wxCheckBox)->GetValue());
	configPointer->Write("/Nano/RealCasLoad", conf[NANO].realCassetteLoad_);
	configPointer->Write("/Nano/NanoVolume", XRCCTRL(*this, "VolumeNano", wxSlider)->GetValue());

	configPointer->Write("/Nano/Clock", conf[NANO].clock_);
	configPointer->Write("/Nano/Sound", XRCCTRL(*this, "SoundNano", wxChoice)->GetSelection());
}
