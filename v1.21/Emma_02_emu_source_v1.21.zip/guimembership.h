#ifndef GUIMEMBERSHIP_H
#define GUIMEMBERSHIP_H

#include "guistudio2.h"
#include "elfconfiguration.h"

class GuiMembership: public GuiStudio2
{
public:

	GuiMembership(const wxString& title, const wxPoint& pos, const wxSize& size, Mode mode, wxString dataDir);
	~GuiMembership() {};

	void readMembershipConfig();
    void writeMembershipDirConfig();
    void writeMembershipConfig();
    void writeMembershipWindowConfig();

	void onMembershipBaudR(wxCommandEvent& event);
	void onMembershipBaudT(wxCommandEvent& event);
	void onMembershipForceUpperCase(wxCommandEvent& event);
	void onMembershipControlWindows(wxCommandEvent& event);
	void onMembershipClock(wxCommandEvent& event);
	void onRam(wxCommandEvent& event);
	void onRomEvent(wxCommandEvent& event);
	void onRom();
	int getLoadromModeMembership();
	void onNvrMembership(wxCommandEvent&event);

	void setBaudChoiceMembership();

protected:
	int loadromMode_;

private:
    wxPoint position_;
	DECLARE_EVENT_TABLE()
};

#endif // GUIMEMBERSHIP_H
