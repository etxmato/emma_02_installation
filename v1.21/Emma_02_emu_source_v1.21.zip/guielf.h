#ifndef GUIELF_H
#define GUIELF_H

#include "guielf2k.h"
#include "elfconfiguration.h"

DECLARE_EVENT_TYPE(ON_UART, 807) 

class GuiElf: public GuiElf2K
{
public:

	GuiElf(const wxString& title, const wxPoint& pos, const wxSize& size, Mode mode, wxString dataDir);
	~GuiElf() {};

    void readElfConfig(int elfType, wxString elfTypeStr);
	void writeElfDirConfig(int elfType, wxString elfTypeStr);
	void writeElfConfig(int elfType, wxString elfTypeStr);
	void writeElfWindowConfig(int elfType, wxString elfTypeStr);

	void onDiskType(wxCommandEvent& event);
	void onMemory(wxCommandEvent& event);
	void onAutoBoot(wxCommandEvent& event);
	void onStartRam(wxCommandEvent& event);
	void onEndRam(wxCommandEvent& event);
	void onVideoType(wxCommandEvent& event);
	void onElfKeyboard(wxCommandEvent& event);
	void onForceUpperCase(wxCommandEvent& event);
 	void onUsePortExtender(wxCommandEvent& event);
	void onLedModule(wxCommandEvent& event);
	void onElfControlWindows(wxCommandEvent& event);
	void onRom1(wxCommandEvent& event);
	void onRom2(wxCommandEvent& event);
    void setGameModeConfig(wxCommandEvent& event);
    void setChipModeConfig(wxCommandEvent& event);
	void setGiantBoard(wxCommandEvent& event);
	void setQuestLoader(wxCommandEvent& event);
	void setSuperBasic1(wxCommandEvent& event);
	void setSuperBasic3(wxCommandEvent& event);
	void setSuperBasic5(wxCommandEvent& event);
	void setSuperBasic6(wxCommandEvent& event);
	void setSuperBasic();
	void setSuperBasicSerial(wxCommandEvent& event);
	void setRcaBasic(wxCommandEvent& event);
	void setRcaBasicPixie(wxCommandEvent& event);
	void setRcaBasicSerial(wxCommandEvent& event);
	void setRcaBasicElfOsInstall(wxCommandEvent& event);
    void setRomMapperPixie(wxCommandEvent& event);
    void setRomMapperSerial(wxCommandEvent& event);
    void setTinyBasicSerial(wxCommandEvent& event);
	void setTinyBasicPixie(wxCommandEvent& event);
	void setTinyBasic6847(wxCommandEvent& event);
	void setFigForth(wxCommandEvent& event);
	void setSuperGoldMonitor(wxCommandEvent& event);
	void setMonitorBasic(wxCommandEvent& event);
	void setMusic(wxCommandEvent& event);
	void setElfOsInstallConfig(wxCommandEvent& event);
	void setElfOsConfig(wxCommandEvent& event);
	void setElfOsIoConfig(wxCommandEvent& event);
	void setElfOsIoInstallConfigPixie(wxCommandEvent& event);
	void setElfOsIoConfigPixie(wxCommandEvent& event);
	void setElfOsIoInstallConfig6845(wxCommandEvent& event);
	void setElfOsIoConfig6845(wxCommandEvent& event);
	void setElfOsIoInstallConfig6847(wxCommandEvent& event);
	void setElfOsIoConfig6847(wxCommandEvent& event);
    void setElfOsIoInstallConfigTms(wxCommandEvent& event);
    void setElfOsIoConfigTms(wxCommandEvent& event);
    void setElfOsIoConfigTmsGra(wxCommandEvent& event);
	void setElfOsConfigMain();
	void setElfOsIoConfigMain();
	void onElfScreenDump(wxCommandEvent& event);
	void onTape(wxCommandEvent& event);
	void onQsound(wxCommandEvent&event);
	void onUart(wxCommandEvent&event);
	void switchUart();

	int getLoadromMode(int elfType, int num);
	long getStartRam(wxString elfTypeStr, int elfType);
	long getEndRam(wxString elfTypeStr, int elfType);
	void setDiskType(wxString elfTypeStr, int elfType, int Selection);
	void setMemory(wxString elfTypeStr, int elfType, int Selection);
	void setElfKeyboard(wxString elfTypeStr, int elfType, int Selection);
	void setVideoType(wxString elfTypeStr, int elfType, int Selection);
	void setTapeType(wxString elfTypeStr, int elfType);

	bool getUpperCase(int elfType) {return elfConfiguration[elfType].forceUpperCase;};
	bool getUseElfControlWindows(int elfType) {return elfConfiguration[elfType].useElfControlWindows;};
	bool getUseSwitch(int elfType) {return elfConfiguration[elfType].useSwitch;};
	bool getUseHex(int elfType) {return elfConfiguration[elfType].useHex;};
	bool getUseTape(int elfType) {return elfConfiguration[elfType].useTape;};

	wxPoint getLedModulePos();
	void setLedModulePos(wxPoint position);
	void reset6847ConfigItem(int num);

protected:
	int ledModuleX_, ledModuleY_;

private:

	int loadromMode_[3][2];
	long startRam_[3];
	long endRam_[3];

	wxBitmap tapeOffBitmap;
	wxBitmap tapeOnBitmap;

	DECLARE_EVENT_TABLE()
};

#endif // GUIELF_H
