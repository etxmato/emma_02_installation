/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guistudio2.h"
#include "pixie.h"

BEGIN_EVENT_TABLE(GuiStudio2, GuiVip)

	EVT_TEXT(XRCID("MainRomStudio2"), GuiMain::onMainRom1Text)
	EVT_COMBOBOX(XRCID("MainRomStudio2"), GuiMain::onMainRom1Text)
	EVT_BUTTON(XRCID("RomButtonStudio2"), GuiMain::onMainRom1)

	EVT_TEXT(XRCID("CartRomStudio2"), GuiMain::onCartRomText)
	EVT_COMBOBOX(XRCID("CartRomStudio2"), GuiMain::onCartRomText)
	EVT_BUTTON(XRCID("CartRomButtonStudio2"), GuiMain::onCartRom)

	EVT_BUTTON(XRCID("ScreenDumpFileButtonStudio2"), GuiMain::onScreenDumpFile)
	EVT_TEXT(XRCID("ScreenDumpFileStudio2"), GuiMain::onScreenDumpFileText)
	EVT_COMBOBOX(XRCID("ScreenDumpFileStudio2"), GuiMain::onScreenDumpFileText)

	EVT_SPIN_UP(XRCID("ZoomSpinStudio2"), GuiMain::onZoomUp)
	EVT_SPIN_DOWN(XRCID("ZoomSpinStudio2"), GuiMain::onZoomDown)
	EVT_TEXT(XRCID("ZoomValueStudio2"), GuiMain::onZoomValue)
	EVT_BUTTON(XRCID("FullScreenF3Studio2"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("ScreenDumpF5Studio2"), GuiMain::onScreenDump)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeStudio2"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeStudio2"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("KeyMapStudio2"), Main::onHexKeyDef)
	EVT_BUTTON(XRCID("ColoursStudio2"), Main::onColoursDef)
	EVT_TEXT(XRCID("BeepFrequencyStudio2"), GuiMain::onBeepFrequency)


	EVT_TEXT(XRCID("MainRomVisicom"), GuiMain::onMainRom1Text)
	EVT_COMBOBOX(XRCID("MainRomVisicom"), GuiMain::onMainRom1Text)
	EVT_BUTTON(XRCID("RomButtonVisicom"), GuiMain::onMainRom1)

	EVT_TEXT(XRCID("CartRomVisicom"), GuiMain::onCartRomText)
	EVT_COMBOBOX(XRCID("CartRomVisicom"), GuiMain::onCartRomText)
	EVT_BUTTON(XRCID("CartRomButtonVisicom"), GuiMain::onCartRom)

	EVT_BUTTON(XRCID("ScreenDumpFileButtonVisicom"), GuiMain::onScreenDumpFile)
	EVT_TEXT(XRCID("ScreenDumpFileVisicom"), GuiMain::onScreenDumpFileText)
	EVT_COMBOBOX(XRCID("ScreenDumpFileVisicom"), GuiMain::onScreenDumpFileText)

	EVT_SPIN_UP(XRCID("ZoomSpinVisicom"), GuiMain::onZoomUp)
	EVT_SPIN_DOWN(XRCID("ZoomSpinVisicom"), GuiMain::onZoomDown)
	EVT_TEXT(XRCID("ZoomValueVisicom"), GuiMain::onZoomValue)
	EVT_BUTTON(XRCID("FullScreenF3Visicom"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("ScreenDumpF5Visicom"), GuiMain::onScreenDump)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeVisicom"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeVisicom"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("KeyMapVisicom"), Main::onHexKeyDef)
	EVT_BUTTON(XRCID("ColoursVisicom"), Main::onColoursDef)
	EVT_TEXT(XRCID("BeepFrequencyVisicom"), GuiMain::onBeepFrequency)


	EVT_TEXT(XRCID("MainRomVictory"), GuiMain::onMainRom1Text)
	EVT_COMBOBOX(XRCID("MainRomVictory"), GuiMain::onMainRom1Text)
	EVT_BUTTON(XRCID("RomButtonVictory"), GuiMain::onMainRom1)

	EVT_TEXT(XRCID("CartRomVictory"), GuiMain::onCartRomText)
	EVT_COMBOBOX(XRCID("CartRomVictory"), GuiMain::onCartRomText)
	EVT_BUTTON(XRCID("CartRomButtonVictory"), GuiMain::onCartRom)

	EVT_BUTTON(XRCID("ScreenDumpFileButtonVictory"), GuiMain::onScreenDumpFile)
	EVT_TEXT(XRCID("ScreenDumpFileVictory"), GuiMain::onScreenDumpFileText)
	EVT_COMBOBOX(XRCID("ScreenDumpFileVictory"), GuiMain::onScreenDumpFileText)

	EVT_SPIN_UP(XRCID("ZoomSpinVictory"), GuiMain::onZoomUp)
	EVT_SPIN_DOWN(XRCID("ZoomSpinVictory"), GuiMain::onZoomDown)
	EVT_TEXT(XRCID("ZoomValueVictory"), GuiMain::onZoomValue)
	EVT_BUTTON(XRCID("FullScreenF3Victory"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("ScreenDumpF5Victory"), GuiMain::onScreenDump)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeVictory"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeVictory"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("KeyMapVictory"), Main::onHexKeyDef)
	EVT_BUTTON(XRCID("ColoursVictory"), Main::onColoursDef)

END_EVENT_TABLE()

GuiStudio2::GuiStudio2(const wxString& title, const wxPoint& pos, const wxSize& size, Mode mode, wxString dataDir)
: GuiVip(title, pos, size, mode, dataDir)
{
}

void GuiStudio2::readStudioConfig()
{
	selectedComputer_ = STUDIO;

    conf[STUDIO].configurationDir_ = dataDir_ + "Configurations" + pathSeparator_ + "Studio2" + pathSeparator_;

    conf[STUDIO].romDir_[MAINROM1] = readConfigDir("/Dir/Studio2/Main_Rom_File", dataDir_ + "Studio2"  + pathSeparator_);
	conf[STUDIO].romDir_[CARTROM] = readConfigDir("/Dir/Studio2/St2_File", dataDir_ + "Studio2" + pathSeparator_);
	conf[STUDIO].screenDumpFileDir_ = readConfigDir("/Dir/Studio2/Video_Dump_File", dataDir_ + "Studio2" + pathSeparator_);

	conf[STUDIO].rom_[MAINROM1] = configPointer->Read("/Studio2/Main_Rom_File", "studio2.rom");
	conf[STUDIO].rom_[CARTROM] = configPointer->Read("/Studio2/St2_File", "");
	conf[STUDIO].screenDumpFile_ = configPointer->Read("/Studio2/Video_Dump_File", "screendump.png");

	wxString defaultZoom;
	defaultZoom.Printf("%2.2f", 2.0);
	conf[STUDIO].zoom_ = configPointer->Read("/Studio2/Zoom", defaultZoom);
	wxString defaultClock;
	defaultClock.Printf("%1.2f", 1.76);
	conf[STUDIO].clock_ = configPointer->Read("/Studio2/Clock_Speed", defaultClock);
 //   conf[STUDIO].beepFrequency_ = (int)configPointer->Read("/Studio2/Beep_Frequency", 480);
    conf[STUDIO].beepFrequency_ = 640;
	conf[STUDIO].volume_ = (int)configPointer->Read("/Studio2/Volume", 25l);

	wxString defaultScale;
	defaultScale.Printf("%i", 3);
	conf[STUDIO].xScale_ = configPointer->Read("/Studio2/Window_Scale_Factor_X", defaultScale);
	conf[STUDIO].mainX_ = (int)configPointer->Read("/Studio2/Window_Position_X", mainWindowX_+windowInfo.mainwX+windowInfo.xBorder);
	conf[STUDIO].mainY_ = (int)configPointer->Read("/Studio2/Window_Position_Y", mainWindowY_);
	conf[STUDIO].realCassetteLoad_ = false;

	if (mode_.gui)
	{
		XRCCTRL(*this, "MainRomStudio2", wxComboBox)->SetValue(conf[STUDIO].rom_[MAINROM1]);
		XRCCTRL(*this, "CartRomStudio2", wxComboBox)->SetValue(conf[STUDIO].rom_[CARTROM]);
		XRCCTRL(*this, "ScreenDumpFileStudio2", wxComboBox)->SetValue(conf[STUDIO].screenDumpFile_);
		XRCCTRL(*this, "ZoomValueStudio2", wxTextCtrl)->ChangeValue(conf[STUDIO].zoom_);
		clockTextCtrl[STUDIO]->ChangeValue(conf[STUDIO].clock_);
//		wxString beepFrequency;
//		beepFrequency.Printf("%d", conf[STUDIO].beepFrequency_);
//		XRCCTRL(*this, "BeepFrequencyStudio2", wxTextCtrl)->ChangeValue(beepFrequency);
		XRCCTRL(*this, "VolumeStudio2", wxSlider)->SetValue(conf[STUDIO].volume_);
	}
}

void GuiStudio2::writeStudioDirConfig()
{
    writeConfigDir("/Dir/Studio2/Main_Rom_File", conf[STUDIO].romDir_[MAINROM1]);
	writeConfigDir("/Dir/Studio2/St2_File", conf[STUDIO].romDir_[CARTROM]);
	writeConfigDir("/Dir/Studio2/Video_Dump_File", conf[STUDIO].screenDumpFileDir_);
}

void GuiStudio2::writeStudioConfig()
{
	configPointer->Write("/Studio2/Main_Rom_File", conf[STUDIO].rom_[MAINROM1]);
	configPointer->Write("/Studio2/St2_File", conf[STUDIO].rom_[CARTROM]);
	configPointer->Write("/Studio2/Video_Dump_File", conf[STUDIO].screenDumpFile_);

	configPointer->Write("/Studio2/Zoom", conf[STUDIO].zoom_);
	configPointer->Write("/Studio2/Clock_Speed", conf[STUDIO].clock_);
//	configPointer->Write("/Studio2/Beep_Frequency", conf[STUDIO].beepFrequency_);
	configPointer->Write("/Studio2/Volume", conf[STUDIO].volume_);
}

void GuiStudio2::writeStudioWindowConfig()
{
	if (conf[STUDIO].mainX_ > 0)
		configPointer->Write("/Studio2/Window_Position_X", conf[STUDIO].mainX_);
	if (conf[STUDIO].mainY_ > 0)
		configPointer->Write("/Studio2/Window_Position_Y", conf[STUDIO].mainY_);

}

void GuiStudio2::readVisicomConfig()
{
	selectedComputer_ = VISICOM;

    conf[VISICOM].configurationDir_ = dataDir_ + "Configurations" + pathSeparator_ + "Visicom" + pathSeparator_;

    conf[VISICOM].romDir_[MAINROM1] = readConfigDir("/Dir/Visicom/Main_Rom_File", dataDir_ + "Visicom"  + pathSeparator_);
	conf[VISICOM].romDir_[CARTROM] = readConfigDir("/Dir/Visicom/St2_File", dataDir_ + "Visicom" + pathSeparator_);
	conf[VISICOM].screenDumpFileDir_ = readConfigDir("/Dir/Visicom/Video_Dump_File", dataDir_ + "Visicom" + pathSeparator_);

	conf[VISICOM].rom_[MAINROM1] = configPointer->Read("/Visicom/Main_Rom_File", "visicom.rom");
	conf[VISICOM].rom_[CARTROM] = configPointer->Read("/Visicom/St2_File", "");
	conf[VISICOM].screenDumpFile_ = configPointer->Read("/Visicom/Video_Dump_File", "screendump.png");

	wxString defaultZoom;
	defaultZoom.Printf("%2.2f", 2.0);
	conf[VISICOM].zoom_ = configPointer->Read("/Visicom/Zoom", defaultZoom);
	wxString defaultClock;
	defaultClock.Printf("%1.2f", 1.76);
	conf[VISICOM].clock_ = configPointer->Read("/Visicom/Clock_Speed", defaultClock);
//	conf[VISICOM].beepFrequency_ = (int)configPointer->Read("/Visicom/Beep_Frequency", 480);
    conf[VISICOM].beepFrequency_ = 640;
	conf[VISICOM].volume_ = (int)configPointer->Read("/Visicom/Volume", 25l);

	wxString defaultScale;
	defaultScale.Printf("%i", 3);
	conf[VISICOM].xScale_ = configPointer->Read("/Visicom/Window_Scale_Factor_X", defaultScale);
	conf[VISICOM].mainX_ = (int)configPointer->Read("/Visicom/Window_Position_X", mainWindowX_+windowInfo.mainwX+windowInfo.xBorder);
	conf[VISICOM].mainY_ = (int)configPointer->Read("/Visicom/Window_Position_Y", mainWindowY_);
	conf[VISICOM].realCassetteLoad_ = false;

	if (mode_.gui)
	{
		XRCCTRL(*this, "MainRomVisicom", wxComboBox)->SetValue(conf[VISICOM].rom_[MAINROM1]);
		XRCCTRL(*this, "CartRomVisicom", wxComboBox)->SetValue(conf[VISICOM].rom_[CARTROM]);
		XRCCTRL(*this, "ScreenDumpFileVisicom", wxComboBox)->SetValue(conf[VISICOM].screenDumpFile_);
		XRCCTRL(*this, "ZoomValueVisicom", wxTextCtrl)->ChangeValue(conf[VISICOM].zoom_);
		clockTextCtrl[VISICOM]->ChangeValue(conf[VISICOM].clock_);
//		wxString beepFrequency;
//		beepFrequency.Printf("%d", conf[VISICOM].beepFrequency_);
//		XRCCTRL(*this, "BeepFrequencyVisicom", wxTextCtrl)->ChangeValue(beepFrequency);
		XRCCTRL(*this, "VolumeVisicom", wxSlider)->SetValue(conf[VISICOM].volume_);
	}
}

void GuiStudio2::writeVisicomDirConfig()
{
    writeConfigDir("/Dir/Visicom/Main_Rom_File", conf[VISICOM].romDir_[MAINROM1]);
	writeConfigDir("/Dir/Visicom/St2_File", conf[VISICOM].romDir_[CARTROM]);
	writeConfigDir("/Dir/Visicom/Video_Dump_File", conf[VISICOM].screenDumpFileDir_);
}

void GuiStudio2::writeVisicomConfig()
{
	configPointer->Write("/Visicom/Main_Rom_File", conf[VISICOM].rom_[MAINROM1]);
	configPointer->Write("/Visicom/St2_File", conf[VISICOM].rom_[CARTROM]);
	configPointer->Write("/Visicom/Video_Dump_File", conf[VISICOM].screenDumpFile_);

	configPointer->Write("/Visicom/Zoom", conf[VISICOM].zoom_);
	configPointer->Write("/Visicom/Clock_Speed", conf[VISICOM].clock_);
//	configPointer->Write("/Visicom/Beep_Frequency", conf[VISICOM].beepFrequency_);
	configPointer->Write("/Visicom/Volume",conf[VISICOM].volume_);
}

void GuiStudio2::writeVisicomWindowConfig()
{
	if (conf[VISICOM].mainX_ > 0)
		configPointer->Write("/Visicom/Window_Position_X", conf[VISICOM].mainX_);
	if (conf[VISICOM].mainY_ > 0)
		configPointer->Write("/Visicom/Window_Position_Y", conf[VISICOM].mainY_);
}

void GuiStudio2::readVictoryConfig()
{
	selectedComputer_ = VICTORY;

    conf[VICTORY].configurationDir_ = dataDir_ + "Configurations" + pathSeparator_ + "Victory" + pathSeparator_;

    conf[VICTORY].romDir_[MAINROM1] = readConfigDir("/Dir/Victory/Main_Rom_File", dataDir_ + "Victory"  + pathSeparator_);
	conf[VICTORY].romDir_[CARTROM] = readConfigDir("/Dir/Victory/St2_File", dataDir_ + "Victory" + pathSeparator_);
	conf[VICTORY].screenDumpFileDir_ = readConfigDir("/Dir/Victory/Video_Dump_File", dataDir_ + "Victory" + pathSeparator_);

	conf[VICTORY].rom_[MAINROM1] = configPointer->Read("/Victory/Main_Rom_File", "victory.rom");
	conf[VICTORY].rom_[CARTROM] = configPointer->Read("/Victory/St2_File", "");
	conf[VICTORY].screenDumpFile_ = configPointer->Read("/Victory/Video_Dump_File", "screendump.png");

	wxString defaultZoom;
	defaultZoom.Printf("%2.2f", 2.0);
	conf[VICTORY].zoom_ = configPointer->Read("/Victory/Zoom", defaultZoom);
	wxString defaultClock;
	defaultClock.Printf("%1.2f", 1.76);
	conf[VICTORY].clock_ = configPointer->Read("/Victory/Clock_Speed", defaultClock);
	conf[VICTORY].volume_ = (int)configPointer->Read("/Victory/Volume", 25l);

	wxString defaultScale;
	defaultScale.Printf("%i", 4);
	conf[VICTORY].xScale_ = configPointer->Read("/Victory/Window_Scale_Factor_X", defaultScale);
	conf[VICTORY].mainX_ = (int)configPointer->Read("/Victory/Window_Position_X", mainWindowX_+windowInfo.mainwX+windowInfo.xBorder);
	conf[VICTORY].mainY_ = (int)configPointer->Read("/Victory/Window_Position_Y", mainWindowY_);
	conf[VICTORY].realCassetteLoad_ = false;

	if (mode_.gui)
	{
		XRCCTRL(*this, "MainRomVictory", wxComboBox)->SetValue(conf[VICTORY].rom_[MAINROM1]);
		XRCCTRL(*this, "CartRomVictory", wxComboBox)->SetValue(configPointer->Read("/Victory/St2_File", ""));
		XRCCTRL(*this, "ScreenDumpFileVictory", wxComboBox)->SetValue(conf[VICTORY].screenDumpFile_);
		XRCCTRL(*this, "ZoomValueVictory", wxTextCtrl)->ChangeValue(conf[VICTORY].zoom_);
		clockTextCtrl[VICTORY]->ChangeValue(conf[VICTORY].clock_);
		XRCCTRL(*this, "VolumeVictory", wxSlider)->SetValue(conf[VICTORY].volume_);
	}
}

void GuiStudio2::writeVictoryDirConfig()
{
    writeConfigDir("/Dir/Victory/Main_Rom_File", conf[VICTORY].romDir_[MAINROM1]);
	writeConfigDir("/Dir/Victory/St2_File", conf[VICTORY].romDir_[CARTROM]);
	writeConfigDir("/Dir/Victory/Video_Dump_File", conf[VICTORY].screenDumpFileDir_);
}

void GuiStudio2::writeVictoryConfig()
{
	configPointer->Write("/Victory/Main_Rom_File",conf[VICTORY].rom_[MAINROM1]);
	configPointer->Write("/Victory/St2_File", conf[VICTORY].rom_[CARTROM]);
	configPointer->Write("/Victory/Video_Dump_File", conf[VICTORY].screenDumpFile_);

	configPointer->Write("/Victory/Zoom", conf[VICTORY].zoom_);
	configPointer->Write("/Victory/Clock_Speed", conf[VICTORY].clock_);
	configPointer->Write("/Victory/Volume", conf[VICTORY].volume_);
}

void GuiStudio2::writeVictoryWindowConfig()
{
	if (conf[VICTORY].mainX_ > 0)
		configPointer->Write("/Victory/Window_Position_X", conf[VICTORY].mainX_);
	if (conf[VICTORY].mainY_ > 0)
		configPointer->Write("/Victory/Window_Position_Y", conf[VICTORY].mainY_);
}
