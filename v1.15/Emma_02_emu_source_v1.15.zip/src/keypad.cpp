/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

/*
 *******************************************************************
 *** This software is copyright 2006 by Michael H Riley          ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "app_icon.xpm"
//#include "elf_icon.xpm"
#endif

#include "main.h"
#include "pushbutton.h"
#include "keypad.h"

BEGIN_EVENT_TABLE(Keypad, wxFrame)
	EVT_CLOSE (Keypad::onClose)
	EVT_PAINT(Keypad::onPaint)
	EVT_KEY_DOWN(Keypad::onKeyDown)
	EVT_KEY_UP(Keypad::onKeyUp)
	EVT_COMMAND(20, wxEVT_ButtonDownEvent, Keypad::onButtonPress)
	EVT_COMMAND(20, wxEVT_ButtonUpEvent, Keypad::onButtonRelease)
	EVT_COMMAND(0, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(1, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(2, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(3, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(4, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(5, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(6, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(7, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(8, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(9, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(10, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(11, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(12, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(13, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(14, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(15, wxEVT_ButtonDownEvent, Keypad::onNumberKeyDown)
	EVT_COMMAND(0, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(1, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(2, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(3, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(4, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(5, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(6, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(7, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(8, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(9, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(10, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(11, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(12, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(13, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(14, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
	EVT_COMMAND(15, wxEVT_ButtonUpEvent, Keypad::onNumberKeyUp)
END_EVENT_TABLE()

Keypad::Keypad(const wxString& title, const wxPoint& pos, const wxSize& size, int computerType)
: wxFrame((wxFrame *)NULL, -1, title, pos, size)
{
	wxString buttonText;
	int x, y;

	computerType_ = computerType;
	SetIcon(wxICON(app_icon));
//	SetIcon(wxICON(elf_icon));

	wxClientDC dc(this);

	keypadBitmapPointer = new wxBitmap("images/hexpad.png", wxBITMAP_TYPE_PNG);
	dc.DrawBitmap(*keypadBitmapPointer, 0, 0);
			
	for (int i=0;i<2;i++) 
	{
		ledPointer[i] = new Led(dc, 20+96*(1-i),174, computerType);
	}
	ledPointer[1]->setStatus(dc, 1);

	inButtonPointer = new PushButton(this, 20, "IN", wxPoint(8, 11), wxSize(30, 30), 0);
	for (int i=0;i<16;i++)
	{
		buttonText.Printf("%01X", i);
		x = 8+(i&0x3)*32;
		y = 139 -(int)i/4*32;
		buttonPointer[i] = new PushButton(this, i, buttonText, wxPoint(x, y), wxSize(30, 30), 0);
	}
	keypadValue_ = 0;
	nextNybble_ = 'H';
	this->SetClientSize(size);
}

Keypad::~Keypad()
{
	delete keypadBitmapPointer;
			
	for (int i=0;i<2;i++) 
	{
		delete ledPointer[i];
	}
	delete inButtonPointer;
	for (int i=0;i<16;i++)
	{
		delete buttonPointer[i];
	}
}

void Keypad::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxPaintDC dc(this);
	dc.DrawBitmap(*keypadBitmapPointer, 0, 0);

	for (int i=0;i<2;i++) 
	{
		ledPointer[i]->onPaint(dc);
	}
}

void Keypad::onClose(wxCloseEvent&WXUNUSED(event))
{
	p_Computer->removeElfHex();
	Destroy();
}

void Keypad::onNumberKeyDown(wxCommandEvent&event)
{
	wxClientDC dc(this);

	int i = event.GetId();
	keypadValue_= (nextNybble_ == 'H')?(keypadValue_&15)+(i<<4):(keypadValue_&0xf0)+i;
	if (nextNybble_ == 'H')
	{
		nextNybble_ = 'L';
		ledPointer[1]->setStatus(dc, 0);
		ledPointer[0]->setStatus(dc, 1);
	}
	else
	{
		nextNybble_ = 'H';
		ledPointer[1]->setStatus(dc, 1);
		ledPointer[0]->setStatus(dc, 0);
	}
	p_Computer->onHexDown(i);
}

void Keypad::onNumberDown(int hex)
{
	wxClientDC dc(this);

	keypadValue_= (nextNybble_ == 'H')?(keypadValue_&15)+(hex<<4):(keypadValue_&0xf0)+hex;
	if (nextNybble_ == 'H')
	{
		nextNybble_ = 'L';
		ledPointer[1]->setStatus(dc, 0);
		ledPointer[0]->setStatus(dc, 1);
	}
	else
	{
		nextNybble_ = 'H';
		ledPointer[1]->setStatus(dc, 1);
		ledPointer[0]->setStatus(dc, 0);
	}
}

void Keypad::onNumberKeyUp(wxCommandEvent&WXUNUSED(event))
{
	p_Computer->onHexKeyUp();
}

void Keypad::onButtonRelease(wxCommandEvent& event)
{
	p_Computer->onInButtonRelease();
	event.Skip();
}

void Keypad::onButtonPress(wxCommandEvent& event)
{
	p_Computer->onInButtonPress(keypadValue_);
	event.Skip();
}

void Keypad::onKeyDown(wxKeyEvent& event)
{
	if (!p_Computer->keyDownPressed(event.GetKeyCode()))
		event.Skip();
}

void Keypad::onKeyUp(wxKeyEvent& event)
{
	if (!p_Computer->keyUpReleased(event.GetKeyCode()))
		event.Skip();
}

