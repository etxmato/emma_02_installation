#ifndef ELF2KSWITCH_H
#define ELF2KSWITCH_H

#include "elf2kdisk.h"

class Elf2Kswitch : public wxFrame 
{
public:
	Elf2Kswitch(const wxString& title, const wxPoint& pos, const wxSize& size);
	~Elf2Kswitch();

	void onClose(wxCloseEvent&WXUNUSED(event));
	void onKeyDown(wxKeyEvent& event);
	void onKeyUp(wxKeyEvent& event);
	void onChar(wxKeyEvent& event);
	void onButtonRelease(wxMouseEvent& event);
	void onButtonPress(wxMouseEvent& event);

	void setRunButtonUp(int up);
	void setInButtonUp(bool up);
	void setLoadButtonUp(int up);
	void setMpButtonUp(int up);
	void setDataSwitchUp(int number, int up);

	void onRunButton(wxCommandEvent& event);
	void onMpButton(wxCommandEvent& event);
	void onLoadButton(wxCommandEvent& event);
	void dataSwitch(wxCommandEvent& event);

private:
	void onPaint(wxPaintEvent&event);

	wxBitmap *elfBitmapPointer;
	wxButton *runButtonPointer;
	wxButton *mpButtonPointer;
	wxButton *loadButtonPointer;
	wxButton *inButtonPointer;
	wxButton *dataSwitchPointer[8];

	wxBitmap *upBitmapPointer;
	wxBitmap *downBitmapPointer;
	wxBitmap *pushUpBitmapPointer;
	wxBitmap *pushDownBitmapPointer;

	wxMask *maskUp;
	wxMask *maskDown;

	DECLARE_EVENT_TABLE()
};

#endif  // ELF2KSWITCH_H
