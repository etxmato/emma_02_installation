#ifndef GUITMC2000_H
#define GUITMC2000_H

#include "guieti660.h"

class GuiTMC2000: public GuiEti
{
public:

	GuiTMC2000(const wxString& title, const wxPoint& pos, const wxSize& size, Mode mode, wxString dataDir);
	~GuiTMC2000() {};

	void readTMC2000Config();
	void writeTMC2000Config();
	void readTMC1800Config();
	void writeTMC1800Config();

private:

	DECLARE_EVENT_TABLE()
};

#endif // GUITMC2000_H
