#ifndef TELMAC2000_H
#define TELMAC2000_H

#include "cdp1802.h"
#include "pixie.h"

class Tmc2000 : public Cdp1802, public Pixie
{
public:
	Tmc2000(const wxString& title, const wxPoint& pos, const wxSize& size, double zoom, double zoomfactor, int computerType);
	~Tmc2000();

	void configureComputer();
	void reDefineKeysA(int *, int *);
	void initComputer();
	void keyDown(int keycode);
	void keyUp(int keycode);

	void onRun();

	Byte ef(int flag);
	Byte ef3();
	Byte in(Byte port, Word address);
	void out(Byte port, Word address, Byte value);
	void outTMC2000(Byte value);
	void cycle(int type);

	void startComputer();
	void writeMemDataType(Word address, Byte type);
	Byte readMemDataType(Word address);
	Byte readMem(Word addr);
	void writeMem(Word addr, Byte value, bool writeRom);
	void cpuInstruction();
	void onReset();
	void checkTMC2000Function();

	Byte read1864ColorDirect(Word addr);
	void write1864ColorDirect(Word addr, Byte value);

private:
	Byte telmac2000KeyPort_;
	Byte telmac2000KeyState_[64];
	bool runPressed_;
	Word addressLatch_;
	bool colorLatch_;
	Word ramMask_;

	int hexKeyDefA1_[64];
	int hexKeyDefA2_[16];
	int hexKeyDefB1_[16];
	int hexKeyDefB2_[16];
    int inKey1_;
    int inKey2_;

	bool simDefA2_;
	bool simDefB2_;

	int keyDefGameHexA_[5];
	int keyDefGameHexB_[5];
};

#endif  // TELMAC2000_H
