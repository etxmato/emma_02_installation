#ifndef SERIAL_H
#define SERIAL_H

#include<windows.h>
#include<stdio.h>

class CSerialComm  
{
public:
    BOOL     m_bPortReady;
    HANDLE   m_hCom;
    DCB      PortDCB;
    COMMTIMEOUTS m_CommTimeouts;
    BOOL     bWriteRC;
    BOOL     bReadRC;
    DWORD     iBytesWritten;
    DWORD     iBytesRead;
    BOOL     m_CommOpen;
    BOOL    _bPortReady;
    char     sBuffer[128];

    CSerialComm();
    virtual ~CSerialComm();
    BOOL OpenSerialPort(LPCSTR portName);
    BOOL Read(char *buffer, unsigned int ByteCount);
    BOOL Write(char *buffer, unsigned int ByteCount);
    BOOL CloseSerialPort();
    DWORD GetModemInfo();
};

#endif  // SERIAL_H


