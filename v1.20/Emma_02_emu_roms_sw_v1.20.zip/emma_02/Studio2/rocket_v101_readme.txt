Rocket v1.01

instructions:

press keypad a button #1 to start
press keypad a button #5 to fire

after 9 rockets press reset to play again
