#ifndef COMP_H
#define COMP_H

#define BASICADDR_MAX 4

class Computer
{
public:
	Computer();
	~Computer() {};

	virtual bool isComputerRunning();
	virtual void startComputerRun(bool load);
	virtual void onReset();
	virtual void onRun();
	virtual void keyDown(int keycode);
	virtual bool keyDownExtended(int keycode, wxKeyEvent& event);
	virtual bool keyDownPressed(int keycode);
	virtual void keyUp(int keycode);
	virtual void keyUpExtended(int keycode, wxKeyEvent& event);
	virtual bool keyUpReleased(int keycode);
	virtual void charEvent(int keycode);
	virtual void cid1Bit8(bool set);
	virtual int getComxExpansionType(int card);
	virtual void sleepComputer(long ms);
	virtual void checkCaps();
	virtual void charFinished();
	virtual void finishStopTape();
	virtual void printOutPecom(int q);
	virtual void setElf2KDivider(Byte value);
	virtual void removeElf2KSwitch();
	virtual void removeElfHex();
	virtual void removeCosmicosHex();
	virtual void removeElfLedModule(); 
	virtual void showData(Byte val);
	virtual void showAddr(Word address);
	virtual void resetVideo();
	virtual void resetComputer();
	virtual void clearBootstrap();
	virtual void onInButtonRelease();
	virtual void onInButtonPress();
	virtual void onInButtonPress(Byte value);
	virtual void realCassette(short val);
	virtual void cassette(short val);
	virtual void cassette(char val);
	virtual void keyClear();
	virtual void startComputer();
	virtual void initComputer();
	virtual void configureComputer();
	virtual void stopComputer();
	virtual void onLoadButton();
	virtual void onMpButton();
	virtual void dataSwitch(int number);
	virtual Byte getData();
	virtual void onHexDown(int hex);
	virtual void onHexKeyUp();
	int getLoadedProgram() {return loadedProgram_;};
	int getLoadedOs() {return loadedOs_;};
	virtual int getRunState();
	virtual void checkLoadedSoftware();
	virtual void dataAvailable(bool data);
	virtual void thrStatus(bool data);
	virtual void setTempo(int tempo);
	virtual void switchQ();
	int getGaugeValue() {return gaugeValue_;};
	void resetGaugeValue() {gaugeValue_ = 0;};
	void setTapePolarity(Byte polarity) {tapePolarity_ = polarity;};
	void setConversionType(int convTypeWav, int convType) {conversionTypeWav_ = convTypeWav; conversionType_ = convType;};
	int getBasicExecAddr(int type){return basicExecAddress_[type];};
	virtual bool isEpromBoardLoaded(){return false;};

protected:
	int baseGiantBoard_;
	int baseQuestLoader_;
	int loadedProgram_;
	int loadedOs_;

	Byte cassetteEf_;
	short gaugeValue_;
	short maxTapeInput_;
	short lastTapeInput_;
	Byte tapePolarity_;
	int conversionType_;
	int conversionTypeWav_;
	int basicExecAddress_[BASICADDR_MAX];
	
private:
	int counter_;
	bool sign_;
	int period_;
	bool lowamp_;
};

#endif	// COMP_H
