/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "app_icon.xpm"
/*#include "comx_icon.xpm"
#include "telmac_icon.xpm"
#include "pecom_icon.xpm"*/
#endif

#include "wx/file.h"
#include "wx/ffile.h"
#include "wx/dcbuffer.h"

#include "main.h"
#include "printer.h"

ComxPrintout::ComxPrintout(const wxString& title, Printer *pointer)
:wxPrintout(title)
{
	printerPointer = pointer;
}

bool ComxPrintout::OnPrintPage(int page)
{
	int pageWidth, pageHeight;

	pageWidth = 960;
	pageHeight = 1408;

	wxDC *dc = GetDC();
	dc->SetAxisOrientation(true, false);

	if (dc)
	{
		FitThisSizeToPageMargins(wxSize(pageWidth, pageHeight), *p_PageSetupData);
		printerPointer->completePage(*dc, page);
		return true;
	}
	else
		return false;

}

bool ComxPrintout::OnBeginDocument(int startPage, int endPage)
{
	if (!wxPrintout::OnBeginDocument(startPage, endPage))
        return false;
	return true;
}

void ComxPrintout::GetPageInfo(int *minPage, int *maxPage, int *selPageFrom, int *selPageTo)
{
	*minPage = 1;
	*maxPage = printerPointer->getNumberofPages();
	*selPageFrom = 1;
	*selPageTo = 2;
}

bool ComxPrintout::HasPage(int pageNum)
{
	return(pageNum <= printerPointer->getNumberofPages());
}

BEGIN_EVENT_TABLE(PrinterCanvas, wxScrolledWindow)
	EVT_PAINT(PrinterCanvas::onPaint)
	EVT_CLOSE(PrinterCanvas::onClose)
END_EVENT_TABLE()

PrinterCanvas::PrinterCanvas(wxWindow *parent, wxWindowID id, const wxPoint &pos, const wxSize &size, long style, const wxString& title)
:wxScrolledWindow(parent, id, pos, size, style, title)
{
	this->SetClientSize(size);

	paperWidth_ = size.GetWidth();

	SetScrollRate(10, 10);
	SetVirtualSize(paperWidth_, 1408);
	SetBackgroundColour(*wxWHITE);
	plotterNumberOfSets_ = 0;

	plotterLineSpace_ = 10;
	plotterTextMode_ = true;
	plotterX_ = 0;
	plotterY_ = 39;
	plotterOriginX_ = 0;
	plotterOriginY_ = 39;
	plotterAngle_ = 0;
	plotterColour_ = 1;
	plotterLineScale_ = 0;
	plotterSolidLine_ = true;
	plotterCharSize_ = 1;
	plotterTextSize_ = 1;
	plotterCharHeight_ = 12 + plotterLineSpace_;
	plotterCharWidth_ = 12;
	plotterGraphCharHeight_ = 12 + plotterLineSpace_;
	plotterGraphCharWidth_ = 12;
	plotterCharSet_ = 0;
	maxY_ = 1408;

	matrixX_ = 0;
	matrixY_ = 0;
	matrixCharHeight_ = 10;
	matrixCharWidth_ = 10;
	pageSize_ = 1408;

	thermalX_ = -1;
	thermalY_ = 0;
	thermalCommand_ = STANDBY;
	thermalCycleValue_ = THERMALCYCLEVALUE;
	thermalLineFeed_ = 20;

	printerBitmapPointer = new wxBitmap(paperWidth_, maxY_);
	dcPreview.SelectObject(*printerBitmapPointer);
}

PrinterCanvas::~PrinterCanvas()
{
	dcPreview.SelectObject(wxNullBitmap);
	delete printerBitmapPointer;
}

void PrinterCanvas::onClose(wxCloseEvent&WXUNUSED(event))
{
	Destroy();
}

void PrinterCanvas::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxBufferedPaintDC dc(this);

	wxSize clientSize = GetClientSize();
	int xbegin, ybegin;
	GetViewStart(&xbegin, &ybegin);
	int xunit, yunit;
	GetScrollPixelsPerUnit(&xunit, &yunit);
	xbegin*=xunit;
	ybegin*=yunit;

	dc.Blit(0, 0, clientSize.GetWidth(), clientSize.GetHeight(), &dcPreview, xbegin, ybegin);
}

void PrinterCanvas::init()
{
	dcPreview.SetPen(*wxBLACK_PEN);
	dcPreview.SetTextForeground(*wxBLACK);
	dcPreview.SetBrush(wxBrush(*wxWHITE_BRUSH));
	dcPreview.SetPen(wxPen(*wxWHITE_PEN));
	dcPreview.DrawRectangle(0, 0, paperWidth_, maxY_);

	for (int i=0; i<16; i+=2)
	{
		plotterDash_[i][0] = i+1;
		plotterDash_[i][1] = i+1;
		plotterDash_[i][2] = i+1;
		plotterDash_[i][3] = i+1;
	}
	for (int i=1; i<16; i+=2)
	{
		plotterDash_[i][0] = i+1;
		plotterDash_[i][1] = 2;
		plotterDash_[i][2] = 2;
		plotterDash_[i][3] = 2;
	}
	dcPreview.SetPen(*wxBLACK_PEN);
}

Byte PrinterCanvas::inThermal()
{
	if (thermalX_ > 0)
		return 0;
	else
		return 4;
}

void PrinterCanvas::outThermal(Byte value)
{
	if (p_Computer->getFlipFlopQ())
	{
		if (value & 0x8)  // Step ?
		{
//			thermalCommand_ = RIGHT;
			thermalX_++;
//			p_Main->messageInt(thermalX_);
			if (thermalX_ == 512)
				thermalLineFeed_ = 9;
		}
		if (value == 0x12)
		{
//			thermalCommand_ = LEFT;
//			p_Main->message("LEFT 9");
			thermalX_ =- 1;
			thermalY_ += thermalLineFeed_;
			checkThermalY();
//			return;
		}
		if (value == 0x20) // LF / START / RIGHT ?
		{
//			p_Main->message("20");
		}
		if ((value&0x7f) == 0x21)
		{
//			thermalCommand_ = BREAK;
			if (value & 0x80) // Line 8
				thermalLine2();
		}
//		p_Main->messageInt(value);
	}
	else
	{
		if (value != 0) // Line 0-7
			thermalLine(value);
	}
}

bool PrinterCanvas::cycleThermal(bool ef4)
{
	thermalCycleValue_ --;
	if (thermalCycleValue_ > 0)  return ef4;

	thermalCycleValue_ = THERMALCYCLEVALUE;

	return !ef4;
/*
	switch(thermalCommand_)
	{
		case STANDBY:
			return;
		break;

		case RIGHT:
			thermalX_++;
		break;

		case LEFT:
			if (thermalX_ >= 0)
			{
				thermalX_--;
				if (thermalX_ == -1)
				{
					thermalY_ += 20;
					checkThermalY();
					thermalCommand_ = STANDBY;
				}
			}
		break;
	}*/
}

void PrinterCanvas::readPlotterRom(wxString DirName, wxString fileName)
{
	wxFFile inFile;
	size_t length;
	char buffer[4096];
	wxString pathName;

	pathName = DirName + fileName;

	for (int j=0; j<256; j++)
		plotterCharacterSets_[0][j] = 0xffff;

	if (fileName.Len() != 0)
	{
		if (wxFile::Exists(pathName))
		{
			if (inFile.Open(pathName, "rb"))
			{
				int Set = 0;
				int charNr = 32;
				plotterCharacterSets_[Set][charNr] = 0;
				charNr++;

				length = inFile.Read(buffer, 4096);
				for (size_t i=0; i<0xc00; i++)
				{
					plotterRom_[i] = (Byte)buffer[i];
					if ((plotterRom_[i]&0x8) == 8)
					{
						if ((Byte)buffer[i+1] != 0)
						{
							plotterCharacterSets_[Set][charNr] = i+1;
							charNr++;
						}
					}
				}
				plotterCharacterSets_[Set][charNr-1] = 0xffff;
				inFile.Close();
			}
		}
	}
}

void PrinterCanvas::readPlotterRomExtension(wxString DirName, wxString fileName)
{
	wxFFile inFile;
	size_t length;
	char buffer[8192];
	wxString pathName;

	pathName = DirName + fileName;

	for (int i=1; i<8; i++)
		for (int j=0; j<256; j++)
			plotterCharacterSets_[i][j] = 0xffff;

	if (fileName.Len() != 0)
	{
		if (wxFile::Exists(pathName))
		{
			if (inFile.Open(pathName, "rb"))
			{
				length = inFile.Read(buffer, 8192);
				for (size_t i=0; i<length; i++)
				{
					plotterRom_[i+0x1000] = (Byte)buffer[i];
				}
				inFile.Close();

				plotterNumberOfSets_ = plotterRom_[0x1000]&07;

				for (int Set=1; Set <= plotterNumberOfSets_; Set++)
				{
					int charNr = 32;
					int Start = plotterRom_[0x1001 +((Set-1)*6)] << 8;
					Start += (plotterRom_[0x1002 +((Set-1)*6)] + 0x1000);

					int address = 0x1000;

					while(address == 0x1000)
					{
						address = plotterRom_[Start] << 8;
						address += (plotterRom_[Start + 1] + 0x1000);
						Start +=2;
					}

					int stop = plotterRom_[0x1001 +((Set)*6)] << 8;
					stop += (plotterRom_[0x1002 +((Set)*6)] + 0x100C);
					if (Set == plotterNumberOfSets_)  stop = 0x3000;

					plotterCharacterSets_[Set][charNr] = address;
					charNr++;
					address++;

					while((address < stop) &&(plotterRom_[address] != 0xff))
					{
						if ((plotterRom_[address-1]&0x8) == 8)
						{
							plotterCharacterSets_[Set][charNr] = address;
							charNr++;
						}
						address++;
					}
				}
			}
		}
	}
}

void PrinterCanvas::completePage(wxDC& dc, int page)
{
	dc.Blit(0, 0, paperWidth_, pageSize_, &dcPreview, 0, pageSize_*(page-1));
}

int PrinterCanvas::getNumberofPages()
{
	return(int) ((maxY_-1)/pageSize_) + 1;
}

void PrinterCanvas::thermalLine(Byte value)
{
	for (int y=thermalY_; y<thermalY_+16; y+=2)
	{
		if (value & 1)
		{
			dcPreview.DrawRectangle(thermalX_&0xffe, y, 2, 2);
		}
		value = value >> 1;
	}

	wxSize clientSize = GetClientSize();
	int xbegin, ybegin;
	GetViewStart(&xbegin, &ybegin);
	int xunit, yunit;
	GetScrollPixelsPerUnit(&xunit, &yunit);
	xbegin*=xunit;
	ybegin*=yunit;

	wxClientDC dc(this);
	dc.Blit(0, 0, clientSize.GetWidth(), clientSize.GetHeight(), &dcPreview, xbegin, ybegin);
}

void PrinterCanvas::thermalLine2()
{
	dcPreview.DrawRectangle(thermalX_, thermalY_+16, 2, 2);

	wxSize clientSize = GetClientSize();
	int xbegin, ybegin;
	GetViewStart(&xbegin, &ybegin);
	int xunit, yunit;
	GetScrollPixelsPerUnit(&xunit, &yunit);
	xbegin*=xunit;
	ybegin*=yunit;

	wxClientDC dc(this);
	dc.Blit(0, 0, clientSize.GetWidth(), clientSize.GetHeight(), &dcPreview, xbegin, ybegin);
}

void PrinterCanvas::plotterLine(wxString printline)
{
	printLine_ = printline;
	plotterTextDrawn_ = false;

	plotterStringPosition_ = 0;
	while(plotterStringPosition_ <(int)printLine_.Len())
	{
		if (plotterTextMode_)
		{
			doText();
		}
		else
		{
			doGraphics();
		}
	}
	if (plotterTextDrawn_)
	{
		plotterY_ = plotterY_+plotterCharHeight_;
		plotterX_ = 0;
		checkXandY();
	}
	wxSize clientSize = GetClientSize();
	int xbegin, ybegin;
	GetViewStart(&xbegin, &ybegin);
	int xunit, yunit;
	GetScrollPixelsPerUnit(&xunit, &yunit);
	xbegin*=xunit;
	ybegin*=yunit;

	wxClientDC dc(this);
	dc.Blit(0, 0, clientSize.GetWidth(), clientSize.GetHeight(), &dcPreview, xbegin, ybegin);
}

void PrinterCanvas::matrixLine(wxString printline)
{
	printLine_ = printline;
	char printCharacter;

	wxMutexGuiEnter();
	matrixStringPosition_ = 0;
	while(matrixStringPosition_ <(int)printLine_.Len())
	{
		printCharacter = printLine_.GetChar(matrixStringPosition_);
		dcPreview.GetTextExtent(printCharacter, &matrixCharWidth_, &matrixCharHeight_);
		checkX();
		dcPreview.DrawText(printCharacter, matrixX_, matrixY_);
		matrixStringPosition_++;
		matrixX_ += matrixCharWidth_;
	}
	matrixX_ = 0;
	checkY();
	wxSize clientSize = GetClientSize();
	int xbegin, ybegin;
	GetViewStart(&xbegin, &ybegin);
	int xunit, yunit;
	GetScrollPixelsPerUnit(&xunit, &yunit);
	xbegin*=xunit;
	ybegin*=yunit;

	wxClientDC dc(this);
	dc.Blit(0, 0, clientSize.GetWidth(), clientSize.GetHeight(), &dcPreview, xbegin, ybegin);
	wxMutexGuiLeave();
}

void PrinterCanvas::doGraphics()
{
	wxPen pen;

	int destinationX;
	int destinationY;

 	if (plotterSolidLine_)
		pen.SetStyle(wxSOLID);
	else
	{
		pen.SetStyle(wxUSER_DASH);
		pen.SetDashes(4, plotterDash_[plotterLineScale_]);
	}

	switch(plotterColour_)
	{
		case 1:
			pen.SetColour(*wxBLACK);
			dcPreview.SetTextForeground(*wxBLACK);
		break;

		case 2:
			pen.SetColour(*wxRED);
			dcPreview.SetTextForeground(*wxRED);
		break;

		case 3:
			pen.SetColour(*wxGREEN);
			dcPreview.SetTextForeground(*wxGREEN);
		break;

		case 4:
			pen.SetColour(*wxBLUE);
			dcPreview.SetTextForeground(*wxBLUE);
		break;
	}
	dcPreview.SetPen(pen);

	switch(printLine_[plotterStringPosition_])
	{
		case 'B':
			plotterStringPosition_++;
			plotterLineScale_ = readInt();
		break;

		case 'H':
			plotterStringPosition_++;
			plotterX_ = plotterOriginX_;
			plotterY_ = plotterOriginY_;
		break;

		case 'D':
			plotterStringPosition_++;
			destinationX = plotterOriginX_ + readInt();
			plotterStringPosition_++;
			destinationY = plotterOriginY_ - readInt();
			dcPreview.DrawLine(plotterX_, plotterY_, destinationX, destinationY);
			plotterX_ = destinationX;
			plotterY_ = destinationY;
			checkXandY();
		break;

		case 'I':
			plotterStringPosition_++;
			destinationX = readInt();
			plotterStringPosition_++;
			destinationY = - readInt();
			dcPreview.DrawLine(plotterX_, plotterY_, plotterX_+destinationX, plotterY_+destinationY);
			plotterX_ = plotterX_+destinationX;
			plotterY_ = plotterY_+destinationY;
			checkXandY();
		break;

		case 'J':
			plotterStringPosition_++;
			plotterColour_ = readInt();
		break;

		case 'L':
			plotterStringPosition_++;
			if (readInt() == 0)
				plotterSolidLine_ = true;
			else
				plotterSolidLine_ = false;
		break;

		case 'M':
			plotterStringPosition_++;
			plotterX_ = plotterOriginX_ + readInt();
			plotterStringPosition_++;
			plotterY_ = plotterOriginY_ - readInt();
			checkXandY();
		break;

		case 'O':
			plotterStringPosition_++;
			plotterOriginX_ = plotterX_;
			plotterOriginY_ = plotterY_;
		break;

		case 'P':
			pen.SetStyle(wxSOLID);
			dcPreview.SetPen(pen);
			plotterStringPosition_++;
			while(plotterStringPosition_ <(int)printLine_.Len())
			{
				printCharacter(printLine_.GetChar(plotterStringPosition_));
				plotterStringPosition_++;
			}
		break;

		case 'Q':
			plotterStringPosition_++;
			plotterAngle_ = readInt();
		break;

		case 'R':
			plotterStringPosition_++;
			plotterX_ += readInt();
			plotterStringPosition_++;
			plotterY_ -= readInt();
			checkXandY();
		break;

		case 'S':
			plotterStringPosition_++;
			plotterCharSize_ = readInt() + 1;
			if (plotterCharSize_ <= 0)  plotterCharSize_ = 1;
			plotterGraphCharWidth_ = 12 * plotterCharSize_;
			plotterGraphCharHeight_ = (12 * plotterCharSize_) + plotterLineSpace_;
		break;

		case 'T':
			plotterTextMode_ = true;
			plotterStringPosition_++;
			plotterX_ = 0;
		break;

		case 'X':
			plotterStringPosition_++;
			plotterStringPosition_ = printLine_.Len();
		break;

		default:
			plotterStringPosition_++;
		break;

	}
}

void PrinterCanvas::doText()
{
	wxColourDatabase penColour;

	switch(plotterColour_)
	{
		case 1:
			dcPreview.SetPen(*wxBLACK_PEN);
			dcPreview.SetTextForeground(*wxBLACK);
		break;

		case 2:
			dcPreview.SetPen(*wxRED_PEN);
			dcPreview.SetTextForeground(*wxRED);
		break;

		case 3:
			dcPreview.SetPen(*wxGREEN_PEN);
			dcPreview.SetTextForeground(*wxGREEN);
		break;

		case 4:
			dcPreview.SetPen(wxPen(penColour.Find("BLUE")));
			dcPreview.SetTextForeground(*wxBLUE);
		break;
	}
	switch(printLine_[plotterStringPosition_])
	{
		case 8:
			plotterStringPosition_++;
			plotterX_ = plotterX_-plotterCharWidth_;
		break;

		case 10:
			plotterStringPosition_++;
			plotterY_ = plotterY_+plotterCharHeight_;
			checkXandY();
		break;

		case 11:
			plotterStringPosition_++;
			plotterY_ = plotterY_-plotterCharHeight_;
		break;

		case 12:
			plotterStringPosition_++;
			plotterCharSet_ = readInt();
			if (plotterCharSet_ > plotterNumberOfSets_)  plotterCharSet_ = 0;
		break;

		case 13:
			plotterStringPosition_++;
			plotterY_ = plotterY_+plotterCharHeight_;
			plotterX_ = 0;
			checkXandY();
		break;

		case 14:
			plotterStringPosition_++;
			plotterTextSize_ = 2;
			plotterY_ = plotterY_+plotterCharHeight_;
			plotterX_ = 0;
			checkXandY();
			plotterCharHeight_ = 24+plotterLineSpace_;
			plotterCharWidth_ = 24;
		break;

		case 15:
			plotterStringPosition_++;
			plotterColour_++;
			if (plotterColour_ == 5)  plotterColour_ = 1;
		break;

		case 18:
			plotterTextMode_ = false;
			plotterStringPosition_++;
		break;

		case 20:
			plotterStringPosition_++;
			plotterTextSize_ = 1;
			plotterCharHeight_ = 12+plotterLineSpace_;
			plotterCharWidth_ = 12;
		break;

		case 27:
			plotterStringPosition_++;
			plotterLineSpace_ = readInt() + 5;
			plotterCharHeight_ = (12*plotterTextSize_)+plotterLineSpace_;
			plotterStringPosition_ = printLine_.Len();
		break;

		default:
			printCharacter(printLine_.GetChar(plotterStringPosition_));
			if (plotterX_ >= 960)
			{
				plotterX_ = 0;
				plotterY_ = plotterY_+plotterCharHeight_;
			}
			checkXandY();
			plotterStringPosition_++;
			plotterTextDrawn_ = true;
		break;
	}
}

void PrinterCanvas::printCharacter(Byte CharNumber)
{
	Byte directionConvertor [8] = {0, 4, 6, 2, 7, 1, 5, 3};
	int steps;
	Byte direction;
	int drawMode;

	int address = plotterCharacterSets_[plotterCharSet_][CharNumber];

	if (address == 0xffff)  return;

	int saveY = plotterY_;
	int saveX = plotterX_;
	while((plotterRom_[address] & 0x8) == 0)
	{
		direction = directionConvertor[(plotterRom_[address] & 0x70) >> 4];
		if (plotterTextMode_)
			steps = (plotterRom_[address] & 0x7)*plotterTextSize_;
		else
		{
			steps = (plotterRom_[address] & 0x7)*plotterCharSize_;
			direction = (direction + plotterAngle_*2) & 0x7;
		}
		drawMode = plotterRom_[address] & 0x80;
		switch(direction)
		{
			case 0:
				drawCharLine(plotterX_, plotterY_, plotterX_+steps, plotterY_, drawMode);
			break;
			case 4:
				drawCharLine(plotterX_, plotterY_, plotterX_-steps, plotterY_, drawMode);
			break;
			case 6:
				drawCharLine(plotterX_, plotterY_, plotterX_, plotterY_-steps, drawMode);
			break;
			case 2:
				drawCharLine(plotterX_, plotterY_, plotterX_, plotterY_+steps, drawMode);
			break;
			case 7:
				drawCharLine(plotterX_, plotterY_, plotterX_+steps, plotterY_-steps, drawMode);
			break;
			case 1:
				drawCharLine(plotterX_, plotterY_, plotterX_+steps, plotterY_+steps, drawMode);
			break;
			case 5:
				drawCharLine(plotterX_, plotterY_, plotterX_-steps, plotterY_-steps, drawMode);
			break;
			case 3:
				drawCharLine(plotterX_, plotterY_, plotterX_-steps, plotterY_+steps, drawMode);
			break;
		}
		address++;
	}
	if (plotterTextMode_)
	{
			plotterY_ = saveY;
			plotterX_ = saveX + plotterCharWidth_;
	}
	else
	{
		switch(plotterAngle_)
		{
			case 0:
				plotterY_ = saveY;
				plotterX_ = saveX + plotterGraphCharWidth_;
			break;

			case 1:
				plotterY_ = saveY + plotterGraphCharWidth_;
				plotterX_ = saveX;
			break;

			case 2:
				plotterY_ = saveY;
				plotterX_ = saveX - plotterGraphCharWidth_;
			break;

			case 3:
				plotterY_ = saveY - plotterGraphCharWidth_;
				plotterX_ = saveX;
			break;
		}
	}
}

void PrinterCanvas::drawCharLine(int x, int y, int xDest, int yDest, int drawmode)
{
	if (drawmode == 0)
		dcPreview.DrawLine(x, y, xDest, yDest);
	plotterX_ = xDest;
	plotterY_ = yDest;
}

int PrinterCanvas::readInt()
{
	size_t digits;
	long value;
	wxString stringValue;

	digits = 0;
	while(((plotterStringPosition_+digits) < printLine_.Len()) &&
		   (((printLine_[plotterStringPosition_+digits] >= 0x30) && (printLine_[plotterStringPosition_+digits] <= 0x39))  ||
		    (printLine_[plotterStringPosition_+digits] == 0x2d) ) )
	{
		digits++;
	}
	stringValue = printLine_.Mid(plotterStringPosition_, digits);
	if (!stringValue.ToLong(&value))
		value = 0;
	plotterStringPosition_ += digits;
	return value;
}

void PrinterCanvas::checkXandY()
{
	if (plotterX_ >= 960)  plotterX_ = 959;
	if (plotterX_ < 0)  plotterX_ = 0;
	if (plotterY_ >= (maxY_ - 200))
	{
		PrinterImage = printerBitmapPointer->ConvertToImage();
		PrinterImage = PrinterImage.Resize(wxSize(960, maxY_ + pageSize_), wxPoint(0,0), 255, 255, 255);

		dcPreview.SelectObject(wxNullBitmap);
		printerBitmapPointer = new wxBitmap(PrinterImage);
		dcPreview.SelectObject(*printerBitmapPointer);

		maxY_ += pageSize_;
		SetVirtualSize(960, maxY_);
	}
	if (plotterY_ < 0)  plotterY_ = 0;
}

void PrinterCanvas::checkX()
{
	if ((matrixX_ + matrixCharWidth_) > 960)
	{
		matrixX_ = 0;
		checkY();
	}
}

void PrinterCanvas::checkY()
{
	if ((matrixY_ +(matrixCharHeight_*2)) >= maxY_)
	{
		if (maxY_ == 1408)  pageSize_ = matrixY_;

		PrinterImage = printerBitmapPointer->ConvertToImage();
		PrinterImage = PrinterImage.Resize(wxSize(paperWidth_, maxY_ + pageSize_), wxPoint(0,0), 255, 255, 255);

		dcPreview.SelectObject(wxNullBitmap);
		printerBitmapPointer = new wxBitmap(PrinterImage);
		dcPreview.SelectObject(*printerBitmapPointer);

		maxY_ += pageSize_;
		SetVirtualSize(paperWidth_, maxY_);
	}
	matrixY_ = matrixY_+matrixCharHeight_;
}

void PrinterCanvas::checkThermalY()
{
	if ((thermalY_ + 20) >= maxY_)
	{
		if (maxY_ == 1408)  pageSize_ = thermalY_;

		PrinterImage = printerBitmapPointer->ConvertToImage();
		PrinterImage = PrinterImage.Resize(wxSize(paperWidth_, maxY_ + pageSize_), wxPoint(0,0), 255, 255, 255);

		dcPreview.SelectObject(wxNullBitmap);
		printerBitmapPointer = new wxBitmap(PrinterImage);
		dcPreview.SelectObject(*printerBitmapPointer);

		maxY_ += pageSize_;
		SetVirtualSize(paperWidth_, maxY_);
	}
}

void PrinterCanvas::printFinished()
{
	thermalLineFeed_ = 20;
}

BEGIN_EVENT_TABLE(PrinterFrame, wxFrame)
	EVT_CLOSE(PrinterFrame::onClose)
	EVT_BUTTON(wxID_PRINT, PrinterFrame::onPrint)
	EVT_BUTTON(wxID_PREVIEW, PrinterFrame::onPreview)
	EVT_BUTTON(wxID_PRINT_SETUP, PrinterFrame::onPageSetup)
	EVT_BUTTON(PRINTER_PLOTTER, PrinterFrame::onPrinterPlotter)
	EVT_BUTTON(PLOTTERROM, PrinterFrame::onRomButton)
	EVT_BUTTON(PLOTTEREXT, PrinterFrame::onExtButton)
	EVT_TEXT(PLOTTERROMTEXT, PrinterFrame::onPlotterRomText)
	EVT_COMBOBOX(PLOTTERROMTEXT, PrinterFrame::onPlotterRomText)
	EVT_TEXT(PLOTTEREXTTEXT, PrinterFrame::onPlotterRomExtensionText)
	EVT_COMBOBOX( PLOTTEREXTTEXT, PrinterFrame::onPlotterRomExtensionText)
END_EVENT_TABLE()

PrinterFrame::PrinterFrame(const wxString& title, const wxPoint& pos, const wxSize& size, int printerType)
: wxFrame((wxFrame *)NULL, -1, title, pos, size)
{
	WindowInfo windowInfo = getWinSizeInfo();

	plotterRomDir_ = p_Main->getPL80Data(0);
	plotterRomFile_ = p_Main->getPL80Data(1);
	plotterRomExtensionDir_ = p_Main->getPL80Data(2);

	SetIcon(wxICON(app_icon));
/*	if (printerType == TELMACPRINTER)
		SetIcon(wxICON(telmac_icon));
	else
	{
		if (printerType == PECOMPRINTER)
			SetIcon(wxICON(pecom_icon));
		else
			SetIcon(wxICON(comx_icon));
	}*/

	this->SetClientSize(wxSize(size.GetWidth()+ windowInfo.xPrint, size.GetHeight()));

	printerCanvasPointer = new PrinterCanvas( this, wxID_ANY, pos, size, wxSUNKEN_BORDER, title);

	printerCanvasPointer->readPlotterRom(plotterRomDir_, plotterRomFile_);
	printerCanvasPointer->readPlotterRomExtension(plotterRomDir_, plotterRomExtensionDir_);
	printerType_ = printerType;
}

PrinterFrame::~PrinterFrame()
{
	printerCanvasPointer->Destroy();
}

void PrinterFrame::onClose(wxCloseEvent&WXUNUSED(event))
{
	if ((printerType_ != TELMACPRINTER) && (printerType_ != PECOMPRINTER))
	{
		p_Main->setPL80Data(0, plotterRomDir_);
		p_Main->setPL80Data(1, plotterRomFile_);
		p_Main->setPL80Data(2, plotterRomExtensionDir_);
	}

	switch(printerType_)
	{
		case TELMACPRINTER:
			p_PrinterTelmac->closePreviewWindow();
		break;

		case PECOMPRINTER:
			p_PrinterPecom->closePreviewWindow();
		break;

		case COMXPRINTER:
			p_PrinterParallel->closePreviewWindow();
		break;

		case COMXTHPRINTER:
			p_PrinterThermal->closePreviewWindow();
		break;

		case COMXRS232:
			p_PrinterSerial->closePreviewWindow();
		break;
	}

	Destroy();
}

void PrinterFrame::init()
{
	printerCanvasPointer->init();
}

Byte PrinterFrame::inThermal()
{
	return printerCanvasPointer->inThermal();
}

void PrinterFrame::outThermal(Byte value)
{
	printerCanvasPointer->outThermal(value);
}

bool PrinterFrame::cycleThermal(bool ef4)
{
	return printerCanvasPointer->cycleThermal(ef4);
}

void PrinterFrame::onPrinterPlotter(wxCommandEvent&WXUNUSED(event))
{
	if (p_Main->getPrintMode() != COMXPRINTPRINTER)
	{
		p_Main->setPrintMode(COMXPRINTPRINTER);
		SetTitle("COMX Printer Output");
		enablePlotterGui(false);
	}
	else
	{
		p_Main->setPrintMode(COMXPRINTPLOTTER);
		SetTitle("COMX Plotter Output");
		enablePlotterGui(true);
	}
}

void PrinterFrame::onPlotterRomExtensionText(wxCommandEvent &event)
{
	plotterRomExtensionDir_ = event.GetString();
	printerCanvasPointer->readPlotterRomExtension(plotterRomDir_, plotterRomExtensionDir_);
}

void PrinterFrame::onPlotterRomText(wxCommandEvent &event)
{
	plotterRomFile_ = event.GetString();
	printerCanvasPointer->readPlotterRom(plotterRomDir_, plotterRomFile_);
}

void PrinterFrame::onRomButton(wxCommandEvent& WXUNUSED(event) )
{
	wxString fileName;

	fileName = wxFileSelector( _T("Select the PL80 ROM file to load"),
                               plotterRomDir_, plotterRomFile_,
                               "",
                               wxString::Format
                              (
                                   _T("Binary File|*.bin;*.rom;|All files (%s)|%s"),
                                   wxFileSelectorDefaultWildcardStr,
                                   wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_OPEN|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );
	if (!fileName)
		return;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);

	plotterRomFile_ = FullPath.GetFullName();
	plotterRomDir_ = FullPath.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);

	showPlotterRomFile(plotterRomFile_);
	printerCanvasPointer->readPlotterRom(plotterRomDir_, plotterRomFile_);
}

void PrinterFrame::onExtButton(wxCommandEvent& WXUNUSED(event) )
{
	wxString fileName;

	fileName = wxFileSelector( _T("Select the PL80 Character ROM file to load"),
                               plotterRomDir_, plotterRomExtensionDir_,
                               "",
                               wxString::Format
                              (
                                   _T("Binary File|*.bin;*.rom;|All files (%s)|%s"),
                                   wxFileSelectorDefaultWildcardStr,
                                   wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_OPEN|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );
	if (!fileName)
		return;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);

	plotterRomExtensionDir_ = FullPath.GetFullName();
	plotterRomDir_ = FullPath.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);

	showPlotterRomExtensionFile(plotterRomExtensionDir_);
	printerCanvasPointer->readPlotterRomExtension(plotterRomDir_, plotterRomExtensionDir_);
}

void PrinterFrame::onPrint(wxCommandEvent&WXUNUSED(event))
{
	switch(printerType_)
	{
		case TELMACPRINTER:
			p_PrinterTelmac->printOut();
		break;

		case PECOMPRINTER:
			p_PrinterPecom->printOut();
		break;

		case COMXPRINTER:
			p_PrinterParallel->printOut();
		break;

		case COMXTHPRINTER:
			p_PrinterThermal->printOut();
		break;

		case COMXRS232:
			p_PrinterSerial->printOut();
		break;
	}
}

void PrinterFrame::onPreview(wxCommandEvent&WXUNUSED(event))
{
	switch(printerType_)
	{
		case TELMACPRINTER:
			p_PrinterTelmac->printPreview();
		break;

		case PECOMPRINTER:
			p_PrinterPecom->printPreview();
		break;

		case COMXPRINTER:
			p_PrinterParallel->printPreview();
		break;

		case COMXTHPRINTER:
			p_PrinterThermal->printPreview();
		break;

		case COMXRS232:
			p_PrinterSerial->printPreview();
		break;
	}
}

void PrinterFrame::onPageSetup(wxCommandEvent&WXUNUSED(event))
{
	switch(printerType_)
	{
		case TELMACPRINTER:
			p_PrinterTelmac->pageSetup();
		break;

		case PECOMPRINTER:
			p_PrinterPecom->pageSetup();
		break;

		case COMXPRINTER:
			p_PrinterParallel->pageSetup();
		break;

		case COMXTHPRINTER:
			p_PrinterThermal->pageSetup();
		break;

		case COMXRS232:
			p_PrinterSerial->pageSetup();
		break;
	}
}

void PrinterFrame::matrixLine(wxString printline)
{
	printerCanvasPointer->matrixLine(printline);
}

void PrinterFrame::plotterLine(wxString printline)
{
	printerCanvasPointer->plotterLine(printline);
}

void PrinterFrame::printFinished()
{
	printerCanvasPointer->printFinished();
}

void PrinterFrame::completePage(wxDC& dc, int page)
{
	printerCanvasPointer->completePage(dc, page);
}

int PrinterFrame::getNumberofPages()
{
	return printerCanvasPointer->getNumberofPages();
}

void PrinterFrame::enablePlotterGui(bool status)
{
	switch(printerType_)
	{
		case TELMACPRINTER:
			p_PrinterTelmac->enablePlotterGui(status);
		break;

		case PECOMPRINTER:
			p_PrinterPecom->enablePlotterGui(status);
		break;

		case COMXPRINTER:
			p_PrinterParallel->enablePlotterGui(status);
		break;

		case COMXTHPRINTER:
			p_PrinterThermal->enablePlotterGui(status);
		break;

		case COMXRS232:
			p_PrinterSerial->enablePlotterGui(status);
		break;
	}
}

void PrinterFrame::showPlotterRomFile(wxString fileName)
{
	switch(printerType_)
	{
		case TELMACPRINTER:
			p_PrinterTelmac->showPlotterRomFile(fileName);
		break;

		case PECOMPRINTER:
			p_PrinterPecom->showPlotterRomFile(fileName);
		break;

		case COMXPRINTER:
			p_PrinterParallel->showPlotterRomFile(fileName);
		break;

		case COMXTHPRINTER:
			p_PrinterThermal->showPlotterRomFile(fileName);
		break;

		case COMXRS232:
			p_PrinterSerial->showPlotterRomFile(fileName);
		break;
	}
}

void PrinterFrame::showPlotterRomExtensionFile(wxString fileName)
{
	switch(printerType_)
	{
		case TELMACPRINTER:
			p_PrinterTelmac->showPlotterRomExtensionFile(fileName);
		break;

		case PECOMPRINTER:
			p_PrinterPecom->showPlotterRomExtensionFile(fileName);
		break;

		case COMXPRINTER:
			p_PrinterParallel->showPlotterRomExtensionFile(fileName);
		break;

		case COMXTHPRINTER:
			p_PrinterThermal->showPlotterRomExtensionFile(fileName);
		break;

		case COMXRS232:
			p_PrinterSerial->showPlotterRomExtensionFile(fileName);
		break;
	}
}

Printer::Printer()
{
	parallelFrameOpen_ = false;
	serialFrameOpen_ = false;
	thermalFrameOpen_ = false;
	telmacFrameOpen_ = false;
	pecomFrameOpen_ = false;
}

Printer::~Printer()
{
}

void Printer::configureElfPrinter()
{
	int output;

	wxString runningComp = p_Main->getRunningComputerStr();

	output = p_Main->getConfigItem(_T(runningComp +"/PrinterOutput"), 7l);
	p_Computer->setOutType(output - 1, PRINTEROUT);

	wxString printBuffer;
	p_Main->message(_T("Configuring Printer"));

	printBuffer.Printf(_T("	Output %d: write data\n"), output);
	p_Main->message(printBuffer);
}

void Printer::configureThermalPrinter()
{
	p_Computer->setCycleType(PRINTCYCLE, THERMALCYCLE);
}

void Printer::initComx(Printer *pointer)
{
	printerPointer = pointer;
	comxPrintMode_ = p_Main->getPrintMode();

	printEscape_ = false;
	setPrintfileName(p_Main->getPrintFile());
	printStarted_ = false;
	thermalEf4_ = false;
	parallelFrameOpen_ = false;
	serialFrameOpen_ = false;
	thermalFrameOpen_ = false;
	line_ = "";
}

void Printer::initTelmac(Printer *pointer)
{
	printerPointer = pointer;
	telmacPrintMode_ = p_Main->getTelmacPrintMode();

	telmacFrameOpen_ = false;
	setTelmacPrintfileName(p_Main->getPrintFile());
}

void Printer::initPecom(Printer *pointer)
{
	printerPointer = pointer;
	pecomPrintMode_ = p_Main->getPecomPrintMode();

	setPecomPrintfileName(p_Main->getPrintFile());
	pecomFrameOpen_ = false;
	line_ = "";
}

Byte Printer::inParallel()
{
	if (comxPrintMode_ == PRINTFILE)
		return 6;
	else
	{
		if ((parallelFrameOpen_)  || printStarted_)
			return 6;
		else
		{
			wxCommandEvent event(OPEN_PRINTER_WINDOW, 800);
			event.SetEventObject(this);
			wxPostEvent(p_Main, event);
			while(!parallelFrameOpen_)
				p_Computer->sleepComputer(1000);
			return 6;
		}
	}
}

Byte Printer::inSerial()
{
	printValue_ = 0;
	bit_ = 0;
	dataBits_ = p_Computer->getRam(0x41b2) & 0xf;
	stopBit_ = dataBits_ + 1;
	if (p_Computer->getRam(0x41b2) & 0x30)
		stopBit_++;

	if (comxPrintMode_ != PRINTFILE && !printStarted_)
	{
		if (!serialFrameOpen_)
		{
			wxCommandEvent event(OPEN_PRINTER_WINDOW, 800);
			event.SetEventObject(this);
			wxPostEvent(p_Main, event);
			while(!serialFrameOpen_)
				p_Computer->sleepComputer(1000);
		}
	}
	return 0;
}

Byte Printer::inThermal()
{
	if (thermalFrameOpen_)
		return printerFramePointer->inThermal();
	else
	{
		wxCommandEvent event(OPEN_PRINTER_WINDOW, 800);
		event.SetEventObject(this);
		wxPostEvent(p_Main, event);
		while(!thermalFrameOpen_)
			p_Computer->sleepComputer(1000);
		return printerFramePointer->inThermal();
	}
}

void Printer::outElf(Byte value)
{
	wxString outputBuffer;
	wxFile printerFile;

	wxString printFile_ = p_Main->getMainDir() + "printer.out";

	if (!wxFile::Exists(printFile_))
		printerFile.Create(printFile_);
	printerFile.Open(printFile_, wxFile::write_append);
	outputBuffer.Printf("%c",value);
	printerFile.Write(outputBuffer);
}

void Printer::outTelmac(Byte value)
{
	wxString outputBuffer;
	wxFile printerFile;
	wxString fileName;

	if (telmacPrintMode_ != PRINTFILE)
	{
		if (!telmacFrameOpen_)
		{
			wxCommandEvent event(OPEN_TELMAC_PRINTER_WINDOW, 800);
			event.SetEventObject(this);
			wxPostEvent(p_Main, event);
			while(!telmacFrameOpen_)
				p_Computer->sleepComputer(1000);
		}

		if (value == 0xd)
		{
			printerFramePointer->matrixLine(line_);
			line_ = "";
		}
		else
		{
			outputBuffer.Printf("%c",value);
			line_ = line_ + outputBuffer;
		}
	}
	else
	{
		if (telmacPrintFile_.Len() != 0)
		{
			if (!wxFile::Exists(telmacPrintFileName_))
			{
				printerFile.Create(telmacPrintFileName_);
				newTelmacPrintFile_ = false;
			}
			if (newTelmacPrintFile_)
			{
				newTelmacPrintFile_ = false;
				fileName = telmacPrintFileName_;
				wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
				wxString Name = FullPath.GetName();
				wxString pathName = FullPath.GetPath();
				wxString Ext = FullPath.GetExt();
				int num = 0;
				wxString Number;

				while(wxFile::Exists(fileName))
				{
					num++;
					Number.Printf("%d", num);
					fileName = pathName + p_Main->getPathSep() + Name + "." + Number + "." + Ext;
				}
				printerFile.Create(fileName);
				telmacPrintFileName_ = fileName;
			}
			printerFile.Open(telmacPrintFileName_, wxFile::write_append);
			outputBuffer.Printf("%c",value);
			printerFile.Write(outputBuffer);
			printerFile.Close();
		}
	}
}

void Printer::startPecomChar()
{
	printValue_ = 0;
	bit_ = 0;

	if (pecomPrintMode_ != PRINTFILE)
	{
		if (!pecomFrameOpen_)
		{
			wxCommandEvent event(OPEN_PECOM_PRINTER_WINDOW, 810);
			event.SetEventObject(this);
			wxPostEvent(p_Main, event);
			while(!pecomFrameOpen_)
				p_Computer->sleepComputer(1000);
		}
	}
}

void Printer::outBitPecom(Byte value)
{
	if (bit_ == 8)
	{
		outPecom(printValue_);
		p_Computer->charFinished();
	}
	if (value == 0)
		printValue_ += (1 <<(bit_));
	bit_++;
}

void Printer::outPecom(Byte value)
{
	wxString outputBuffer;
	wxFile printerFile;
	wxString fileName;

	if (pecomPrintMode_ != PRINTFILE)
	{
		if (!pecomFrameOpen_)
		{
			wxCommandEvent event(OPEN_PECOM_PRINTER_WINDOW, 810);
			event.SetEventObject(this);
			wxPostEvent(p_Main, event);
			while(!pecomFrameOpen_)
				p_Computer->sleepComputer(1000);
		}

		if (value == 0xd)
		{
			printerFramePointer->matrixLine(line_);
			line_ = "";
		}
		else
		{
			outputBuffer.Printf("%c",value);
			line_ = line_ + outputBuffer;
		}
	}
	else
	{
		if (pecomPrintFile_.Len() != 0)
		{
			if (!wxFile::Exists(pecomPrintFileName_))
			{
				printerFile.Create(pecomPrintFileName_);
				newPecomPrintFile_ = false;
			}
			if (newPecomPrintFile_)
			{
				newPecomPrintFile_ = false;
				fileName = pecomPrintFileName_;
				wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
				wxString Name = FullPath.GetName();
				wxString pathName = FullPath.GetPath();
				wxString Ext = FullPath.GetExt();
				int num = 0;
				wxString Number;

				while(wxFile::Exists(fileName))
				{
					num++;
					Number.Printf("%d", num);
					fileName = pathName + p_Main->getPathSep() + Name + "." + Number + "." + Ext;
				}
				printerFile.Create(fileName);
				pecomPrintFileName_ = fileName;
			}
			if (value == 0xa)  return;
			printerFile.Open(pecomPrintFileName_, wxFile::write_append);
			outputBuffer.Printf("%c",value);
			printerFile.Write(outputBuffer);
			printerFile.Close();
		}
	}
}

void Printer::outParallel(Byte value)
{
	wxString outputBuffer;
	wxFile printerFile;
	wxString fileName;

	if (!printStarted_ &&(parallelFrameOpen_ || serialFrameOpen_))
		disablePrintPlotter();

	printStarted_ = true;
	if (printEscape_)
	{
		printEscape_ = false;
		return;
	}
	switch(value)
	{
		case '@':
			if (comxPrintMode_ != PRINTFILE)
				value = 219;
		break;

		case 0x1:
			value = 0xb6;
		break;

		case 0xa:
			return;
		break;

		case 0x1b:
			if (comxPrintMode_ != COMXPRINTPLOTTER)
			{
				printEscape_ = true;
				return;
			}
		break;

		case 0x8:
			if (comxPrintMode_ != COMXPRINTPLOTTER)
			{
				printEscape_ = true;
				return;
			}
		break;
	}

	p_Main->statusLedOnEvent();

	if (parallelFrameOpen_ || serialFrameOpen_)
	{
		if (value == 0xd)
		{
			if (comxPrintMode_ == COMXPRINTPRINTER)
				printerFramePointer->matrixLine(line_);
			else
				printerFramePointer->plotterLine(line_);
			line_ = "";
		}
		else
		{
			outputBuffer.Printf("%c",value);
			line_ = line_ + outputBuffer;
		}
	}
	if (comxPrintMode_ == PRINTFILE)
	{
		if (printFile_.Len() != 0)
		{
			if (!wxFile::Exists(printFileName_))
			{
				printerFile.Create(printFileName_);
				newPrintFile_ = false;
			}
			if (newPrintFile_)
			{
				newPrintFile_ = false;
				fileName = printFileName_;
				wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
				wxString Name = FullPath.GetName();
				wxString pathName = FullPath.GetPath();
				wxString Ext = FullPath.GetExt();
				int num = 0;
				wxString Number;

				while(wxFile::Exists(fileName))
				{
					num++;
					Number.Printf("%d", num);
					fileName = pathName + p_Main->getPathSep() + Name + "." + Number + "." + Ext;
				}
				printerFile.Create(fileName);
				printFileName_ = fileName;
			}
			printerFile.Open(printFileName_, wxFile::write_append);
			outputBuffer.Printf("%c",value);
			printerFile.Write(outputBuffer);
			printerFile.Close();
		}
	}

	p_Main->statusLedOffEvent();
}

void Printer::outSerial(Byte value)
{
	if (bit_ == stopBit_)  outParallel(printValue_);
	if ((bit_ > 0) &&(bit_ <= dataBits_))
	{
		if (value == 0)
			printValue_ += (1 <<(bit_ -1));
	}
	bit_++;
}

void Printer::outThermal(Byte value)
{
	printStarted_ = true;

	p_Main->statusLedOnEvent();

	if (thermalFrameOpen_)
		printerFramePointer->outThermal(value);

	p_Main->statusLedOffEvent();
}

void Printer::cycleThermal()
{
	if (thermalFrameOpen_)
	{
		thermalEf4_ = printerFramePointer->cycleThermal(thermalEf4_);
	}
	else
		thermalEf4_ = false;
}

void Printer::setPrintMode(int mode)
{
	comxPrintMode_ = mode;
}

void Printer::setTelmacPrintMode(int mode)
{
	telmacPrintMode_ = mode;
}

void Printer::setPecomPrintMode(int mode)
{
	pecomPrintMode_ = mode;
}

bool Printer::getThermalEf4()
{
	return thermalEf4_;
}

void Printer::closeFrames()
{
	if (parallelFrameOpen_ || serialFrameOpen_ || thermalFrameOpen_ || telmacFrameOpen_ || pecomFrameOpen_)
	{
		printerFramePointer->Destroy();
		parallelFrameOpen_ = false;
		serialFrameOpen_ = false;
		thermalFrameOpen_ = false;
		telmacFrameOpen_ = false;
		pecomFrameOpen_ = false;
	}
}

void Printer::closePreviewWindow()
{
	if (parallelFrameOpen_ || serialFrameOpen_ || thermalFrameOpen_ || telmacFrameOpen_ || pecomFrameOpen_)
	{
		delete printButtonPointer;
		delete previewButtonPointer;
		delete pageSetupButtonPointer;
		if (!thermalFrameOpen_ && !telmacFrameOpen_ && !pecomFrameOpen_)
		{
			delete printerPlotterButtonPointer;
			delete plotterRomPointer;
			delete plotterRomTextPointer;
			delete plotterExtensionRomPointer;
			delete plotterExtensionRomTextPointer;
		}
		parallelFrameOpen_ = false;
		serialFrameOpen_ = false;
		thermalFrameOpen_ = false;
		telmacFrameOpen_ = false;
		pecomFrameOpen_ = false;
	}
}

void Printer::onF4Parallel()
{
	printerType_ = COMXPRINTER;

	if (!parallelFrameOpen_)
	{
		onF4();
	}
	parallelFrameOpen_ = true;
}

void Printer::onF4Serial()
{
	printerType_ = COMXRS232;

	if (!serialFrameOpen_)
	{
		onF4();
	}
	serialFrameOpen_ = true;
}

void Printer::onTelmacF4()
{
	printerType_ = TELMACPRINTER;

	if (!telmacFrameOpen_)
	{
		printerFramePointer = new PrinterFrame( "Telmac Printer Output", wxPoint(-1, -1), wxSize(960, 1408/2), printerType_);
		printerFramePointer->CreateToolBar();
		printButtonPointer = new wxButton(printerFramePointer->GetToolBar(), wxID_PRINT, "PRINT", wxPoint(-1, -1), wxSize(-1, -1));
		printButtonPointer->SetToolTip("Send output to Printer");
		previewButtonPointer = new wxButton(printerFramePointer->GetToolBar(), wxID_PREVIEW, "PREVIEW", wxPoint(-1, -1), wxSize(-1, -1));
		previewButtonPointer->SetToolTip("Send output to Preview Window");
		pageSetupButtonPointer = new wxButton(printerFramePointer->GetToolBar(), wxID_PRINT_SETUP, "PAGE SETUP", wxPoint(-1, -1), wxSize(-1, -1));
		pageSetupButtonPointer->SetToolTip("Specify Preview and Printout page details");

		printerFramePointer->GetToolBar()->AddControl(printButtonPointer);
		printerFramePointer->GetToolBar()->AddControl(previewButtonPointer);
		printerFramePointer->GetToolBar()->AddControl(pageSetupButtonPointer);
		printerFramePointer->GetToolBar()->Realize();

		printerFramePointer->Show(true);
		printerFramePointer->init();
		enableToolbar(true);
	}
	telmacFrameOpen_ = true;
}

void Printer::onPecomF4()
{
	printerType_ = PECOMPRINTER;

	if (!pecomFrameOpen_)
	{
		printerFramePointer = new PrinterFrame( "Pecom Printer Output", wxPoint(-1, -1), wxSize(960, 1408/2), printerType_);
		printerFramePointer->CreateToolBar();
		printButtonPointer = new wxButton(printerFramePointer->GetToolBar(), wxID_PRINT, "PRINT", wxPoint(-1, -1), wxSize(-1, -1));
		printButtonPointer->SetToolTip("Send output to Printer");
		previewButtonPointer = new wxButton(printerFramePointer->GetToolBar(), wxID_PREVIEW, "PREVIEW", wxPoint(-1, -1), wxSize(-1, -1));
		previewButtonPointer->SetToolTip("Send output to Preview Window");
		pageSetupButtonPointer = new wxButton(printerFramePointer->GetToolBar(), wxID_PRINT_SETUP, "PAGE SETUP", wxPoint(-1, -1), wxSize(-1, -1));
		pageSetupButtonPointer->SetToolTip("Specify Preview and Printout page details");

		printerFramePointer->GetToolBar()->AddControl(printButtonPointer);
		printerFramePointer->GetToolBar()->AddControl(previewButtonPointer);
		printerFramePointer->GetToolBar()->AddControl(pageSetupButtonPointer);
		printerFramePointer->GetToolBar()->Realize();

		printerFramePointer->Show(true);
		printerFramePointer->init();
		enableToolbar(true);
	}
	pecomFrameOpen_ = true;
}

void Printer::onF4Thermal()
{
	printerType_ = COMXTHPRINTER;

	if (!thermalFrameOpen_)
	{
		printerFramePointer = new PrinterFrame( "COMX Thermal Printer Output", wxPoint(-1, -1), wxSize(480, 1408/2), COMXTHPRINTER);
		printerFramePointer->CreateToolBar();
		printButtonPointer = new wxButton(printerFramePointer->GetToolBar(), wxID_PRINT, "PRINT", wxPoint(-1, -1), wxSize(-1, -1));
		printButtonPointer->SetToolTip("Send output to Printer");
		previewButtonPointer = new wxButton(printerFramePointer->GetToolBar(), wxID_PREVIEW, "PREVIEW", wxPoint(-1, -1), wxSize(-1, -1));
		previewButtonPointer->SetToolTip("Send output to Preview Window");
		pageSetupButtonPointer = new wxButton(printerFramePointer->GetToolBar(), wxID_PRINT_SETUP, "PAGE SETUP", wxPoint(-1, -1), wxSize(-1, -1));
		pageSetupButtonPointer->SetToolTip("Specify Preview and Printout page details");

		printerFramePointer->GetToolBar()->AddControl(printButtonPointer);
		printerFramePointer->GetToolBar()->AddControl(previewButtonPointer);
		printerFramePointer->GetToolBar()->AddControl(pageSetupButtonPointer);
		printerFramePointer->GetToolBar()->Realize();

		printerFramePointer->Show(true);
		printerFramePointer->init();
		enableToolbar(false);

		thermalFrameOpen_ = true;
	}
}

void Printer::onF4()
{
	wxString choices[3];

	if (comxPrintMode_ == COMXPRINTPRINTER)
	{
		printerFramePointer = new PrinterFrame( "COMX Printer Output", wxPoint(-1, -1), wxSize(960, 1408/2), printerType_);
	}
	else
	{
		printerFramePointer = new PrinterFrame( "COMX Plotter Output", wxPoint(-1, -1), wxSize(960, 1408/2), printerType_);
	}
	printerFramePointer->CreateToolBar();
	printButtonPointer = new wxButton(printerFramePointer->GetToolBar(), wxID_PRINT, "PRINT", wxPoint(-1, -1), wxSize(-1, -1));
	printButtonPointer->SetToolTip("Send output to Printer");
	previewButtonPointer = new wxButton(printerFramePointer->GetToolBar(), wxID_PREVIEW, "PREVIEW", wxPoint(-1, -1), wxSize(-1, -1));
	previewButtonPointer->SetToolTip("Send output to Preview Window");
	pageSetupButtonPointer = new wxButton(printerFramePointer->GetToolBar(), wxID_PRINT_SETUP, "PAGE SETUP", wxPoint(-1, -1), wxSize(-1, -1));
	pageSetupButtonPointer->SetToolTip("Specify Preview and Printout page details");
	printerPlotterButtonPointer = new wxButton(printerFramePointer->GetToolBar(), PRINTER_PLOTTER, "PRINTER <-> PLOTTER", wxPoint(-1, -1), wxSize(-1, -1));
	printerPlotterButtonPointer->SetToolTip("Switch output PRINTER <-> PLOTTER");

	choices [0] = "";
	choices [1] = "pl80.bin";
	plotterRomPointer = new wxButton(printerFramePointer->GetToolBar(), PLOTTERROM, "ROM", wxPoint(-1, -1), wxSize(-1, -1));
	plotterRomPointer->SetToolTip("Browse for Plotter ROM File");
	plotterRomTextPointer = new wxComboBox(printerFramePointer->GetToolBar(), PLOTTERROMTEXT, p_Main->getPL80Data(1), wxPoint(-1, -1), wxSize(177, -1), 2, choices);
	plotterRomTextPointer->SetToolTip("Specify Plotter ROM File");

	choices [0] = "";
	choices [1] = "pl80.it.em.ou.bin";
	choices [2] = "pl80.tiny.bin";
	plotterExtensionRomPointer = new wxButton(printerFramePointer->GetToolBar(), PLOTTEREXT, "CHAR", wxPoint(-1, -1), wxSize(-1, -1));
	plotterExtensionRomPointer->SetToolTip("Browse for Plotter Character ROM File");
	plotterExtensionRomTextPointer = new wxComboBox(printerFramePointer->GetToolBar(), PLOTTEREXTTEXT, p_Main->getPL80Data(2), wxPoint(-1, -1), wxSize(177, -1), 3, choices);
	plotterExtensionRomTextPointer->SetToolTip("Specify Plotter Character ROM File");

	printerFramePointer->GetToolBar()->AddControl(printButtonPointer);
	printerFramePointer->GetToolBar()->AddControl(previewButtonPointer);
	printerFramePointer->GetToolBar()->AddControl(pageSetupButtonPointer);
	printerFramePointer->GetToolBar()->AddControl(printerPlotterButtonPointer);
	printerFramePointer->GetToolBar()->AddSeparator();
	printerFramePointer->GetToolBar()->AddControl(plotterRomPointer);
	printerFramePointer->GetToolBar()->AddControl(plotterRomTextPointer);
	printerFramePointer->GetToolBar()->AddControl(plotterExtensionRomPointer);
	printerFramePointer->GetToolBar()->AddControl(plotterExtensionRomTextPointer);
	printerFramePointer->GetToolBar()->Realize();

	printerFramePointer->Show(true);
	printerFramePointer->init();
	enableToolbar(false);
	if (comxPrintMode_ == COMXPRINTPRINTER)
		enablePlotterGui(false);
	else
		enablePlotterGui(true);
}

void Printer::printFinished()
{
	if (!printStarted_) return;

	printStarted_ = false;
	if (parallelFrameOpen_ || serialFrameOpen_ || thermalFrameOpen_)
	{
		enableToolbar(true);
		if (thermalFrameOpen_)
			printerFramePointer->printFinished();
	}
	else
	{
		setPrintfileName(p_Main->getPrintFile());
	}
}

void Printer::enableToolbar(bool status)
{
	printButtonPointer->Enable(status);
	previewButtonPointer->Enable(status);
	pageSetupButtonPointer->Enable(status);
}

void Printer::enablePlotterGui(bool status)
{
	plotterRomPointer->Enable(status);
	plotterRomTextPointer->Enable(status);
	plotterExtensionRomPointer->Enable(status);
	plotterExtensionRomTextPointer->Enable(status);
}

void Printer::disablePrintPlotter()
{
	printerPlotterButtonPointer->Enable(false);
}

void Printer::showPlotterRomFile(wxString fileName)
{
	plotterRomTextPointer->SetValue(fileName);
}

void Printer::showPlotterRomExtensionFile(wxString fileName)
{
	plotterExtensionRomTextPointer->SetValue(fileName);
}

void Printer::completePage(wxDC& dc, int page)
{
	printerFramePointer->completePage(dc, page);
}

int Printer::getNumberofPages()
{
	return printerFramePointer->getNumberofPages();
}

void Printer::setPrintfileName(wxString fileName)
{
	printFileName_ = fileName;
	newPrintFile_ = true;

	wxFileName FullPath = wxFileName::wxFileName(printFileName_, wxPATH_NATIVE);
	printFile_ = FullPath.GetFullName();
}

void Printer::setTelmacPrintfileName(wxString fileName)
{
	telmacPrintFileName_ = fileName;
	newTelmacPrintFile_ = true;

	wxFileName FullPath = wxFileName::wxFileName(telmacPrintFileName_, wxPATH_NATIVE);
	telmacPrintFile_ = FullPath.GetFullName();
}

void Printer::setPecomPrintfileName(wxString fileName)
{
	pecomPrintFileName_ = fileName;
	newPecomPrintFile_ = true;

	wxFileName FullPath = wxFileName::wxFileName(pecomPrintFileName_, wxPATH_NATIVE);
	pecomPrintFile_ = FullPath.GetFullName();
}

void Printer::printOut()
{
	if (printerType_ == TELMACPRINTER)
	{
		telmacPrintOut();
		return;
	}

	if (printerType_ == PECOMPRINTER)
	{
		pecomPrintOut();
		return;
	}

	wxPrintDialogData printDialogData(* PrintDataPointer);

	wxPrinter printer(& printDialogData);
	ComxPrintout printout(_T("COMX-35 Printout"), printerPointer);

	if (!printer.Print(NULL, &printout, true ))
	{
		if (wxPrinter::GetLastError() == wxPRINTER_ERROR)
			wxMessageBox(_T("There was a problem printing.\nPerhaps your current printer is not set correctly?"), _T("Printing"), wxOK);
		else
			wxMessageBox(_T("You canceled printing"), _T("Printing"), wxOK);
	}
	else
	{
		(*PrintDataPointer) = printer.GetPrintDialogData().GetPrintData();
	}
}

void Printer::telmacPrintOut()
{
	wxPrintDialogData printDialogData(* PrintDataPointer);

	wxPrinter printer(& printDialogData);
	ComxPrintout printout(_T("Telmac Printout"), printerPointer);

	if (!printer.Print(NULL, &printout, true ))
	{
		if (wxPrinter::GetLastError() == wxPRINTER_ERROR)
			wxMessageBox(_T("There was a problem printing.\nPerhaps your current printer is not set correctly?"), _T("Printing"), wxOK);
		else
			wxMessageBox(_T("You canceled printing"), _T("Printing"), wxOK);
	}
	else
	{
		(*PrintDataPointer) = printer.GetPrintDialogData().GetPrintData();
	}
}

void Printer::pecomPrintOut()
{
	wxPrintDialogData printDialogData(* PrintDataPointer);

	wxPrinter printer(& printDialogData);
	ComxPrintout printout(_T("Pecom Printout"), printerPointer);

	if (!printer.Print(NULL, &printout, true ))
	{
		if (wxPrinter::GetLastError() == wxPRINTER_ERROR)
			wxMessageBox(_T("There was a problem printing.\nPerhaps your current printer is not set correctly?"), _T("Printing"), wxOK);
		else
			wxMessageBox(_T("You canceled printing"), _T("Printing"), wxOK);
	}
	else
	{
		(*PrintDataPointer) = printer.GetPrintDialogData().GetPrintData();
	}
}

void Printer::printPreview()
{
	if (printerType_ == TELMACPRINTER)
	{
		telmacPrintPreview();
		return;
	}

	if (printerType_ == PECOMPRINTER)
	{
		pecomPrintPreview();
		return;
	}

	wxPrintDialogData printDialogData(* PrintDataPointer);
	wxPrintPreview *preview = new wxPrintPreview(new ComxPrintout(_T("COMX-35 Printout"), printerPointer), new ComxPrintout(_T("COMX-35 Printout"), printerPointer), & printDialogData);

	if (!preview->Ok())
	{
		delete preview;
		wxMessageBox(_T("There was a problem previewing.\nPerhaps your current printer is not set correctly?"), _T("Previewing"), wxOK);
		return;
	}

	wxPreviewFrame *frame = new wxPreviewFrame(preview, NULL, _T("COMX-35 Printer/Plotter Preview"), wxPoint(-1, -1), wxSize(600, 650));
	frame->Centre(wxBOTH);
	frame->Initialize();
	frame->Show();
}

void Printer::telmacPrintPreview()
{
	wxPrintDialogData printDialogData(* PrintDataPointer);
	wxPrintPreview *preview = new wxPrintPreview(new ComxPrintout(_T("Telmac Printout"), printerPointer), new ComxPrintout(_T("Telmac Printout"), printerPointer), & printDialogData);

	if (!preview->Ok())
	{
		delete preview;
		wxMessageBox(_T("There was a problem previewing.\nPerhaps your current printer is not set correctly?"), _T("Previewing"), wxOK);
		return;
	}

	wxPreviewFrame *frame = new wxPreviewFrame(preview, NULL, _T("Telmac Printer Preview"), wxPoint(-1, -1), wxSize(600, 650));
	frame->Centre(wxBOTH);
	frame->Initialize();
	frame->Show();
}

void Printer::pecomPrintPreview()
{
	wxPrintDialogData printDialogData(* PrintDataPointer);
	wxPrintPreview *preview = new wxPrintPreview(new ComxPrintout(_T("Pecom Printout"), printerPointer), new ComxPrintout(_T("Pecom Printout"), printerPointer), & printDialogData);

	if (!preview->Ok())
	{
		delete preview;
		wxMessageBox(_T("There was a problem previewing.\nPerhaps your current printer is not set correctly?"), _T("Previewing"), wxOK);
		return;
	}

	wxPreviewFrame *frame = new wxPreviewFrame(preview, NULL, _T("Pecom Printer Preview"), wxPoint(-1, -1), wxSize(600, 650));
	frame->Centre(wxBOTH);
	frame->Initialize();
	frame->Show();
}

void Printer::pageSetup()
{
   (*p_PageSetupData) = *PrintDataPointer;

    wxPageSetupDialog pageSetupDialog(NULL, p_PageSetupData);
    pageSetupDialog.ShowModal();

   (*PrintDataPointer) = pageSetupDialog.GetPageSetupDialogData().GetPrintData();
   (*p_PageSetupData) = pageSetupDialog.GetPageSetupDialogData();
}
