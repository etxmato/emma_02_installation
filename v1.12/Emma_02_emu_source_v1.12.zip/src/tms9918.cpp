/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

/*
 *******************************************************************
 *** This software is copyright 2006 by Michael H Riley          ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "app_icon.xpm"
//#include "elf_icon.xpm"
#endif

#include "wx/dcbuffer.h"
#include "main.h"
#include "tms9918.h"

BEGIN_EVENT_TABLE(Tms9918Screen, wxWindow)
	EVT_PAINT(Tms9918Screen::onPaint)
	EVT_CHAR(Tms9918Screen::onChar)
	EVT_KEY_DOWN(Tms9918Screen::onKeyDown)
	EVT_KEY_UP(Tms9918Screen::onKeyUp)
END_EVENT_TABLE()

Tms9918Screen::Tms9918Screen(wxWindow *parent, const wxSize& size, int zoom, int computerType)
: wxWindow(parent, wxID_ANY, wxDefaultPosition, size)
{
	zoom_ = zoom;
	computerType_ = computerType;
}

void Tms9918Screen::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxPaintDC dcWindow(this);
	p_Video->setReBlit();
}

void Tms9918Screen::onChar(wxKeyEvent& event)
{
	p_Computer->charEvent(event.GetKeyCode());
}

void Tms9918Screen::onKeyDown(wxKeyEvent& event)
{
	if (!p_Computer->keyDownPressed(event.GetKeyCode()))
		event.Skip();
}

void Tms9918Screen::onKeyUp(wxKeyEvent& event)
{
	if (!p_Computer->keyUpReleased(event.GetKeyCode()))
		event.Skip();
}

void Tms9918Screen::blit(wxCoord xdest, wxCoord ydest, wxCoord width, wxCoord height, wxDC *source, wxCoord xsrc, wxCoord ysrc)
{
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
#endif
	wxClientDC dcWindow(this);
	dcWindow.SetUserScale(zoom_, zoom_);
	dcWindow.Blit(xdest, ydest, width, height, source, xsrc, ysrc);
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#endif
}

void Tms9918Screen::drawBackground(wxColour clr, int xSize, int ySize, wxCoord offsetX, wxCoord offsetY)
{
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
#endif
	wxClientDC dcWindow(this);
	wxSize size = wxGetDisplaySize();

	dcWindow.SetUserScale(zoom_, zoom_);
	dcWindow.SetBrush(wxBrush(clr));
	dcWindow.SetPen(wxPen(clr));
	dcWindow.DrawRectangle(0, 0, size.x/zoom_, offsetY);
	dcWindow.DrawRectangle(0, offsetY, offsetX, ySize);
	dcWindow.DrawRectangle(offsetX+xSize, offsetY, offsetX+1, ySize);
	dcWindow.DrawRectangle(0, offsetY+ySize, size.x/zoom_, offsetY+1);
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#endif
}

void Tms9918Screen::setZoom(int zoom)
{
	zoom_ = zoom;
}

BEGIN_EVENT_TABLE(Tms9918, wxFrame)
	EVT_CLOSE (Tms9918::onClose)
END_EVENT_TABLE()

Tms9918::Tms9918(const wxString& title, const wxPoint& pos, const wxSize& size, int zoom, int computerType, double clock)
: Video(title, pos, size)
{
	computerType_ = computerType;
	zoom_ = zoom;
	restoreZoomAfterFullScreen_ = zoom;

	tms9918ScreenPointer = new Tms9918Screen(this, size, zoom, computerType);

	SetIcon(wxICON(app_icon));
//	SetIcon(wxICON(elf_icon));
	screenCopyPointer = new wxBitmap(320, 240);
	dcMemory.SelectObject(*screenCopyPointer);

	for (int i=0; i<8; i++) registers_[i] = 0;
	for (int i=0; i<16384; i++) tmsMemory_[i] = 0;
	mode_ = 0;
	nameAddress_ = 0;
	colorAddress_ = 0;
	patternAddress_ = 0;
	currentAddress_ = 0;
	toggle_ = 0;

	defineColours(computerType_);

	offsetX_ = 0;
	offsetY_ = 0;
	backGroundX_ = 0;
	backGroundY_ = 0;
	cycleSize_ = (int) (((clock * 1000000) / 8) / 50);
	cycleValue_ = cycleSize_;
	f3Pressed_ = false;
	newBackGround_ = false;
	fullScreenSet_ = false;
	updateTile_ = false;
	tileListPointer = NULL;

	this->SetClientSize(size);
}

Tms9918::~Tms9918()
{
	TileList *temp;

	dcMemory.SelectObject(wxNullBitmap);
	delete screenCopyPointer;
	delete tms9918ScreenPointer;
	if (updateTile_)
	{
		while(tileListPointer != NULL)
		{
			temp = tileListPointer;
			tileListPointer = temp->nextTile;
			delete temp;
		}
	}
}

void Tms9918::onClose(wxCloseEvent&WXUNUSED(event) )
{
	p_Main->stopComputer();
}

void Tms9918::setReBlit()
{
	newBackGround_ = true;
	reBlit_ = true;
}

void Tms9918::configure()
{
	int highOutput, lowOutput;

	wxString runningComp = p_Main->getRunningComputerStr();

	highOutput = p_Main->getConfigItem(_T(runningComp +"/TmsModeHighOutput"), 5l);
	lowOutput = p_Main->getConfigItem(_T(runningComp +"/TmsModeLowOutput"), 6l);

	p_Computer->setOutType(highOutput - 1, TMSHIGHOUT);
	p_Computer->setOutType(lowOutput - 1, TMSLOWOUT);
	p_Computer->setCycleType(VIDEOCYCLE, TMSCYCLE);

	wxString printBuffer;
	p_Main->message(_T("Configuring TMS 9918"));

	printBuffer.Printf(_T("	Output %d: register port, output %d: data port\n"), highOutput, lowOutput);
	p_Main->message(printBuffer);
}

void Tms9918::modeHighOut(Byte value)
{
	if (toggle_)
	{
		if ((value & 0xf8) == 0x80 )
		{
			registers_[value & 7] = value_;
			nameAddress_ = (registers_[2] & 0xf) << 10;
			colorAddress_ = registers_[3] << 6;
			patternAddress_ = (registers_[4] & 0x7) << 11;
			mode_ = 0; // Graphics I
			if (registers_[0] & 2) mode_ = 1; // Graphics II
			if (registers_[1] & 8) mode_ = 2; // Multicolor
			if (registers_[1] & 16) mode_ = 4; // Text
			if (mode_ == 1)
			{
				colorAddress_ = (registers_[3] & 128) ? 0x2000 : 0;
				patternAddress_ = (registers_[4] & 4) ? 0x2000 : 0;
			}
			reBlit_ = true;
			drawScreen();
		}
		if ((value & 0xc0) == 0x40)
		{
			currentAddress_ = value_ +((value & 0x3f) << 8);
		}
		toggle_ = 0;
	}
	else
	{
		value_ = value;
		toggle_ = 1;
	}
}

void Tms9918::modeLowOut(Byte value)
{
	int  p;
	Word addr;

	addr = currentAddress_;
	tmsMemory_[currentAddress_++] = value;

#if defined(__WXGTK__)
				wxMutexGuiEnter();
#endif
	switch(mode_)
	{
		case 0:
			if (addr >= nameAddress_ && addr < nameAddress_+768)
			{
				drawTile(addr - nameAddress_);
#if defined(__WXGTK__)
				wxMutexGuiLeave();
#endif
				return;
			}
			if (addr >= colorAddress_ && addr < colorAddress_+32)
			{
				p = addr - colorAddress_;
				for (int i=0; i<768; i++)
					if ((tmsMemory_[nameAddress_+i] >> 3) == p) drawTile(i);
#if defined(__WXGTK__)
				wxMutexGuiLeave();
#endif
				return;
			}
			if (addr >= patternAddress_ && addr < patternAddress_+2048)
			{
				p = (addr - patternAddress_) >> 3;
				for (int i=0; i<768; i++)
					if (tmsMemory_[nameAddress_+i] == p) drawTile(i);
			}
		break;

		case 1:
			if (addr >= nameAddress_ && addr < nameAddress_+768)
			{
				drawTile(addr - nameAddress_);
#if defined(__WXGTK__)
				wxMutexGuiLeave();
#endif
				return;
			}
			if (addr >= colorAddress_ && addr < colorAddress_+2048)
			{
				p = addr - colorAddress_;
				for (int i=0; i<256; i++)
					if (tmsMemory_[nameAddress_+i] == p) drawTile(i);
#if defined(__WXGTK__)
				wxMutexGuiLeave();
#endif
				return;
			}
			if (addr >= colorAddress_+2048 && addr < colorAddress_+4096)
			{
				p = addr -(colorAddress_-2048);
				for (int i=256; i<512; i++)
					if (tmsMemory_[nameAddress_+i] == p) drawTile(i);
#if defined(__WXGTK__)
				wxMutexGuiLeave();
#endif
				return;
			}
			if (addr >= colorAddress_+4096 && addr < colorAddress_+6144)
			{
				p = addr -(colorAddress_-4096);
				for (int i=512; i<768; i++)
					if (tmsMemory_[nameAddress_+i] == p) drawTile(i);
#if defined(__WXGTK__)
				wxMutexGuiLeave();
#endif
				return;
			}
			if (addr >= patternAddress_ && addr < patternAddress_+2048)
			{
				p = (addr -(patternAddress_-2048)) >> 3;
				for (int i=0; i<256; i++)
					if (tmsMemory_[nameAddress_+i] == p) drawTile(i);
#if defined(__WXGTK__)
				wxMutexGuiLeave();
#endif
				return;
			}
			if (addr >= patternAddress_+2048 && addr < patternAddress_+4096)
			{
				p = (addr -(patternAddress_-2048)) >> 3;
				for (int i=256; i<512; i++)
					if (tmsMemory_[nameAddress_+i] == p) drawTile(i);
#if defined(__WXGTK__)
				wxMutexGuiLeave();
#endif
				return;
			}
			if (addr >= patternAddress_+4096 && addr < patternAddress_+6144)
			{
				p = (addr -(patternAddress_-4096)) >> 3;
				for (int i=512; i<768; i++)
					if (tmsMemory_[nameAddress_+i] == p) drawTile(i);
			}
		break;

		case 4:
			if (addr >= nameAddress_ && addr < nameAddress_+960)
			{
				drawTile(addr - nameAddress_);
			}
		break;
	}
#if defined(__WXGTK__)
	wxMutexGuiLeave();
#endif
}

void Tms9918::cycleTms()
{
	cycleValue_ --;
	if (cycleValue_ == 0)
	{
		cycleValue_ = cycleSize_;
		if (f3Pressed_)
		{
			fullScreenSet_ = !fullScreenSet_;
			this->ShowFullScreen(fullScreenSet_);
			if (fullScreenSet_)
			{
				setFullScreen();
				backGroundX_ = FSBACKX;
				backGroundY_ = FSBACKY;
			}
			else
			{
				zoom_ = restoreZoomAfterFullScreen_;
				this->SetClientSize(320*zoom_, 240*zoom_);
				tms9918ScreenPointer->SetClientSize(320*zoom_, 240*zoom_);
				tms9918ScreenPointer->setZoom(zoom_);
				offsetX_ = 0;
				offsetY_ = 0;
				backGroundX_ = 0;
				backGroundY_ = 0;
			}
			f3Pressed_ = false;
			reBlit_ = true;
		}
		reDrawScreen();
	}
}

void Tms9918::reDrawScreen()
{
	copyScreen();
}

void Tms9918::copyScreen()
{
	TileList *temp;

	if (reColour_)
	{
		for (int i=0; i<numberOfColours_; i++)
		{
			colour_[i] = colourNew_[i];
			brushColour_[i] = brushColourNew_[i];
			penColour_[i] = penColourNew_[i];
		}
		drawScreen();
		reBlit_ = true;
		reColour_ = false;
	}

	if (fullScreenSet_ && newBackGround_)
		drawBackground();

	if (reBlit_)
	{
		if (fullScreenSet_)
			tms9918ScreenPointer->blit(offsetX_, offsetY_, TMSX, TMSY, &dcMemory, backGroundX_, backGroundY_);
		else
			tms9918ScreenPointer->blit(offsetX_, offsetY_, 320, 240, &dcMemory, backGroundX_, backGroundY_);
		reBlit_ = false;
		if (updateTile_)
		{
			updateTile_ = false;
			while(tileListPointer != NULL)
			{
				temp = tileListPointer;
				tileListPointer = temp->nextTile;
				delete temp;
			}
		}
	}
	if (updateTile_)
	{
		updateTile_ = false;
		while(tileListPointer != NULL)
		{
			tms9918ScreenPointer->blit(offsetX_+ tileListPointer->x-backGroundX_, offsetY_+tileListPointer->y-backGroundY_, tileListPointer->size, 8, &dcMemory, tileListPointer->x, tileListPointer->y);
			temp = tileListPointer;
			tileListPointer = temp->nextTile;
			delete temp;
		}
	}
}

void Tms9918::setColour(int clr)
{
	dcMemory.SetBrush(brushColour_[clr+16]);
	dcMemory.SetPen(penColour_[clr+16]);
}

void Tms9918::drawTile(Word tile)
{
	int p;
	int c;
	int b;
	int cl;
	int x,y, size;
	Word ofs;

	p = tmsMemory_[nameAddress_+tile];
	switch(mode_)
	{
		case 0:
			c = tmsMemory_[colorAddress_ +(p >> 3)];
			x = (tile % 32)*8+BACKX;
			y = (tile / 32)*8+BACKY;
			size = 8;

			for (int py=0; py<8; py++)
			{
				b = tmsMemory_[patternAddress_+p*8+py];
				for (int px=0; px<8; px++)
				{
					cl = (b & 128) ? c>>4 : c & 0xf;
					if (cl == 0) cl = registers_[7] & 0xf;
					if (cl == 0) cl = 1;
					setColour(cl);
					dcMemory.DrawPoint(x+px, y+py);
					b = (b << 1) & 0xff;
				}
			}
		break;

		case 1:
			x = tile % 32;
			y = tile / 32;
			size = 8;

			ofs = 0;
			if (y>7) ofs = 2048;
			if (y>15) ofs = 4096;

			x = x*8+BACKX;
			y = y*8+BACKY;

			for (int py=0; py<8; py++)
			{
				b = tmsMemory_[ofs + patternAddress_ + p*8 + py];
				c = tmsMemory_[ofs + colorAddress_ + p*8 + py];
				for (int px=0; px<8; px++)
				{
					cl = (b & 128) ? c>>4 : c & 0xf;
					if (cl == 0) cl = registers_[7] & 0xf;
					if (cl == 0) cl = 1;
 					setColour(cl);
					dcMemory.DrawPoint(x+px, y+py);
					b = (b << 1) & 0xff;
				}
			}
		break;

		case 4:
			c = registers_[7];
			x = (tile % 40)*6+BACKX+8;
			y = (tile / 40)*8+BACKY;
			size = 6;

			setColour(c & 0xf);
			dcMemory.DrawRectangle(x, y, 6, 8);

			for (int py=0; py<8; py++)
			{
				b = tmsMemory_[patternAddress_+p*8+py];
				for (int px=0; px<6; px++)
				{
					if (b & 128)
					{
						cl = (c>>4) & 0xf;
						if (cl == 0) cl = registers_[7] & 0xf;
						setColour(cl);
						dcMemory.DrawPoint(x+px, y+py);
					}
					b = (b << 1) & 0xff;
				}
			}
		break;

		default:
			x = 0;
			y = 0;
			size = 0;
		break;
	}
#if defined(__WXGTK__)
	reBlit_ = true;
#else
	if (reBlit_)  return;
	TileList *temp = new TileList;
	temp->x = x;
	temp->y = y;
	temp->size = size;
	temp->nextTile = tileListPointer;
	tileListPointer = temp;
	updateTile_ = true;
#endif
}

void Tms9918::drawScreen()
{
#if defined(__WXGTK__)
	wxMutexGuiEnter();
#endif
	if (mode_ == 0)
	{
		for (int x=0; x<768; x++)
			drawTile(x);
		if (fullScreenSet_)  return;
		int cl = registers_[7] & 0xf;
		setColour(cl);
		dcMemory.DrawRectangle(0, 0,(256+(BACKX*2)), BACKY);
		dcMemory.DrawRectangle(0, BACKY, BACKX, 192);
		dcMemory.DrawRectangle((256+BACKX), BACKY, BACKX, 192);
		dcMemory.DrawRectangle(0,(192+BACKY),(256+(BACKX*2)), BACKY);
	}
	if (mode_ == 1)
	{
		for (int x=0; x<768; x++)
			drawTile(x);
		if (fullScreenSet_)  return;
		int cl = registers_[7] & 0xf;
		setColour(cl);
		dcMemory.DrawRectangle(0, 0,(256+(BACKX*2)), BACKY);
		dcMemory.DrawRectangle(0, BACKY, BACKX, 192);
		dcMemory.DrawRectangle((256+BACKX), BACKY, BACKX, 192);
		dcMemory.DrawRectangle(0,(192+BACKY),(256+(BACKX*2)), BACKY);
	}
	if (mode_ == 4)
	{
		for (int x=0; x<960; x++)
			drawTile(x);
		if (fullScreenSet_)  return;
		int cl = registers_[7] & 0xf;
		setColour(cl);
		dcMemory.DrawRectangle(0, 0,(256+(BACKX*2)), BACKY);
		dcMemory.DrawRectangle(0, BACKY,(BACKX+8), 192);
		dcMemory.DrawRectangle((256+BACKX-8), BACKY,(BACKX+8), 192);
		dcMemory.DrawRectangle(0,(192+BACKY),(256+(BACKX*2)), BACKY);
	}
#if defined(__WXGTK__)
	wxMutexGuiLeave();
#endif
}

void Tms9918::setZoom(int zoom)
{
	restoreZoomAfterFullScreen_ = zoom;
	zoom_ = zoom;
	this->SetClientSize((256+(BACKX*2))*zoom,(192+(BACKY*2))*zoom);
	tms9918ScreenPointer->SetClientSize((256+(BACKX*2))*zoom,(192+(BACKY*2))*zoom);

	tms9918ScreenPointer->setZoom(zoom_);
	reBlit_ = true;
}

void Tms9918::onF3()
{
	f3Pressed_ = true;
}

void Tms9918::setFullScreen()
{
	int zoomx, zoomy;
	wxSize size;

#if defined(__WXGTK__)
	wxMutexGuiEnter();
#endif
	size = wxGetDisplaySize();
	zoomx = (int) (size.x/TMSX);
	zoomy = (int) (size.y/TMSY);
	if (zoomx <= zoomy)
		zoom_ = zoomx;
	else
		zoom_ = zoomy;
	offsetX_ = (size.x/zoom_ - TMSX) / 2;
	offsetY_ = (size.y/zoom_ - TMSY) / 2;
	tms9918ScreenPointer->setZoom(zoom_);
	tms9918ScreenPointer->SetClientSize(size.x, size.y);
#if defined(__WXGTK__)
	wxMutexGuiLeave();
#endif
	newBackGround_ = true;
}

void Tms9918::drawBackground()
{
	tms9918ScreenPointer->drawBackground(colour_[(registers_[7] & 0xf)+16], TMSX, TMSY, offsetX_, offsetY_);
	newBackGround_ = false;
}

void Tms9918::onF5()
{
	int num = 0;
	wxFile screenDump;
	wxString number;
	wxString fileName;

	fileName = p_Main->getScreenDumpFile();

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	wxString Name = FullPath.GetName();
	wxString Path = FullPath.GetPath();
	wxString Ext = FullPath.GetExt();

	while(wxFile::Exists(fileName))
	{
		num++;
		number.Printf("%d", num);
		fileName = Path + p_Main->getPathSep() + Name + "." + number + "." + Ext;
	}
	screenDump.Create(fileName);
	if (Ext == "bmp")
	{
		screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_BMP);
		return;
	}
	if (Ext == "jpeg")
	{
		screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_JPEG);
		return;
	}
	if (Ext == "png")
	{
		screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_PNG);
		return;
	}
	if (Ext == "pcx")
	{
		screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_PCX);
		return;
	}
	screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_BMP);
}

