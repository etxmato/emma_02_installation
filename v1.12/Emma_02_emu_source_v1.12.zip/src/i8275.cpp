/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "app_icon.xpm"
//#include "elf2k_icon.xpm"
//#include "elf_icon.xpm"
#endif

#define I8275CHARW 8

#define C_NONE 0
#define C_RESET 1
#define C_START_DISPLAY 2
#define C_STOP_DISPLAY 3
#define C_LIGHT_PEN 4
#define C_LOAD_CURSOR 5
#define C_ENABLE_INT 6
#define C_DISABLE_INT 7
#define C_PRESET_COUNTERS 8

#define FOREGROUND8275 2
#define BACKGROUND8275 3
#define HIGHLIGHT8275 4

#include "main.h"
#include "i8275.h"

BEGIN_EVENT_TABLE(i8275Screen, wxWindow)
	EVT_PAINT(i8275Screen::onPaint)
	EVT_CHAR(i8275Screen::onChar)
	EVT_KEY_DOWN(i8275Screen::onKeyDown)
	EVT_KEY_UP(i8275Screen::onKeyUp)
END_EVENT_TABLE()

int const SSS [8] = {0, 7, 15, 23, 31, 39, 47, 55};
int const BB [4] = {1, 2, 4, 8};

i8275Screen::i8275Screen(wxWindow *parent, const wxSize& size, int zoom, int computerType)
: wxWindow(parent, wxID_ANY, wxDefaultPosition, size, wxFULL_REPAINT_ON_RESIZE)
{
	zoom_ = zoom;
	computerType_ = computerType;
}

void i8275Screen::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxPaintDC dcWindow(this);
	p_Video->setReBlit();
}

void i8275Screen::onChar(wxKeyEvent& event)
{
	p_Computer->charEvent(event.GetKeyCode());
}

void i8275Screen::onKeyDown(wxKeyEvent& event)
{
	if (!p_Computer->keyDownPressed(event.GetKeyCode()))
		event.Skip();
}

void i8275Screen::onKeyUp(wxKeyEvent& event)
{
	if (!p_Computer->keyUpReleased(event.GetKeyCode()))
		event.Skip();
}

void i8275Screen::blit(wxCoord xdest, wxCoord ydest, wxCoord width, wxCoord height, wxDC *source, wxCoord xsrc, wxCoord ysrc)
{
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
#endif
	wxClientDC dcWindow(this);
	dcWindow.SetUserScale(zoom_, zoom_);
	dcWindow.Blit(xdest, ydest, width, height, source, xsrc, ysrc);
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#endif
}

void i8275Screen::drawBackground(wxColour clr, int i8275X, int i8275Y, wxCoord offsetX, wxCoord offsetY)
{
#if defined(__WXGTK__)
	wxMutexGuiEnter();
#endif
	wxClientDC dcWindow(this);
	wxSize size = wxGetDisplaySize();

	dcWindow.SetUserScale(zoom_, zoom_);
	dcWindow.SetBrush(wxBrush(clr));
	dcWindow.SetPen(wxPen(clr));
	dcWindow.DrawRectangle(0, 0, size.x/zoom_, offsetY);
	dcWindow.DrawRectangle(0, offsetY, offsetX, i8275Y);
	dcWindow.DrawRectangle(offsetX+i8275X, offsetY, offsetX+1, i8275Y);
	dcWindow.DrawRectangle(0, offsetY+i8275Y, size.x/zoom_, offsetY+1);
#if defined(__WXGTK__)
	wxMutexGuiLeave();
#endif
}

void i8275Screen::drawRectangle(wxColour clr, int x, int y, wxCoord width, wxCoord height)
{
	wxClientDC dcWindow(this);

	dcWindow.SetBrush(wxBrush(clr));
	dcWindow.SetPen(wxPen(clr));
	dcWindow.DrawRectangle(x, y, width, height);
}

void i8275Screen::setZoom(int zoom)
{
	zoom_ = zoom;
}

BEGIN_EVENT_TABLE(i8275, wxFrame)
	EVT_CLOSE (i8275::onClose)
END_EVENT_TABLE()

i8275::i8275(const wxString& title, const wxPoint& pos, const wxSize& size, int zoom, int computerType, double clock)
: Video(title, pos, size)
{
	computerType_ = computerType;
	clock_ = clock;

	SetIcon(wxICON(app_icon));
	switch(computerType_)
	{
		case ELF:
			readCharRomFile(p_Main->getCharRomDir(ELF), "CharRomElf");
			interlace_ = p_Main->getCheckBox("InterlaceElf");
//			SetIcon(wxICON(elf_icon));
		break;

		case ELFII:
			readCharRomFile(p_Main->getCharRomDir(ELFII), "CharRomElfII");
			interlace_ = p_Main->getCheckBox("InterlaceElfII");
//			SetIcon(wxICON(elf_icon));
		break;

		case ELF2K:
			readCharRomFile(p_Main->getCharRomDir(ELF2K), "CharRomElf2K");
			interlace_ = p_Main->getCheckBox("InterlaceElf2K");
//			SetIcon(wxICON(elf2k_icon));
		break;

		case SUPERELF:
			readCharRomFile(p_Main->getCharRomDir(SUPERELF), "CharRomSuperElf");
			interlace_ = p_Main->getCheckBox("InterlaceSuperElf");
//			SetIcon(wxICON(elf_icon));
		break;
	}

	defineColours(computerType_);

	fullScreenSet_ = false;
	zoom_ = zoom;
	restoreZoomAfterFullScreen_ = zoom;

	horizontalCharactersPerRow_ = 80;
	verticalRowsPerFrame_ = 24;
	linesPerCharacterRow_ = 10;
	verticalRetraceRowCount_ = 2;
	horizontalRetraceCount_ = 16;
	burstCountCode_ = 8;
	burstSpaceCode_ = 0;
	lineCounterMode_ = 1;
	screenCopyPointer = new wxBitmap(horizontalCharactersPerRow_*I8275CHARW*zoom_, verticalRowsPerFrame_*linesPerCharacterRow_*2*zoom_);
	dcMemory.SelectObject(*screenCopyPointer);

	i8275ScreenPointer = new i8275Screen(this, size, zoom, computerType);

	horizontalRetraceCycleSize8275_ = (int) ((((clock * 1000000) / 8) / 60) / ((verticalRowsPerFrame_+verticalRetraceRowCount_)*(horizontalCharactersPerRow_+horizontalRetraceCount_))*horizontalRetraceCount_);
	rowCycleSize8275_ = (int) ((((clock * 1000000) / 8) / 60) / (verticalRowsPerFrame_+verticalRetraceRowCount_))-horizontalRetraceCycleSize8275_;
	verticalRetraceCycleSize8275_ = (int) ((((clock * 1000000) / 8) / 60) / (verticalRowsPerFrame_+verticalRetraceRowCount_)*verticalRetraceRowCount_);
	dmaCycleSize8275_ = (int) ((((clock * 1000000) / 8) / 60) / ((verticalRowsPerFrame_+verticalRetraceRowCount_)*(horizontalCharactersPerRow_+horizontalRetraceCount_))*burstSpaceCode_);

	cycleValue8275_ = -1;
	dmaCycleValue8275_ = -1;
	retrace_ = false;
	screenLocation_ = 0;
	bufferLocation_ = 0;
	reverse_ = false;
	underline_ = false;
	highlight_ = false;
	gpa_ = 0;
	blink_ = false;
	blinkOn_ = false;
	cursorBlinkOn_ = true;
	cursorLine_ = false;
	cursorBlinking_ = false;
	attributeChange_ = false;
	blinkCount_ = 16;
	videoM_ = 2;
	status_ = 0;
	ef_ = 1;
	cursorCharPosition_ = 0;
	cursorRowPosition_ = 0;
	cursorAddress_ = 0;
//	videoSyncCount_ = 0;
	for (int i=0; i<5120; i++)
	{
		i8275ram_[i] = 32;
		cursorReset_[i] = false;
		reverseScr_[i] = false;
		underlineScr_[i] = false;
		highlightScr_[i] = false;
		blinkScr_[i] = false;
		gpaScr_[i] = 0;
	}

	this->SetBackgroundColour(colour_[BACKGROUND8275]);
	this->SetClientSize(horizontalCharactersPerRow_*I8275CHARW*zoom_, verticalRowsPerFrame_*linesPerCharacterRow_*2*zoom_);
	characterListPointer8275 = NULL;
}

i8275::~i8275()
{
	CharacterList8275 *temp;

	dcMemory.SelectObject(wxNullBitmap);
	delete screenCopyPointer;
	delete i8275ScreenPointer;
	if (updateCharacter8275_)
	{
		while(characterListPointer8275 != NULL)
		{
			temp = characterListPointer8275;
			characterListPointer8275 = temp->nextCharacter;
			delete temp;
		}
	}
}

void i8275::onClose(wxCloseEvent&WXUNUSED(event) )
{
	p_Main->stopComputer();
//	Destroy();
}

void i8275::setReBlit()
{
	newBackGround_ = true;
	reDraw_ = true;
}

void i8275::configure8275()
{
	wxString runningComp = p_Main->getRunningComputerStr();

	int i8275WriteCommand = p_Main->getConfigItem(_T(runningComp+"/I8275WriteCommand"), 5l);
	int i8275ReadStatus = p_Main->getConfigItem(_T(runningComp+"/I8275ReadStatus"), 5l);
	int i8275WriteParameter = p_Main->getConfigItem(_T(runningComp+"/I8275WriteParameter"), 1l);
	int i8275ReadParameter = p_Main->getConfigItem(_T(runningComp+"/I8275ReadParameter"), 1l);
	int i8275VerticalRetrace = p_Main->getConfigItem(_T(runningComp+"/I8275VerticalRetrace"), 1l);

	p_Computer->setCycleType(VIDEOCYCLE, I8275CYCLE);
	p_Computer->setOutType(i8275WriteParameter - 1, I8275PREGWRITE);
	p_Computer->setOutType(i8275WriteCommand - 1, I8275CREGWRITE);
	p_Computer->setInType(i8275ReadParameter - 1, I8275PREGREAD);
	p_Computer->setInType(i8275ReadStatus - 1, I8275SREGREAD);
	p_Computer->setEfType(i8275VerticalRetrace, I8275EF);

	p_Main->message("Configuring intel 8275");

	wxString printBuffer;
	printBuffer.Printf("	Output %d write command, input %d read status", i8275WriteCommand, i8275ReadStatus);
	p_Main->message(printBuffer);
	printBuffer.Printf("	Output %d write parameter, input %d read parameter", i8275WriteParameter, i8275ReadParameter);
	p_Main->message(printBuffer);
	printBuffer.Printf("	EF %d: vertical retrace\n", i8275VerticalRetrace);
	p_Main->message(printBuffer);
}

void i8275::init8275()
{
	offsetX_ = 0;
	offsetY_ = 0;
	f3Pressed_ = false;
	reDraw_ = true;
	reBlit_ = false;
	reBlink_ = false;
	newBackGround_ = false;
	updateCharacter8275_ = false;
}

void i8275::setZoom(int zoom)
{
	restoreZoomAfterFullScreen_ = zoom;
	zoom_ = zoom;
	this->SetClientSize(horizontalCharactersPerRow_*I8275CHARW*zoom_, verticalRowsPerFrame_*linesPerCharacterRow_*2*zoom_);
	i8275ScreenPointer->SetClientSize(horizontalCharactersPerRow_*I8275CHARW*zoom_, verticalRowsPerFrame_*linesPerCharacterRow_*2*zoom_);

	i8275ScreenPointer->setZoom(zoom_);
	reBlit_ = true;
}

void i8275::onF3()
{
	f3Pressed_ = true;
}

void i8275::onF5()
{
	int num = 0;
	wxFile screenDump;
	wxString number;
	wxString fileName;

	fileName = p_Main->getScreenDumpFile();

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	wxString Name = FullPath.GetName();
	wxString Path = FullPath.GetPath();
	wxString Ext = FullPath.GetExt();

	while(wxFile::Exists(fileName))
	{
		num++;
		number.Printf("%d", num);
		fileName = Path + p_Main->getPathSep() + Name + "." + number + "." + Ext;
	}
	screenDump.Create(fileName);
	if (Ext == "bmp")
	{
		screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_BMP);
		return;
	}
	if (Ext == "jpeg")
	{
		screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_JPEG);
		return;
	}
	if (Ext == "png")
	{
		screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_PNG);
		return;
	}
	if (Ext == "pcx")
	{
		screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_PCX);
		return;
	}
	screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_BMP);
}

void i8275::setFullScreen()
{
	int zoomx, zoomy;
	wxSize size;

#if defined(__WXGTK__)
	wxMutexGuiEnter();
#endif
	size = wxGetDisplaySize();
	zoomx = (int) (size.x/(horizontalCharactersPerRow_*I8275CHARW));
	zoomy = (int) (size.y/(verticalRowsPerFrame_*linesPerCharacterRow_*2));
	if (zoomx <= zoomy)
		zoom_ = zoomx;
	else
		zoom_ = zoomy;
	offsetX_ = (size.x/zoom_ - (horizontalCharactersPerRow_*I8275CHARW)) / 2;
	offsetY_ = (size.y/zoom_ - (verticalRowsPerFrame_*linesPerCharacterRow_*2)) / 2;
	i8275ScreenPointer->setZoom(zoom_);
	i8275ScreenPointer->SetClientSize(size.x, size.y);
	newBackGround_ = true;
#if defined(__WXGTK__)
	wxMutexGuiLeave();
#endif
}

void i8275::drawBackground()
{
	i8275ScreenPointer->drawBackground(colour_[BACKGROUND8275], (horizontalCharactersPerRow_*I8275CHARW),  (verticalRowsPerFrame_*linesPerCharacterRow_*2), offsetX_, offsetY_);
	newBackGround_ = false;
}

Byte i8275::ef8275()
{
	return ef_;
}

void i8275::pRegWrite(Byte value)
{
	float characterCycleSize8275_, fullRowCycleSize8275_;

	if (command_ == 0)
	{
		status_ |= 0x8;
		return;
	}

	switch (command_)
	{
		case C_RESET:
			switch (parameters_)
			{
				case 4:
					spacedRows_ = ((value & 0x80) == 1);
					value = (value & 0x7f) + 1;
					if (value >= 80)  value = 80;
					horizontalCharactersPerRow_ = value;
					changeSize();
//					p_Main->message("Column:");
//					p_Main->messageInt(horizontalCharactersPerRow_);
				break;

				case 3:
					verticalRetraceRowCount_ = ((value & 0xc0) >> 6) + 1;
					verticalRowsPerFrame_ = (value & 0x3f) + 1;
					changeSize();
//					p_Main->message("Rows:");
//					p_Main->messageInt(verticalRowsPerFrame_);
//					p_Main->message("Vertical Retrace Row Count:");
//					p_Main->messageInt(verticalRetraceRowCount_);
				break;

				case 2:
					underLinePlacement_ = ((value & 0xf0) >> 4) + 1;
					linesPerCharacterRow_ = (value & 0x0f) + 1;
					changeSize();
//					p_Main->message("Under Line Placement");
//					p_Main->messageInt(underLinePlacement_);
//					p_Main->message("ScanLine:");
//					p_Main->messageInt(linesPerCharacterRow_);
				break;

				case 1:
					lineCounterMode_ = (value & 0x80) >> 7;
					fieldAttributeMode_ = (value & 0x40) >> 6;
					cursorBlinking_ = (((value & 0x20) >> 4) == 0);
					cursorBlinkOn_ = true;
					cursorLine_ = (((value & 0x10) >> 4) == 1);
					horizontalRetraceCount_ = ((value & 0x0f) + 1)*2;
					changeSize();
//					p_Main->message("Line Counter Mode:");
//					p_Main->messageInt(lineCounterMode_);
//					p_Main->message("Field Attribute Mode:");
//					p_Main->messageInt(fieldAttributeMode_);
//					p_Main->message("Horizontal Retrace Count:");
//					p_Main->messageInt(horizontalRetraceCount_);
				break;
			}
			characterCycleSize8275_ = (((clock_ * 1000000) / 8) / 60) / ((verticalRowsPerFrame_+verticalRetraceRowCount_)*(horizontalCharactersPerRow_+horizontalRetraceCount_));
			horizontalRetraceCycleSize8275_ = (int) (characterCycleSize8275_*horizontalRetraceCount_);
			fullRowCycleSize8275_ = (((clock_ * 1000000) / 8) / 60) / (verticalRowsPerFrame_+verticalRetraceRowCount_);
			rowCycleSize8275_ = (int) (fullRowCycleSize8275_-(characterCycleSize8275_*horizontalRetraceCount_));
			verticalRetraceCycleSize8275_ = (int) (fullRowCycleSize8275_*verticalRetraceRowCount_);
			dmaCycleSize8275_ = (int) ((((clock_ * 1000000) / 8) / 60) / ((verticalRowsPerFrame_+verticalRetraceRowCount_)*(horizontalCharactersPerRow_+horizontalRetraceCount_))*burstSpaceCode_);
//					p_Main->message("horizontalRetraceCycleSize8275_");
//					p_Main->messageInt(horizontalRetraceCycleSize8275_);
//					p_Main->message("rowCycleSize8275_");
//					p_Main->messageInt(rowCycleSize8275_);
//					p_Main->message("verticalRetraceCycleSize8275_");
//					p_Main->messageInt(verticalRetraceCycleSize8275_);
		break;

		case C_LOAD_CURSOR:
			switch (parameters_)
			{
				case 2:
					cursorCharPosition_ = value;
					cursorAddress_ = cursorCharPosition_ + (cursorRowPosition_*80);
				break;
				case 1:
					cursorRowPosition_ = value;
					cursorAddress_ = cursorCharPosition_ + (cursorRowPosition_*80);
				break;
			}
		break;
	}

	parameters_--;
	if (parameters_ < 0)
	{
		status_ |= 0x8;
		parameters_ = 0;
	}
}

void i8275::cRegWrite(Byte value)
{
	if (parameters_ != 0)
		status_ |= 0x8;

/*	if (value != 0x80)
	{
	p_Main->message("8275 Register_");
	p_Main->messageInt(value);
	}*/
	parameters_ = 0;
	command_ = C_NONE;

	if (value == 0) // RESET
	{
		command_ = C_RESET;
		parameters_ = 4;
		status_ &= 0xbf;
	}

	if (value == 0x40) // STOP_DISPLAY
	{
		cycleValue8275_ = -1;
		dmaCycleValue8275_ = -1;
		status_ &= 0xfb;

		dcMemory.SetBrush(brushColour_[BACKGROUND8275]);
		dcMemory.SetPen(penColour_[BACKGROUND8275]);
		dcMemory.DrawRectangle(0, 0, horizontalCharactersPerRow_*I8275CHARW, verticalRowsPerFrame_*linesPerCharacterRow_*2);
		reBlit_ = true;
		copyScreen();
	}

	if (value == 0x60) // LIGHT_PEN
	{
		command_ = C_LIGHT_PEN;
		parameters_ = 2;
	}

	if (value == 0x80) // LOAD_CURSOR
	{
		command_ = C_LOAD_CURSOR;
		parameters_ = 2;
	}

	if (value == 0xe0) // PRESET_COUNTERS
	{
		bufferLocation_ = 0;
		screenLocation_ = 0;
	}

	if ((value & 0xf0) == 0x20)  // START DISPLAY
	{
		burstSpaceCode_ = SSS[(value & 0x1c) >> 2];
		burstCountCode_ = BB[(value & 0x3)];
//		p_Main->message("Burst Space Code:");
//		p_Main->messageInt(burstSpaceCode_);
//		p_Main->message("Burst Count Code:");
//		p_Main->messageInt(burstCountCode_);
		bufferLocation_ = 0;
		screenLocation_ = 0;
		cycleValue8275_ = rowCycleSize8275_;
//		p_Elf2->startTime();
		status_ |= 0x44;
	}

}

Byte i8275::pRegRead()
{
	return 0;
}

Byte i8275::sRegRead()
{
	Byte ret = status_;
	status_ &= 0xc4;

    ef_ = 1;
	return ret;
}

void i8275::cycle8275()
{
	if (cycleValue8275_ < 0)  return;
	cycleValue8275_--;
	if (cycleValue8275_ <= 0)
	{
		if (retrace_)
		{
			dmaCycleValue8275_ = dmaCycleSize8275_;
			bufferLocation_ = 0;
			retrace_ = false;
			cycleValue8275_ = rowCycleSize8275_;
		}
		else
		{
			if (dmaCycleValue8275_ > 0)
			{
				dmaCycleValue8275_ = -1;
				screenLocation_ = screenLocation_ + horizontalCharactersPerRow_ - bufferLocation_;
				status_ |= 0x2;
			}
			retrace_ = true;
			copyScreen();
			if ((status_ & 0x40) == 0x40)
			{
				status_ |= 0x20;
				p_Computer->pixieInterrupt();
				p_Computer->setCycle0();
			}

			cycleValue8275_ = horizontalRetraceCycleSize8275_;
			if (screenLocation_ == (verticalRowsPerFrame_*horizontalCharactersPerRow_))
			{
				attributeChange_ = false;
				reverse_ = false;
				underline_ = false;
				highlight_ = false;
				gpa_ = 0;
				blink_ = false;
				cycleValue8275_ = verticalRetraceCycleSize8275_;
				ef_ = 0;
//				videoSyncCount_++;
				screenLocation_ = 0;
				blinkCount_--;
				if (blinkCount_ <= 0)
				{
					blinkCount_ = 16;
					blinkOn_ = !blinkOn_;
					reBlink_ = true;
					if (cursorBlinking_)
						cursorBlinkOn_ = !cursorBlinkOn_;
				}
				if (blinkCount_ == 8)
					if (cursorBlinking_)
					{
						cursorBlinkOn_ = !cursorBlinkOn_;
					}
				if (f3Pressed_)
				{
					fullScreenSet_ = !fullScreenSet_;
					this->ShowFullScreen(fullScreenSet_);
					if (fullScreenSet_)
					{
						setFullScreen();
					}
					else
					{
						zoom_ = restoreZoomAfterFullScreen_;
						this->SetClientSize(horizontalCharactersPerRow_*I8275CHARW*zoom_, verticalRowsPerFrame_*linesPerCharacterRow_*2*zoom_);
						i8275ScreenPointer->SetClientSize(horizontalCharactersPerRow_*I8275CHARW*zoom_, verticalRowsPerFrame_*linesPerCharacterRow_*2*zoom_);
						i8275ScreenPointer->setZoom(zoom_);
						offsetX_ = 0;
						offsetY_ = 0;
					}
					f3Pressed_ = false;
					reBlit_ = true;
				}
			}
		}
	}

	if (dmaCycleValue8275_ < 0)  return;
	dmaCycleValue8275_--;
	if (dmaCycleValue8275_ <= 0)
	{
		int i=1;
		while (((i <= burstCountCode_) || (dmaCycleSize8275_ == 0)) && (bufferLocation_ != horizontalCharactersPerRow_))
		{
			Byte value = p_Computer->pixieDmaOut();
			if ((value & 0xc0) == 0x80)
			{
				underline_ = ((value &0x20) == 0x20);
				reverse_ = ((value &0x10) == 0x10);
				blink_ = ((value &0x2) == 0x2);
				gpa_ = (value &0xc) << 9;
				highlight_ = ((value &0x1) == 0x1);
			}
			if ((i8275ram_[screenLocation_] != value) || (highlightScr_[screenLocation_] != highlight_) || (gpaScr_[screenLocation_] != gpa_) || (blinkScr_[screenLocation_] != blink_) || (reverseScr_[screenLocation_] != reverse_) || (underlineScr_[screenLocation_] != underline_) || (screenLocation_ == cursorAddress_) || cursorReset_[screenLocation_])
			{
			/*	if ((value & 0xc0) == 0x80)
				{
					attributeChange_ = true;
			//		reDraw_ = true;
				}*/
				underlineScr_[screenLocation_] = underline_;
				reverseScr_[screenLocation_] = reverse_;
				blinkScr_[screenLocation_] = blink_;
				gpaScr_[screenLocation_] = gpa_;
				highlightScr_[screenLocation_] = highlight_;
				draw8275(screenLocation_, value);
			}

			i++;
			bufferLocation_++;
			screenLocation_++;
		}
		if (bufferLocation_ == horizontalCharactersPerRow_)
			dmaCycleValue8275_ = -1;
		else
			dmaCycleValue8275_ = dmaCycleSize8275_;
	}
}

Byte i8275::read8275CharRom(Word addr)
{
 	return i8275CharRom_[addr];
}

void i8275::write8275CharRom(Word addr, Byte value)
{
	i8275CharRom_[addr] = value;
	reDraw_ = true;
}

void i8275::copyScreen()
{
	CharacterList8275 *temp;

	if (reColour_)
	{
		for (int i=0; i<numberOfColours_; i++)
		{
			colour_[i] = colourNew_[i];
			brushColour_[i] = brushColourNew_[i];
			penColour_[i] = penColourNew_[i];
		}
		reDraw_ = true;
		reBlit_ = true;
		reColour_ = false;
	}

	if (reDraw_)
		drawScreen8275();
	if (reBlink_)
		blinkScreen8275();

	if (fullScreenSet_ && newBackGround_)
		drawBackground();
	if (reBlit_ || reDraw_ || reBlink_)
	{
		i8275ScreenPointer->blit(offsetX_, offsetY_, horizontalCharactersPerRow_*I8275CHARW, verticalRowsPerFrame_*linesPerCharacterRow_*videoM_, &dcMemory, 0, 0);
		reBlit_ = false;
		reDraw_ = false;
		reBlink_ = false;
		if (updateCharacter8275_)
		{
			updateCharacter8275_ = false;
			while(characterListPointer8275 != NULL)
			{
				temp = characterListPointer8275;
				characterListPointer8275 = temp->nextCharacter;
				delete temp;
			}
		}
	}
	if (updateCharacter8275_)
	{
		updateCharacter8275_ = false;
		while(characterListPointer8275 != NULL)
		{
			i8275ScreenPointer->blit(offsetX_+(characterListPointer8275->x), offsetY_+(characterListPointer8275->y), I8275CHARW, linesPerCharacterRow_*videoM_, &dcMemory, characterListPointer8275->x, characterListPointer8275->y);
			temp = characterListPointer8275;
			characterListPointer8275 = temp->nextCharacter;
			delete temp;
		}
	}
}

void i8275::drawScreen8275()
{
	int addr = 0;
	for (int i=0; i<(horizontalCharactersPerRow_*verticalRowsPerFrame_); i++)
	{
		draw8275(addr, i8275ram_[addr]);

		addr++;
		addr &= 0x7ff;
	}
}

void i8275::blinkScreen8275()
{
	int addr = 0;
	for (int i=0; i<(horizontalCharactersPerRow_*verticalRowsPerFrame_); i++)
	{
		if (blinkScr_[addr])
			draw8275(addr, i8275ram_[addr]);
		addr++;
		addr &= 0x7ff;
	}
}

void i8275::draw8275(Word addr, Byte value)
{
	i8275ram_[addr] = value;
	cursorReset_[addr] = (addr == cursorAddress_);

	int y = (addr/horizontalCharactersPerRow_)*linesPerCharacterRow_*videoM_;
 	int x = (addr%horizontalCharactersPerRow_)*I8275CHARW;
 	drawCharacter8275(x, y, value, cursorReset_[addr], addr);
}

void i8275::drawCharacter8275(wxCoord x, wxCoord y, Byte v, bool cursor, Word addr)
{
	int line_byte, line, drawLine;

#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
	reBlit_ = true;
#else
	CharacterList8275 *temp = new CharacterList8275;
	temp->x = x;
	temp->y = y;
	temp->nextCharacter = characterListPointer8275;
	characterListPointer8275 = temp;
	updateCharacter8275_ = true;
#endif

	if ((v & 0xc0) == 0x80)
	{
	/*	underline_ = ((v &0x20) == 0x20);
		reverse_ = ((v &0x10) == 0x10);
		blink_ = ((v &0x2) == 0x2);
		highlight_ = ((v &0x1) == 0x1);
		gpa_ = (v &0xc) << 9;*/

		dcMemory.SetBrush(brushColour_[BACKGROUND8275]);
		dcMemory.SetPen(penColour_[BACKGROUND8275]);
		if ((cursor && cursorBlinkOn_) && !cursorLine_)
		{
			dcMemory.SetBrush(brushColour_[FOREGROUND8275]);
			dcMemory.SetPen(penColour_[FOREGROUND8275]);
		}
		dcMemory.DrawRectangle(x, y, I8275CHARW, linesPerCharacterRow_*videoM_);
		if ((cursor && cursorBlinkOn_) && cursorLine_)
		{
			dcMemory.SetBrush(brushColour_[FOREGROUND8275]);
			dcMemory.SetPen(penColour_[FOREGROUND8275]);
			dcMemory.DrawRectangle(x, y+(underLinePlacement_-2), I8275CHARW, videoM_);
		}
		return;
	}

	if ((reverseScr_[addr] && !((cursor && cursorBlinkOn_) && !cursorLine_)) || ((cursor && cursorBlinkOn_) && !cursorLine_ && !reverseScr_[addr]))
	{
		if (highlightScr_[addr])
		{
			dcMemory.SetBrush(brushColour_[HIGHLIGHT8275]);
			dcMemory.SetPen(penColour_[HIGHLIGHT8275]);
		}
		else
		{
			dcMemory.SetBrush(brushColour_[FOREGROUND8275]);
			dcMemory.SetPen(penColour_[FOREGROUND8275]);
		}
		dcMemory.DrawRectangle(x, y, I8275CHARW, linesPerCharacterRow_*videoM_);

		dcMemory.SetBrush(brushColour_[BACKGROUND8275]);
		dcMemory.SetPen(penColour_[BACKGROUND8275]);
	}
	else
	{
		dcMemory.SetBrush(brushColour_[BACKGROUND8275]);
		dcMemory.SetPen(penColour_[BACKGROUND8275]);
		dcMemory.DrawRectangle(x, y, I8275CHARW, linesPerCharacterRow_*videoM_);

		if (highlightScr_[addr])
		{
			dcMemory.SetBrush(brushColour_[HIGHLIGHT8275]);
			dcMemory.SetPen(penColour_[HIGHLIGHT8275]);
		}
		else
		{
			dcMemory.SetBrush(brushColour_[FOREGROUND8275]);
			dcMemory.SetPen(penColour_[FOREGROUND8275]);
		}
	}

	if (blinkScr_[addr] && blinkOn_)
		return;

	drawLine = 0;
	if (lineCounterMode_ == 0)
		line = 0;
	else
		line = linesPerCharacterRow_-1;

	for (wxCoord j=y; j<y+(linesPerCharacterRow_*videoM_); j+=videoM_)
	{
		if ((underLinePlacement_ > 7) && ((drawLine == 0) || (drawLine == (linesPerCharacterRow_-1))))
			line_byte = 0;
		else
		{
			if (line >= 8)
				line_byte =	i8275CharRom_[v*8+line-8+0x400+gpaScr_[addr]];
			else
				line_byte =	i8275CharRom_[v*8+line+gpaScr_[addr]];
		}

		for (wxCoord i=x; i<x+I8275CHARW; i++)
		{
			if ((line_byte & 1) || ((drawLine == underLinePlacement_) && ((underlineScr_[addr] && !((cursor && cursorBlinkOn_) && cursorLine_)) || ((cursor && cursorBlinkOn_) && cursorLine_ && !underlineScr_[addr]))))
			{
				if (interlace_ & !(videoM_ == 1))
					dcMemory.DrawRectangle(i, j, 1, videoM_);
				else
					dcMemory.DrawPoint(i, j);
			}
			line_byte >>= 1;
		}
		drawLine++;
		line++;
		if (line >= linesPerCharacterRow_)
			line = 0;
	}

#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#endif
}

void i8275::setInterlace(bool status)
{
	interlace_ = status;
	reDraw_ = true;
}

bool i8275::readCharRomFile(wxString romDir, wxString FileRef)
{
	wxFFile inFile;
	size_t length, number;
	char buffer[8192];

	for (size_t i=0; i<8192; i++)
	{
		i8275CharRom_[i] = 0;
	}

	if (p_Main->getComboValue(FileRef) == "")
	{
		p_Main->errorMessage("No font filename specified");
		return false;
	}

	wxString fileName = romDir + p_Main->getComboValue(FileRef);

	if (!wxFile::Exists(fileName))
	{
		p_Main->errorMessage("File " + fileName + " not found");
		return false;
	}

	if (inFile.Open(fileName, "rb"))
	{
		length = inFile.Read(buffer, 8192);
		number = 0;
		for (size_t i=0; i<length; i++)
		{
			i8275CharRom_[i] = (Byte)buffer[i];
			number++;
		}
		inFile.Close();
		return true;
	}
	else
	{
		p_Main->errorMessage("Error reading " + fileName);
		return false;
	}
}

void i8275::changeSize()
{
#if defined(__WXGTK__)
	wxMutexGuiEnter();
#endif
	dcMemory.SelectObject(wxNullBitmap);
	delete screenCopyPointer;
	screenCopyPointer = new wxBitmap(horizontalCharactersPerRow_*I8275CHARW, verticalRowsPerFrame_*linesPerCharacterRow_*2);
	dcMemory.SelectObject(*screenCopyPointer);

	if (fullScreenSet_)
		setFullScreen();
	else
	{
		this->SetClientSize(horizontalCharactersPerRow_*I8275CHARW*zoom_, verticalRowsPerFrame_*linesPerCharacterRow_*2*zoom_);
		i8275ScreenPointer->SetClientSize(horizontalCharactersPerRow_*I8275CHARW*zoom_, verticalRowsPerFrame_*linesPerCharacterRow_*2*zoom_);
		i8275ScreenPointer->setZoom(zoom_);
	}
#if defined(__WXGTK__)
	wxMutexGuiLeave();
#endif
}

long i8275::getVideoSyncCount()
{
	return videoSyncCount_;
}

