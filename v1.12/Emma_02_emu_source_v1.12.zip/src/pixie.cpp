/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

/*
 *******************************************************************
 *** This software is copyright 2006 by Michael H Riley          ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "app_icon.xpm"
/*#include "vip_icon.xpm"
#include "nano_icon.xpm"
#include "elf2k_icon.xpm"
#include "elf_icon.xpm"
#include "emma_02_icon.xpm"
#include "studio_icon.xpm"
#include "victory_icon.xpm"
#include "visiciom_icon.xpm"*/
#endif

#include "wx/frame.h"

#include "main.h"
#include "pixie.h"

BEGIN_EVENT_TABLE(PixieScreen, wxWindow)
	EVT_PAINT(PixieScreen::onPaint)
	EVT_CHAR(PixieScreen::onChar)
	EVT_KEY_DOWN(PixieScreen::onKeyDown)
	EVT_KEY_UP(PixieScreen::onKeyUp)
END_EVENT_TABLE()

PixieScreen::PixieScreen(wxWindow *parent, const wxSize& size, int zoom, int computerType)
: wxWindow(parent, wxID_ANY, wxDefaultPosition, size)
{
	zoom_ = zoom;
	computerType_ = computerType;
}

void PixieScreen::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxPaintDC dcWindow(this);
	p_Video->setReBlit();
}

void PixieScreen::onChar(wxKeyEvent& event)
{
	p_Computer->charEvent(event.GetKeyCode());
}

void PixieScreen::onKeyDown(wxKeyEvent& event)
{
	int key = event.GetKeyCode();

	switch (computerType_)
	{
		case ELF:
		case ELFII:
		case ELF2K:
		case SUPERELF:
		case COSMICOS:
			if (p_Computer->keyDownPressed(key))
				return;
		break;

		default:
			switch(key)
			{
				case WXK_F1:
					p_Main->onF1();
					return;
				break;

				case WXK_F2:
					p_Computer->showTime();
					return;
				break;

				case WXK_F3:
					p_Video->onF3();
					return;
				break;

				case WXK_F5:
					p_Video->onF5();
					return;
				break;

				case WXK_F12:
					p_Computer->onRun();
					return;
				break;
			}
			p_Computer->keyDown(key);
		break;
	}
	event.Skip();
}

void PixieScreen::onKeyUp(wxKeyEvent& event)
{
	int key = event.GetKeyCode();

	switch (computerType_)
	{
		case ELF:
		case ELFII:
		case ELF2K:
		case SUPERELF:
		case COSMICOS:
			if (p_Computer->keyUpReleased(key))
				return;
		break;

		default:
			p_Computer->keyUp(key);
		break;
	}
	event.Skip();
}

void PixieScreen::blit(wxCoord xdest, wxCoord ydest, wxCoord width, wxCoord height, wxDC *source, wxCoord xsrc, wxCoord ysrc)
{
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
#endif
	wxClientDC dcWindow(this);
	dcWindow.SetUserScale(zoom_*3, zoom_);
	dcWindow.Blit(xdest, ydest, width, height, source, xsrc, ysrc);
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#endif
}

void PixieScreen::drawBackground(wxColour clr, int xSize, int ySize, wxCoord offsetX, wxCoord offsetY)
{
#if defined(__WXGTK__)
	wxMutexGuiEnter();
#endif
	wxClientDC dcWindow(this);
	wxSize size = wxGetDisplaySize();

	dcWindow.SetUserScale(zoom_*3, zoom_);
	dcWindow.SetBrush(wxBrush(clr));
	dcWindow.SetPen(wxPen(clr));
	dcWindow.DrawRectangle(0, 0, size.x/(zoom_*3), offsetY);
	dcWindow.DrawRectangle(0, offsetY, offsetX, ySize);
	dcWindow.DrawRectangle(offsetX+xSize, offsetY, offsetX+1, ySize);
	dcWindow.DrawRectangle(0, offsetY+ySize, size.x/(zoom_*3), offsetY+1);
#if defined(__WXGTK__)
	wxMutexGuiLeave();
#endif
}

void PixieScreen::disableScreen(wxColour clr, int xSize, int ySize, wxCoord offsetX, wxCoord offsetY)
{
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
#endif
	wxClientDC dcWindow(this);
	dcWindow.SetUserScale(zoom_*3, zoom_);
	dcWindow.SetBrush(wxBrush(clr));
	dcWindow.SetPen(wxPen(clr));
	dcWindow.DrawRectangle(offsetX, offsetY, xSize, ySize);
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#endif
}

void PixieScreen::setZoom(int zoom)
{
	zoom_ = zoom;
}

BEGIN_EVENT_TABLE(Pixie, wxFrame)
	EVT_CLOSE (Pixie::onClose)
END_EVENT_TABLE()

Pixie::Pixie(const wxString& title, const wxPoint& pos, const wxSize& size, int zoom, int computerType)
: Video(title, pos, size)
{
	computerType_ = computerType;
	runningComputer_ = p_Main->getRunningComputerStr();

	this->SetClientSize(size);

	pixieScreenPointer = new PixieScreen(this, size, zoom, computerType);

	if ((computerType_ == TMC2000) || (computerType_ == NANO) || (computerType_ == COSMICOS) || (computerType_ == ETI) || (computerType_ == VICTORY))
		ySize_ = 192;
	else
		ySize_ = 128;

	SetIcon(wxICON(app_icon));
/*	switch (computerType_)
	{
		case VIP:
			SetIcon(wxICON(vip_icon));
		break;

		case NANO:
			SetIcon(wxICON(nano_icon));
		break;

		case ELF2K:
			SetIcon(wxICON(elf2k_icon));
		break;

		case ELF:
		case ELFII:
		case SUPERELF:
			SetIcon(wxICON(elf_icon));
		break;

		case STUDIO:
			SetIcon(wxICON(studio_icon));
		break;

		case VICTORY:
			SetIcon(wxICON(victory_icon));
		break;

		case VISICOM:
			SetIcon(wxICON(visicom_icon));
		break;

		default:
			SetIcon(wxICON(app_icom));
		break;
	}*/

	screenCopyPointer = new wxBitmap(64, ySize_);
	dcMemory.SelectObject(*screenCopyPointer);
	fullScreenSet_ = false;
	restoreZoomAfterFullScreen_ = zoom;
	zoom_ = zoom;

	offsetX_ = 0;
	offsetY_ = 0;

	plotListPointer = NULL;
}

Pixie::~Pixie()
{
	PlotList *temp;

	dcMemory.SelectObject(wxNullBitmap);
	delete screenCopyPointer;
	delete pixieScreenPointer;
	if (updatePlot_ > 0)
	{
		while(plotListPointer != NULL)
		{
			temp = plotListPointer;
			plotListPointer = temp->nextPlot;
			delete temp;
		}
	}
}

void Pixie::onClose(wxCloseEvent&WXUNUSED(event) )
{
	p_Main->stopComputer();
}

void Pixie::setReBlit()
{
	newBackGround_ = true;
	reBlit_ = true;
}

void Pixie::configurePixie()
{
	int pixieIn, pixieEf, pixieOut;

	wxString runningComp = p_Main->getRunningComputerStr();

	pixieOut = p_Main->getConfigItem(runningComp +"/PixieOutput", 1l);
	pixieIn = p_Main->getConfigItem(runningComp +"/PixieInput", 1l);
	pixieEf = p_Main->getConfigItem(runningComp +"/PixieEF", 1l);

	p_Computer->setOutType(pixieOut - 1, PIXIEOUT);
	p_Computer->setCycleType(VIDEOCYCLE, PIXIECYCLE);
	p_Computer->setInType(pixieIn - 1, PIXIEIN);
	p_Computer->setEfType(pixieEf, PIXIEEF);

	backGroundInit_ = 1;
	colourMask_ = 0;

	wxString printBuffer;
	p_Main->message("Configuring CDP 1861");

	printBuffer.Printf("	Output %d: disable graphics, input %d: enable graphics, EF %d: in frame indicator\n", pixieOut, pixieIn, pixieEf);
	p_Main->message(printBuffer);
}

void Pixie::configurePixieStudio2()
{
	p_Computer->setOutType(0, PIXIEOUT);
	p_Computer->setCycleType(VIDEOCYCLE, PIXIECYCLE);
	p_Computer->setInType(0, PIXIEIN);
	p_Computer->setEfType(1, PIXIEEF);

	backGroundInit_ = 1;
	colourMask_ = 0;

	p_Main->message("Configuring CDP 1861");
	p_Main->message("	Output 1: disable graphics, input 1: enable graphics, EF 1: in frame indicator\n");
}

void Pixie::configurePixieVisicom()
{
	p_Computer->setOutType(0, PIXIEOUT);
	p_Computer->setCycleType(VIDEOCYCLE, PIXIECYCLE);
//	p_Computer->setInType(0, PIXIEIN);
	p_Computer->setEfType(1, PIXIEEF);

	backGroundInit_ = 0;
	colourMask_ = 0; 

	p_Main->message("Configuring CDP 1861");
	p_Main->message("	Output 1: enable graphics, EF 1: in frame indicator\n");
}

void Pixie::configurePixieVip()
{
	p_Computer->setOutType(0, PIXIEOUT);
	p_Computer->setCycleType(VIDEOCYCLE, PIXIECYCLE);
	p_Computer->setInType(0, PIXIEIN);
	p_Computer->setEfType(1, PIXIEEF);

	if (p_Main->getCheckBox("VP590"))
	{
		backGroundInit_ = 8;
		colourMask_ = 0; 
		p_Computer->setOutType(4, VIPOUT5);

		p_Main->message("Configuring CDP 1861/1862");
		p_Main->message("	Output 1: disable graphics, input 1: enable graphics, EF 1: in frame indicator");
		p_Main->message("	Output 5: step background colour\n");
	}
	else
	{
		backGroundInit_ = 9;
		colourMask_ = 7;

		p_Main->message("Configuring CDP 1861");
		p_Main->message("	Output 1: disable graphics, input 1: enable graphics, EF 1: in frame indicator\n");
	}
}

void Pixie::configurePixieTmc1800()
{
	p_Computer->setCycleType(VIDEOCYCLE, PIXIECYCLE);
	p_Computer->setInType(0, PIXIEIN);
	p_Computer->setInType(3, PIXIEOUT);
	p_Computer->setEfType(1, PIXIEEF);

	backGroundInit_ = 1;
	colourMask_ = 0;

	p_Main->message("Configuring CDP 1861");

	p_Main->message("	Input 1: enable graphics, input 4: disable graphics");
	p_Main->message("	EF 1: in frame indicator\n");
}

void Pixie::configurePixieTelmac()
{
	p_Computer->setOutType(0, PIXIEBACKGROUND);
	p_Computer->setCycleType(VIDEOCYCLE, PIXIECYCLE);
	p_Computer->setInType(0, PIXIEIN);
	p_Computer->setInType(3, PIXIEOUT);
	p_Computer->setEfType(1, PIXIEEF);

	backGroundInit_ = 8;
	colourMask_ = 0;

	p_Main->message("Configuring CDP 1864");

	p_Main->message("	Output 1: switch background colour");
	p_Main->message("	Input 1: enable graphics, input 4: disable graphics");
	p_Main->message("	EF 1: in frame indicator\n");
}

void Pixie::configurePixieVictory()
{
	p_Computer->setOutType(0, PIXIEBACKGROUND);
	p_Computer->setCycleType(VIDEOCYCLE, PIXIECYCLE);
	p_Computer->setInType(0, PIXIEIN);
//	p_Computer->setInType(3, PIXIEOUT);
	p_Computer->setEfType(1, PIXIEEF);

	backGroundInit_ = 8;
	colourMask_ = 0;

	p_Main->message("Configuring CDP 1864");

	p_Main->message("	Output 1: switch background colour, output 4: tone latch");
	p_Main->message("	Input 1: enable graphics");
	p_Main->message("	EF 1: in frame indicator\n");
}

void Pixie::configurePixieNano()
{
	p_Computer->setOutType(0, PIXIEOUT);
	p_Computer->setCycleType(VIDEOCYCLE, PIXIECYCLE);
	p_Computer->setInType(0, PIXIEIN);
	p_Computer->setInType(3, PIXIEOUT);
	p_Computer->setEfType(1, PIXIEEF);

	backGroundInit_ = 1;
	colourMask_ = 0;

	p_Main->message("Configuring CDP 1864");
	p_Main->message("	Input 1: enable graphics, input 4: disable graphics");
	p_Main->message("	EF 1: in frame indicator\n");

	if (p_Main->getChoiceSelection("SoundNano") == 0)
		p_Computer->setSoundFollowQ(false);
	else
		p_Computer->setSoundFollowQ(true);
}

void Pixie::configurePixieCosmicos()
{
	p_Computer->setCycleType(VIDEOCYCLE, PIXIECYCLE);
	p_Computer->setOutType(1, PIXIEIN);
	p_Computer->setInType(0, PIXIEIN);
	p_Computer->setInType(1, PIXIEOUT);
	p_Computer->setEfType(3, COSMICOSREQ);

	backGroundInit_ = 1;
	colourMask_ = 0;

	p_Main->message("Configuring CDP 1864");
	p_Main->message("	Q=0: Input 1: enable graphics, input 2: disable graphics");
	p_Main->message("	Q=1: Output 2: tone latch");
	p_Main->message("	EF 3: in frame indicator (when graphics enabled)\n");

}

void Pixie::configurePixieEti()
{
	p_Computer->setOutType(0, PIXIEBACKGROUND);
	p_Computer->setCycleType(VIDEOCYCLE, PIXIECYCLE);
	p_Computer->setInType(0, PIXIEIN);
	p_Computer->setInType(3, PIXIEOUT);
	p_Computer->setEfType(1, PIXIEEF);

	backGroundInit_ = 8;
	colourMask_ = 7;

	p_Main->message("Configuring CDP 1864");

	p_Main->message("	Output 1: switch background colour, output 4: tone latch");
	p_Main->message("	Input 1: enable graphics, input 4: disable graphics");
	p_Main->message("	EF 1: in frame indicator\n");
}

void Pixie::initiateColour(bool colour)
{
	if (colour)
		colourMask_ = 0;
	else
		colourMask_ = 7;
}

void Pixie::initPixie()
{
	vidInt_ = 0;
	vidCycle_ = 0;
	pixieEf_ = 1;

	for (int x=0; x<64; x++) for (int y=0; y<192; y++)
	{
		pbacking_[x][y] = 0;
		color_[x][y] = 0;
	}

	defineColours(computerType_);

	graphicsOn_ = false;
	graphicsNext_ = 0;
	graphicsMode_ = 0;

	f3Pressed_ = false;
	newBackGround_ = false;
	reBlit_ = true;
	reDraw_ = false;
	updatePlot_ = 0;
	backGround_ = backGroundInit_;

	pixieScreenPointer->disableScreen(colour_[backGround_], 64, ySize_, offsetX_, offsetY_);
	drawScreen();
}

Byte Pixie::efPixie()
{
	return pixieEf_;
}

Byte Pixie::inPixie()
{
	graphicsOn_ = true;
	reBlit_ = true;
	return 0;
}

void Pixie::outPixie()
{
	graphicsOn_ = false;
	if (computerType_ == ETI)
		pixieScreenPointer->disableScreen(colour_[backGround_], 64, ySize_, offsetX_, offsetY_);
}

void Pixie::outPixieBackGround()
{
	graphicsOn_ = true;
	backGround_++;
	if (backGround_ == 12)  backGround_ = 9;
	newBackGround_ = true;
	reBlit_ = true;
	drawScreen();
}

void Pixie::cyclePixie()
{
	int j;
	Byte v, vram1, vram2;
	int color;

	if (graphicsNext_ == 0)
	{
		p_Computer->debugTrace("H.Sync");
		graphicsMode_++;
		if (graphicsMode_ == 60) pixieEf_ = 0;
		if (graphicsMode_ == 64) pixieEf_ = 1;
		if (graphicsMode_ == 188) pixieEf_ = 0;
		if (graphicsMode_ == 192) pixieEf_ = 1;
		if (graphicsMode_ >= 262)
		{
			if (f3Pressed_)
			{
				fullScreenSet_ = !fullScreenSet_;
				this->ShowFullScreen(fullScreenSet_);
				if (fullScreenSet_)
				{
					setFullScreen();
				}
				else
				{
					zoom_ = restoreZoomAfterFullScreen_;
					this->SetClientSize(192*zoom_, ySize_*zoom_);
					pixieScreenPointer->SetClientSize(192*zoom_, ySize_*zoom_);
					pixieScreenPointer->setZoom(zoom_);
					offsetX_ = 0;
					offsetY_ = 0;
				}
				reBlit_ = true;
				f3Pressed_ = false;
			}
			graphicsMode_ = 0;
			reDrawScreen();
		}

	}
	if (graphicsNext_ == 2)
	{
		if (graphicsMode_ == 62)
		{
			if (graphicsOn_)
			{
				p_Computer->pixieInterrupt();
				vidInt_ = 1;
				p_Computer->setCycle0();
			}
			else vidInt_ = 0;
		}
	}
	if (graphicsMode_ >= 64 && graphicsMode_ <=191 && graphicsOn_ && vidInt_ == 1 && graphicsNext_ >=4 && graphicsNext_ <=11)
	{
		j = 0;
		while(graphicsNext_ >= 4 && graphicsNext_ <= 11)
		{
			graphicsNext_ ++;
			if (computerType_ == VISICOM)
			{
				p_Computer->visicomDmaOut(&vram1, &vram2);
				for (int i=0; i<8; i++)
				{
					color = 0;
					if (vram1 & 128)	color |= 1;
					if (vram2 & 128)	color |= 2;
					plot(j+i, graphicsMode_-64, 1, color);
					vram1 <<= 1;
					vram2 <<= 1;
				}
			}
			else
			{
				v = p_Computer->pixieDmaOut(&color);
				for (int i=0; i<8; i++)
				{
					plot(j+i, graphicsMode_-64,(v & 128) ? 1 : 0, (color|colourMask_)&7);
					v <<= 1;
				}
			}
			j += 8;
		}
		p_Computer->setCycle0();
		graphicsNext_ -= 1;
	}
	graphicsNext_ += 1;
	if (graphicsNext_ > 13)
		graphicsNext_ = 0;
}

void Pixie::cyclePixieTelmac()
{
	int j;
	Byte v;
	int color;

	if (graphicsNext_ == 0)
	{
		p_Computer->debugTrace("H.Sync");
		graphicsMode_++;
		if (graphicsMode_ == 72) pixieEf_ = 0;
		if (graphicsMode_ == 76) pixieEf_ = 1;
		if (graphicsMode_ == 264) pixieEf_ = 0;
		if (graphicsMode_ == 268) pixieEf_ = 1;
		if (graphicsMode_ >= 284)
		{
			if (f3Pressed_)
			{
				fullScreenSet_ = !fullScreenSet_;
				this->ShowFullScreen(fullScreenSet_);
				if (fullScreenSet_)
				{
					setFullScreen();
				}
				else
				{
					zoom_ = restoreZoomAfterFullScreen_;
					this->SetClientSize(192*zoom_, ySize_*zoom_);
					pixieScreenPointer->SetClientSize(192*zoom_, ySize_*zoom_);
					pixieScreenPointer->setZoom(zoom_);
					offsetX_ = 0;
					offsetY_ = 0;
				}
				reBlit_ = true;
				f3Pressed_ = false;
			}
			graphicsMode_ = 0;
			reDrawScreen();
		}
	}
	if (graphicsNext_ == 2)
	{
		if (graphicsMode_ == 74)
		{
			if (graphicsOn_)
			{
				p_Computer->pixieInterrupt();
				vidInt_ = 1;
				p_Computer->setCycle0();
			}
			else vidInt_ = 0;
		}
	}
	if (graphicsMode_ >= 76 && graphicsMode_ <=267 && graphicsOn_ && vidInt_ == 1 && graphicsNext_ >=4 && graphicsNext_ <=11)
	{
		j = 0;
		while(graphicsNext_ >= 4 && graphicsNext_ <= 11)
		{
			graphicsNext_ ++;
			v = p_Computer->pixieDmaOut(&color);
			for (int i=0; i<8; i++)
			{
				plot(j+i, graphicsMode_-76, (v & 128) ? 1 : 0, (color|colourMask_)&7);
				v <<= 1;
			}
			j += 8;
		}
		p_Computer->setCycle0();
		graphicsNext_ -= 1;
	}
	graphicsNext_ += 1;
	if (graphicsNext_ > 13)
		graphicsNext_ = 0;
}

void Pixie::reDrawScreen()
{
	copyScreen();
}

void Pixie::copyScreen()
{
	PlotList *temp;

	if (!graphicsOn_ && (computerType_ == ETI))  return;

	if (reColour_)
	{
		for (int i=0; i<numberOfColours_; i++)
		{
			colour_[i] = colourNew_[i];
			brushColour_[i] = brushColourNew_[i];
			penColour_[i] = penColourNew_[i];
		}
		reDraw_ = true;
		reBlit_ = true;
		reColour_ = false;
	}

	if (reDraw_)
	{
		drawScreen();
		reDraw_ = false;
	}

	if (fullScreenSet_ && newBackGround_)
		drawBackground();

	if (reBlit_)
	{
		pixieScreenPointer->blit(offsetX_, offsetY_, 64, ySize_, &dcMemory, 0, 0);
		reBlit_ = false;
		if (updatePlot_ > 0)
		{
			updatePlot_ = 0;
			while(plotListPointer != NULL)
			{
				temp = plotListPointer;
				plotListPointer = temp->nextPlot;
				delete temp;
			}
		}
	}
	if (updatePlot_ > 0)
	{
		updatePlot_ = 0;
		while(plotListPointer != NULL)
		{
			pixieScreenPointer->blit(offsetX_+ plotListPointer->x, offsetY_+plotListPointer->y, 1, 1, &dcMemory, plotListPointer->x, plotListPointer->y);
			temp = plotListPointer;
			plotListPointer = temp->nextPlot;
			delete temp;
		}
	}
}

void Pixie::drawScreen()
{
	int v;
	int color;

#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
#endif
	dcMemory.SetPen(penColour_[backGround_]);
	dcMemory.SetBrush(brushColour_[backGround_]);
	dcMemory.DrawRectangle(0, 0, 64, ySize_);

	for (int x=0; x<64; x++)
	{
		for (int y=0; y<ySize_; y++)
		{
			v = pbacking_[x][y];
			color = color_[x][y];
			if (v)
			{
				dcMemory.SetPen(penColour_[color]);
				dcMemory.SetBrush(brushColour_[color]);
				dcMemory.DrawPoint(x, y);
			}
		}
	}
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#endif
}

void Pixie::plot(int x, int y, int c, int color)
{
	if (pbacking_[x][y] == c)
		if (!c || (color_[x][y] == color))  return;

	color_[x][y] = color;
	pbacking_[x][y] = c;

#if defined(__WXGTK__)
	wxMutexGuiEnter();
#endif
	if (c)
	{
		dcMemory.SetPen(penColour_[color]);
		dcMemory.SetBrush(brushColour_[color]);
	}
	else
	{
		dcMemory.SetPen(penColour_[backGround_]);
		dcMemory.SetBrush(brushColour_[backGround_]);
	}
	dcMemory.DrawPoint(x, y);
#if defined(__WXGTK__)
	wxMutexGuiLeave();
#endif
	if (reBlit_)  return;
#if defined(__WXGTK__)
	reBlit_ = true;
#else
	PlotList *temp = new PlotList;
	temp->x = x;
	temp->y = y;
	temp->nextPlot = plotListPointer;
	plotListPointer = temp;
	updatePlot_++;
	if (updatePlot_ > 40)
		reBlit_ = true;
#endif
}

void Pixie::setZoom(int zoom)
{
	restoreZoomAfterFullScreen_ = zoom;
	zoom_ = zoom;
	pixieScreenPointer->setZoom(zoom_);
	this->SetClientSize(192*zoom_, ySize_*zoom_);
	pixieScreenPointer->SetClientSize(192*zoom_, ySize_*zoom_);
	reBlit_ = true;
}

void Pixie::onF3()
{
	f3Pressed_ = true;
}

void Pixie::onF5()
{
	int num = 0;
	wxFile screenDump;
	wxString number;
	wxString fileName;

	fileName = p_Main->getScreenDumpFile();

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	wxString Name = FullPath.GetName();
	wxString Path = FullPath.GetPath();
	wxString Ext = FullPath.GetExt();

	wxMemoryDC dcFile;
	screenFilePointer = new wxBitmap(192, ySize_);
	dcFile.SelectObject(*screenFilePointer);
	dcFile.SetUserScale(3, 1);
	dcFile.Blit(0, 0, 192, ySize_, &dcMemory, 0, 0);

	while(wxFile::Exists(fileName))
	{
		num++;
		number.Printf("%d", num);
		fileName = Path + p_Main->getPathSep() + Name + "." + number + "." + Ext;
	}
	screenDump.Create(fileName);
	if (Ext == "bmp")
	{
		screenFilePointer->SaveFile(fileName, wxBITMAP_TYPE_BMP);
		delete screenFilePointer;
		return;
	}
	if (Ext == "jpeg")
	{
		screenFilePointer->SaveFile(fileName, wxBITMAP_TYPE_JPEG);
		delete screenFilePointer;
		return;
	}
	if (Ext == "png")
	{
		screenFilePointer->SaveFile(fileName, wxBITMAP_TYPE_PNG);
		delete screenFilePointer;
		return;
	}
	if (Ext == "pcx")
	{
		screenFilePointer->SaveFile(fileName, wxBITMAP_TYPE_PCX);
		delete screenFilePointer;
		return;
	}
	delete screenFilePointer;
	screenFilePointer->SaveFile(fileName, wxBITMAP_TYPE_BMP);
}

void Pixie::setFullScreen()
{
	int zoomx, zoomy;
	wxSize size;

	size = wxGetDisplaySize();
	zoomx = (int) (size.x/192);
	zoomy = (int) (size.y/ySize_);
	if (zoomx <= zoomy)
		zoom_ = zoomx;
	else
		zoom_ = zoomy;
	offsetX_ = (size.x/(zoom_*3) - 64) / 2;
	offsetY_ = (size.y/zoom_ - ySize_) / 2;
	pixieScreenPointer->setZoom(zoom_);
	pixieScreenPointer->SetClientSize(size.x, size.y);
	newBackGround_ = true;
}

void Pixie::drawBackground()
{
	pixieScreenPointer->drawBackground(colour_[backGround_], 64, ySize_, offsetX_, offsetY_);
	newBackGround_ = false;
}
