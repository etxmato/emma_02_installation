#ifndef ELFCONFIG_H
#define ELFCONFIG_H

class ElfConfiguration
{
public:
	bool usePixie;
	bool useS100;
	bool use6845;
	bool use6847;
	int charLine;
	int screenHeight6847;
	bool useTMS9918;
	bool use8275;
	int vtType;
	bool useUart;
	int baudR;
	int baudT;
	bool autoBoot;
	bool rtc;
	bool nvr;
	bool useSwitch;
	bool useHex;
	bool useTape;

	bool useHexKeyboard;
	bool useHexKeyboardEf3;
	bool useKeyboard;
	bool UsePS2;
	bool ps2Interrupt;	
	bool usePs2gpio;

	bool ideEnabled;
	bool fdcEnabled;

	bool usePrinter;
	bool usePortExtender;
	bool usePager;
	bool useEms;
	bool useLedModule;
	bool useElfControlWindows;
	bool showAddress;
};

#endif	// ELFCONFIG_H