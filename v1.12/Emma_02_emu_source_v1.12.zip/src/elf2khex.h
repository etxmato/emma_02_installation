#ifndef ELF2KHEX_H
#define ELF2KHEX_H

#include "led.h"
#include "cdp1802.h"

class Elf2Khex : public wxFrame
{
public:
	Elf2Khex(const wxString& title, const wxPoint& pos, const wxSize& size);
	~Elf2Khex();

	void onClose(wxCloseEvent&WXUNUSED(event));
	void onPaint(wxPaintEvent&event);
	void onKeyDown(wxKeyEvent& event);
	void onKeyUp(wxKeyEvent& event);
	void onChar(wxKeyEvent& event);
	void onNumberKey(wxCommandEvent&event);
	Byte getData();
	void setRunButtonUp(int up);
	void setInButtonUp(bool up);
	void setLoadButtonUp(int up);
	void setMpButtonUp(int up);

	void onRunButton(wxCommandEvent& event);
	void onMpButton(wxCommandEvent& event);
	void onResetButton(wxCommandEvent& event);
	void onInButton(wxCommandEvent& event);
	void onLoadButton(wxCommandEvent& event);
	void onInButtonTimer(wxTimerEvent& event);

private:
	wxBitmap *keypadBitmapPointer;
	wxButton *buttonPointer[16];
	wxBitmapButton *inButtonPointer;
	wxBitmapButton *runButtonPointer;
	wxBitmapButton *loadButtonPointer;
	wxBitmapButton *mpButtonPointer;
	wxBitmapButton *resetButtonPointer;

	wxBitmap *inUpBitmapPointer;
	wxBitmap *inDownBitmapPointer;
	wxBitmap *runUpBitmapPointer;
	wxBitmap *runDownBitmapPointer;
	wxBitmap *loadUpBitmapPointer;
	wxBitmap *loadDownBitmapPointer;
	wxBitmap *mpUpBitmapPointer;
	wxBitmap *mpDownBitmapPointer;
	wxBitmap *resetUpBitmapPointer;
	wxBitmap *resetDownBitmapPointer;

	wxTimer *inButtonTimerPointer;

	Byte keypadValue_;
	char nextNybble_;

	DECLARE_EVENT_TABLE()
};

#endif  // ELF2KHEX_H