#ifndef KEYPAD_H
#define KEYPAD_H

#include "led.h"

class Keypad : public wxFrame
{
public:
	Keypad(const wxString& title, const wxPoint& pos, const wxSize& size, int computerType);
	~Keypad();

	void onClose(wxCloseEvent&WXUNUSED(event));
	void onPaint(wxPaintEvent&event);
	void onButtonRelease(wxCommandEvent& event);
	void onButtonPress(wxCommandEvent& event);
	void onNumberKeyDown(wxCommandEvent&event);
	void onNumberDown(int hex);
	void onNumberKeyUp(wxCommandEvent&event);
	void onKeyDown(wxKeyEvent& event);
	void onKeyUp(wxKeyEvent& event);

private:
	int computerType_;

	wxBitmap *keypadBitmapPointer;
	wxButton *inButtonPointer;
	wxButton *buttonPointer[16];
	Led *ledPointer[2];

	Byte keypadValue_;
	char nextNybble_;

	DECLARE_EVENT_TABLE()
};

#endif  // KEYPAD_H