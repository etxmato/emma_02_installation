#ifndef ETI660_H
#define ETI660_H

#include "cdp1802.h"
#include "pixie.h"

class RunEti : public wxThread
{
public:
	RunEti() {};
	virtual void *Entry();
};

class Eti : public Cdp1802, public Pixie
{
public:
	Eti(const wxString& title, const wxPoint& pos, const wxSize& size, int zoom, int computerType);
	~Eti();

	void configureComputer();
	void initComputer();
	void keyDown(int keycode);
	void keyUp(int keycode);

	void onRun();

	Byte ef(int flag);
	Byte ef3();
	Byte in(Byte port, Word address);
	Byte inEti(WORD address);
	void out(Byte port, Word address, Byte value);
	void outEti(WORD address, Byte value);
	void cycle(int type);

	void startComputer();
	void stopComputer();
	Byte readMem(Word addr);
	void writeMem(Word addr, Byte value, bool writeRom);
	void cpuInstruction();
	void onReset();
	void checkEtiFunction();
	void finishStopTape();
	void keyClear();

	Byte read1864ColorDirect(Word addr);
	void write1864ColorDirect(Word addr, Byte value);

private:
	RunEti *threadPointer;

	bool eti660KeyState_[16];
	bool resetPressed_;
	int cPressed;
	bool colorLatch_;
	Word ramMask_;

	int hexKeyDefA_[16];

	bool DataDirection_;
	Byte outputKeyLatch_;
	Byte inputKeyLatch_;
	Byte outputKeyValue_;
	Word endSave_;

	bool step_;
};

#endif  // ETI660_H
