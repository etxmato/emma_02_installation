#ifndef KEYMAPDLG_H
#define KEYMAPDLG_H

class KeyMapDialog : public wxDialog
{
public:

    KeyMapDialog(wxWindow* parent);
	~KeyMapDialog(){};

private:
    void onSaveButton( wxCommandEvent &event );
    void onHexKey( wxCommandEvent &event );
    void onSwitchPad( wxCommandEvent &event );
    void onHexLocation( wxCommandEvent &event );
    void onHexChar( wxCommandEvent &event );
	void onSwitchStudio( wxCommandEvent &event );
	void onStudioLocation( wxCommandEvent &event );
    void onStudioChar( wxCommandEvent &event );
	void onKeyDown(wxKeyEvent& event);
	void connectKeyDownEvent(wxWindow* pclComponent); 
	void updateButtons();
	void setLabel(int button, int key);

	wxButton *Button0Pointer;
	int hexKey_;
	int hexKeyDefA_[16];
	int hexKeyDefB_[16];
	bool hexPadA_;
	wxString computerTypeStr_;
	int numberOfKeys_;

    DECLARE_EVENT_TABLE()

};

#endif  // KEYMAPDLG_H
