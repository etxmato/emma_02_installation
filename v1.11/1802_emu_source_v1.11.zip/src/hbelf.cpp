/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

/*
 *******************************************************************
 *** This software is copyright 2006 by Michael H Riley          ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "elf_icon.xpm"
#endif

#include "main.h"

#include "hbelf.h"
#include "elf.xpm"
#include "swup.xpm"
#include "swdn.xpm"
#include "pushup.xpm"
#include "pushdn.xpm"

BEGIN_EVENT_TABLE(Elf, wxFrame)
	EVT_CLOSE (Elf::onClose)
	EVT_PAINT(Elf::onPaint)
	EVT_CHAR(Elf::onChar)
	EVT_KEY_DOWN(Elf::onKeyDown)
	EVT_KEY_UP(Elf::onKeyUp)
	EVT_LEFT_DOWN(Elf::onButtonPress)
	EVT_LEFT_UP(Elf::onButtonRelease)
	EVT_BUTTON(1, Elf::onRunButton)
	EVT_BUTTON(2, Elf::onMpButton)
	EVT_BUTTON(3, Elf::onPowerButton)
	EVT_BUTTON(4, Elf::onLoadButton)
	EVT_BUTTON(10, Elf::dataSwitch)
	EVT_BUTTON(11, Elf::dataSwitch)
	EVT_BUTTON(12, Elf::dataSwitch)
	EVT_BUTTON(13, Elf::dataSwitch)
	EVT_BUTTON(14, Elf::dataSwitch)
	EVT_BUTTON(15, Elf::dataSwitch)
	EVT_BUTTON(16, Elf::dataSwitch)
	EVT_BUTTON(17, Elf::dataSwitch)
	EVT_BUTTON(20, Elf::efSwitch)
	EVT_BUTTON(21, Elf::efSwitch)
	EVT_BUTTON(22, Elf::efSwitch)
	EVT_BUTTON(23, Elf::efSwitch)
	EVT_TIMER(901, Elf::addressTimeout)
END_EVENT_TABLE()

Elf::Elf(const wxString& title, const wxPoint& pos, const wxSize& size, double clock, ElfConfiguration conf)
: wxFrame((wxFrame *)NULL, -1, title, pos, size)
{
	wxClientDC dc(this);
	elfClockSpeed_ = clock;
	elfConfiguration = conf;
	data_ = 0;
	lastAddress_ = 0;

	wxString switchNumber;

	SetIcon(wxICON(elf_icon));
	this->SetClientSize(size);

	elfBitmapPointer = new wxBitmap(elf_xpm);
	upBitmapPointer = new wxBitmap(swup_xpm);
	downBitmapPointer = new wxBitmap(swdn_xpm);
	pushUpBitmapPointer = new wxBitmap(pushup_xpm);
	pushDownBitmapPointer = new wxBitmap(pushdn_xpm);

	runButtonPointer = new wxBitmapButton(this, 1, *downBitmapPointer, wxPoint(190, 312), wxSize(25, 25), 0, wxDefaultValidator, "onRunButton");
	mpButtonPointer = new wxBitmapButton(this, 2, *downBitmapPointer, wxPoint(150, 312), wxSize(25, 25), 0, wxDefaultValidator, "MPButton");
	powerButtonPointer = new wxBitmapButton(this, 3, *downBitmapPointer, wxPoint(313, 312), wxSize(25, 25), 0, wxDefaultValidator, "PowerButton");
	loadButtonPointer = new wxBitmapButton(this, 4, *downBitmapPointer, wxPoint(75, 312), wxSize(25, 25), 0, wxDefaultValidator, "LoadButton");

	for (int i=0; i<8; i++)
	{
		switchNumber.Printf("%i", i);
		dataSwitchPointer[i] = new wxBitmapButton(this, i+10, *downBitmapPointer, wxPoint(18+30*(7-i), 362), wxSize(25, 25), 0, wxDefaultValidator, switchNumber);
	}
	for (int i=0; i<4; i++)
	{
		switchNumber.Printf("%i", i);
		efSwitchPointer[i] = new wxBitmapButton(this, i+20, *downBitmapPointer, wxPoint(138+30*(3-i), 422), wxSize(25, 25), 0, wxDefaultValidator, switchNumber);
		addressPointer[i] = new Til311();
	}
	for (int i=0; i<2; i++)
	{
		dataPointer[i] = new Til311();
	}
	qLedPointer = new Led(dc, 324, 250, ELFLED);

	threadPointer = new RunElf();
	if ( threadPointer->Create() != wxTHREAD_NO_ERROR )
	{
		p_Main->message("Can't create thread");
	}
	threadPointer->SetPriority(WXTHREAD_MAX_PRIORITY);
	addressTimerPointer = new wxTimer(this, 901);
}

Elf::~Elf()
{
	addressTimerPointer->Stop();
	delete addressTimerPointer;
	if (elfConfiguration.useHexKeyboard && !hexKeypadClosed_)
	{
		p_Main->setKeypadPos(ELF, keypadPointer->GetPosition());
		keypadPointer->Destroy();
	}
	if (elfConfiguration.useLedModule && !ledModuleClosed_)
	{
		p_Main->setLedModulePos(ledModulePointer->GetPosition());
		ledModulePointer->Destroy();
	}
	if (elfConfiguration.usePixie)
	{
		p_Main->setPixiePos(ELF, pixiePointer->GetPosition());
		pixiePointer->Destroy();
	}
	if (elfConfiguration.useTMS9918)
	{
		p_Main->setTmsPos(ELF, tmsPointer->GetPosition());
		tmsPointer->Destroy();
	}
	if (elfConfiguration.use6845||elfConfiguration.useS100)
	{
		p_Main->set6845Pos(ELF, mc6845Pointer->GetPosition());
		mc6845Pointer->Destroy();
	}
	if (elfConfiguration.use6847)
	{
		p_Main->set6847Pos(ELF, mc6847Pointer->GetPosition());
		mc6847Pointer->Destroy();
	}
	if (elfConfiguration.use8275)
	{
		p_Main->set8275Pos(ELF, i8275Pointer->GetPosition());
		i8275Pointer->Destroy();
	}
	if (elfConfiguration.vtType != VTNONE)
	{
		p_Main->setVtPos(ELF, vtPointer->GetPosition());
		vtPointer->Destroy();
	}
	if (elfConfiguration.usePrinter)
	{
		delete elfPrinterPointer;
	}
	p_Main->setMainPos(ELF, GetPosition());

	delete elfBitmapPointer;
	delete upBitmapPointer;
	delete downBitmapPointer;
	delete pushUpBitmapPointer;
	delete pushDownBitmapPointer;

	delete runButtonPointer;
	delete mpButtonPointer;
	delete powerButtonPointer;
	delete loadButtonPointer;

	for (int i=0; i<8; i++)
	{
		delete dataSwitchPointer[i];
	}
	for (int i=0; i<4; i++)
	{
		delete efSwitchPointer[i];
		delete addressPointer[i];
	}
	for (int i=0; i<2; i++)
	{
		delete dataPointer[i];
	}
 	delete qLedPointer;
}

void Elf::stopComputer()
{
	threadPointer->Delete();
}

void Elf::showModules(bool status)
{
	if (elfConfiguration.useHexKeyboard && !hexKeypadClosed_)
		keypadPointer->Show(status);
	if (elfConfiguration.useLedModule && !ledModuleClosed_)
		ledModulePointer->Show(status);
}

void Elf::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxPaintDC dc(this);
	dc.DrawBitmap(*elfBitmapPointer, 0, 0);
	dc.DrawBitmap(*pushUpBitmapPointer, 33, 312);

	for (int i=0; i<4; i++)
	{
		addressPointer[i]->onPaint(dc);
	}
	for (int i=0; i<2; i++)
	{
		dataPointer[i]->onPaint(dc);
	}
	qLedPointer->onPaint(dc);
}

void Elf::onClose(wxCloseEvent&WXUNUSED(event) )
{
	threadPointer->Pause();
	p_Main->stopComputer();
}

void Elf::onKeyDown(wxKeyEvent& event)
{
	if (!keyDownPressed(event.GetKeyCode()))
		event.Skip();
}

bool Elf::keyDownPressed(int key)
{
	switch(key)
	{
		case WXK_F1:
			p_Main->onF1();
			return true;
		break;

		case WXK_F2:
			showTime();
			return true;
		break;

		case WXK_F3:
			if ((elfConfiguration.vtType != VTNONE) || elfConfiguration.usePixie || elfConfiguration.use8275 || elfConfiguration.useS100 || elfConfiguration.use6845 || elfConfiguration.use6847 || elfConfiguration.useTMS9918)
			{
				if ((p_Video != NULL) && (p_Vt100 != NULL))
				{
					if (!p_Video->isFullScreenSet() && !p_Vt100->isFullScreenSet())
						p_Vt100->onF3();
					else if (p_Vt100->isFullScreenSet())
					{
						p_Vt100->onF3();
						while (p_Vt100->isFullScreenSet()) 
						{
							threadPointer->Sleep(1);
						}
						p_Video->onF3();
					}
					else
					{
						p_Video->onF3();
					}

					return true;
				}
				if (p_Video != NULL)
					p_Video->onF3();
				if (p_Vt100 != NULL)
					p_Vt100->onF3();
				return true;
			}
		break;

		case WXK_F5:
			if ((elfConfiguration.vtType != VTNONE) || elfConfiguration.usePixie || elfConfiguration.use8275 || elfConfiguration.useS100 || elfConfiguration.use6845 || elfConfiguration.use6847 || elfConfiguration.useTMS9918)
			{
				if (p_Video != NULL)
					p_Video->onF5();
				if (p_Vt100 != NULL)
					p_Vt100->onF5();
				return true;
			}
		break;

		case WXK_INSERT:
			onInButtonKeyboard();
			return true;
		break;

		case WXK_F12:
			onRun();
			return true;
		break;
	}
	onHexKeyDown(key);
	if (elfConfiguration.useKeyboard)
		keyboardUp();
	if (elfConfiguration.UsePS2)
	{
		keyDownPs2(key);
			return true;
	}
	return false;
}

void Elf::onKeyUp(wxKeyEvent& event)
{
	if (!keyUpReleased(event.GetKeyCode()))
		event.Skip();
}

bool Elf::keyUpReleased(int key)
{
	if (key == WXK_INSERT)
	{
		onInButtonRelease();
		return true;
	}
	onHexKeyUp();
	if (elfConfiguration.UsePS2)
	{
		keyUpPs2(key);
		return true;
	}
	return false;
}

void Elf::onChar(wxKeyEvent& event)
{
	if (elfConfiguration.useKeyboard)
		charEventKeyboard(event.GetKeyCode());
}

void Elf::charEvent(int keycode)
{
	if (elfConfiguration.useKeyboard)
		charEventKeyboard(keycode);
}

void Elf::onButtonRelease(wxMouseEvent& event)
{
	onInButtonRelease();
	event.Skip();
}

void Elf::onButtonPress(wxMouseEvent& event)
{
	int x, y;
	event.GetPosition(&x, &y);

	if ((x >= 33) &&(x <= 63) &&(y >= 312) &&(y <= 342))
	{
		onInButtonPress(getData());
	}
	event.Skip();
}

void Elf::onInButtonKeyboard()
{
	if (elfConfiguration.useHexKeyboard)
		onInButtonPress(switches_);
	else
		onInButtonPress(getData());
}

void Elf::onInButtonPress(Byte value)
{
	inPressed_ = true;
	if (cpuMode_ == LOAD)
	{
		dmaIn(value);
		showData(value);
	}
	else
	{
		efSwitchState_[3] = 1;
	}
	wxClientDC dc(this);
	dc.DrawBitmap(*pushDownBitmapPointer, 33, 312);
}

void Elf::onInButtonRelease()
{
	if (efSwitchState_[3] == 1)
	{
		inPressed_ = false;
		efSwitchState_[3] = 0;
	}
	wxClientDC dc(this);
	dc.DrawBitmap(*pushUpBitmapPointer, 33, 312);
}

void Elf::onHexKeyDown(int keycode)
{
	if (!elfConfiguration.useHexKeyboard)
		return;
	for (int i=0; i<16; i++)
	{
		if (keycode == hexKeyDefA_[i])
		{
			ef3State_ = 0;
			switches_ = ((switches_ << 4) & 0xf0) | i;
			keypadPointer->onNumberDown(i);
		}
	}
}

void Elf::onHexDown(int hex)
{
	ef3State_ = 0;
	switches_ = ((switches_ << 4) & 0xf0) | hex;
}

void Elf::onHexKeyUp()
{
	if (!elfConfiguration.useHexKeyboard)
		return;
	ef3State_ = 1;
}

void Elf::configureComputer()
{
	int efPort; 
	wxString printBuffer;

	inType_[3] = ELFIN;
	outType_[3] = ELFOUT;

	p_Main->message("Configuring Elf");
	p_Main->message("	Output 4: display output, input 4: data input");
	if (elfConfiguration.useHexKeyboardEf3)
	{
		efPort = p_Main->getConfigItem(_T("/Elf/HexEf"), 3l);
		efType_[efPort] = ELFEF3;
		printBuffer.Printf("	EF %d: 0 when hex button pressed", efPort);
		p_Main->message(printBuffer);
	}
	if (elfConfiguration.useTape)
	{
		efPort = p_Main->getConfigItem(_T("/Elf/TapeEf"), 2l);
		efType_[efPort] = ELF2EF2;
		printBuffer.Printf("	EF %d: cassette in", efPort);
		p_Main->message(printBuffer);
	}
	if (efType_[4] == 0)
	{
		efType_[4] = ELFINEF;
		p_Main->message("	EF 4: 0 when in button pressed");
	}
	p_Main->message("");

	hexKeyDefA_[0] = p_Main->getConfigItem(_T("/Elf/HexKeyA0"), 48);
	hexKeyDefA_[1] = p_Main->getConfigItem(_T("/Elf/HexKeyA1"), 49);
	hexKeyDefA_[2] = p_Main->getConfigItem(_T("/Elf/HexKeyA2"), 50);
	hexKeyDefA_[3] = p_Main->getConfigItem(_T("/Elf/HexKeyA3"), 51);
	hexKeyDefA_[4] = p_Main->getConfigItem(_T("/Elf/HexKeyA4"), 52);
	hexKeyDefA_[5] = p_Main->getConfigItem(_T("/Elf/HexKeyA5"), 53);
	hexKeyDefA_[6] = p_Main->getConfigItem(_T("/Elf/HexKeyA6"), 54);
	hexKeyDefA_[7] = p_Main->getConfigItem(_T("/Elf/HexKeyA7"), 55);
	hexKeyDefA_[8] = p_Main->getConfigItem(_T("/Elf/HexKeyA8"), 56);
	hexKeyDefA_[9] = p_Main->getConfigItem(_T("/Elf/HexKeyA9"), 57);
	hexKeyDefA_[10] = p_Main->getConfigItem(_T("/Elf/HexKeyAA"), 65);
	hexKeyDefA_[11] = p_Main->getConfigItem(_T("/Elf/HexKeyAB"), 66);
	hexKeyDefA_[12] = p_Main->getConfigItem(_T("/Elf/HexKeyAC"), 67);
	hexKeyDefA_[13] = p_Main->getConfigItem(_T("/Elf/HexKeyAD"), 68);
	hexKeyDefA_[14] = p_Main->getConfigItem(_T("/Elf/HexKeyAE"), 69);
	hexKeyDefA_[15] = p_Main->getConfigItem(_T("/Elf/HexKeyAF"), 70);

	resetCpu();
}

void Elf::initComputer()
{
	Show(elfConfiguration.useElfControlWindows);
	runButtonState_ = 0;
	for (int i=0; i<8; i++)  dataSwitchState_[i]=0;
	for (int i=0; i<4; i++)  efSwitchState_[i]=0;
	inPressed_ = false;
	mpButtonState_ = 0;
	loadButtonState_ = 1;

	wxClientDC dc(this);
	for (int i=0; i<4; i++)
	{
		addressPointer[i]->init(dc, 18+i*40, 226);
	}
	for (int i=0; i<2; i++)
	{
		dataPointer[i]->init(dc, 218+i*40, 226);
	}
	qState_ = flipFlopQ_ + 1;
	switches_ = 0;
	ef3State_ = 1;
	hexKeypadClosed_ = false;
	ledModuleClosed_ = false;
}

Byte Elf::ef(int flag)
{
	switch(efType_[flag])
	{
		case 0:
			return 1;
		break;

		case PIXIEEF:
			return pixiePointer->efPixie();
		break;

		case KEYBRDEF:
			return efKeyboard();
		break;

		case PS2GPIOEF:
			return efPs2gpio();
		break;

		case PS2EF:
			return efPs2();
		break;

		case FDCEF:
			return ef1793();
		break;

		case VT100EF:
			return vtPointer->ef();
		break;

		case MC6847EF:
			return mc6845Pointer->ef6845();
		break;

		case I8275EF:
			return i8275Pointer->ef8275();
		break;

		case ELFINEF:
			return ef4();
		break;

		case VTINEF:
			if (inPressed_ == true)
				return 0;
			else
				return vtPointer->ef();
		break;

		case ELF2EF2:
			return cassetteEf_;
		break;

		case ELFEF3:
			return ef3State_;
		break;

		default:
			return 1;
	}
}

Byte Elf::ef4()
{
	if (inPressed_ == true)
		return 0;
	else
		return 1;
}

Byte Elf::in(Byte port, Word WXUNUSED(address))
{
	Byte ret;

	switch(inType_[port-1])
	{
		case 0:
			ret = 255;
		break;

		case PIXIEIN:
			ret = pixiePointer->inPixie();
		break;

		case I8275PREGREAD:
			ret = i8275Pointer->pRegRead();
		break;

		case I8275SREGREAD:
			ret = i8275Pointer->sRegRead();
		break;

		case KEYBRDIN:
			ret = inKeyboard();
		break;

		case PS2GPIOIN:
			ret = inPs2gpio();
		break;

		case PS2IN:
			ret = inPs2();
		break;

		case ELFIN:
			if (elfConfiguration.useHexKeyboard)
				ret = switches_;
			else
				ret = getData();
		break;

		case FDCIN:
			ret = in1793();
		break;

		case IDEIN:
			ret = inIde();
		break;

		case PORTEXTIN:
			ret = inPortExtender();
		break;

		case UARTIN:
			return vtPointer->uartIn();
		break;

		case UARTSTATUS:
			return vtPointer->uartStatus();
		break;

		default:
			ret = 255;
	}
	inValues_[port] = ret;
	return ret;
}

Byte Elf::getData()
{
	return(dataSwitchState_[7]?128:0) +(dataSwitchState_[6]?64:0) +(dataSwitchState_[5]?32:0) +(dataSwitchState_[4]?16:0) +(dataSwitchState_[3]?8:0) +(dataSwitchState_[2]?4:0) +(dataSwitchState_[1]?2:0) +(dataSwitchState_[0]?1:0);
}

void Elf::out(Byte port, Word WXUNUSED(address), Byte value)
{
	outValues_[port] = value;

	switch(outType_[port-1])
	{
		case 0:
			return;
		break;

		case TMSHIGHOUT:
			tmsPointer->modeHighOut(value);
		break;

		case TMSLOWOUT:
			tmsPointer->modeLowOut(value);
		break;

		case PIXIEOUT:
			pixiePointer->outPixie();
		break;

		case MC6847OUT:
			mc6847Pointer->outMc6847(value);
		break;

		case I8275PREGWRITE:
			i8275Pointer->pRegWrite(value);
		break;

		case I8275CREGWRITE:
			i8275Pointer->cRegWrite(value);
		break;

		case VT100OUT:
			vtPointer->out(value);
		break;

		case PRINTEROUT:
			elfPrinterPointer->outElf(value);
		break;

		case LEDMODOUT:
			ledModulePointer->write(value);
		break;

		case PS2OUT:
			outPs2(value);
		break;

		case ELFOUT:
			showData(value);
		break;

		case FDCSELECTOUT:
			selectRegister1793(value);
		break;

		case FDCWRITEOUT:
			writeRegister1793(value);
		break;

		case IDESELECTOUT:
			selectIdeRegister(value);
		break;

		case IDEWRITEOUT:
			outIde(value);
		break;

		case PORTEXTSELECTOUT:
			selectPortExtender(value);
		break;

		case PORTEXTWRITEOUT:
			outPortExtender(value);
		break;

		case UARTOUT:
			return vtPointer->uartOut(value);
		break;

		case UARTCONTROL:
			return vtPointer->uartControl(value);
		break;
	}
}

void Elf::showData(Byte val)
{
	wxClientDC dc(this);

	dataPointer[0]->update(dc,(val>>4)&15);
	dataPointer[1]->update(dc, val&15);
}

void Elf::cycle(int type)
{
	switch(cycleType_[type])
	{
		case 0:
			return;
		break;

		case KEYBRDCYCLE:
			cycleKeyboard();
		break;

		case PS2GPIOCYCLE:
			cyclePs2gpio();
		break;

		case PS2CYCLE:
			cyclePs2();
		break;

		case PIXIECYCLE:
			pixiePointer->cyclePixie();
		break;

		case TMSCYCLE:
			tmsPointer->cycleTms();
		break;

		case MC6847CYCLE:
			mc6847Pointer->cycle6847();
		break;

		case MC6845BLINK:
			mc6845Pointer->blink6845();
		break;

		case MC6845CYCLE:
			mc6845Pointer->cycle6845();
		break;

		case I8275CYCLE:
			i8275Pointer->cycle8275();
		break;

		case VT100CYCLE:
			vtPointer->cycleVt();
		break;

		case FDCCYCLE:
			cycleFdc();
		break;

		case IDECYCLE:
			cycleIde();
		break;
	}
}

void Elf::addressTimeout(wxTimerEvent&WXUNUSED(event))
{
	showAddr(address_);
}

void Elf::showAddr(Word address)
{
//	if (cpuMode_ != RUN || elfConfiguration.showAddress)
//	{
	if (address != lastAddress_)
	{
		wxClientDC dc(this);
		addressPointer[0]->update(dc, address>>12);
		addressPointer[1]->update(dc,(address>>8)&15);
		addressPointer[2]->update(dc,(address>>4)&15);
		addressPointer[3]->update(dc, address&15);
		lastAddress_ = address;
	}
}

void Elf::autoBoot()
{
	runButtonPointer->SetBitmapLabel(*upBitmapPointer);
	runButtonState_ = 1;
	setClear(runButtonState_);
	if (cpuMode_ == RESET)  showAddr(0);
	if (cpuMode_ != RUN)  showTime();
}

void Elf::updateQState()
{
	if (qState_ != flipFlopQ_)
	{
		qState_ = flipFlopQ_;
		wxClientDC dc(this);
		qLedPointer->setStatus(dc, flipFlopQ_);
	}
}

int Elf::getMpButtonState()
{
	return mpButtonState_;
}

void Elf::onRunButton(wxCommandEvent&WXUNUSED(event))
{
	onRun();
}

void Elf::onRun()
{
	if (runButtonState_)
	{
		runButtonPointer->SetBitmapLabel(*downBitmapPointer);
		runButtonState_ = 0;
	}
	else
	{
		runButtonPointer->SetBitmapLabel(*upBitmapPointer);
		runButtonState_ = 1;
		startTime_ = wxGetLocalTime();
	}
	setClear(runButtonState_);
	p_Main->updateTitle();
	if (cpuMode_ == RESET)  showAddr(0);
	if (cpuMode_ != RUN)  showTime();
}

void Elf::onMpButton(wxCommandEvent&WXUNUSED(event))
{
	if (mpButtonState_)
	{
		mpButtonPointer->SetBitmapLabel(*downBitmapPointer);
		mpButtonState_ = 0;
	}
	else
	{
		mpButtonPointer->SetBitmapLabel(*upBitmapPointer);
		mpButtonState_ = 1;
	}
}

void Elf::onLoadButton(wxCommandEvent&WXUNUSED(event))
{
	if (!loadButtonState_)
	{
		loadButtonPointer->SetBitmapLabel(*downBitmapPointer);
		loadButtonState_ = 1;
	}
	else
	{
		loadButtonPointer->SetBitmapLabel(*upBitmapPointer);
		loadButtonState_ = 0;
	}
	setWait(loadButtonState_);
	if (cpuMode_ == RESET)  showAddr(0);
}

void Elf::onPowerButton(wxCommandEvent&WXUNUSED(event))
{
	powerButtonPointer->SetBitmapLabel(*upBitmapPointer);
	threadPointer->Pause();
	p_Main->stopComputer();
}

void Elf::dataSwitch(wxCommandEvent&event)
{
	int i;

	i = event.GetId() - 10;

	if (dataSwitchState_[i])
	{
		dataSwitchPointer[i]->SetBitmapLabel(*downBitmapPointer);
		dataSwitchState_[i] = 0;
	}
	else
	{
		dataSwitchPointer[i]->SetBitmapLabel(*upBitmapPointer);
		dataSwitchState_[i] = 1;
	}
}

void Elf::efSwitch(wxCommandEvent&event)
{
	int i;

	i = event.GetId() - 20;

	if (efSwitchState_[i])
	{
		efSwitchPointer[i]->SetBitmapLabel(*downBitmapPointer);
		efSwitchState_[i] = 0;
	}
	else
	{
		efSwitchPointer[i]->SetBitmapLabel(*upBitmapPointer);
		efSwitchState_[i] = 1;
	}
    setEf(i+1, 1-efSwitchState_[i]);
}

void Elf::startComputer()
{
	startElfKeyFile("Elf");

	resetPressed_ = false;

	if (elfConfiguration.usePortExtender)
		configurePortExt(ELF);

	defineMemoryType(p_Main->getStartRam("Elf", ELF), p_Main->getEndRam("Elf", ELF), RAM);

	if (elfConfiguration.usePager)
	{
		allocPagerMemory();
		definePortExtForPager();

		defineMemoryType(0, 65535, PAGER);
	}
	if (elfConfiguration.useEms)
	{
		allocEmsMemory();
		defineMemoryType(0x8000, 0xbfff, EMSMEMORY);
	}

	p_Main->enableDebugGuiMemory();
	readProgramCombo(p_Main->getRomDir(ELF, MAINROM), "MainRomElf", p_Main->getLoadromMode(ELF, 0), 0, NONAME);
	readProgramCombo(p_Main->getRomDir(ELF, MAINROM2), "MainRom2Elf", p_Main->getLoadromMode(ELF, 1), 0, NONAME);

	configureElfExtensions();
	if (elfConfiguration.autoBoot)
	{
		scratchpadRegister_[0]=p_Main->getBootAddress("Elf", ELF);
		autoBoot();
	}

	if (elfConfiguration.vtType != VTNONE)
		setEf(4,0);

	if (elfConfiguration.usePortExtender)
		p_Main->setGuiPortExtenderValue();

	p_Main->setSwName("");
	p_Main->updateTitle();
	address_ = 0;

	cpuCycles_ = 0;
	startTime_ = wxGetLocalTime();

	long ms;
	wxString stringMs = p_Main->getTextValue("ShowAddressElf");
	if (!stringMs.ToLong(&ms, 10))
	{
		p_Main->setTextValue("ShowAddressElf", "100");
		p_Main->errorMessage("Please specify TIL311 address update in decimal (reset to 100)\n");
		ms = 100;
	}
	if (ms > 0)
		addressTimerPointer->Start(ms, wxTIMER_CONTINUOUS);

	threadPointer->Run();
}

Byte Elf::readMem(Word addr)
{
	address_ = addr;

	switch (memoryType_[addr/256])
	{
		case EMSMEMORY:
			switch (emsMemoryType_[((addr & 0x3fff) |(emsPage_ << 14))/256])
			{
				case UNDEFINED:
					return 255;
				break;

				case ROM:
				case RAM:
					return emsRam_[(long) ((addr & 0x3fff) |(emsPage_ << 14))];
				break;

				default:
					return 255;
				break;
			}
		break;

		case UNDEFINED:
			return 255;
		break;

		case ROM:
		case RAM:
			return mainMemory_[addr];
		break;

		case MC6847RAM:
			return mc6847Pointer->read6847(addr);
		break;

		case MC6845RAM:
			return mc6845Pointer->read6845(addr & 0x7ff);
		break;

		case MC6845REGISTERS:
			return mc6845Pointer->readData6845(addr);
		break;

		case PAGER:
			switch (pagerMemoryType_[((getPager(addr>>12) << 12) |(addr &0xfff))/256])
			{
				case UNDEFINED:
					return 255;
				break;

				case ROM:
				case RAM:
					return mainMemory_[(getPager(addr>>12) << 12) |(addr &0xfff)];
				break;

				default:
					return 255;
				break;
			}
		break;

		default:
			return 255;
		break;
	}
}

void Elf::writeMem(Word addr, Byte value, bool writeRom)
{
	address_ = addr;

	if (emsMemoryDefined_)
	{
		if (addr>=0xc000 && addr <=0xffff)
		{
			emsPage_ = value & 0x1f;
		}
	}

	switch (memoryType_[addr/256])
	{
		case EMSMEMORY:
			switch (emsMemoryType_[((addr & 0x3fff) |(emsPage_ << 14))/256])
			{
				case UNDEFINED:
				case ROM:
					if (writeRom)
						emsRam_[(long) ((addr & 0x3fff) |(emsPage_ << 14))] = value;
				break;

				case RAM:
					if (!getMpButtonState())
						emsRam_[(long) ((addr & 0x3fff) |(emsPage_ << 14))] = value;
				break;
			}
		break;

		case MC6847RAM:
			mc6847Pointer->write(addr, value);
			mainMemory_[addr] = value;
		break;

		case MC6845RAM:
			mc6845Pointer->write6845(addr & 0x7ff, value);
		break;

		case MC6845REGISTERS:
			mc6845Pointer->writeRegister6845(addr, value);
		break;

		case UNDEFINED:
		case ROM:
			if (writeRom)
				mainMemory_[addr]=value;
		break;

		case RAM:
			if (!getMpButtonState())
				mainMemory_[addr]=value;
		break;

		case PAGER:
			switch (pagerMemoryType_[((getPager(addr>>12) << 12) |(addr &0xfff))/256])
			{
				case UNDEFINED:
				case ROM:
					if (writeRom)
						mainMemory_[(getPager(addr>>12) << 12) |(addr &0xfff)] = value;
				break;

				case RAM:
					if (!getMpButtonState())
						mainMemory_[(getPager(addr>>12) << 12) |(addr &0xfff)] = value;
				break;
			}
		break;

	}
}

void Elf::cpuInstruction()
{
	if (debugMode_)
		p_Main->updateWindow();
	if (cpuMode_ == RUN)
	{
		if (steps_ != 0)
		{
			cycle0_=0;
			machineCycle();
			if (cycle0_ == 0) machineCycle();
			if (cycle0_ == 0 && steps_ != 0)
			{
				cpuCycle();
				cpuCycles_ += 2;
			}
		}
		else
			soundCycle();

		playSaveLoad();
		checkElfFunction();
		if (resetPressed_)
		{
			resetCpu();
			if (elfConfiguration.use8275)
				i8275Pointer->cRegWrite(0x40);
			if (elfConfiguration.autoBoot)
			{
				scratchpadRegister_[0]=p_Main->getBootAddress("Elf", ELF);
				autoBoot();
			}
			resetPressed_ = false;
			p_Main->setSwName("");
			startElfKeyFile("Elf");
		}
		if (debugMode_)
			p_Main->cycleDebug();

		updateQState();
/*		if (elfConfiguration.vtType != VTNONE)
			vtPointer->getKey();*/
	}
	else
	{
		machineCycle();
		machineCycle();
		cpuCycles_ = 0;
		startTime_ = wxGetLocalTime();
		if (cpuMode_ == LOAD)
		{
			showData(readMem(address_));
			threadPointer->Sleep(1);
		}
	}
}

void Elf::configureElfExtensions()
{
	wxString fileName, fileName2;

	if (elfConfiguration.usePixie)
	{
		int zoom = p_Main->getSpinValue("ZoomElf");
		pixiePointer = new Pixie( "Elf - Pixie", p_Main->getPixiePos(ELF), wxSize(192*zoom, 128*zoom), zoom, ELF);
		p_Video = pixiePointer;
		pixiePointer->setZoom(zoom);
		pixiePointer->configurePixie();
		pixiePointer->initPixie();
		pixiePointer->Show(true);
	}

	if (elfConfiguration.use6845)
	{
		int zoom = p_Main->getSpinValue("ZoomElf");
		mc6845Pointer = new MC6845( "Elf - MC6845", p_Main->get6845Pos(ELF), wxSize(64*8*zoom, 16*8*zoom), zoom, ELF, elfClockSpeed_, 8);
		p_Video = mc6845Pointer;
		mc6845Pointer->configure6845();
		mc6845Pointer->init6845();
		mc6845Pointer->Show(true);
	}

	if (elfConfiguration.useS100)
	{
		int zoom = p_Main->getSpinValue("ZoomElf");
		mc6845Pointer = new MC6845( "Elf - Quest Super Video", p_Main->get6845Pos(ELF), wxSize(64*7*zoom, 16*9*zoom), zoom, ELF, elfClockSpeed_, 7);
		p_Video = mc6845Pointer;
		mc6845Pointer->configureSuperVideo();
		mc6845Pointer->init6845();
		mc6845Pointer->Show(true);
	}

	if (elfConfiguration.use6847)
	{
		int zoom = p_Main->getSpinValue("ZoomElf");
		mc6847Pointer = new mc6847( "Elf - MC6847", p_Main->get6847Pos(ELF), wxSize(elfConfiguration.charLine*8*zoom, elfConfiguration.screenHeight6847*zoom), zoom, ELF, elfClockSpeed_);
		p_Video = mc6847Pointer;
		mc6847Pointer->configure();
		mc6847Pointer->Show(true);
	}

	if (elfConfiguration.use8275)
	{
		int zoom = p_Main->getSpinValue("ZoomElf");
		i8275Pointer = new i8275( "Elf - Intel 8275", p_Main->get8275Pos(ELF), wxSize(80*8*zoom, 24*10*2*zoom), zoom, ELF, elfClockSpeed_);
		p_Video = i8275Pointer;
		i8275Pointer->configure8275();
		i8275Pointer->init8275();
		i8275Pointer->Show(true);
	}

	if (elfConfiguration.useTMS9918)
	{
		int zoom = p_Main->getSpinValue("ZoomElf");
		tmsPointer = new Tms9918( "Elf - TMS 9918", p_Main->getTmsPos(ELF), wxSize((256+(BACKX*2))*zoom,(192+(BACKY*2))*zoom), zoom, ELF, elfClockSpeed_);
		p_Video = tmsPointer;
		tmsPointer->configure();
		tmsPointer->Show(true);
	}

	if (elfConfiguration.fdcEnabled)
	{
		configure1793(1, 40, 18, 256, ELF);
		resetFdc();
	}

	if (elfConfiguration.ideEnabled)
	{
		fileName = p_Main->getIdeDir(ELF);
		fileName2 = fileName;

		fileName.operator += (p_Main->getTextValue("IdeFileElf"));
		fileName2.operator += ("disk2.ide");

		configureIde(fileName, fileName2);
	}

	if (elfConfiguration.usePrinter)
	{
		elfPrinterPointer = new Printer();
		elfPrinterPointer->configureElfPrinter();
	}

	if (elfConfiguration.useLedModule)
	{
		ledModulePointer = new LedModule("Led Module", p_Main->getLedModulePos(), wxSize(172, 116), ELF);
		ledModulePointer->configure();
		ledModulePointer->Show(elfConfiguration.useElfControlWindows);
	}

	if (elfConfiguration.vtType != VTNONE)
	{
		int zoom = p_Main->getSpinValue("ZoomElf");
		vtPointer = new Vt100("Elf - VT 100", p_Main->getVtPos(ELF), wxSize(640*zoom, 400*zoom), zoom, ELF, elfClockSpeed_, elfConfiguration.vtType);
		p_Vt100 = vtPointer;
		vtPointer->configure(elfConfiguration.baudR, elfConfiguration.baudT);
		vtPointer->Show(true);
		vtPointer->drawScreen();
		setSoundFollowQ (false);
	}
	else
		setSoundFollowQ (true);

	if (elfConfiguration.useHexKeyboard)
	{
		keypadPointer = new Keypad("Keypad", p_Main->getKeypadPos(ELF), wxSize(172, 229), ELF);
		keypadPointer->Show(elfConfiguration.useElfControlWindows);
		p_Main->message("Configuring Elf Keypad\n");
	}

	if (elfConfiguration.useKeyboard)
		configureKeyboard(ELF);

	if (elfConfiguration.UsePS2)
		configurePs2(elfConfiguration.ps2Interrupt);
}

void Elf::tmsAndPixieZoom(int zoom)
{
	if (elfConfiguration.useTMS9918)
	{
		tmsPointer->setZoom(zoom);
		tmsPointer->reDrawScreen();
	}
	if (elfConfiguration.usePixie)
	{
		pixiePointer->setZoom(zoom);
		pixiePointer->reDrawScreen();
	}
	if (elfConfiguration.use6845||elfConfiguration.useS100)
	{
		mc6845Pointer->setZoom(zoom);
		mc6845Pointer->copyScreen();
	}
	if (elfConfiguration.use6847)
	{
		mc6847Pointer->setZoom(zoom);
		mc6847Pointer->copyScreen();
	}
	if (elfConfiguration.use8275)
	{
		i8275Pointer->setZoom(zoom);
		i8275Pointer->copyScreen();
	}
	if (elfConfiguration.vtType != VTNONE)
	{
		vtPointer->setZoom(zoom);
		vtPointer->copyScreen();
	}
}

void Elf::moveWindows()
{
	if (elfConfiguration.useHexKeyboard)
		keypadPointer->Move(p_Main->getKeypadPos(ELF));
	if (elfConfiguration.useLedModule)
		ledModulePointer->Move(p_Main->getLedModulePos());
	if (elfConfiguration.usePixie)
		pixiePointer->Move(p_Main->getPixiePos(ELF));
	if (elfConfiguration.useTMS9918)
		tmsPointer->Move(p_Main->getTmsPos(ELF));
	if (elfConfiguration.use6845||elfConfiguration.useS100)
		mc6845Pointer->Move(p_Main->get6845Pos(ELF));
	if (elfConfiguration.use6847)
		mc6847Pointer->Move(p_Main->get6847Pos(ELF));
	if (elfConfiguration.use8275)
		i8275Pointer->Move(p_Main->get8275Pos(ELF));
	if (elfConfiguration.vtType != VTNONE)
		vtPointer->Move(p_Main->getVtPos(ELF));
}

void Elf::updateTitle(wxString Title)
{
	if (elfConfiguration.usePixie)
		pixiePointer->SetTitle("Elf - Pixie"+Title);
	if (elfConfiguration.useTMS9918)
		tmsPointer->SetTitle("Elf - TMS 9918"+Title);
	if (elfConfiguration.use6845)
		mc6845Pointer->SetTitle("Elf - MC6845"+Title);
	if (elfConfiguration.useS100)
		mc6845Pointer->SetTitle("Elf - Quest Super Video"+Title);
	if (elfConfiguration.use6847)
		mc6847Pointer->SetTitle("Elf - MC6847"+Title);
	if (elfConfiguration.use8275)
		i8275Pointer->SetTitle("Elf - Intel 8275"+Title);
	if (elfConfiguration.vtType != VTNONE)
		vtPointer->SetTitle("Elf - VT 100"+Title);
	if (elfConfiguration.useLedModule)
		ledModulePointer->SetTitle("Led Module"+Title);
	if (elfConfiguration.useHexKeyboard)
		keypadPointer->SetTitle("Keypad"+Title);
}

void Elf::setForceUpperCase(bool status)
{
	if (elfConfiguration.vtType != VTNONE)
		vtPointer->setForceUCVt(status);
	if (elfConfiguration.useKeyboard)
		setForceUpperCaseKeyboard(status);
}

void Elf::onReset()
{
	resetPressed_ = true;
}

Byte Elf::read8275CharRom(Word addr)
{
	if (elfConfiguration.use8275)
		return i8275Pointer->read8275CharRom(addr);
	else
		return 0;
}

void Elf::write8275CharRom(Word addr, Byte value)
{
	if (elfConfiguration.use8275)
		i8275Pointer->write8275CharRom(addr, value);
}
Byte Elf::read6845CharRom(Word addr)
{
	if (elfConfiguration.use6845||elfConfiguration.useS100)
		return mc6845Pointer->read6845CharRom(addr);
	else
		return 0;
}

void Elf::write6845CharRom(Word addr, Byte value)
{
	mc6845Pointer->write6845CharRom(addr, value);
}

Byte Elf::read6847CharRom(Word addr)
{
	if (elfConfiguration.use6847)
		return mc6847Pointer->read6847CharRom(addr);
	else
		return 0;
}

void Elf::write6847CharRom(Word addr, Byte value)
{
	if (elfConfiguration.use6847)
		mc6847Pointer->write6847CharRom(addr, value);
}

int Elf::readDirect6847(Word addr)
{
	if (elfConfiguration.use6847)
		return mc6847Pointer->readDirect6847(addr); 
	else
		return 0;
}

void Elf::writeDirect6847(Word addr, int value)
{
	if (elfConfiguration.use6847)
		mc6847Pointer->writeDirect6847(addr, value); 
}

Word Elf::get6847RamMask()
{
 	if (elfConfiguration.use6847)
		return mc6847Pointer->get6847RamMask();
	else
		return 0;
}

void *RunElf::Entry()
{
	while(!TestDestroy())
	{
		p_Computer->cpuInstruction();
	}
	return NULL;
}
