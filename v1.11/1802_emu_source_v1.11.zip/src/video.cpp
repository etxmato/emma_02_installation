/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "wx/frame.h"

#include "main.h"
#include "video.h"

Video::Video(const wxString& title, const wxPoint& pos, const wxSize& size)
: wxFrame((wxFrame *)NULL, -1, title, pos, size)
{
}

void Video::onF3()
{
	p_Main->message("Illegal call to full screen change");
}

void Video::onF5()
{
	p_Main->message("Illegal call to video screen dump");
}

void Video::setInterlace(bool status)
{
	if (status)
		p_Main->message("Illegal call to interlace set");
	else
		p_Main->message("Illegal call to interlace reset");
}

void Video::setStretchDot(bool status)
{
	if (status)
		p_Main->message("Illegal call to stretch dot set");
	else
		p_Main->message("Illegal call to stretch dot reset");
}

void Video::setReBlit()
{
	p_Main->message("Illegal call to re-blit screen");
}

long Video::getVideoSyncCount()
{
	p_Main->message("Illegal request for video synchronization counter");
	return 0;
}

void Video::focus()
{
	p_Main->message("Illegal call to set CDP 1870 focus");
}

void Video::updateStatusLed(bool WXUNUSED(status))
{
	p_Main->message("Illegal call to update COMX status led");
}

void Video::dataAvailable()
{
	p_Main->message("Illegal call to vt-100 data available");
}

void Video::framingError(bool WXUNUSED(data))
{
	p_Main->message("Illegal call to vt-100 framing error");
}

void Video::setVtMemory(int WXUNUSED(address), Byte WXUNUSED(value))
{
}

Byte Video::getVtMemory(int WXUNUSED(address))
{
	return 0;
}

bool Video::charPressed(wxKeyEvent& WXUNUSED(event))
{
	return false;
}

void Video::keyDownPressed(wxKeyEvent& WXUNUSED(event))
{
}

void Video::keyUpPressed()
{
}

void Video::uartOut(Byte WXUNUSED(value))
{
}

Byte Video::uartIn()
{
	return 0;
}

void Video::defineColours(int type)
{
	wxString colour, computerType;

	ScreenInfo screenInfo = p_Main->getScreenInfo(type);
	computerType = p_Main->getRunningComputerStr();
	numberOfColours_ = screenInfo.number;
	reColour_ = false;
	for (int i=screenInfo.start; i<screenInfo.number; i++)
	{
		colour.Printf("%d", i);
		colour.Trim(false);
		colour_[i] = wxColour(p_Main->getConfigItem(_T(computerType+"/Colour"+colour), screenInfo.defaultColour[i]));
		brushColour_[i] = wxBrush(colour_[i]);
		penColour_[i] = wxPen(colour_[i]);
	}
}

void Video::setColour(int colourNumber, wxString colour)
{
	colourNew_[colourNumber] = wxColour(colour);
	brushColourNew_[colourNumber] = wxBrush(colourNew_[colourNumber]);
	penColourNew_[colourNumber] = wxPen(colourNew_[colourNumber]);
}

void Video::ResetIo()
{
}

