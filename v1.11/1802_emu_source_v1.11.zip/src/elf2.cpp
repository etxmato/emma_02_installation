/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

/*
 *******************************************************************
 *** This software is copyright 2006 by Michael H Riley          ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "elf_icon.xpm"
#endif

#include "main.h"
#include "pushbutton.h"

#include "elf2.h"
#include "elf2.xpm"
#include "swup2.xpm"
#include "swdn2.xpm"

#define OFF    1

BEGIN_EVENT_TABLE(Elf2, wxFrame)
	EVT_CLOSE (Elf2::onClose)
	EVT_PAINT(Elf2::onPaint)
	EVT_CHAR(Elf2::onChar)
	EVT_KEY_UP(Elf2::onKeyUp)
	EVT_KEY_DOWN(Elf2::onKeyDown)
	EVT_COMMAND(20, wxEVT_ButtonDownEvent, Elf2::onButtonPress)
	EVT_COMMAND(20, wxEVT_ButtonUpEvent, Elf2::onButtonRelease)
	EVT_BUTTON(21, Elf2::onRunButton)
	EVT_BUTTON(22, Elf2::onMpButton)
	EVT_BUTTON(23, Elf2::onPowerButton)
	EVT_BUTTON(24, Elf2::onLoadButton)
	EVT_COMMAND(0, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(1, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(2, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(3, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(4, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(5, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(6, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(7, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(8, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(9, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(10, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(11, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(12, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(13, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(14, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(15, wxEVT_ButtonDownEvent, Elf2::onNumberKeyDown)
	EVT_COMMAND(0, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(1, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(2, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(3, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(4, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(5, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(6, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(7, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(8, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(9, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(10, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(11, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(12, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(13, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(14, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
	EVT_COMMAND(15, wxEVT_ButtonUpEvent, Elf2::onNumberKeyUp)
END_EVENT_TABLE()

Elf2::Elf2(const wxString& title, const wxPoint& pos, const wxSize& size, double clock, ElfConfiguration conf)
: wxFrame((wxFrame *)NULL, -1, title, pos, size)
{
	elfConfiguration = conf;
	wxClientDC dc(this);
	elfClockSpeed_ = clock;

	wxString buttonText;
	int x, y;

	SetIcon(wxICON(elf_icon));
	this->SetClientSize(size);

	Elf2BitmapPointer = new wxBitmap(elf2_xpm);
	upBitmapPointer = new wxBitmap(swup_xpm);
	downBitmapPointer = new wxBitmap(swdn_xpm);

	inButtonPointer = new PushButton(this, 20, "IN", wxPoint(435, 327), wxSize(30, 30));
	runButtonPointer = new wxBitmapButton(this, 21, *downBitmapPointer, wxPoint(440, 235), wxSize(25, 25), 0, wxDefaultValidator, "onRunButton");
	mpButtonPointer = new wxBitmapButton(this, 22, *downBitmapPointer, wxPoint(440, 295), wxSize(25, 25), 0, wxDefaultValidator, "MPButton");
	powerButtonPointer = new wxBitmapButton(this, 23, *upBitmapPointer, wxPoint(490, 20), wxSize(25, 25), 0, wxDefaultValidator, "PowerButton");
	loadButtonPointer = new wxBitmapButton(this, 24, *downBitmapPointer, wxPoint(440, 265), wxSize(25, 25), 0, wxDefaultValidator, "LoadButton");
	qLedPointer = new Led(dc, 440, 190, ELFIILED);

	for (int i=0; i<16; i++)
	{
		buttonText.Printf("%01X", i);
		x = 304 +(i&0x3)*32;
		y = 327 -(int)i/4*32;
		buttonPointer[i] = new PushButton(this, i, buttonText, wxPoint(x, y), wxSize(30, 30));
	}
	for (int i=0; i<2; i++)
	{
		dataPointer[i] = new Til311();
	}
	offset_ = 0;
	threadPointer = new RunElf2();
	if ( threadPointer->Create() != wxTHREAD_NO_ERROR )
	{
		p_Main->message("Can't create thread");
	}
	threadPointer->SetPriority(WXTHREAD_MAX_PRIORITY);
}

Elf2::~Elf2()
{
	if (elfConfiguration.usePixie)
	{
		p_Main->setPixiePos(ELFII, pixiePointer->GetPosition());
		pixiePointer->Destroy();
	}
	if (elfConfiguration.useTMS9918)
	{
		p_Main->setTmsPos(ELFII, tmsPointer->GetPosition());
		tmsPointer->Destroy();
	}
	if (elfConfiguration.use6845||elfConfiguration.useS100)
	{
		p_Main->set6845Pos(ELFII, mc6845Pointer->GetPosition());
		mc6845Pointer->Destroy();
	}
	if (elfConfiguration.use6847)
	{
		p_Main->set6847Pos(ELFII, mc6847Pointer->GetPosition());
		mc6847Pointer->Destroy();
	}
	if (elfConfiguration.use8275)
	{
		p_Main->set8275Pos(ELFII, i8275Pointer->GetPosition());
		i8275Pointer->Destroy();
	}
	if (elfConfiguration.vtType != VTNONE)
	{
		p_Main->setVtPos(ELFII, vtPointer->GetPosition());
		vtPointer->Destroy();
	}
	if (elfConfiguration.usePrinter)
	{
		delete elfPrinterPointer;
	}
	p_Main->setMainPos(ELFII, GetPosition());

	delete Elf2BitmapPointer;
 	delete upBitmapPointer;
 	delete downBitmapPointer;

	delete inButtonPointer;
	delete runButtonPointer;
	delete mpButtonPointer;
	delete powerButtonPointer;
	delete loadButtonPointer;
	delete qLedPointer;

	for (int i=0;i<16;i++)
	{
		delete buttonPointer[i];
	}
	for (int i=0; i<2; i++)
	{
		delete dataPointer[i];
	}
}

void Elf2::stopComputer()
{
	threadPointer->Delete();
}

void Elf2::onClose(wxCloseEvent&WXUNUSED(event) )
{
	threadPointer->Pause();
	p_Main->stopComputer();
}

void Elf2::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxPaintDC dc(this);
	dc.DrawBitmap(*Elf2BitmapPointer, 0, 0);

	for (int i=0; i<2; i++)
	{
		dataPointer[i]->onPaint(dc);
	}
	qLedPointer->onPaint(dc);
}

void Elf2::onChar(wxKeyEvent& event)
{
	if (elfConfiguration.useKeyboard)
		charEventKeyboard(event.GetKeyCode());
}

void Elf2::charEvent(int keycode)
{
	if (elfConfiguration.useKeyboard)
		charEventKeyboard(keycode);
}

void Elf2::onKeyDown(wxKeyEvent& event)
{
	if (!keyDownPressed(event.GetKeyCode()))
		event.Skip();
}

bool Elf2::keyDownPressed(int key)
{
	switch(key)
	{
		case WXK_F1:
			p_Main->onF1();
			return true;
		break;

		case WXK_F2:
			showTime();
			return true;
		break;

		case WXK_F3:
			if ((elfConfiguration.vtType != VTNONE) || elfConfiguration.usePixie || elfConfiguration.use8275 || elfConfiguration.useS100 || elfConfiguration.use6845 || elfConfiguration.use6847 || elfConfiguration.useTMS9918)
			{
				if ((p_Video != NULL) && (p_Vt100 != NULL))
				{
					if (!p_Video->isFullScreenSet() && !p_Vt100->isFullScreenSet())
						p_Vt100->onF3();
					else if (p_Vt100->isFullScreenSet())
					{
						p_Vt100->onF3();
						while (p_Vt100->isFullScreenSet()) 
						{
							threadPointer->Sleep(1);
						}
						p_Video->onF3();
					}
					else
					{
						p_Video->onF3();
					}

					return true;
				}
				if (p_Video != NULL)
					p_Video->onF3();
				if (p_Vt100 != NULL)
					p_Vt100->onF3();
				return true;
			}
		break;

		case WXK_F5:
			if ((elfConfiguration.vtType != VTNONE) || elfConfiguration.usePixie || elfConfiguration.use8275 || elfConfiguration.useS100 || elfConfiguration.use6845 || elfConfiguration.use6847 || elfConfiguration.useTMS9918)
			{
				if (p_Video != NULL)
					p_Video->onF5();
				if (p_Vt100 != NULL)
					p_Vt100->onF5();
				return true;
			}
		break;

		case WXK_INSERT:
			onInButtonPress();
			return true;
		break;

		case WXK_F12:
			onRun();
			return true;
		break;
	}
	onHexKeyDown(key);
	if (elfConfiguration.useKeyboard)
		keyboardUp();
	if (elfConfiguration.UsePS2)
	{
		keyDownPs2(key);
			return true;
	}
	return false;
}

void Elf2::onKeyUp(wxKeyEvent& event)
{
	if (!keyUpReleased(event.GetKeyCode()))
		event.Skip();
}

bool Elf2::keyUpReleased(int key)
{

	if (key == WXK_INSERT)
	{
		onInButtonRelease();
		return true;
	}
	onHexKeyUp();
	if (elfConfiguration.UsePS2)
	{
		keyUpPs2(key);
		return true;
	}
	return false;
}

void Elf2::onButtonRelease(wxCommandEvent& event)
{
	ef4State_ = 1;
	event.Skip();
}

void Elf2::onButtonPress(wxCommandEvent& event)
{
	onInButtonPress();
	event.Skip();
}

void Elf2::onInButtonPress()
{
	if (cpuMode_ == LOAD)
	{
		Byte value = getData();
		dmaIn(value);
		showData(value);
	}
	else
	{
		ef4State_ = 0;
	}
}

void Elf2::onInButtonRelease()
{
	ef4State_ = 1;
}

void Elf2::configureComputer()
{
	int efPort;
	wxString printBuffer;

	inType_[3] = ELF2IN;
	outType_[3] = ELF2OUT;
//	inType_[6] = RCADISKIN;
//	outType_[6] = RCADISKOUT;

	p_Main->message("Configuring Elf II");
	p_Main->message("	Output 4: display output, input 4: data input");

	if (elfConfiguration.useTape)
	{
		efPort = p_Main->getConfigItem(_T("/ElfII/TapeEf"), 2l);
		efType_[efPort] = ELF2EF2;
		printBuffer.Printf("	EF %d: cassette in", efPort);
		p_Main->message(printBuffer);
	}
	if (elfConfiguration.useHexKeyboardEf3)
	{
		efPort = p_Main->getConfigItem(_T("/ElfII/HexEf"), 3l);
		efType_[efPort] = ELF2EF3;
		printBuffer.Printf("	EF %d: 0 when hex button pressed", efPort);
		p_Main->message(printBuffer);
	}

	if (efType_[4] == 0)
	{
		efType_[4] = ELFINEF;
		p_Main->message("	EF 4: 0 when in button pressed");
	}
	p_Main->message("");

	hexKeyDefA_[0] = p_Main->getConfigItem(_T("/ElfII/HexKeyA0"), 48);
	hexKeyDefA_[1] = p_Main->getConfigItem(_T("/ElfII/HexKeyA1"), 49);
	hexKeyDefA_[2] = p_Main->getConfigItem(_T("/ElfII/HexKeyA2"), 50);
	hexKeyDefA_[3] = p_Main->getConfigItem(_T("/ElfII/HexKeyA3"), 51);
	hexKeyDefA_[4] = p_Main->getConfigItem(_T("/ElfII/HexKeyA4"), 52);
	hexKeyDefA_[5] = p_Main->getConfigItem(_T("/ElfII/HexKeyA5"), 53);
	hexKeyDefA_[6] = p_Main->getConfigItem(_T("/ElfII/HexKeyA6"), 54);
	hexKeyDefA_[7] = p_Main->getConfigItem(_T("/ElfII/HexKeyA7"), 55);
	hexKeyDefA_[8] = p_Main->getConfigItem(_T("/ElfII/HexKeyA8"), 56);
	hexKeyDefA_[9] = p_Main->getConfigItem(_T("/ElfII/HexKeyA9"), 57);
	hexKeyDefA_[10] = p_Main->getConfigItem(_T("/ElfII/HexKeyAA"), 65);
	hexKeyDefA_[11] = p_Main->getConfigItem(_T("/ElfII/HexKeyAB"), 66);
	hexKeyDefA_[12] = p_Main->getConfigItem(_T("/ElfII/HexKeyAC"), 67);
	hexKeyDefA_[13] = p_Main->getConfigItem(_T("/ElfII/HexKeyAD"), 68);
	hexKeyDefA_[14] = p_Main->getConfigItem(_T("/ElfII/HexKeyAE"), 69);
	hexKeyDefA_[15] = p_Main->getConfigItem(_T("/ElfII/HexKeyAF"), 70);

	resetCpu();
}

void Elf2::initComputer()
{
	Show(elfConfiguration.useElfControlWindows);

	wxClientDC dc(this);
	dc.DrawBitmap(*Elf2BitmapPointer, 0, 0);

	cassetteEf_ = 0;
	runButtonState_ = 0;
	mpButtonState_ = 0;
	loadButtonState_ = 1;
	ef3State_ = 1;
	ef4State_ = 1;
	switches_ = 0;
	qLed_ = 0;
	elfRunState_ = RESETSTATE;

	for (int i=0; i<2; i++)
	{
		dataPointer[i]->init(dc, 370+i*28,180);
	}
}

Byte Elf2::ef(int flag)
{
	switch(efType_[flag])
	{
		case 0:
			return 1;
		break;

		case PIXIEEF:
			return pixiePointer->efPixie();
		break;

		case KEYBRDEF:
			return efKeyboard();
		break;

		case PS2GPIOEF:
			return efPs2gpio();
		break;

		case PS2EF:
			return efPs2();
		break;

		case FDCEF:
			return ef1793();
		break;

		case VT100EF:
			return vtPointer->ef();
		break;

		case MC6847EF:
			return mc6845Pointer->ef6845();
		break;

		case I8275EF:
			return i8275Pointer->ef8275();
		break;

		case ELFINEF:
			return ef4();
		break;

		case ELF2EF2:
			return cassetteEf_;
		break;

		case ELF2EF3:
			return ef3State_;
		break;

		case VTINEF:
			if (ef4State_ == 0)
				return 0;
			else
				return vtPointer->ef();
		break;

		default:
			return 1;
	}
}

Byte Elf2::ef4()
{
	return ef4State_;
}

Byte Elf2::in(Byte port, Word WXUNUSED(address))
{
	Byte ret;

	switch(inType_[port-1])
	{
		case 0:
			ret = 255;
		break;

		case PIXIEIN:
			ret = pixiePointer->inPixie();
		break;

		case I8275PREGREAD:
			ret = i8275Pointer->pRegRead();
		break;

		case I8275SREGREAD:
			ret = i8275Pointer->sRegRead();
		break;

		case KEYBRDIN:
			ret = inKeyboard();
		break;

		case PS2GPIOIN:
			ret = inPs2gpio();
		break;

		case PS2IN:
			ret = inPs2();
		break;

		case ELF2IN:
			ret = getData();
		break;

		case FDCIN:
			ret = in1793();
		break;

		case IDEIN:
			ret = inIde();
		break;

		case PORTEXTIN:
			ret = inPortExtender();
		break;

		case UARTIN:
			return vtPointer->uartIn();
		break;

		case UARTSTATUS:
			return vtPointer->uartStatus();
		break;

		default:
			ret = 255;
	}
	inValues_[port] = ret;
	return ret;
}

Byte Elf2::getData()
{
	return switches_;
}

void Elf2::out(Byte port, Word WXUNUSED(address), Byte value)
{
	outValues_[port] = value;

	switch(outType_[port-1])
	{
		case 0:
			return;
		break;

//		case RCADISKOUT:
//			psave(value);
//		break;

		case TMSHIGHOUT:
			tmsPointer->modeHighOut(value);
		break;

		case TMSLOWOUT:
			tmsPointer->modeLowOut(value);
		break;

		case PIXIEOUT:
			pixiePointer->outPixie();
		break;

		case MC6847OUT:
			mc6847Pointer->outMc6847(value);
		break;

		case I8275PREGWRITE:
			i8275Pointer->pRegWrite(value);
		break;

		case I8275CREGWRITE:
			i8275Pointer->cRegWrite(value);
		break;

		case VT100OUT:
			vtPointer->out(value);
		break;

		case PRINTEROUT:
			elfPrinterPointer->outElf(value);
		break;

		case PS2OUT:
			outPs2(value);
		break;

		case ELF2OUT:
			showData(value);
		break;

		case FDCSELECTOUT:
			selectRegister1793(value);
		break;

		case FDCWRITEOUT:
			writeRegister1793(value);
		break;

		case IDESELECTOUT:
			selectIdeRegister(value);
		break;

		case IDEWRITEOUT:
			outIde(value);
		break;

		case PORTEXTSELECTOUT:
			selectPortExtender(value);
		break;

		case PORTEXTWRITEOUT:
			outPortExtender(value);
		break;

		case UARTOUT:
			return vtPointer->uartOut(value);
		break;

		case UARTCONTROL:
			return vtPointer->uartControl(value);
		break;
	}
}
/*
void Elf2::psave(Byte value)
{
	wxFFile diskFile;
	Byte buffer_[1];

	wxString fileName = p_Main->getWaveDir(ELFII) + p_Main->getTextValue("WavFileElfII");

	if (!wxFile::Exists(fileName))
	{
		diskFile.Open(fileName, "wb+");
 		diskFile.Close();
	}
	if (!diskFile.Open(fileName, "rb+"))
	{
		return;
	}
	diskFile.Seek(offset_, wxFromStart);
	buffer_[0] = value;
	diskFile.Write(buffer_, 1);
	offset_++;
	diskFile.Close();
}*/

void Elf2::showData(Byte val)
{
	wxClientDC dc(this);

	dataPointer[0]->update(dc,(val>>4)&15);
	dataPointer[1]->update(dc, val&15);
}

void Elf2::cycle(int type)
{
	switch(cycleType_[type])
	{
		case 0:
			return;
		break;

		case KEYBRDCYCLE:
			cycleKeyboard();
		break;

		case PS2GPIOCYCLE:
			cyclePs2gpio();
		break;

		case PS2CYCLE:
			cyclePs2();
		break;

		case PIXIECYCLE:
			pixiePointer->cyclePixie();
		break;

		case TMSCYCLE:
			tmsPointer->cycleTms();
		break;

		case MC6847CYCLE:
			mc6847Pointer->cycle6847();
		break;

		case MC6845BLINK:
			mc6845Pointer->blink6845();
		break;

		case MC6845CYCLE:
			mc6845Pointer->cycle6845();
		break;

		case I8275CYCLE:
			i8275Pointer->cycle8275();
		break;

		case VT100CYCLE:
			vtPointer->cycleVt();
		break;

		case FDCCYCLE:
			cycleFdc();
		break;

		case IDECYCLE:
			cycleIde();
		break;
	}
}

void Elf2::autoBoot()
{
	runButtonPointer->SetBitmapLabel(*upBitmapPointer);
	runButtonState_ = 1;
	setClear(runButtonState_);
	if (cpuMode_ != RUN)  showTime();
}

void Elf2::updateQState()
{
	if (qLed_ != flipFlopQ_)
	{
		wxClientDC dc(this);
		qLedPointer->setStatus(dc, flipFlopQ_);
		qLed_ = flipFlopQ_;
	}
}

int Elf2::getMpButtonState()
{
	return mpButtonState_;
}

void Elf2::onRunButton(wxCommandEvent&WXUNUSED(event))
{
	onRun();
}

void Elf2::onRun()
{
	stopTape();
	if (runButtonState_)
	{
		runButtonPointer->SetBitmapLabel(*downBitmapPointer);
		runButtonState_ = 0;
	}
	else
	{
		runButtonPointer->SetBitmapLabel(*upBitmapPointer);
		runButtonState_ = 1;
		startTime_ = wxGetLocalTime();
	}
	setClear(runButtonState_);
	p_Main->updateTitle();
	if (cpuMode_ != RUN)  showTime();
}

void Elf2::onMpButton(wxCommandEvent&WXUNUSED(event))
{
	if (mpButtonState_)
	{
		mpButtonPointer->SetBitmapLabel(*downBitmapPointer);
		mpButtonState_ = 0;
	}
	else
	{
		mpButtonPointer->SetBitmapLabel(*upBitmapPointer);
		mpButtonState_ = 1;
	}
}

void Elf2::onPowerButton(wxCommandEvent&WXUNUSED(event))
{
	threadPointer->Pause();
	powerButtonPointer->SetBitmapLabel(*downBitmapPointer);
	p_Main->stopComputer();
}

void Elf2::onLoadButton(wxCommandEvent&WXUNUSED(event))
{
	if (!loadButtonState_)
	{
		loadButtonPointer->SetBitmapLabel(*downBitmapPointer);
		loadButtonState_ = 1;
	}
	else
	{
		loadButtonPointer->SetBitmapLabel(*upBitmapPointer);
		loadButtonState_ = 0;
	}
	setWait(loadButtonState_);
}

void Elf2::onNumberKeyDown(wxCommandEvent&event)
{
	int i = event.GetId();
	ef3State_ = 0;
	switches_ = ((switches_ << 4) & 0xf0) | i;
}

void Elf2::onNumberKeyUp(wxCommandEvent&WXUNUSED(event))
{
	ef3State_ = 1;
}

void Elf2::onHexKeyDown(int keycode)
{
	for (int i=0; i<16; i++)
	{
		if (keycode == hexKeyDefA_[i])
		{
			ef3State_ = 0;
			switches_ = ((switches_ << 4) & 0xf0) | i;
		}
	}
}

void Elf2::onHexKeyUp()
{
	ef3State_ = 1;
}

void Elf2::startComputer()
{
	startElfKeyFile("ElfII");
	resetPressed_ = false;

	if (elfConfiguration.usePortExtender)
		configurePortExt(ELFII);

	defineMemoryType(p_Main->getStartRam("ElfII", ELFII), p_Main->getEndRam("ElfII", ELFII), RAM);

	if (elfConfiguration.usePager)
	{
		allocPagerMemory();
		definePortExtForPager();

		defineMemoryType(0, 65535, PAGER);
	}
	if (elfConfiguration.useEms)
	{
		allocEmsMemory();
		defineMemoryType(0x8000, 0xbfff, EMSMEMORY);
	}

	p_Main->enableDebugGuiMemory();
	readProgramCombo(p_Main->getRomDir(ELFII, MAINROM), "MainRomElfII", p_Main->getLoadromMode(ELFII, 0), 0, NONAME);
	readProgramCombo(p_Main->getRomDir(ELFII, MAINROM2), "MainRom2ElfII", p_Main->getLoadromMode(ELFII, 1), 0, NONAME);

	configureElfExtensions();
	if (elfConfiguration.autoBoot)
	{
		scratchpadRegister_[0]=p_Main->getBootAddress("ElfII", ELFII);
		autoBoot();
	}

	if (elfConfiguration.vtType != VTNONE)
		setEf(4,0);

	if (elfConfiguration.usePortExtender)
		p_Main->setGuiPortExtenderValue();

	p_Main->setSwName("");
	p_Main->updateTitle();

	cpuCycles_ = 0;
	startTime_ = wxGetLocalTime();

	threadPointer->Run();
}

Byte Elf2::readMem(Word addr)
{
	address_ = addr;

	switch (memoryType_[addr/256])
	{
		case EMSMEMORY:
			switch (emsMemoryType_[((addr & 0x3fff) |(emsPage_ << 14))/256])
			{
				case UNDEFINED:
					return 255;
				break;

				case ROM:
				case RAM:
					return emsRam_[(long) ((addr & 0x3fff) |(emsPage_ << 14))];
				break;

				default:
					return 255;
				break;
			}
		break;

		case UNDEFINED:
			return 255;
		break;

		case ROM:
		case RAM:
			return mainMemory_[addr];
		break;

		case MC6847RAM:
			return mc6847Pointer->read6847(addr);
		break;

		case MC6845RAM:
			return mc6845Pointer->read6845(addr & 0x7ff);
		break;

		case MC6845REGISTERS:
			return mc6845Pointer->readData6845(addr);
		break;

		case PAGER:
			switch (pagerMemoryType_[((getPager(addr>>12) << 12) |(addr &0xfff))/256])
			{
				case UNDEFINED:
					return 255;
				break;

				case ROM:
				case RAM:
					return mainMemory_[(getPager(addr>>12) << 12) |(addr &0xfff)];
				break;

				default:
					return 255;
				break;
			}
		break;

		default:
			return 255;
		break;
	}
}

void Elf2::writeMem(Word addr, Byte value, bool writeRom)
{
	address_ = addr;

	if (emsMemoryDefined_)
	{
		if (addr>=0xc000 && addr <=0xffff)
		{
			emsPage_ = value & 0x1f;
		}
	}

	switch (memoryType_[addr/256])
	{
		case EMSMEMORY:
			switch (emsMemoryType_[((addr & 0x3fff) |(emsPage_ << 14))/256])
			{
				case UNDEFINED:
				case ROM:
					if (writeRom)
						emsRam_[(long) ((addr & 0x3fff) |(emsPage_ << 14))] = value;
				break;

				case RAM:
					if (!getMpButtonState())
						emsRam_[(long) ((addr & 0x3fff) |(emsPage_ << 14))] = value;
				break;
			}
		break;

		case MC6847RAM:
			mc6847Pointer->write(addr, value);
			mainMemory_[addr] = value;
		break;

		case MC6845RAM:
			mc6845Pointer->write6845(addr & 0x7ff, value);
		break;

		case MC6845REGISTERS:
			mc6845Pointer->writeRegister6845(addr, value);
		break;

		case UNDEFINED:
		case ROM:
			if (writeRom)
				mainMemory_[addr]=value;
		break;

		case RAM:
			if (!getMpButtonState())
				mainMemory_[addr]=value;
		break;

		case PAGER:
			switch (pagerMemoryType_[((getPager(addr>>12) << 12) |(addr &0xfff))/256])
			{
				case UNDEFINED:
				case ROM:
					if (writeRom)
						mainMemory_[(getPager(addr>>12) << 12) |(addr &0xfff)] = value;
				break;

				case RAM:
					if (!getMpButtonState())
						mainMemory_[(getPager(addr>>12) << 12) |(addr &0xfff)] = value;
				break;
			}
		break;

	}
}

void Elf2::cpuInstruction()
{
	if (debugMode_)
		p_Main->updateWindow();
	if (cpuMode_ == RUN)
	{
		if (steps_ != 0)
		{
			cycle0_=0;
			machineCycle();
			if (cycle0_ == 0) machineCycle();
			if (cycle0_ == 0 && steps_ != 0)
			{
				cpuCycle();
				cpuCycles_ += 2;
			}
		}
		else
			soundCycle();
		playSaveLoad();
		checkElfFunction();
		if (resetPressed_)
		{
			resetCpu();
			if (elfConfiguration.use8275)
				i8275Pointer->cRegWrite(0x40);
			if (elfConfiguration.autoBoot)
			{
				scratchpadRegister_[0]=p_Main->getBootAddress("ElfII", ELFII);
				autoBoot();
			}
			resetPressed_ = false;
			elfRunState_ = RESETSTATE;
			p_Main->setSwName("");
			startElfKeyFile("ElfII");
		}
		if (debugMode_)
			p_Main->cycleDebug();
		if (steps_ != 0)
			updateQState();
/*		if (elfConfiguration.vtType != VTNONE)
			vtPointer->getKey();*/
	}
	else
	{
		machineCycle();
		machineCycle();
		cpuCycles_ = 0;
		startTime_ = wxGetLocalTime();
		if (cpuMode_ == LOAD)
		{
			showData(readMem(address_));
		}
	}
}

void Elf2::configureElfExtensions()
{
	wxString fileName, fileName2;

	if (elfConfiguration.usePixie)
	{
		int zoom = p_Main->getSpinValue("ZoomElfII");
		pixiePointer = new Pixie( "Elf II - Pixie", p_Main->getPixiePos(ELFII), wxSize(192*zoom, 128*zoom), zoom, ELFII);
		p_Video = pixiePointer;
		pixiePointer->setZoom(zoom);
		pixiePointer->configurePixie();
		pixiePointer->initPixie();
		pixiePointer->Show(true);
	}

	if (elfConfiguration.use6845)
	{
		int zoom = p_Main->getSpinValue("ZoomElfII");
		mc6845Pointer = new MC6845( "Elf II - MC6845", p_Main->get6845Pos(ELFII), wxSize(64*8*zoom, 16*8*2*zoom), zoom, ELFII, elfClockSpeed_, 8);
		p_Video = mc6845Pointer;
		mc6845Pointer->configure6845();
		mc6845Pointer->init6845();
		mc6845Pointer->Show(true);
	}

	if (elfConfiguration.useS100)
	{
		int zoom = p_Main->getSpinValue("ZoomElfII");
		mc6845Pointer = new MC6845( "Elf II - Quest Super Video", p_Main->get6845Pos(ELFII), wxSize(64*7*zoom, 16*9*zoom), zoom, ELFII, elfClockSpeed_, 7);
		p_Video = mc6845Pointer;
		mc6845Pointer->configureSuperVideo();
		mc6845Pointer->init6845();
		mc6845Pointer->Show(true);
	}

	if (elfConfiguration.use8275)
	{
		int zoom = p_Main->getSpinValue("ZoomElfII");
		i8275Pointer = new i8275( "Elf II - Intel 8275", p_Main->get8275Pos(ELFII), wxSize(80*8*zoom, 24*10*2*zoom), zoom, ELFII, elfClockSpeed_);
		p_Video = i8275Pointer;
		i8275Pointer->configure8275();
		i8275Pointer->init8275();
		i8275Pointer->Show(true);
	}

	if (elfConfiguration.use6847)
	{
		int zoom = p_Main->getSpinValue("ZoomElfII");
		mc6847Pointer = new mc6847( "Elf II - MC6847", p_Main->get6847Pos(ELFII), wxSize(elfConfiguration.charLine*8*zoom, elfConfiguration.screenHeight6847*zoom), zoom, ELFII, elfClockSpeed_);
		p_Video = mc6847Pointer;
		mc6847Pointer->configure();
		mc6847Pointer->init6847();
		mc6847Pointer->Show(true);
	}

	if (elfConfiguration.useTMS9918)
	{
		int zoom = p_Main->getSpinValue("ZoomElfII");
		tmsPointer = new Tms9918( "Elf II - TMS 9918", p_Main->getTmsPos(ELFII), wxSize((256+(BACKX*2))*zoom,(192+(BACKY*2))*zoom), zoom, ELFII, elfClockSpeed_);
		p_Video = tmsPointer;
		tmsPointer->configure();
		tmsPointer->Show(true);
	}

	if (elfConfiguration.fdcEnabled)
	{
		configure1793(1, 40, 18, 256, ELFII);
		resetFdc();
	}

	if (elfConfiguration.ideEnabled)
	{
		fileName = p_Main->getIdeDir(ELFII);
		fileName2 = fileName;

		fileName.operator += (p_Main->getTextValue("IdeFileElfII"));
		fileName2.operator += ("disk2.ide");

		configureIde(fileName, fileName2);
	}

	if (elfConfiguration.usePrinter)
	{
		elfPrinterPointer = new Printer();
		elfPrinterPointer->configureElfPrinter();
	}

	if (elfConfiguration.vtType != VTNONE)
	{
		int zoom = p_Main->getSpinValue("ZoomElfII");
		vtPointer = new Vt100("Elf II - VT 100", p_Main->getVtPos(ELFII), wxSize(800*zoom, 500*zoom), zoom, ELFII, elfClockSpeed_, elfConfiguration.vtType);
		p_Vt100 = vtPointer;
		vtPointer->configure(elfConfiguration.baudR, elfConfiguration.baudT);
		vtPointer->Show(true);
		vtPointer->drawScreen();
		setSoundFollowQ (false);
	}
	else
		setSoundFollowQ (true);

	if (elfConfiguration.useKeyboard)
		configureKeyboard(ELFII);

	if (elfConfiguration.UsePS2)
		configurePs2(elfConfiguration.ps2Interrupt);
}

void Elf2::tmsAndPixieZoom(int zoom)
{
	if (elfConfiguration.useTMS9918)
	{
		tmsPointer->setZoom(zoom);
		tmsPointer->reDrawScreen();
	}
	if (elfConfiguration.usePixie)
	{
		pixiePointer->setZoom(zoom);
		pixiePointer->reDrawScreen();
	}
	if (elfConfiguration.use6845||elfConfiguration.useS100)
	{
		mc6845Pointer->setZoom(zoom);
		mc6845Pointer->copyScreen();
	}
	if (elfConfiguration.use6847)
	{
		mc6847Pointer->setZoom(zoom);
		mc6847Pointer->copyScreen();
	}
	if (elfConfiguration.use8275)
	{
		i8275Pointer->setZoom(zoom);
		i8275Pointer->copyScreen();
	}
	if (elfConfiguration.vtType != VTNONE)
	{
		vtPointer->setZoom(zoom);
		vtPointer->copyScreen();
	}
}

void Elf2::moveWindows()
{
	if (elfConfiguration.usePixie)
		pixiePointer->Move(p_Main->getPixiePos(ELFII));
	if (elfConfiguration.useTMS9918)
		tmsPointer->Move(p_Main->getTmsPos(ELFII));
	if (elfConfiguration.use6845||elfConfiguration.useS100)
		mc6845Pointer->Move(p_Main->get6845Pos(ELFII));
	if (elfConfiguration.use6847)
		mc6847Pointer->Move(p_Main->get6847Pos(ELFII));
	if (elfConfiguration.use8275)
		i8275Pointer->Move(p_Main->get8275Pos(ELFII));
	if (elfConfiguration.vtType != VTNONE)
		vtPointer->Move(p_Main->getVtPos(ELFII));
}

void Elf2::updateTitle(wxString Title)
{
	if (elfConfiguration.usePixie)
		pixiePointer->SetTitle("Elf II - Pixie"+Title);
	if (elfConfiguration.useTMS9918)
		tmsPointer->SetTitle("Elf II - TMS 9918"+Title);
	if (elfConfiguration.use6845)
		mc6845Pointer->SetTitle("Elf II - MC6845"+Title);
	if (elfConfiguration.useS100)
		mc6845Pointer->SetTitle("Elf II - Quest Super Video"+Title);
	if (elfConfiguration.use6847)
		mc6847Pointer->SetTitle("Elf II - MC6847"+Title);
	if (elfConfiguration.use8275)
		i8275Pointer->SetTitle("Elf II - Intel 8275"+Title);
	if (elfConfiguration.vtType != VTNONE)
		vtPointer->SetTitle("Elf II - VT 100"+Title);
}

void Elf2::setForceUpperCase(bool status)
{
	if (elfConfiguration.vtType != VTNONE)
		vtPointer->setForceUCVt(status);
	if (elfConfiguration.useKeyboard)
		setForceUpperCaseKeyboard(status);
}

void Elf2::onReset()
{
	resetPressed_ = true;
}

Byte Elf2::read6845CharRom(Word addr)
{
	if (elfConfiguration.use6845||elfConfiguration.useS100)
		return mc6845Pointer->read6845CharRom(addr);
	else
		return 0;
}

void Elf2::write6845CharRom(Word addr, Byte value)
{
	if (elfConfiguration.use6845||elfConfiguration.useS100)
		mc6845Pointer->write6845CharRom(addr, value);
}

Byte Elf2::read8275CharRom(Word addr)
{
	if (elfConfiguration.use8275)
		return i8275Pointer->read8275CharRom(addr);
	else
		return 0;
}

void Elf2::write8275CharRom(Word addr, Byte value)
{
	if (elfConfiguration.use8275)
		i8275Pointer->write8275CharRom(addr, value);
}

Byte Elf2::read6847CharRom(Word addr)
{
	if (elfConfiguration.use6847)
		return mc6847Pointer->read6847CharRom(addr);
	else
		return 0;
}

void Elf2::write6847CharRom(Word addr, Byte value)
{
	if (elfConfiguration.use6847)
		mc6847Pointer->write6847CharRom(addr, value);
}

int Elf2::readDirect6847(Word addr)
{
	if (elfConfiguration.use6847)
		return mc6847Pointer->readDirect6847(addr); 
	else
		return 0;
}

void Elf2::writeDirect6847(Word addr, int value)
{
	if (elfConfiguration.use6847)
		mc6847Pointer->writeDirect6847(addr, value); 
}

Word Elf2::get6847RamMask()
{
 	if (elfConfiguration.use6847)
		return mc6847Pointer->get6847RamMask();
	else
		return 0;
}

long Elf2::getVideoSyncCount()
{
	if (elfConfiguration.use8275)
		return i8275Pointer->getVideoSyncCount();
	else
		return 0;
}

void *RunElf2::Entry()
{
	while(!TestDestroy())
	{
		p_Computer->cpuInstruction();
	}
	return NULL;
}
