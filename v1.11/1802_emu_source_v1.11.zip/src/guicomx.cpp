/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"
#include "wx/tglbtn.h"

#include "main.h"
#include "guicomx.h"
#include "printer.h"

DEFINE_EVENT_TYPE(STATUS_LED_ON)
DEFINE_EVENT_TYPE(STATUS_LED_OFF)
DEFINE_EVENT_TYPE(EXP_LED_ON)
DEFINE_EVENT_TYPE(EXP_LED_OFF)
DEFINE_EVENT_TYPE(STATUS_BAR_1870)
DEFINE_EVENT_TYPE(STATUS_BAR_6845)

BEGIN_EVENT_TABLE(GuiComx, GuiElf)

	EVT_BUTTON(XRCID("RomButtonComx"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("ExpRomButtonComx"), GuiComx::onExpansionRom)
	EVT_BUTTON(XRCID("Cart1RomButtonComx"), GuiComx::onCard1Rom)
	EVT_BUTTON(XRCID("Cart2RomButtonComx"), GuiComx::onCard2Rom)
	EVT_BUTTON(XRCID("Cart3RomButtonComx"), GuiComx::onCard3Rom)
	EVT_BUTTON(XRCID("Cart4RomButtonComx"), GuiComx::onCard4Rom)
	EVT_BUTTON(XRCID("Disk1ButtonComx"), GuiComx::onComxDisk1)
	EVT_TEXT(XRCID("Disk1FileComx"), GuiComx::onComxDiskText1)
	EVT_BUTTON(XRCID("EjectDisk1Comx"), GuiComx::onComxDiskEject1)
	EVT_BUTTON(XRCID("Disk2ButtonComx"), GuiComx::onComxDisk2)
	EVT_TEXT(XRCID("Disk2FileComx"), GuiComx::onComxDiskText2)
	EVT_BUTTON(XRCID("EjectDisk2Comx"), GuiComx::onComxDiskEject2)
	EVT_BUTTON(XRCID("PrintFileButtonComx"), GuiMain::onPrintFile)
	EVT_TEXT(XRCID("PrintFileComx"), GuiComx::onPrintFileText)
	EVT_CHOICE(XRCID("PrintModeComx"), GuiComx::onPrintMode)
	EVT_BUTTON(XRCID("PrintButtonComx"), GuiComx::onPrintButton)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonComx"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Comx"), GuiMain::onScreenDump)
	EVT_BUTTON(XRCID("CasButtonComx"), GuiMain::onCassette)
	EVT_BUTTON(XRCID("EjectCasComx"), GuiMain::onCassetteEject)
	EVT_BUTTON(XRCID("KeyFileButtonComx"), GuiMain::onKeyFile)
	EVT_BUTTON(XRCID("EjectKeyFileComx"), GuiMain::onKeyFileEject)
	EVT_CHOICE(XRCID("VidModeComx"), GuiComx::onComxVideoMode)
	EVT_SPINCTRL(XRCID("ZoomComx"), GuiMain::onZoom)
	EVT_BUTTON(XRCID("FullScreenF3Comx"), GuiMain::onFullScreen)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeComx"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeComx"), GuiMain::onVolume)
	EVT_CHECKBOX(XRCID("InterlaceComx"), GuiMain::onInterlace)
	EVT_CHECKBOX(XRCID("ExpRamComx"), GuiComx::onComxExpansionRam)
	EVT_SPINCTRL(XRCID("ExpRamSlotComx"), GuiComx::onComxExpansionRamSlot)
	EVT_CHECKBOX(XRCID("UseLocationComx"), GuiMain::onUseLocation)
	EVT_BUTTON(XRCID("SaveButtonComx"), GuiMain::onSaveButton)
	EVT_BUTTON(XRCID("LoadButtonComx"), GuiMain::onLoadButton)
	EVT_BUTTON(XRCID("RunButtonComx"), GuiMain::onPloadRun)
	EVT_BUTTON(XRCID("DsaveButtonComx"), GuiMain::onDsave)
	EVT_CHECKBOX(XRCID("TurboComx"), GuiMain::onTurbo)
	EVT_TEXT(XRCID("TurboClockComx"), GuiMain::onTurboClock)
	EVT_CHECKBOX(XRCID("AutoCasLoadComx"), GuiMain::onAutoLoad)
	EVT_BUTTON(XRCID("CasLoadComx"), GuiMain::onCassetteLoad)
	EVT_BUTTON(XRCID("CasSaveComx"), GuiMain::onCassetteSave)
	EVT_BUTTON(XRCID("CasStopComx"), GuiMain::onCassetteStop)
	EVT_BUTTON(XRCID("RealCasLoadComx"), GuiMain::onRealCas)
	EVT_TOGGLEBUTTON(XRCID("ComxWavFile"), GuiMain::onWavFile)
	EVT_TEXT(XRCID(_T("ClockComx")), GuiMain::onClock)
	EVT_BUTTON(XRCID(_T("ColoursComx")), Main::onColoursDef)

	EVT_COMMAND(wxID_ANY, OPEN_PRINTER_WINDOW, GuiComx::openPrinterFrame)
	EVT_COMMAND(wxID_ANY, STATUS_LED_ON, GuiComx::statusLedOn)
	EVT_COMMAND(wxID_ANY, STATUS_LED_OFF, GuiComx::statusLedOff)
	EVT_COMMAND(wxID_ANY, STATUS_BAR_1870, GuiComx::v1870BarSize)
	EVT_COMMAND(wxID_ANY, STATUS_BAR_6845, GuiComx::mc6845BarSize)
	EVT_COMMAND(wxID_ANY, EXP_LED_ON, GuiComx::expLedOn)
	EVT_COMMAND(wxID_ANY, EXP_LED_OFF, GuiComx::expLedOff)

	END_EVENT_TABLE()

GuiComx::GuiComx(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiElf(title, pos, size)
{
	conf[COMX].loadFileNameFull_ = "";
	conf[COMX].loadFileName_ = "";

	conf[COMX].pLoadSaveName_[0] = 'C';
	conf[COMX].pLoadSaveName_[1] = 'O';
	conf[COMX].pLoadSaveName_[2] = 'M';
	conf[COMX].pLoadSaveName_[3] = 'X';

	conf[COMX].defus_ = 0x4281;
	conf[COMX].eop_ = 0x4283;
	conf[COMX].string_ = 0x4292;
	conf[COMX].arrayValue_ = 0x4294;
	conf[COMX].eod_ = 0x4299;
	conf[COMX].basicRamAddress_ = 0x4400;
}

GuiComx::~GuiComx()
{
}

void GuiComx::readComxConfig()
{
	bool turbo, interlace ;
	selectedComputer_ = COMX;

	conf[COMX].romDir_[MAINROM] = configPointer->Read(_T("/Comx/ComxRomDir"), dataDir_ + "Comx" + pathSeparator_);
	conf[COMX].romDir_[EXPROM] = configPointer->Read(_T("/Comx/ComxExpRomDir"), dataDir_ + "Comx" + pathSeparator_);
	conf[COMX].romDir_[CARTROM1] = configPointer->Read(_T("/Comx/ComxCardDir1"), dataDir_ + "Comx" + pathSeparator_);
	conf[COMX].romDir_[CARTROM2] = configPointer->Read(_T("/Comx/ComxCardDir2"), dataDir_ + "Comx" + pathSeparator_);
	conf[COMX].romDir_[CARTROM3] = configPointer->Read(_T("/Comx/ComxCardDir3"), dataDir_ + "Comx" + pathSeparator_);
	conf[COMX].romDir_[CARTROM4] = configPointer->Read(_T("/Comx/ComxCardDir4"), dataDir_ + "Comx" + pathSeparator_);
	conf[COMX].keyFileDir_ = configPointer->Read(_T("/Comx/ComxKeyFileDir"), dataDir_ + "Comx" + pathSeparator_);
	Pl80Data_[0] = configPointer->Read(_T("/Comx/PL80RomDir"), dataDir_ + "Comx" + pathSeparator_);
	Pl80Data_[1] = configPointer->Read(_T("/Comx/PL80Rom"), "pl80.bin");
	Pl80Data_[2] = configPointer->Read(_T("/Comx/PL80Extension"), "pl80.it.em.ou.bin");
	floppyDir_[0] = configPointer->Read(_T("/Comx/FloppyDir"), dataDir_ + "Comx" + pathSeparator_ + "Disks" + pathSeparator_);
	floppyDir_[1] = configPointer->Read(_T("/Comx/FloppyDir2"), dataDir_ + "Comx" + pathSeparator_ + "Disks" + pathSeparator_);
	conf[COMX].ramDir_ = configPointer->Read(_T("/Comx/ComxSWDir"), dataDir_ + "Comx" + pathSeparator_);
	conf[COMX].screenDumpFileDir_ = configPointer->Read(_T("/Comx/ComxScreenDumpFileDir"), dataDir_ + "Comx" + pathSeparator_);
	conf[COMX].wavFileDir_ = configPointer->Read(_T("/Comx/WavFileDir"), dataDir_ + "Comx" + pathSeparator_);
	comxPalClock_ = configPointer->Read(_T("/Comx/PalClock"), "2.813");
	comxNtscClock_ = configPointer->Read(_T("/Comx/NtscClock"), "2.835");

	conf[COMX].turboClock_ = configPointer->Read(_T("/Comx/TurboClock"), "15");
	XRCCTRL(*this, "TurboClockComx", wxTextCtrl)->SetValue(conf[COMX].turboClock_);
	conf[COMX].volume_ = configPointer->Read(_T("/Comx/ComxVolume"), 25l);
	XRCCTRL(*this, "VolumeComx", wxSlider)->SetValue(conf[COMX].volume_);
	XRCCTRL(*this, "MainRomComx", wxComboBox)->SetValue(configPointer->Read(_T("/Comx/ComxMainRom"), "comx35.1.1.bin"));
	XRCCTRL(*this, "ExpRomComx", wxComboBox)->SetValue(configPointer->Read(_T("/Comx/ComxExtRom"), "f&m.expansion.3.1.bin"));
	XRCCTRL(*this, "Cart1RomComx", wxComboBox)->SetValue(configPointer->Read(_T("/Comx/ComxCart1Rom"), "fdc.bin"));
	XRCCTRL(*this, "Cart2RomComx", wxComboBox)->SetValue(configPointer->Read(_T("/Comx/ComxCart2Rom"), "f&m.joycard.bin"));
	XRCCTRL(*this, "Cart3RomComx", wxComboBox)->SetValue(configPointer->Read(_T("/Comx/ComxCart3Rom"), "f&m.printer.1.2.bin"));
	XRCCTRL(*this, "Cart4RomComx", wxComboBox)->SetValue(configPointer->Read(_T("/Comx/ComxCart4Rom"), "80column.1.1.bin"));
	XRCCTRL(*this, "Disk1FileComx", wxTextCtrl)->SetValue(configPointer->Read(_T("/Comx/ComxDisk1File"), "dos.1.4+f&m.disk.tools.img"));
	XRCCTRL(*this, "Disk2FileComx", wxTextCtrl)->SetValue(configPointer->Read(_T("/Comx/ComxDisk2File"), "f&m-heijmans.sw.img"));
	XRCCTRL(*this, "KeyFileComx", wxTextCtrl)->SetValue(configPointer->Read(_T("/Comx/ComxKeyFile"), ""));
	XRCCTRL(*this, "PrintFileComx", wxTextCtrl)->SetValue(configPointer->Read(_T("/Comx/ComxPrintFile"), "printerout.txt"));
	conf[COMX].printFileDir_ = configPointer->Read(_T("/Comx/PrintFileDir"), dataDir_ + "Comx" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileComx", wxTextCtrl)->SetValue(configPointer->Read(_T("/Comx/ComxScreenDumpFile"), "screendump.bmp"));
	configPointer->Read(_T("/Comx/Turbo"), &turbo, true);
	XRCCTRL(*this, "TurboComx", wxCheckBox)->SetValue(turbo);
	turboGui("Comx");
	configPointer->Read(_T("/Comx/AutoCasLoad"), &conf[COMX].autoCassetteLoad_, true);
	XRCCTRL(*this, "AutoCasLoadComx", wxCheckBox)->SetValue(conf[COMX].autoCassetteLoad_);

	configPointer->Read(_T("/Comx/RealCasLoad"), &conf[COMX].realCassetteLoad_, false);
	setRealCas(COMX);

	configPointer->Read(_T("/Comx/Comx80Interlace"), &interlace, true);
	XRCCTRL(*this, "InterlaceComx", wxCheckBox)->SetValue(interlace);

	configPointer->Read(_T("/Comx/ComxExpRam"), &useExpansionRam_, false);
	XRCCTRL(*this, "ExpRamComx", wxCheckBox)->SetValue(useExpansionRam_);
	XRCCTRL(*this, "ExpRamSlotComx", wxSpinCtrl)->SetValue(configPointer->Read(_T("/Comx/ComxExpRamSlot"), 4l));
	expansionRamSlot_ = XRCCTRL(*this, "ExpRamSlotComx", wxSpinCtrl)->GetValue();

	configPointer->Read(_T("/Comx/ExpBox"), &expansionRomLoaded_, true);
	XRCCTRL(*this, "Cart2RomButtonComx", wxButton)->Enable(expansionRomLoaded_ );
	XRCCTRL(*this, "Cart2RomComx", wxComboBox)->Enable(expansionRomLoaded_ );
	XRCCTRL(*this, "Cart3RomButtonComx", wxButton)->Enable(expansionRomLoaded_ );
	XRCCTRL(*this, "Cart3RomComx", wxComboBox)->Enable(expansionRomLoaded_ );
	XRCCTRL(*this, "Cart4RomButtonComx", wxButton)->Enable(expansionRomLoaded_ );
	XRCCTRL(*this, "Cart4RomComx", wxComboBox)->Enable(expansionRomLoaded_ );

	XRCCTRL(*this, "ExpRamSlotComx", wxSpinCtrl)->Enable(useExpansionRam_);
	if (useExpansionRam_)
		setComxExpRamSlot();
	configPointer->Read(_T("/Comx/diskRomLoaded_"), &diskRomLoaded_, true);
	XRCCTRL(*this, "Disk1ButtonComx", wxButton)->Enable(diskRomLoaded_);
	XRCCTRL(*this, "Disk1FileComx", wxTextCtrl)->Enable(diskRomLoaded_);
	XRCCTRL(*this, "EjectDisk1Comx", wxButton)->Enable(diskRomLoaded_ );
	XRCCTRL(*this, "Disk2ButtonComx", wxButton)->Enable(diskRomLoaded_);
	XRCCTRL(*this, "Disk2FileComx", wxTextCtrl)->Enable(diskRomLoaded_);
	XRCCTRL(*this, "EjectDisk2Comx", wxButton)->Enable(diskRomLoaded_ );
	XRCCTRL(*this, "WavFileComx", wxTextCtrl)->SetValue(configPointer->Read(_T("/Comx/WavFile"), ""));
	XRCCTRL(*this, "VidModeComx", wxChoice)->SetSelection(configPointer->Read(_T("/Comx/ComxVidMode"), 0l));
	if (XRCCTRL(*this, "VidModeComx", wxChoice)->GetSelection() == PAL)
		XRCCTRL(*this, _T("ClockComx"), wxTextCtrl)->ChangeValue(comxPalClock_);
	else
		XRCCTRL(*this, _T("ClockComx"), wxTextCtrl)->ChangeValue(comxNtscClock_);

	XRCCTRL(*this, "ZoomComx", wxSpinCtrl)->SetValue(configPointer->Read(_T("/Comx/1870Zoom"), 2l));
	XRCCTRL(*this, "PrintModeComx", wxChoice)->SetSelection(configPointer->Read(_T("/Comx/ComxPrintMode"), 1l));
	comxPrintMode_ = configPointer->Read(_T("/Comx/ComxPrintMode"), 1l);
	setComxPrintMode();

	conf[COMX].mainX_ = configPointer->Read(_T("/Comx/ComxX"), mainWindowX_+windowInfo.mainwX);
	conf[COMX].mainY_ = configPointer->Read(_T("/Comx/ComxY"), mainWindowY_);
	conf[COMX].mc6845X_ = configPointer->Read(_T("/Comx/Comx6845X"), mainWindowX_);
	conf[COMX].mc6845Y_ = configPointer->Read(_T("/Comx/Comx6845Y"), mainWindowY_+windowInfo.mainwY);
	XRCCTRL(*this, "UseLocationComx", wxCheckBox)->SetValue(false);
	conf[COMX].useLoadLocation_ = false;
}

void GuiComx::writeComxConfig()
{
	if (useExpansionRam_)
		resetCardText();

	configPointer->Write(_T("/Comx/ComxRomDir"), conf[COMX].romDir_[MAINROM]);
	configPointer->Write(_T("/Comx/ComxExpRomDir"), conf[COMX].romDir_[EXPROM]);
	configPointer->Write(_T("/Comx/ComxCardDir1"), conf[COMX].romDir_[CARTROM1]);
	configPointer->Write(_T("/Comx/ComxCardDir2"), conf[COMX].romDir_[CARTROM2]);
	configPointer->Write(_T("/Comx/ComxCardDir3"), conf[COMX].romDir_[CARTROM3]);
	configPointer->Write(_T("/Comx/ComxCardDir4"), conf[COMX].romDir_[CARTROM4]);
	configPointer->Write(_T("/Comx/ComxKeyFileDir"), conf[COMX].keyFileDir_);
	configPointer->Write(_T("/Comx/PL80RomDir"), Pl80Data_[0]);
	configPointer->Write(_T("/Comx/PL80Rom"), Pl80Data_[1]);
	configPointer->Write(_T("/Comx/PL80Extension"), Pl80Data_[2]);
	configPointer->Write(_T("/Comx/FloppyDir"), floppyDir_[0]);
	configPointer->Write(_T("/Comx/FloppyDir2"), floppyDir_[1]);
	configPointer->Write(_T("/Comx/ComxSWDir"), conf[COMX].ramDir_);
	configPointer->Write(_T("/Comx/ComxScreenDumpFileDir"), conf[COMX].screenDumpFileDir_);
	configPointer->Write(_T("/Comx/WavFileDir"), conf[COMX].wavFileDir_);
	configPointer->Write(_T("/Comx/PalClock"), comxPalClock_);
	configPointer->Write(_T("/Comx/NtscClock"), comxNtscClock_);
	configPointer->Write(_T("/Comx/TurboClock"), conf[COMX].turboClock_);
	configPointer->Write(_T("/Comx/ComxVolume"), XRCCTRL(*this, "VolumeComx", wxSlider)->GetValue());
	configPointer->Write(_T("/Comx/ComxMainRom"), XRCCTRL(*this, "MainRomComx", wxComboBox)->GetValue());
	configPointer->Write(_T("/Comx/ComxExtRom"), XRCCTRL(*this, "ExpRomComx", wxComboBox)->GetValue());
	configPointer->Write(_T("/Comx/ComxCart1Rom"), XRCCTRL(*this, "Cart1RomComx", wxComboBox)->GetValue());
	configPointer->Write(_T("/Comx/ComxCart2Rom"), XRCCTRL(*this, "Cart2RomComx", wxComboBox)->GetValue());
	configPointer->Write(_T("/Comx/ComxCart3Rom"), XRCCTRL(*this, "Cart3RomComx", wxComboBox)->GetValue());
	configPointer->Write(_T("/Comx/ComxCart4Rom"), XRCCTRL(*this, "Cart4RomComx", wxComboBox)->GetValue());
	configPointer->Write(_T("/Comx/ComxDisk1File"), XRCCTRL(*this, "Disk1FileComx", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Comx/ComxDisk2File"), XRCCTRL(*this, "Disk2FileComx", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Comx/ComxScreenDumpFile"), XRCCTRL(*this, "ScreenDumpFileComx", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Comx/ComxPrintFile"), XRCCTRL(*this, "PrintFileComx", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Comx/ComxKeyFile"), XRCCTRL(*this, "KeyFileComx", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Comx/PrintFileDir"), conf[COMX].printFileDir_);
	configPointer->Write(_T("/Comx/WavFile"), XRCCTRL(*this, "WavFileComx", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Comx/Turbo"), XRCCTRL(*this, "TurboComx", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Comx/ComxVidMode"), XRCCTRL(*this, "VidModeComx", wxChoice)->GetSelection());
	configPointer->Write(_T("/Comx/1870Zoom"), XRCCTRL(*this, "ZoomComx", wxSpinCtrl)->GetValue());
	configPointer->Write(_T("/Comx/AutoCasLoad"), XRCCTRL(*this, "AutoCasLoadComx", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Comx/RealCasLoad"), conf[COMX].realCassetteLoad_);
	configPointer->Write(_T("/Comx/Comx80Interlace"), XRCCTRL(*this, "InterlaceComx", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Comx/ComxExpRam"), XRCCTRL(*this, "ExpRamComx", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Comx/ComxExpRamSlot"), XRCCTRL(*this, "ExpRamSlotComx", wxSpinCtrl)->GetValue());
	configPointer->Write(_T("/Comx/ExpBox"), expansionRomLoaded_);
	configPointer->Write(_T("/Comx/diskRomLoaded_"), diskRomLoaded_);

	configPointer->Write(_T("/Comx/ComxPrintMode"), comxPrintMode_);

	if (conf[COMX].mainX_ > 0)
		configPointer->Write(_T("/Comx/ComxX"), conf[COMX].mainX_);
	if (conf[COMX].mainY_ > 0)
		configPointer->Write(_T("/Comx/ComxY"), conf[COMX].mainY_);
	if (conf[COMX].mc6845X_ > 0)
		configPointer->Write(_T("/Comx/Comx6845X"), conf[COMX].mc6845X_);
	if (conf[COMX].mc6845Y_ > 0)
		configPointer->Write(_T("/Comx/Comx6845Y"), conf[COMX].mc6845Y_);
}

void GuiComx::onExpansionRom(wxCommandEvent& WXUNUSED(event) )
{
	wxString fileName;

	fileName = wxFileSelector( _T("Select the Expansion ROM file to load"),
                               conf[COMX].romDir_[EXPROM], XRCCTRL(*this, "ExpRomComx", wxComboBox)->GetValue(),
                               "",
                               wxString::Format
                              (
                                    _T("Binary File|*.bin;*.rom;*.ram;*.cos|Intel Hex File|*.hex|All files (%s)|%s"),
                                    wxFileSelectorDefaultWildcardStr,
                                    wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_OPEN|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );
	if (!fileName)
	{
		expansionRomLoaded_ = false;
		XRCCTRL(*this, "Cart2RomButtonComx", wxButton)->Enable(false);
		XRCCTRL(*this, "Cart2RomComx", wxComboBox)->Enable(false);
		XRCCTRL(*this, "Cart3RomButtonComx", wxButton)->Enable(false);
		XRCCTRL(*this, "Cart3RomComx", wxComboBox)->Enable(false);
		XRCCTRL(*this, "Cart4RomButtonComx", wxButton)->Enable(false);
		XRCCTRL(*this, "Cart4RomComx", wxComboBox)->Enable(false);
		return;
	}

	expansionRomLoaded_ = true;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	conf[COMX].romDir_[EXPROM] = FullPath.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);

	XRCCTRL(*this, "ExpRomComx", wxComboBox)->SetValue(FullPath.GetFullName());
	if ((expansionRamSlot_ != 2) || !useExpansionRam_)
	{
		XRCCTRL(*this, "Cart2RomButtonComx", wxButton)->Enable(true);
		XRCCTRL(*this, "Cart2RomComx", wxComboBox)->Enable(true);
	}
	if ((expansionRamSlot_ != 3) || !useExpansionRam_)
	{
		XRCCTRL(*this, "Cart3RomButtonComx", wxButton)->Enable(true);
		XRCCTRL(*this, "Cart3RomComx", wxComboBox)->Enable(true);
	}
	if ((expansionRamSlot_ != 4) || !useExpansionRam_)
	{
		XRCCTRL(*this, "Cart4RomButtonComx", wxButton)->Enable(true);
		XRCCTRL(*this, "Cart4RomComx", wxComboBox)->Enable(true);
	}
}

void GuiComx::onCard1Rom(wxCommandEvent& WXUNUSED(event) )
{
	wxString fileName;

	fileName = wxFileSelector( _T("Select the Cartridge 1 ROM file to load"),
                               conf[COMX].romDir_[CARTROM1], XRCCTRL(*this, "Cart1RomComx", wxComboBox)->GetValue(),
                               "",
                               wxString::Format
                              (
                                    _T("Binary File|*.bin;*.rom;*.ram;*.cos|Intel Hex File|*.hex|All files (%s)|%s"),
                                    wxFileSelectorDefaultWildcardStr,
                                    wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_OPEN|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );
	if (!fileName)
		return;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	conf[COMX].romDir_[CARTROM1] = FullPath.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);

	XRCCTRL(*this, "Cart1RomComx", wxComboBox)->SetValue(FullPath.GetFullName());
}

void GuiComx::onCard2Rom(wxCommandEvent& WXUNUSED(event) )
{
	wxString fileName;

	fileName = wxFileSelector( _T("Select the Cartridge 2 ROM file to load"),
                               conf[COMX].romDir_[CARTROM2], XRCCTRL(*this, "Cart2RomComx", wxComboBox)->GetValue(),
                               "",
                               wxString::Format
                              (
                                    _T("Binary File|*.bin;*.rom;*.ram;*.cos|Intel Hex File|*.hex|All files (%s)|%s"),
                                    wxFileSelectorDefaultWildcardStr,
                                    wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_OPEN|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );
	if (!fileName)
		return;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	conf[COMX].romDir_[CARTROM2] = FullPath.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);

	XRCCTRL(*this, "Cart2RomComx", wxComboBox)->SetValue(FullPath.GetFullName());
}

void GuiComx::onCard3Rom(wxCommandEvent& WXUNUSED(event) )
{
	wxString fileName;

	fileName = wxFileSelector( _T("Select the Cartridge 3 ROM file to load"),
                               conf[COMX].romDir_[CARTROM3], XRCCTRL(*this, "Cart3RomComx", wxComboBox)->GetValue(),
                               "",
                               wxString::Format
                              (
                                    _T("Binary File|*.bin;*.rom;*.ram;*.cos|Intel Hex File|*.hex|All files (%s)|%s"),
                                    wxFileSelectorDefaultWildcardStr,
                                    wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_OPEN|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );
	if (!fileName)
		return;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	conf[COMX].romDir_[CARTROM3] = FullPath.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);

	XRCCTRL(*this, "Cart3RomComx", wxComboBox)->SetValue(FullPath.GetFullName());
}

void GuiComx::onCard4Rom(wxCommandEvent& WXUNUSED(event) )
{
	wxString fileName;

	fileName = wxFileSelector( _T("Select the Cartridge 4 ROM file to load"),
                               conf[COMX].romDir_[CARTROM4], XRCCTRL(*this, "Cart4RomComx", wxComboBox)->GetValue(),
                               "",
                               wxString::Format
                              (
                                    _T("Binary File|*.bin;*.rom;*.ram;*.cos|Intel Hex File|*.hex|All files (%s)|%s"),
                                    wxFileSelectorDefaultWildcardStr,
                                    wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_OPEN|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );
	if (!fileName)
		return;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	conf[COMX].romDir_[CARTROM4] = FullPath.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);

	XRCCTRL(*this, "Cart4RomComx", wxComboBox)->SetValue(FullPath.GetFullName());
}

void GuiComx::onComxDisk1(wxCommandEvent& WXUNUSED(event) )
{
	wxString fileName;

	fileName = wxFileSelector( _T("Select the Disk 1 file to load"),
                               floppyDir_[0], XRCCTRL(*this, "Disk1FileComx", wxTextCtrl)->GetValue(),
                               "img",
                               wxString::Format
                              (
                                    _T("Disk Image (*.img)|*.img|All files (%s)|%s"),
                                    wxFileSelectorDefaultWildcardStr,
                                    wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_OPEN|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );
	if (!fileName)
		return;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	floppyDir_[0] = FullPath.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);

	XRCCTRL(*this, "Disk1FileComx", wxTextCtrl)->SetValue(FullPath.GetFullName());
}

void GuiComx::onComxDiskText1(wxCommandEvent&WXUNUSED(event))
{
	wxString diskFile;

	if ((runningComputer_ == COMX) && diskRomLoaded_)
	{
		diskFile = XRCCTRL(*this, "Disk1FileComx", wxTextCtrl)->GetValue();
		if (diskFile.Len() == 0)
		{
			p_Comx->setDiskName(1, "");
		}
		else
		{
			diskFile = floppyDir_[0];
			diskFile.operator += (XRCCTRL(*this, "Disk1FileComx", wxTextCtrl)->GetValue());
			p_Comx->setDiskName(1, diskFile);
		}
	}
}

void GuiComx::onComxDiskEject1(wxCommandEvent& WXUNUSED(event) )
{
	XRCCTRL(*this, "Disk1FileComx", wxTextCtrl)->SetValue("");
}

void GuiComx::onComxDisk2(wxCommandEvent& WXUNUSED(event) )
{
	wxString fileName;

	fileName = wxFileSelector( _T("Select the Disk 2 file to load"),
                               floppyDir_[1], XRCCTRL(*this, "Disk2FileComx", wxTextCtrl)->GetValue(),
                               "img",
                               wxString::Format
                              (
                                    _T("Disk Image (*.img)|*.img|All files (%s)|%s"),
                                    wxFileSelectorDefaultWildcardStr,
                                    wxFileSelectorDefaultWildcardStr
                               ),
                               wxFD_OPEN|wxFD_CHANGE_DIR|wxFD_PREVIEW,
                               this
                              );
	if (!fileName)
		return;

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	floppyDir_[1] = FullPath.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);

	XRCCTRL(*this, "Disk2FileComx", wxTextCtrl)->SetValue(FullPath.GetFullName());
}

void GuiComx::onComxDiskText2(wxCommandEvent&WXUNUSED(event))
{
	wxString diskFile;

	if ((runningComputer_ == COMX) && diskRomLoaded_)
	{
		diskFile = XRCCTRL(*this, "Disk2FileComx", wxTextCtrl)->GetValue();
		if (diskFile.Len() == 0)
		{
			p_Comx->setDiskName(2, "");
		}
		else
		{
			diskFile = floppyDir_[1];
			diskFile.operator += (XRCCTRL(*this, "Disk2FileComx", wxTextCtrl)->GetValue());
			p_Comx->setDiskName(2, diskFile);
		}
	}
}

void GuiComx::onComxDiskEject2(wxCommandEvent& WXUNUSED(event) )
{
	XRCCTRL(*this, "Disk2FileComx", wxTextCtrl)->SetValue("");
}

void GuiComx::onPrintFileText(wxCommandEvent&WXUNUSED(event))
{
	wxString printFile;

	if (runningComputer_ == COMX)
	{
		if (p_Comx->isPrintRomLoaded(COMXPARALLEL))
		{
			printFile = XRCCTRL(*this, "PrintFileComx", wxTextCtrl)->GetValue();
			if (printFile.Len() == 0)
			{
				p_PrinterParallel->setPrintfileName("");
			}
			else
			{
				printFile = conf[COMX].printFileDir_;
				printFile.operator += (XRCCTRL(*this, "PrintFileComx", wxTextCtrl)->GetValue());
				p_PrinterParallel->setPrintfileName(printFile);
			}
		}
		if (p_Comx->isPrintRomLoaded(COMXSERIAL))
		{
			printFile = XRCCTRL(*this, "PrintFileComx", wxTextCtrl)->GetValue();
			if (printFile.Len() == 0)
			{
				p_PrinterSerial->setPrintfileName("");
			}
			else
			{
				printFile = conf[COMX].printFileDir_;
				printFile.operator += (XRCCTRL(*this, "PrintFileComx", wxTextCtrl)->GetValue());
				p_PrinterSerial->setPrintfileName(printFile);
			}
		}
		if (p_Comx->isPrintRomLoaded(COMXTHERMAL))
		{
			printFile = XRCCTRL(*this, "PrintFileComx", wxTextCtrl)->GetValue();
			if (printFile.Len() == 0)
			{
				p_PrinterThermal->setPrintfileName("");
			}
			else
			{
				printFile = conf[COMX].printFileDir_;
				printFile.operator += (XRCCTRL(*this, "PrintFileComx", wxTextCtrl)->GetValue());
				p_PrinterThermal->setPrintfileName(printFile);
			}
		}
	}
}

void GuiComx::onPrintMode(wxCommandEvent&event)
{
	comxPrintMode_ = event.GetSelection();
	setComxPrintMode();

	if (runningComputer_ == COMX)
	{
		if (p_Comx->isPrintRomLoaded(COMXPARALLEL))
		{
			p_PrinterParallel->setPrintMode(comxPrintMode_);
		}
		if (p_Comx->isPrintRomLoaded(COMXSERIAL))
		{
			p_PrinterSerial->setPrintMode(comxPrintMode_);
		}
	}
}

void GuiComx::onPrintButton(wxCommandEvent&WXUNUSED(event))
{
	onF4();
}

void GuiComx::onComxVideoMode(wxCommandEvent&event)
{
	switch(event.GetSelection())
	{
		case PAL:
			XRCCTRL(*this, "ClockComx", wxTextCtrl)->ChangeValue(comxPalClock_);
		break;

		case NTSC:
			XRCCTRL(*this, "ClockComx", wxTextCtrl)->ChangeValue(comxNtscClock_);
		break;
	}
}

void GuiComx::onComxExpansionRam(wxCommandEvent&event)
{
	useExpansionRam_ = event.IsChecked();
	XRCCTRL(*this, "ExpRamSlotComx", wxSpinCtrl)->Enable(useExpansionRam_);
	if (useExpansionRam_)
		setComxExpRamSlot();
	else
		resetCardText();
}

void GuiComx::onComxExpansionRamSlot(wxSpinEvent&event)
{
	resetCardText();

	expansionRamSlot_ = event.GetPosition();

	setComxExpRamSlot();
}

void GuiComx::setLocation(bool state, Word saveStart, Word saveEnd, Word saveExec)
{
	wxString printBuffer;

	if (state)
	{
		printBuffer.Printf("%04X",saveStart);
		XRCCTRL(*this,"SaveStartComx",wxTextCtrl)->SetValue(printBuffer);
		printBuffer.Printf("%04X",saveEnd);
		XRCCTRL(*this,"SaveEndComx",wxTextCtrl)->SetValue(printBuffer);
		printBuffer.Printf("%04X",saveExec);
		XRCCTRL(*this,"SaveExecComx",wxTextCtrl)->SetValue(printBuffer);
	}
	else
	{
		XRCCTRL(*this,"SaveStartComx",wxTextCtrl)->SetValue("");
		XRCCTRL(*this,"SaveEndComx",wxTextCtrl)->SetValue("");
		XRCCTRL(*this,"SaveExecComx",wxTextCtrl)->SetValue("");
	}
	XRCCTRL(*this, "UseLocationComx", wxCheckBox)->SetValue(state);
	conf[COMX].useLoadLocation_ = state;
}

void GuiComx::statusLedOnEvent()
{
	if (wxIsMainThread())
	{
		statusLedOnDirect();
		return;
	}
	wxCommandEvent event(STATUS_LED_ON, 801);
	event.SetEventObject(this);
	wxPostEvent(this, event);
	while(!isComxStatusLedOn_)
		p_Computer->sleepComputer(1);
}

void GuiComx::statusLedOffEvent()
{
	if (wxIsMainThread())
	{
		statusLedOffDirect();
		return;
	}
	wxCommandEvent event(STATUS_LED_OFF, 802);
	event.SetEventObject(this);
	wxPostEvent(this, event);
	while(isComxStatusLedOn_)
		p_Computer->sleepComputer(1);
}

void GuiComx::expLedOnEvent()
{
	if (wxIsMainThread())
	{
		expLedOnDirect();
		return;
	}
	if (isComxExpLedOn_)  return;
	wxCommandEvent event(EXP_LED_ON, 805);
	event.SetEventObject(this);
	wxPostEvent(this, event);
	while(!isComxExpLedOn_)
		p_Computer->sleepComputer(1);
}

void GuiComx::expLedOffEvent()
{
	if (wxIsMainThread())
	{
		expLedOffDirect();
		return;
	}
	if (!isComxExpLedOn_)  return;
	wxCommandEvent event(EXP_LED_OFF, 806);
	event.SetEventObject(this);
	wxPostEvent(this, event);
	while(isComxExpLedOn_)
		p_Computer->sleepComputer(1);
}

void GuiComx::v1870BarSizeEvent()
{
	wxCommandEvent event(STATUS_BAR_1870, 803);
	event.SetEventObject(this);
	wxPostEvent(this, event);
}

void GuiComx::mc6845BarSizeEvent()
{
	wxCommandEvent event(STATUS_BAR_6845, 804);
	event.SetEventObject(this);
	wxPostEvent(this, event);
}

wxString GuiComx::getFloppyDir(int drive)
{
	return floppyDir_[drive];
}

wxString GuiComx::getPL80Data(int item)
{
	return Pl80Data_[item];
}

void GuiComx::setPL80Data(int item, wxString data)
{
	Pl80Data_[item] = data;
}

void GuiComx::enableComxGui(bool status)
{
	if (useExpansionRam_)
	{
		XRCCTRL(*this, "ExpRamSlotComx", wxSpinCtrl)->Enable(status);
		switch(expansionRamSlot_)
		{
			case 1:
				XRCCTRL(*this, "Cart1RomComx", wxComboBox)->Enable(false);
				XRCCTRL(*this, "Cart1RomButtonComx", wxButton)->Enable(false);
			break;

			case 2:
				XRCCTRL(*this, "Cart2RomComx", wxComboBox)->Enable(false);
				XRCCTRL(*this, "Cart2RomButtonComx", wxButton)->Enable(false);
			break;

			case 3:
				XRCCTRL(*this, "Cart3RomComx", wxComboBox)->Enable(false);
				XRCCTRL(*this, "Cart3RomButtonComx", wxButton)->Enable(false);
			break;

			case 4:
				XRCCTRL(*this, "Cart4RomComx", wxComboBox)->Enable(false);
				XRCCTRL(*this, "Cart4RomButtonComx", wxButton)->Enable(false);
			break;
		}
	}
}

void GuiComx::statusLedOn(wxCommandEvent&WXUNUSED(event))
{
	if (runningComputer_ != COMX)  return;
	p_Comx->updateStatusLed(true);
	isComxStatusLedOn_ = true;
}

void GuiComx::statusLedOnDirect()
{
	if (runningComputer_ != COMX)  return;
	p_Comx->updateStatusLed(true);
	isComxStatusLedOn_ = true;
}

void GuiComx::statusLedOff(wxCommandEvent&WXUNUSED(event))
{
	if (runningComputer_ != COMX)  return;
	p_Comx->updateStatusLed(false);
	isComxStatusLedOn_ = false;
}

void GuiComx::statusLedOffDirect()
{
	if (runningComputer_ != COMX)  return;
	p_Comx->updateStatusLed(false);
	isComxStatusLedOn_ = false;
}

void GuiComx::expLedOn(wxCommandEvent&WXUNUSED(event))
{
	if (runningComputer_ != COMX)  return;
	p_Comx->updateExpansionLed(true);
	isComxExpLedOn_ = true;
}

void GuiComx::expLedOnDirect()
{
	if (runningComputer_ != COMX)  return;
	p_Comx->updateExpansionLed(true);
	isComxExpLedOn_ = true;
}

void GuiComx::expLedOff(wxCommandEvent&WXUNUSED(event))
{
	if (runningComputer_ != COMX)  return;
	p_Comx->updateExpansionLed(false);
	isComxExpLedOn_ = false;
}

void GuiComx::expLedOffDirect()
{
	if (runningComputer_ != COMX)  return;
	p_Comx->updateExpansionLed(false);
	isComxExpLedOn_ = false;
}

void GuiComx::v1870BarSize(wxCommandEvent&WXUNUSED(event))
{
	if (runningComputer_ != COMX)  return;
	p_Comx->v1870BarSize();
}

void GuiComx::mc6845BarSize(wxCommandEvent&WXUNUSED(event))
{
	if (runningComputer_ != COMX)  return;
	p_Comx->mc6845BarSize();
}

void GuiComx::setComxExpRamSlot()
{
	switch(expansionRamSlot_)
	{
		case 1:
			saveCardText_ = XRCCTRL(*this, "Cart1RomComx", wxComboBox)->GetValue();
			XRCCTRL(*this, "Cart1RomComx", wxComboBox)->SetValue("Ram Card");
			XRCCTRL(*this, "Cart1RomComx", wxComboBox)->Enable(false);
			XRCCTRL(*this, "Cart1RomButtonComx", wxButton)->Enable(false);
		break;

		case 2:
			saveCardText_ = XRCCTRL(*this, "Cart2RomComx", wxComboBox)->GetValue();
			XRCCTRL(*this, "Cart2RomComx", wxComboBox)->SetValue("Ram Card");
			XRCCTRL(*this, "Cart2RomComx", wxComboBox)->Enable(false);
			XRCCTRL(*this, "Cart2RomButtonComx", wxButton)->Enable(false);
		break;

		case 3:
			saveCardText_ = XRCCTRL(*this, "Cart3RomComx", wxComboBox)->GetValue();
			XRCCTRL(*this, "Cart3RomComx", wxComboBox)->SetValue("Ram Card");
			XRCCTRL(*this, "Cart3RomComx", wxComboBox)->Enable(false);
			XRCCTRL(*this, "Cart3RomButtonComx", wxButton)->Enable(false);
		break;

		case 4:
			saveCardText_ = XRCCTRL(*this, "Cart4RomComx", wxComboBox)->GetValue();
			XRCCTRL(*this, "Cart4RomComx", wxComboBox)->SetValue("Ram Card");
			XRCCTRL(*this, "Cart4RomComx", wxComboBox)->Enable(false);
			XRCCTRL(*this, "Cart4RomButtonComx", wxButton)->Enable(false);
		break;
	}
}

void GuiComx::resetCardText()
{
	switch(expansionRamSlot_)
	{
		case 1:
			XRCCTRL(*this, "Cart1RomComx", wxComboBox)->SetValue(saveCardText_);
			XRCCTRL(*this, "Cart1RomComx", wxComboBox)->Enable(true);
			XRCCTRL(*this, "Cart1RomButtonComx", wxButton)->Enable(true);
		break;

		case 2:
			XRCCTRL(*this, "Cart2RomComx", wxComboBox)->SetValue(saveCardText_);
			if (expansionRomLoaded_)
			{
				XRCCTRL(*this, "Cart2RomComx", wxComboBox)->Enable(true);
				XRCCTRL(*this, "Cart2RomButtonComx", wxButton)->Enable(true);
			}
		break;

		case 3:
			XRCCTRL(*this, "Cart3RomComx", wxComboBox)->SetValue(saveCardText_);
			if (expansionRomLoaded_)
			{
				XRCCTRL(*this, "Cart3RomComx", wxComboBox)->Enable(true);
				XRCCTRL(*this, "Cart3RomButtonComx", wxButton)->Enable(true);
			}
		break;

		case 4:
			XRCCTRL(*this, "Cart4RomComx", wxComboBox)->SetValue(saveCardText_);
			if (expansionRomLoaded_)
			{
				XRCCTRL(*this, "Cart4RomComx", wxComboBox)->Enable(true);
				XRCCTRL(*this, "Cart4RomButtonComx", wxButton)->Enable(true);
			}
		break;
	}
}

bool GuiComx::isSaving()
{
	if (runningComputer_ == COMX)
		return p_Comx->isSaving();
	else
		return false;
}

void GuiComx::setComxPrintMode()
{
	if (comxPrintMode_ == PRINTFILE)
	{
		XRCCTRL(*this, "PrintFileButtonComx", wxButton)->Enable(true);
		XRCCTRL(*this, "PrintFileComx", wxTextCtrl)->Enable(true);
	}
	else
	{
		XRCCTRL(*this, "PrintFileButtonComx", wxButton)->Enable(false);
		XRCCTRL(*this, "PrintFileComx", wxTextCtrl)->Enable(false);
	}
}

void GuiComx::openPrinterFrame(wxCommandEvent&WXUNUSED(event))
{
	if (runningComputer_ != COMX)  return;
	onF4();
}

void GuiComx::onF4()
{
	if (runningComputer_ == COMX)
	{
		p_Comx->onF4();
		if (comxPrintMode_ == PRINTFILE)
		{
			comxPrintMode_ = COMXPRINTPLOTTER;
			XRCCTRL(*this, "PrintModeComx", wxChoice)->SetSelection(comxPrintMode_);
			setComxPrintMode();
		}
	}
}

void GuiComx::setFandMBasicGui()
{
	if (p_Comx->isFAndMBasicRunning())
	{
		XRCCTRL(*this, "RunButtonComx", wxButton)->SetLabel("F&&M RUN");
		XRCCTRL(*this, "SaveButtonComx", wxButton)->SetLabel("F&&M SAVE");
		XRCCTRL(*this, "LoadButtonComx", wxButton)->SetLabel("F&&M LOAD");
	}
	else
	{
		XRCCTRL(*this, "RunButtonComx", wxButton)->SetLabel("RUN");
		XRCCTRL(*this, "SaveButtonComx", wxButton)->SetLabel("SAVE");
		XRCCTRL(*this, "LoadButtonComx", wxButton)->SetLabel("LOAD");
	}
}

void GuiComx::enableDiskRomGui(bool DiskRom)
{
	diskRomLoaded_ = DiskRom;
	XRCCTRL(*this, "Disk1FileComx", wxTextCtrl)->Enable(diskRomLoaded_);
	XRCCTRL(*this, "Disk1ButtonComx", wxButton)->Enable(diskRomLoaded_);
	XRCCTRL(*this, "EjectDisk1Comx", wxButton)->Enable(diskRomLoaded_);
	XRCCTRL(*this, "Disk2FileComx", wxTextCtrl)->Enable(diskRomLoaded_);
	XRCCTRL(*this, "Disk2ButtonComx", wxButton)->Enable(diskRomLoaded_);
	XRCCTRL(*this, "EjectDisk2Comx", wxButton)->Enable(diskRomLoaded_);
}

void GuiComx::setExtRomStatus(bool expansionRomLoaded)
{
	expansionRomLoaded_ = expansionRomLoaded;
}

void GuiComx::setPrintMode(int mode)
{
	comxPrintMode_ = mode;
}

int GuiComx::getPrintMode()
{
	return comxPrintMode_;
}