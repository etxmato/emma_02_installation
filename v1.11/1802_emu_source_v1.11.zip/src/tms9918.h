#ifndef TMS9918_H
#define TMS9918_H

#include "video.h"

#if defined(__WXGTK__)
#define TMSX 320
#define TMSY 240
#define FSBACKX 0
#define FSBACKY 0
#define BACKX 32
#define BACKY 24
#else
#define TMSX 256
#define TMSY 192
#define FSBACKX 32
#define FSBACKY 24
#define BACKX 32
#define BACKY 24
#endif

class TileList
{
public:
	wxCoord x;
	wxCoord y;
	int size;
	TileList *nextTile;
};

class Tms9918Screen : public wxWindow
{
public:
	Tms9918Screen(wxWindow *parent, const wxSize& size, int zoom, int computerType);
	~Tms9918Screen() {};

	void onPaint(wxPaintEvent&event);
	void onChar(wxKeyEvent&event);
	void onKeyDown(wxKeyEvent&event);
	void onKeyUp(wxKeyEvent&event);

	void blit(wxCoord xdest, wxCoord ydest, wxCoord width, wxCoord height, wxDC *source, wxCoord xsrc, wxCoord ysrc);
	void drawBackground(wxColour clr, int v1870X, int v1870Y, wxCoord offsetX, wxCoord offsetY);
	void setZoom(int zoom);

private:
	int zoom_;
	int computerType_;

	DECLARE_EVENT_TABLE()
};

class Tms9918 : public Video
{
public:

	Tms9918(const wxString& title, const wxPoint& pos, const wxSize& size, int zoom, int computerType, double clock);
	~Tms9918();

	void onClose(wxCloseEvent&event );
	void setReBlit();

	void configure();
	void modeHighOut(Byte value);
	void modeLowOut(Byte value);
	void cycleTms();

	void reDrawScreen();
	void copyScreen();
	void setColour(int clr);
	void drawTile(Word tile);
	void drawScreen();
	void setZoom(int zoom);

	Byte getTmsMemory(int address) {return tmsMemory_[address];}
	void setTmsMemory(int address, Byte value) {tmsMemory_[address] = value;}

	void onF3();
	void onF5();
	bool isFullScreenSet() {return fullScreenSet_;};

private:
	void setFullScreen();
	void drawBackground();

	wxBitmap *screenCopyPointer;
	TileList *tileListPointer;
    class Tms9918Screen *tms9918ScreenPointer;

	wxMemoryDC dcMemory;

	Byte tmsMemory_[16384];
	int computerType_;
	Byte registers_[8];
	Byte mode_;
	Word nameAddress_;
	Word colorAddress_;
	Word patternAddress_;
	Word spAttrAddress_;
	Word currentAddress_;
	Byte toggle_;
	Byte value_;

	int zoom_;
	int restoreZoomAfterFullScreen_;

	wxCoord offsetX_;
	wxCoord offsetY_;
	wxCoord backGroundX_;
	wxCoord backGroundY_;
	bool fullScreenSet_;
	bool f3Pressed_;
	bool newBackGround_;
	bool updateTile_;


	int cycleValue_;
	int cycleSize_;

	DECLARE_EVENT_TABLE()
};

#endif  // TMS9918_H
