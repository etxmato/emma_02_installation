#ifndef GUIVIP_H
#define GUIVIP_H

#include "guitmc2000.h"

class GuiVip: public GuiTMC2000
{
public:

	GuiVip(const wxString& title, const wxPoint& pos, const wxSize& size);
	~GuiVip() {};

	void readVipConfig();
	void writeVipConfig();


	void onTempo(wxScrollEvent&event);
	void onSound(wxCommandEvent&event);
	void onRamSWVip(wxCommandEvent&event);
	void onRamSWText(wxCommandEvent&event);
	void setSoundGui(int sound);

private:

	DECLARE_EVENT_TABLE()
};

#endif // GUIVIP_H