#ifndef COMXSTATUSBAR_H
#define COMXSTATUSBAR_H

#define LED_SIZE_X 12
#define LED_SIZE_Y 7

class ComxStatusBar : public wxStatusBar
{
public:
	ComxStatusBar(wxWindow *parent, int size);
	~ComxStatusBar();

	void initComxBar(int zoom, bool expansionRomLoaded, int expansionTypeCard0);
	void updateLedStatus(int card, int i, bool status);
	void reDrawBar(int zoom);
	void setBarSize(int size, int zoom);

private:
	void displayText(int zoom);
	void displayLeds(int zoom);
	void deleteBitmaps();
	void updateStatusBarText(int zoom);

	wxBitmapButton *ledBitmapPointers [4][2];
	wxBitmap *ledOffPointer;
	wxBitmap *ledOnPointer;

	int statusBarSize_;
	bool expansionRomLoaded_;
	int expansionTypeCard0_;
	bool ledsDefined_;
};

#endif  //_comxstatusbar_H_