#ifndef STUDIO2_H
#define STUDIO2_H

#include "cdp1802.h"
#include "pixie.h"

class RunStudio : public wxThread
{
public:
	RunStudio() {};
	virtual void *Entry();
};

class KeyDef
{
public:
	bool defined;
	int player;
	int key;
};

class Studio2 : public Cdp1802, public Pixie
{
public:
	Studio2(const wxString& title, const wxPoint& pos, const wxSize& size, int zoom, int computerType);
	~Studio2();

	void configureComputer();
	void keyDown(int keycode);
	void keyUp(int keycode);

	Byte ef(int flag);
	Byte ef3();
	Byte ef4();
	Byte in(Byte port, Word address);
	void out(Byte port, Word address, Byte value);
	void outStudio(Byte value);
	void cycle(int type);

	void startComputer();
	void stopComputer();
	Byte readMem(Word addr);
	void writeMem(Word addr, Byte value, bool writeRom);
	void cpuInstruction();
	void readSt2Program(wxString FileRef);
	void onReset();
	void onRun();

private:
	RunStudio *threadPointer;

	int studioKeyPort_;
	Byte studioKeyState_[2][10];
	bool resetPressed_;

	int keyDefA_[16];
	int keyDefB_[16];
	KeyDef keyDefinition[512];
};

#endif  // STUDO2_H
