#ifndef ELF_H
#define ELF_H

#include "elf.h"
#include "til311.h"
#include "led.h"
#include "tms9918.h"
#include "pixie.h"
#include "mc6847.h"
#include "mc6845.h"
#include "i8275.h"
#include "keypad.h"
#include "ledmodule.h"
#include "printer.h"
#include "elfconfiguration.h"

class RunElf : public wxThread
{
public:
	RunElf() {};
	virtual void *Entry();
};

class Elf : public wxFrame,  public MainElf
{
public:
	Elf(const wxString& title, const wxPoint& pos, const wxSize& size, double clock, ElfConfiguration conf);
	Elf() {};
	~Elf();

	void onClose(wxCloseEvent&WXUNUSED(event));
	void onKeyDown(wxKeyEvent& event);
	bool keyDownPressed(int keycode);
	void onKeyUp(wxKeyEvent& event);
	bool keyUpReleased(int keycode);
	void onChar(wxKeyEvent& event);
	void charEvent(int keycode);
	void onButtonRelease(wxMouseEvent& event);
	void onButtonPress(wxMouseEvent& event);
	void addressTimeout(wxTimerEvent&WXUNUSED(event));

	void onRun();
	void onInButtonKeyboard();
	void onInButtonPress() {onInButtonPress(0);};
	void onInButtonPress(Byte value);
	void onInButtonRelease();
	void onHexKeyDown(int keycode);
	void onHexDown(int hex);
	void onHexKeyUp();

	void configureComputer();
	void initComputer();
	Byte ef(int flag);
	Byte ef4();
	Byte in(Byte port, Word address);
	Byte getData();
	void out(Byte port, Word address, Byte value);
	void showData(Byte value);
	void cycle(int type);
	void showAddr(Word adr);
	void setef3State(Byte ef3State) {ef3State_=ef3State;};

	void autoBoot();
	void updateQState();
	int getMpButtonState();
	void onRunButton(wxCommandEvent& event);
	void onMpButton(wxCommandEvent& event);
	void onLoadButton(wxCommandEvent& event);
	void onPowerButton(wxCommandEvent& event);
	void dataSwitch(wxCommandEvent& event);
	void efSwitch(wxCommandEvent& event);

	void startComputer();
	void stopComputer();
	void removeElfLedModule() {ledModuleClosed_ = true;};
	void showModules(bool status);
	void removeElfHex() {hexKeypadClosed_ = true;};
	Byte readMem(Word addr);
	void writeMem(Word addr, Byte value, bool writeRom);
	void cpuInstruction();
	void configureElfExtensions();
	void tmsAndPixieZoom(int zoom);
	void moveWindows();
	void updateTitle(wxString Title);
	void setForceUpperCase(bool status);
	void onReset();
	void sleepComputer(long ms);

	Byte getTmsMemory(int address) {return tmsPointer->getTmsMemory(address);};
	void setTmsMemory(int address, Byte value) {tmsPointer->setTmsMemory(address, value);};
//	void setReBlit();
	Byte read8275CharRom(Word addr);
	void write8275CharRom(Word addr, Byte value);
	Byte read6845CharRom(Word addr);
	void write6845CharRom(Word addr, Byte value);
	Byte read6847CharRom(Word addr);
	void write6847CharRom(Word addr, Byte value);
	int readDirect6847(Word addr);
	Word get6847RamMask();
	void writeDirect6847(Word addr, int value);

private:
	void onPaint(wxPaintEvent&event);

	RunElf *threadPointer;
	Tms9918 *tmsPointer;
	Pixie *pixiePointer;
	MC6845 *mc6845Pointer;
	mc6847 *mc6847Pointer;
	i8275 *i8275Pointer;
	Keypad *keypadPointer;
	LedModule *ledModulePointer;
	wxTimer *addressTimerPointer;

	wxBitmap *elfBitmapPointer;
	wxBitmapButton *runButtonPointer;
	wxBitmapButton *mpButtonPointer;
	wxBitmapButton *powerButtonPointer;
	wxBitmapButton *loadButtonPointer;
	wxBitmapButton *inButtonPointer;
	wxBitmapButton *dataSwitchPointer[8];
	wxBitmapButton *efSwitchPointer[4];

	wxBitmap *upBitmapPointer;
	wxBitmap *downBitmapPointer;
	wxBitmap *pushUpBitmapPointer;
	wxBitmap *pushDownBitmapPointer;
	wxBitmap *redLedOnBitmapPointer;
	wxBitmap *redLedOffBitmapPointer;

	wxMask *maskUp;
	wxMask *maskDown;

	Til311 *addressPointer[4];
	Til311 *dataPointer[2];

	Led *qLedPointer;

	int runButtonState_;
	int mpButtonState_;
	int loadButtonState_;
	int dataSwitchState_[8];
	int efSwitchState_[4];
	int qState_;
	bool inPressed_;
	bool resetPressed_;
	Byte ef3State_;
	Byte switches_;
	Byte data_;
	Word lastAddress_;

	bool ledModuleClosed_;
	bool hexKeypadClosed_;

	int hexKeyDefA_[16];
	double elfClockSpeed_;

	DECLARE_EVENT_TABLE()
};

#endif  // ELF_H
