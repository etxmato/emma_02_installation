/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

/*
 *******************************************************************
 *** This software is copyright 2006 by Michael H Riley          ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/textfile.h"

#include "main.h"

Cdp1802::Cdp1802()
{
}

void Cdp1802::initCpu(int computerType)
{
	cpu1805_ = false;
	switch (computerType)
	{
		case ELF:
			cpu1805_ = p_Main->getCheckBox(_T("CpuModeElf"));
		break;
		case ELFII:
			cpu1805_ = p_Main->getCheckBox(_T("CpuModeElfII"));
		break;
		case SUPERELF:
			cpu1805_ = p_Main->getCheckBox(_T("CpuModeSuperElf"));
		break;
		case ELF2K:
			cpu1805_ = p_Main->getCheckBox(_T("Elf2KCpuMode"));
		break;
		case COSMICOS:
			cpu1805_ = p_Main->getCheckBox(_T("CpuModeCosmicos"));
		break;
	}
	computerType_ = computerType;

	for (int i=0; i<16; i++)
		scratchpadRegister_[i] = 0;
	efFlags_ = 0xf;

	cpuMode_ = RESET;
	clear_ = 0;
	wait_ = 1;
	accumulator_ = 0;
	dataFlag_ = 0;
	registerT_ = 0;
	initIo();
	steps_ = -1;
	baseGiantBoard_ = 0x10000;
	baseQuestLoader_ = 0x10000;

	for (int i=0; i<8; i++) outValues_[i] = 0;
	for (int i=0; i<8; i++) inValues_[i] = 0;

	debugMode_ = false;
	trace_ = false;
	traceDma_ = false;
	traceInt_ = false;
	traceInp_ = 0;
	traceOut_ = 0;
}

void Cdp1802::resetCpu()
{
	flipFlopQ_ = 0;
	interruptEnable_ = 1;
	ci_ = 0;
	xi_ = 0;
	dataPointer_ = 0;
	programCounter_ = 0;
	scratchpadRegister_[0] = 0;
	ctrPre_ = 0;
	tq_ = 0;
	ctrRunning_ = 0;
	idle_ = 0;
	address_ = 0;
	colourMask_ = 0;
}

void Cdp1802::machineCycle()
{
	for (int i=1; i<5; i++)
	{
		setEf(i, ef(i));
	}

	for (int i=0; i<MAXCYCLE; i++)
	{
		cycle(i);
	}
	soundCycle();
}

void Cdp1802::setMode()
{
	if (clear_ == 0 && wait_==1)
	{
		cpuMode_ = RESET;
		resetCpu();
	}
	if (clear_ == 1 && wait_==1) cpuMode_ = RUN;
	if (clear_ == 0 && wait_==0) cpuMode_ = LOAD;
	if (clear_ == 1 && wait_==0) cpuMode_ = PAUSE;
}

void Cdp1802::setClear(int value)
{
	clear_= (value)?1:0;
	setMode();
}

void Cdp1802::setWait(int value)
{
	wait_= (value)?1:0;
	setMode();
}

void Cdp1802::dmaIn(Byte value)
{
	if (traceDma_)
	{
		wxString traceText;
		traceText.Printf("DMA in       R0=%X", scratchpadRegister_[0]);
		p_Main->debugTrace(traceText);
	}
	if (cpuMode_ != RUN && cpuMode_ != LOAD) return;
	writeMem(scratchpadRegister_[0], value, false);
	address_ = scratchpadRegister_[0]++;
	idle_=0;
}

Byte Cdp1802::dmaOut()
{
	Byte ret;
	ret = 255;
	if (traceDma_)
	{
		wxString traceText;
		traceText.Printf("DMA out      R0=%X", scratchpadRegister_[0]);
		p_Main->debugTrace(traceText);
	}
	ret=readMem(scratchpadRegister_[0]);
	scratchpadRegister_[0]++;
	idle_=0;
	cpuCycles_++;
	machineCycle();

	return ret;
}

Byte Cdp1802::pixieDmaOut(int *color)
{
	Byte ret;
	ret = 255;
	if (traceDma_)
	{
		wxString traceText;
		traceText.Printf("DMA out      R0=%X", scratchpadRegister_[0]);
		p_Main->debugTrace(traceText);
	}
	ret=readMem(scratchpadRegister_[0]);
	switch (computerType_)
	{
		case ETI:
			*color = colorMemory1864_[((scratchpadRegister_[0] >> 1) & 0xf8) + (scratchpadRegister_[0] & 0x7)] & 0x7;
		break;
		case VIP:
			if (colourMask_ == 0)
				*color = 7;
			else
				*color = colorMemory1864_[scratchpadRegister_[0] & colourMask_] & 0x7;
		break;
		case VICTORY:
			*color = colorMemory1864_[((scratchpadRegister_[0] >> 2) & 0x38) + (scratchpadRegister_[0] & 0x7)] & 0x7;
		break;
		default:
			*color = colorMemory1864_[scratchpadRegister_[0] & 0x3ff] & 0x7;
		break;
	}
	scratchpadRegister_[0]++;
	idle_=0;
	cpuCycles_++;
	soundCycle();

	return ret;
}

void Cdp1802::visicomDmaOut(Byte *vram1, Byte *vram2)
{
	if (traceDma_)
	{
		wxString traceText;
		traceText.Printf("DMA out      R0=%X", scratchpadRegister_[0]);
		p_Main->debugTrace(traceText);
	}
	*vram1 = readMem(scratchpadRegister_[0]);
	*vram2 = readMem(scratchpadRegister_[0]+0x200);

	scratchpadRegister_[0]++;
	idle_=0;
	cpuCycles_++;
	soundCycle();
}

Byte Cdp1802::pixieDmaOut()
{
	Byte ret;
	ret = 255;
	if (traceDma_)
	{
		wxString traceText;
		traceText.Printf("DMA out      R0=%X", scratchpadRegister_[0]);
		p_Main->debugTrace(traceText);
	}
	ret=readMem(scratchpadRegister_[0]);
	scratchpadRegister_[0]++;
	idle_=0;
	cpuCycles_++;
	soundCycle();

	return ret;
}

void Cdp1802::decCounter()
{
	if (--counter_ == 0)
	{
		if (tq_)
		{
			flipFlopQ_ = (flipFlopQ_) ? 0 : 1;
		}
		ci_ = (cie_) ? 1 : 0;
		counter_ = ch_;
	}
}

void Cdp1802::setEf(int flag,int value)
{
	if (flag == 1)
	{
		if (ctrMode_ == 2 && ctrRunning_)
		{
			if (value == 0 &&(efFlags_ & 1)) decCounter();
		}
		if (value) efFlags_ |= 1;
		else efFlags_ &= 0xe;
	}
	if (flag == 2)
	{
		if (ctrMode_ == 3 && ctrRunning_)
		{
 			if (value == 0 &&(efFlags_ & 2)) decCounter();
		}
		if (value) efFlags_ |= 2;
		else efFlags_ &= 0xd;
	}
	if (flag == 3)
	{
		if (value) efFlags_ |= 4;
		else efFlags_ &= 0xb;
	}
	if (flag == 4)
	{
 		if (value) efFlags_ |= 8;
		else efFlags_ &= 7;
	}
}

void Cdp1802::interrupt()
{
	if (interruptEnable_ && (clear_ == 1))
	{
		if (traceInt_)
		{
			p_Main->debugTrace("Interrupt");
		}
		registerT_= (dataPointer_<<4) | programCounter_;
		dataPointer_=2;
		programCounter_=1;
		interruptEnable_=0;
		cpuCycles_++;
		machineCycle();
	}
	idle_=0;
}

void Cdp1802::pixieInterrupt()
{
	if (interruptEnable_)
	{
		if (traceInt_)
		{
			p_Main->debugTrace("Interrupt");
		}
		registerT_= (dataPointer_<<4) | programCounter_;
		dataPointer_=2;
		programCounter_=1;
		interruptEnable_=0;
		cpuCycles_++;
	}
	idle_=0;
}

void Cdp1802::inst1805(wxString *tr)
{
	wxString buffer;

	Byte i,h,l,n;
	int  a,b;
	int w;
	w = 0;
	i=readMem(scratchpadRegister_[programCounter_]);
	n = i & 15;
	i = i>>4;
	scratchpadRegister_[programCounter_]++;
	switch(i)
	{
		case 0:
			switch(n)
			{
				case 0:
					ctrRunning_ = 0;
					ctrPre_ = 0;
					ctrMode_ = 0;
 					if (trace_)
					{
						buffer.Printf(" STPC");
						*tr = *tr + buffer;
					}
				break;
				case 1:
					decCounter();
					if (trace_)
					{
						buffer.Printf(" DTC");
						*tr = *tr + buffer;
					}
				break;
				case 2:
					ctrMode_ = 5;
					ctrRunning_ = 1;
					if (trace_)
					{
						buffer.Printf(" SPM2");
						*tr = *tr + buffer;
					}
				break;
				case 3:
					ctrMode_ = 3;
					ctrRunning_ = 1;
					if (trace_)
					{
						buffer.Printf(" SCM2");
						*tr = *tr + buffer;
					}
				break;
				case 4:
					ctrMode_ = 4;
					ctrRunning_ = 1;
					if (trace_)
					{
						buffer.Printf(" SPM1");
						*tr = *tr + buffer;
					}
				break;
				case 5:
					ctrMode_ = 2;
					ctrRunning_ = 1;
					if (trace_)
					{
						buffer.Printf(" SCM1");
						*tr = *tr + buffer;
					}
				break;
				case 6:
					ch_ = accumulator_;
					if (!ctrRunning_)
					{
  						counter_ = accumulator_;
  						ci_ = 0;
					}
					if (trace_)
					{
						buffer.Printf(" LDC");
						*tr = *tr + buffer;
					}
				break;
				case 7:
					ctrMode_ = 1;
					ctrRunning_ = 1;
					if (trace_)
					{
						buffer.Printf(" STM");
						*tr = *tr + buffer;
					}
				break;
				case 8:
					accumulator_ = counter_;
					if (trace_)
					{
						buffer.Printf(" GEC");
						*tr = *tr + buffer;
					}
				break;
				case 9:
					tq_ = 1;
					if (trace_)
					{
						buffer.Printf(" ETQ");
						*tr = *tr + buffer;
					}
				break;
				case 10:
					xie_ = 1;
					if (trace_)
					{
						buffer.Printf(" XIE");
						*tr = *tr + buffer;
					}
				break;
				case 11:
					xie_ = 0;
					if (trace_)
					{
						buffer.Printf(" XID");
						*tr = *tr + buffer;
					}
				break;
				case 12:
					cie_ = 1;
					if (trace_)
					{
						buffer.Printf(" CIE");
						*tr = *tr + buffer;
					}
				break;
				case 13:
					cie_ = 0;
					if (trace_)
					{
						buffer.Printf(" CID");
						*tr = *tr + buffer;
					}
				break;
			}
		break;

		case 2:
			h=readMem(scratchpadRegister_[programCounter_]);
			l=readMem((Word) (scratchpadRegister_[programCounter_]+1));
			cpuCycles_ += 1;
			w= (h<<8)|l;
			if (--scratchpadRegister_[n] != 0) scratchpadRegister_[programCounter_] = w;
			else scratchpadRegister_[programCounter_]+=2;
			if (trace_)
			{
				buffer.Printf(" DBNZ %02x%02x ",h,l);
				*tr = *tr + buffer;
			}
		break;

		case 3:
			switch(n)
			{
				case 14:
					if (ci_)
					{
						i=readMem(scratchpadRegister_[programCounter_]);
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" BCI %02x ",i);
						*tr = *tr + buffer;
					}
				break;
				case 15:
					if (xi_)
					{
						i=readMem(scratchpadRegister_[programCounter_]);
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" BXI %02x ",i);
						*tr = *tr + buffer;
					}
				break;
			}
 		break;

		case 6:
			w = readMem(scratchpadRegister_[dataPointer_]++) << 8;
			w |= readMem(scratchpadRegister_[dataPointer_]++);
			scratchpadRegister_[n] = w;
			if (trace_)
			{
 				buffer.Printf(" RLXA %x ",n);
 				*tr = *tr + buffer;
 			}
  		break;

		case 7:
			switch(n)
			{
				case 4:
					w = readMem(scratchpadRegister_[dataPointer_]);
					a = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					a |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					w = accumulator_;
					b = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					b |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					a += b + dataFlag_;
					dataFlag_ = (a > 99) ? 1 : 0;
					accumulator_ = ((a / 10) << 4) | a % 10;
					if (trace_)  {
						buffer.Printf(" DADC ");
						*tr = *tr + buffer;
					}
				break;
				case 6:writeMem(--scratchpadRegister_[dataPointer_], registerT_, false);
					writeMem(--scratchpadRegister_[dataPointer_], accumulator_, false);
					writeMem(--scratchpadRegister_[dataPointer_],(Byte) ((accumulator_ << 1) | dataFlag_), false);
					if (trace_)  {
          				buffer.Printf(" DSAV %x ",n);
  					*tr = *tr + buffer;
					}
				break;
				case 7:w = readMem(scratchpadRegister_[dataPointer_]);
					a = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					a |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					w = accumulator_;
					b = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					b |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					b -= (a +(dataFlag_)?0:1);
					a = b;
					dataFlag_ = (a < 0) ? 0 : 1;
					a = abs(a);
					accumulator_ = ((a / 10) << 4) | a % 10;
					if (trace_)  {
						buffer.Printf(" DADD ");
						*tr = *tr + buffer;
					}
				break;
				case 12:w = readMem(scratchpadRegister_[programCounter_]++);
					a = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					a |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					w = accumulator_;
					b = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					b |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					a += b + dataFlag_;
					dataFlag_ = (a > 99) ? 1 : 0;
					accumulator_ = ((a / 10) << 4) | a % 10;
					if (trace_)  {
						buffer.Printf(" DACI ");
						*tr = *tr + buffer;
					}
				break;
				case 15:w = readMem(scratchpadRegister_[programCounter_]++);
					a = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					a |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					w = accumulator_;
					b = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					b |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					b -= (a +(dataFlag_)?0:1);
					a = b;
					dataFlag_ = (a < 0) ? 0 : 1;
					a = abs(a);
					accumulator_ = ((a / 10) << 4) | a % 10;
					if (trace_)  {
						buffer.Printf(" DADD ");
						*tr = *tr + buffer;
					}
				break;
 			}
 		break;

		case 8: writeMem(scratchpadRegister_[dataPointer_]--,(Byte) (scratchpadRegister_[n] & 0xff), false);
            writeMem(scratchpadRegister_[dataPointer_]--,(Byte) (scratchpadRegister_[n] >> 8), false);
            scratchpadRegister_[n] = scratchpadRegister_[programCounter_];
            w = readMem(scratchpadRegister_[n]++) << 8;
            w |= readMem(scratchpadRegister_[n]++);
            scratchpadRegister_[programCounter_] = w;
            if (trace_)
			{
 				buffer.Printf(" SCAL %x ",n);
 				*tr = *tr + buffer;
 			}
  		break;

		case 9:
			scratchpadRegister_[programCounter_] = scratchpadRegister_[n];
            w = readMem(++scratchpadRegister_[dataPointer_]) << 8;
            w |= readMem(++scratchpadRegister_[dataPointer_]);
            if (trace_)
			{
 				buffer.Printf(" SRET %x ",n);
 				*tr = *tr + buffer;
 			}
  		break;

		case 10:
			writeMem(scratchpadRegister_[dataPointer_]++,(Byte) (scratchpadRegister_[n] >> 8), false);
			writeMem(scratchpadRegister_[dataPointer_]++,(Byte) (scratchpadRegister_[n] & 0xff), false);
			w |= readMem(scratchpadRegister_[dataPointer_]++);
			scratchpadRegister_[n] = w;
			if (trace_)
			{
 				buffer.Printf(" RSXD %x ",n);
 				*tr = *tr + buffer;
 			}
  		break;

		case 11:
			scratchpadRegister_[dataPointer_] = scratchpadRegister_[n];
            if (trace_)
			{
 				buffer.Printf(" RNX %x ",n);
 				*tr = *tr + buffer;
 			}
  		break;

		case 12:
			w = readMem(scratchpadRegister_[programCounter_]++) << 8;
			w |= readMem(scratchpadRegister_[programCounter_]++);
			scratchpadRegister_[n] = w;
            if (trace_)
			{
 				buffer.Printf(" RLDI %x ",n);
 				*tr = *tr + buffer;
 			}
  		break;

		case 15:
			switch(n)
			{
				case 4:
					w = readMem(scratchpadRegister_[dataPointer_]);
					a = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					a |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					w = accumulator_;
					b = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					b |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					a += b;
					dataFlag_ = (a > 99) ? 1 : 0;
					accumulator_ = ((a / 10) << 4) | a % 10;
					if (trace_)
					{
						buffer.Printf(" DADD ");
						*tr = *tr + buffer;
					}
				break;
				case 7:
					w = readMem(scratchpadRegister_[dataPointer_]);
					a = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					a |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					w = accumulator_;
					b = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					b |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					b -= a; a=b;
					dataFlag_ = (a < 0) ? 0 : 1;
					a = abs(a);
					accumulator_ = ((a / 10) << 4) | a % 10;
					if (trace_)
					{
						buffer.Printf(" DADD ");
						*tr = *tr + buffer;
					}
				break;
				case 12:
					w = readMem(scratchpadRegister_[programCounter_]++);
					a = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					a |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					w = accumulator_;
					b = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					b |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					a += b;
					dataFlag_ = (a > 99) ? 1 : 0;
					accumulator_ = ((a / 10) << 4) | a % 10;
					if (trace_)
					{
						buffer.Printf(" DADI ");
						*tr = *tr + buffer;
					}
				break;
				case 15:
					w = readMem(scratchpadRegister_[programCounter_]++);
					a = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					a |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					w = accumulator_;
					b = (((w >> 4) > 9) ? 9 : w >> 4) *10;
					b |= ((w & 0xf) > 9) ? 9 :(w & 0xf);
					b -= a; a=b;
					dataFlag_ = (a < 0) ? 0 : 1;
					a = abs(a);
					accumulator_ = ((a / 10) << 4) | a % 10;
					if (trace_)
					{
						buffer.Printf(" DADD ");
						*tr = *tr + buffer;
					}
				break;
			}
		break;
	}
}

void Cdp1802::cpuCycle()
{
	wxString tr, buffer;
	Byte i,h,l,n;
	int w;
	Byte df1;
	Byte tmp;
	bool trUpdated = false;

	if (cpuMode_ != RUN) return;
	if (idle_) return;
	if (trace_)
	{
		tr.Printf("%04X: ",scratchpadRegister_[programCounter_]);
	}
	i=readMem(scratchpadRegister_[programCounter_]);
	n = i & 15;
	i = i>>4;
	scratchpadRegister_[programCounter_]++;
	switch(i)
	{
 		case 0:
			if (n == 0)
			{
				idle_=1;
				if (trace_)
				{
					tr = tr + " IDL";
				}
			}
			else
			{
				accumulator_=readMem(scratchpadRegister_[n]);
				if (trace_)
				{
					buffer.Printf(" LDN %X       D=%02X",n,accumulator_);
					tr = tr + buffer;
				}
			}
		break;

		case 1:
			scratchpadRegister_[n]++;
			if (trace_)
			{
				buffer.Printf(" INC %X       R[%X]=%04X",n,n,scratchpadRegister_[n]);
				tr = tr + buffer;
			}
		break;

		case 2:
			scratchpadRegister_[n]--;
			if (trace_)
			{
				buffer.Printf(" DEC %X       R[%X]=%04X",n,n,scratchpadRegister_[n]);
				tr = tr + buffer;
			}
		break;

		case 3:
			switch(n)
			{
				case 0:
					i=readMem(scratchpadRegister_[programCounter_]);
					scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					if (trace_)
					{
						buffer.Printf(" BR %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 1:
					i=readMem(scratchpadRegister_[programCounter_]);
					if (flipFlopQ_)
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" BQ %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 2:
					i=readMem(scratchpadRegister_[programCounter_]);
					if (!accumulator_)
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" BZ %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 3:
					i=readMem(scratchpadRegister_[programCounter_]);
					if (dataFlag_)
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" BDF %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 4:
					i=readMem(scratchpadRegister_[programCounter_]);
					if (!(efFlags_ & 1))
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" B1 %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 5:
					i=readMem(scratchpadRegister_[programCounter_]);
					if (!(efFlags_ & 2))
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" B2 %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 6:
					i=readMem(scratchpadRegister_[programCounter_]);
					if (!(efFlags_ & 4))
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" B3 %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 7:
					i=readMem(scratchpadRegister_[programCounter_]);
					if (!(efFlags_ & 8))
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" B4 %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 8:
					scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" NBR");
						tr = tr + buffer;
					}
				break;
				case 9:
					i=readMem(scratchpadRegister_[programCounter_]);
					if (!flipFlopQ_)
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" BNQ %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 10:
					i=readMem(scratchpadRegister_[programCounter_]);
					if (accumulator_)
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" BNZ %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 11:
					i=readMem(scratchpadRegister_[programCounter_]);
					if (!dataFlag_)
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" BNF %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 12:
					i=readMem(scratchpadRegister_[programCounter_]);
//					p_Main->message("BN1");
//					p_Main->messageInt(scratchpadRegister_[programCounter_]-1);
					if (efFlags_ & 1)
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" BN1 %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 13:
					i=readMem(scratchpadRegister_[programCounter_]);
//					p_Main->message("BN2");
//					p_Main->messageInt(scratchpadRegister_[programCounter_]-1);
					if (efFlags_ & 2)
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" BN2 %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 14:
					i=readMem(scratchpadRegister_[programCounter_]);
//					p_Main->message("BN3");
//					p_Main->messageInt(scratchpadRegister_[programCounter_]-1);
					if (efFlags_ & 4)
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" BN3 %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 15:
					i=readMem(scratchpadRegister_[programCounter_]);
//					p_Main->message("BN4");
//					p_Main->messageInt(scratchpadRegister_[programCounter_]-1);
					if (efFlags_ & 8)
					{
						scratchpadRegister_[programCounter_]= (scratchpadRegister_[programCounter_]&0xff00) | i;
					}
					else
						scratchpadRegister_[programCounter_]++;
					if (trace_)
					{
						buffer.Printf(" BN4 %02X ",i);
						tr = tr + buffer;
					}
				break;
			}
		break;
		case 4:
			accumulator_=readMem(scratchpadRegister_[n]++);
			if (trace_)
			{
				buffer.Printf(" LDA %X       D=M(%X)=%X",n,scratchpadRegister_[n]-1,accumulator_);
				tr = tr + buffer;
			}
		break;
		case 5:
			writeMem(scratchpadRegister_[n], accumulator_, false);
			if (trace_)
			{
				buffer.Printf(" STR %X       M(%X)=%X",n,scratchpadRegister_[n],accumulator_);
 				tr = tr + buffer;
			}
		break;
		case 6:
			if (n == 0)
			{
				scratchpadRegister_[dataPointer_]++;
				if (trace_)
				{
					buffer.Printf(" IRX         R%X=%X",dataPointer_,scratchpadRegister_[dataPointer_]);
					tr = tr + buffer;
				}
				break;
			}
			if (n == 8 && cpu1805_)
			{
				inst1805(&tr);
				break;
			}
			if (n <= 7)
			{
				tmp = readMem(scratchpadRegister_[dataPointer_]++);
				out(n, scratchpadRegister_[dataPointer_]-1, tmp);
				if (!trace_)
				{
					tr.Printf("%04X: ",scratchpadRegister_[programCounter_]-1);
				}
				if (trace_ || traceOut_[n])
				{
					switch (computerType_)
					{
						case COMX:
						case CIDELSA:
						case PECOM:
							if (n>3)
								buffer.Printf(" OUT %X       [%04X]",n,scratchpadRegister_[dataPointer_]-1);
							else
								buffer.Printf(" OUT %X       [%02X]",n,tmp);
						break;

						case TMC600:
							if (n==5 && (p_Computer->getOutValue(7) != 0x20) && (p_Computer->getOutValue(7) != 0x30))
								buffer.Printf(" OUT %X       [%04X]",n,scratchpadRegister_[dataPointer_]-1);
							else
								buffer.Printf(" OUT %X       [%02X]",n,tmp);
						break;

						default:
							buffer.Printf(" OUT %X       [%02X]",n,tmp);
						break;
					}
					tr = tr + buffer;
					trUpdated = true;
				}
				break;
			}
			if (n == 8) return;
			i=in((Byte) (n-8), scratchpadRegister_[dataPointer_]);
			writeMem(scratchpadRegister_[dataPointer_], i, false);
			accumulator_=i;
			if (trace_ || traceInp_[n-8])
			{
				if (!trace_)
				{
					tr.Printf("%04X: ",scratchpadRegister_[programCounter_]-1);
				}
				buffer.Printf(" INP %X ",n-8);
				tr = tr + buffer;
				trUpdated = true;
			}
		break;
		case 7:
			switch(n)
			{
 				case 0:
					i=readMem(scratchpadRegister_[dataPointer_]++);
					programCounter_=i & 15;
					dataPointer_= (i>>4);
					interruptEnable_=1;
					if (trace_)
					{
						buffer.Printf(" RET");
						tr = tr + buffer;
					}
				break;
				case 1:
					i=readMem(scratchpadRegister_[dataPointer_]++);
					programCounter_=i & 15;
					dataPointer_=i>>4;
					interruptEnable_=0;
					if (trace_)
					{
						buffer.Printf(" DIS");
						tr = tr + buffer;
					}
				break;
				case 2:
					accumulator_ = readMem(scratchpadRegister_[dataPointer_]++);
					if (trace_)
					{
						buffer.Printf(" LDXA        m(%X)=%X",scratchpadRegister_[dataPointer_]-1,accumulator_);
						tr = tr + buffer;
					}
				break;
				case 3:
					writeMem(scratchpadRegister_[dataPointer_]--, accumulator_, false);
					if (trace_)
					{
						buffer.Printf(" STXD        m(%X)=%X",scratchpadRegister_[dataPointer_]+1,accumulator_);
						tr = tr + buffer;
					}
				break;
				case 4:
					w=accumulator_ + readMem(scratchpadRegister_[dataPointer_]) + dataFlag_;
					if (w>255)
					{
						accumulator_ = w & 255;
						dataFlag_=1;
					}
					else
					{
						accumulator_=w;
						dataFlag_=0;
					}
					if (trace_)
					{
						buffer.Printf(" ADC ");
						tr = tr + buffer;
					}
				break;
				case 5:
					w=readMem(scratchpadRegister_[dataPointer_]) +((~accumulator_)&0xff) + dataFlag_;
					if (w>255)
					{
						accumulator_ = w&255;
						dataFlag_=1;
					}
					else
					{
						accumulator_=w&255;
						dataFlag_=0;
					}
					if (trace_)
					{
						buffer.Printf(" SDB ");
						tr = tr + buffer;
					}
 				break;
				case 6:
					df1= (dataFlag_) ? 128 : 0;
					dataFlag_ = (accumulator_ & 1) ? 1 : 0;
					accumulator_ = (accumulator_ >> 1) | df1;
					if (trace_)
					{
						buffer.Printf(" SHRC ");
						tr = tr + buffer;
					}
				break;
				case 7:
					w=accumulator_ +((~readMem(scratchpadRegister_[dataPointer_]))&0xff) + dataFlag_;
					if (w>255)
					{
						accumulator_ = w & 0xff;
						dataFlag_=1;
					}
					else
					{
						accumulator_=w&255;
						dataFlag_=0;
					}
					if (trace_)
					{
						buffer.Printf(" SMB ");
						tr = tr + buffer;
					}
				break;
				case 8:
					writeMem(scratchpadRegister_[dataPointer_], registerT_, false);
					if (trace_)
					{
						buffer.Printf(" SAV m(%X)",scratchpadRegister_[dataPointer_]);
						tr = tr + buffer;
					}
				break;
				case 9:
					registerT_= (dataPointer_<<4) | programCounter_;
					writeMem(scratchpadRegister_[2]--, registerT_, false);
					dataPointer_=programCounter_;
					if (trace_)
					{
						buffer.Printf(" MARK ");
						tr = tr + buffer;
					}
				break;
				case 10:
					flipFlopQ_=0;
					if (trace_)
					{
						tr = tr + " REQ";
					}
	//				trUpdated = true;
					switchQ(0);
					psaveAmplitudeChange(0);
				break;
				case 11:
					flipFlopQ_=1;
					if (trace_)
					{
						tr = tr + " SEQ";
					}
	//				trUpdated = true;
					switchQ(1);
					psaveAmplitudeChange(1);
				break;
				case 12:
					i=readMem(scratchpadRegister_[programCounter_]++);
					w=accumulator_ + i + dataFlag_;
					if (w>255)
					{
						accumulator_ = w & 255;
						dataFlag_=1;
					}
					else
					{
						accumulator_=w;
						dataFlag_=0;
					}
					if (trace_)
					{
						buffer.Printf(" ADC %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 13:
					i=readMem(scratchpadRegister_[programCounter_]++);
					w=i +((~accumulator_)&0xff) + dataFlag_;
					if (w>255)
					{
						accumulator_ = w & 0xff;
						dataFlag_=1;
					}
					else
					{
						accumulator_=w&255;
						dataFlag_=0;
					}
					if (trace_)
					{
						buffer.Printf(" SDBI %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 14:
					df1= (dataFlag_ & 1) ? 1: 0;
					dataFlag_ = (accumulator_ & 128) ? 1 : 0;
					accumulator_ = (accumulator_ << 1) | df1;
					if (trace_)
					{
						buffer.Printf(" SHLC ");
						tr = tr + buffer;
					}
				break;
				case 15:
					i= (~readMem(scratchpadRegister_[programCounter_]++)) & 0xff;
					w=accumulator_ + i + dataFlag_;
					if (w>255)
					{
						accumulator_ = w & 0xff;
						dataFlag_=1;
					}
					else
					{
						accumulator_=w&255;
						dataFlag_=0;
					}
					if (trace_)
					{
						buffer.Printf(" SMBI %02X ",i);
						tr = tr + buffer;
					}
				break;
			}
		break;
		case 8:
			accumulator_= (scratchpadRegister_[n] & 255);
			if (trace_)
			{
				buffer.Printf(" GLO %X       D=%X",n,accumulator_);
				tr = tr + buffer;
			}
		break;
		case 9:
			accumulator_= (scratchpadRegister_[n] >> 8);
			if (trace_)
			{
				buffer.Printf(" GHI %X       D=%X",n,accumulator_);
				tr = tr + buffer;
			}
		break;
		case 10:
			scratchpadRegister_[n]= (scratchpadRegister_[n] & 0xff00) | accumulator_;
			if (trace_)
			{
				buffer.Printf(" PLO %X       R%X = %04X ",n,n,scratchpadRegister_[n]);
				tr = tr + buffer;
			}
		break;
		case 11:
			scratchpadRegister_[n]= (scratchpadRegister_[n] & 0x00ff) |(accumulator_<<8);
			if (trace_)
			{
				buffer.Printf(" PHI %X       R%X = %04X ",n,n,scratchpadRegister_[n]);
				tr = tr + buffer;
			}
		break;
		case 12:
			h=readMem(scratchpadRegister_[programCounter_]);
			l=readMem((Word) (scratchpadRegister_[programCounter_]+1));
			cpuCycles_ += 1;
			w= (h<<8)|l;
			switch(n)
			{
				case 0:
					scratchpadRegister_[programCounter_]=w;
					if (trace_)
					{
						buffer.Printf(" LBR %02X%02X ",h,l);
						tr = tr + buffer;
					}
				break;
				case 1:
					if (flipFlopQ_) scratchpadRegister_[programCounter_]=w;
					else scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LBQ %02X%02X ",h,l);
						tr = tr + buffer;
					}
				break;
				case 2:
					if (!accumulator_) scratchpadRegister_[programCounter_]=w;
					else scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LBZ %02X%02X ",h,l);
						tr = tr + buffer;
					}
				break;
				case 3:
					if (dataFlag_) scratchpadRegister_[programCounter_]=w;
					else scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LBDF %02X%02X ",h,l);
						tr = tr + buffer;
					}
				break;
				case 4:
					if (trace_)
					{
						buffer.Printf(" NOP ");
						tr = tr + buffer;
					}
				break;
				case 5:
					if (!flipFlopQ_) scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LSNQ ");
						tr = tr + buffer;
					}
				break;
				case 6:
					if (accumulator_) scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LSNZ ");
						tr = tr + buffer;
					}
				break;
				case 7:
					if (!dataFlag_) scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LSNF ");
						tr = tr + buffer;
					}
				break;
				case 8:
					scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" NLBR ");
						tr = tr + buffer;
					}
				break;
				case 9:
					if (!flipFlopQ_) scratchpadRegister_[programCounter_]=w;
					else scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LBNQ %02X%02X ",h,l);
						tr = tr + buffer;
					}
				break;
				case 10:
					if (accumulator_) scratchpadRegister_[programCounter_]=w;
					else scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LBNZ %02X%02X ",h,l);
						tr = tr + buffer;
					}
				break;
				case 11:
					if (!dataFlag_) scratchpadRegister_[programCounter_]=w;
					else scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LBNF %02X%02X ",h,l);
						tr = tr + buffer;
					}
				break;
				case 12:
					if (interruptEnable_) scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LSIE ");
						tr = tr + buffer;
					}
				break;
				case 13:
					if (flipFlopQ_) scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LSQ ");
						tr = tr + buffer;
					}
				break;
				case 14:
					if (!accumulator_) scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LSZ ");
						tr = tr + buffer;
					}
				break;
				case 15:
					if (dataFlag_) scratchpadRegister_[programCounter_]+=2;
					if (trace_)
					{
						buffer.Printf(" LSDF ");
						tr = tr + buffer;
					}
				break;
			}
			machineCycle();
		break;
		case 13:
			programCounter_=n;
			if (trace_)
			{
				buffer.Printf(" SEP %X ",n);
				tr = tr + buffer;
			}
		break;
		case 14:
			dataPointer_=n;
			if (trace_)
			{
				buffer.Printf(" SEX %X ",n);
				tr = tr + buffer;
			}
		break;
		case 15:
			switch(n)
			{
				case 0:
					accumulator_=readMem(scratchpadRegister_[dataPointer_]);
					if (trace_)
					{
						buffer.Printf(" LDX         D=m(%X)=%X",scratchpadRegister_[dataPointer_],accumulator_);
						tr = tr + buffer;
					}
				break;
				case 1:
					accumulator_=readMem(scratchpadRegister_[dataPointer_]) | accumulator_;
					if (trace_)
					{
						buffer.Printf(" OR         D=%02X",accumulator_);
						tr = tr + buffer;
					}
				break;
				case 2:
					accumulator_=readMem(scratchpadRegister_[dataPointer_]) & accumulator_;
					if (trace_) {
						buffer.Printf(" AND         D=%02X",accumulator_);
						tr = tr + buffer;
					}
				break;
				case 3:
					accumulator_=readMem(scratchpadRegister_[dataPointer_]) ^ accumulator_;
					if (trace_)
					{
						buffer.Printf(" XOR         D=%02X",accumulator_);
						tr = tr + buffer;
					}
				break;
				case 4:
					w=accumulator_ + readMem(scratchpadRegister_[dataPointer_]);
					if (w>255)
					{
						accumulator_ = w & 255;
						dataFlag_=1;
					}
					else
					{
						accumulator_=w;
						dataFlag_=0;
					}
					if (trace_)
					{
						buffer.Printf(" ADD         D=%02X",accumulator_);
						tr = tr + buffer;
					}
				break;
				case 5:
					w=readMem(scratchpadRegister_[dataPointer_]) +((~accumulator_)&0xff)+1;
					if (w>255)
					{
						accumulator_ = w & 0xff;
						dataFlag_=1;
					}
					else
					{
						accumulator_=w&255;
						dataFlag_=0;
					}
					if (trace_)
					{
						buffer.Printf(" SD ");
						tr = tr + buffer;
					}
 				break;
				case 6:
					dataFlag_= (accumulator_ & 1)? 1 : 0;
					accumulator_=accumulator_>>1;
					if (trace_)
					{
						buffer.Printf(" SHR         D=%02X",accumulator_);
						tr = tr + buffer;
					}
				break;
				case 7:
					w=accumulator_+((~readMem(scratchpadRegister_[dataPointer_]))&0xff)+1;
					if (w>255)
					{
						accumulator_ = w & 0xff;
						dataFlag_=1;
					}
					else
					{
						accumulator_=w&255;
						dataFlag_=0;
					}
					if (trace_)
					{
						buffer.Printf(" SM ");
						tr = tr + buffer;
					}
				break;
				case 8:
					accumulator_=readMem(scratchpadRegister_[programCounter_]++);
					if (trace_)
					{
						buffer.Printf(" LDI %02X",accumulator_);
						tr = tr + buffer;
					}
				break;
				case 9:
					i=readMem(scratchpadRegister_[programCounter_]++);
					accumulator_ |= i;
					if (trace_)
					{
						buffer.Printf(" ORI %02X      D=%02X",i,accumulator_);
						tr = tr + buffer;
					}
				break;
				case 10:
					i=readMem(scratchpadRegister_[programCounter_]++);
					accumulator_ &= i;
					if (trace_)
					{
						buffer.Printf(" ANI %02X      D=%02X",i,accumulator_);
						tr = tr + buffer;
					}
				break;
				case 11:
					i=readMem(scratchpadRegister_[programCounter_]++);
					accumulator_ ^= i;
					if (trace_)
					{
						buffer.Printf(" XRI %02X      D=%02X",i,accumulator_);
						tr = tr + buffer;
					}
				break;
				case 12:
					i=readMem(scratchpadRegister_[programCounter_]++);
					w=accumulator_ + i;
					if (w>255)
					{
						accumulator_ = w & 255;
						dataFlag_=1;
					}
					else
					{
						accumulator_=w;
						dataFlag_=0;
					}
					if (trace_)
					{
						buffer.Printf(" ADI %02X      D=%02X",i,accumulator_);
						tr = tr + buffer;
					}
 				break;
				case 13:
					i=readMem(scratchpadRegister_[programCounter_]++);
					w=i+((~accumulator_)&0xff)+1;
					if (w>255)
					{
						accumulator_ = w&0xff;
						dataFlag_=1;
					}
					else
					{
						accumulator_=w&255;
						dataFlag_=0;
					}
					if (trace_)
					{
						buffer.Printf(" SDI %02X ",i);
						tr = tr + buffer;
					}
				break;
				case 14:
					dataFlag_= (accumulator_ & 128)? 1 : 0;
					accumulator_=accumulator_<<1;
					if (trace_)
					{
						buffer.Printf(" SHL         D=%02X",accumulator_);
						tr = tr + buffer;
					}
				break;
				case 15:
					i= (~readMem(scratchpadRegister_[programCounter_]++))&0xff;
					w=accumulator_+i+1;
					if (w>255)
					{
						accumulator_ = w&0xff;
						dataFlag_=1;
					}
					else
					{
						accumulator_=w&255;
						dataFlag_=0;
					}
					if (trace_)
					{
						buffer.Printf(" SMI %02X      D=%X",(~i)&0xff,accumulator_);
 						tr = tr + buffer;
					}
				break;
			}
		break;
	}
	if (trace_ || trUpdated) p_Main->debugTrace(tr);
}

bool Cdp1802::readIntelFile(wxString fileName, int memoryType, long end, bool showFilename)
{
	wxTextFile inFile;
	wxString line, strValue;
	long count;
	long address;
	long value;
	int spaces;
	bool overloaded = false;
	Word start = 0xffff;
	Word last = 0;

	if (inFile.Open(fileName))
	{
		for (line=inFile.GetFirstLine(); !inFile.Eof(); line=inFile.GetNextLine())
		{
			spaces = 0;
			int maxSpaces = 6;
			if (line.Len() < 6)  maxSpaces = line.Len();
			for (int i=0; i<maxSpaces; i++) if (line[i] == 32) spaces++;
			if (spaces == 0)
			{
				strValue = line.Mid(1, 2);
				strValue.ToLong(&count, 16);

				strValue = line.Mid(3, 4);
				strValue.ToLong(&address, 16);

				strValue = line.Mid(7, 2);
				strValue.ToLong(&value, 16);

				if (value == 1)
				{
					inFile.Close();
					if (overloaded)
					{
						wxString endStr;
						endStr.Printf("%04X", (int)end);
						p_Main->errorMessage("Attempt to load after address " + endStr);
					}
					setAddress(showFilename, start, last);
					return true;
				}
				if (address < start)
					start = address;
				for (int i=0; i<count; i++)
				{
					strValue = line.Mid((i*2)+9, 2);
					strValue.ToLong(&value, 16);
					if (memoryType != NOCHANGE)
						defineMemoryType(address, memoryType);
					if (address < end)
						writeMem(address,(Byte)value, true);
					else
						overloaded = true;
					address++;
				}
				if (address > last)
					last = address;
			}
			else
			{
				strValue = line.Mid(1, 4);
				strValue.ToLong(&address, 16);
				for (size_t i=5; i<=line.Len(); i++)
				{
					if ((line[i] >= '0' && line [i] <= '9') ||
						(line[i] >= 'A' && line [i] <= 'F') ||
						(line[i] >= 'a' && line [i] <= 'f'))
					{
						strValue = line.Mid(i, 2);
						if (strValue.ToLong(&value, 16))
						{
							value &= 255;
							if (memoryType != NOCHANGE)
								defineMemoryType(address, memoryType);
							if (address < end)
								writeMem(address,(Byte)value, true);
							else
								overloaded = true;
							address++;
							i++;
						}
					}
				}
			}
		}
		inFile.Close();
		if (overloaded)
		{
			wxString endStr;
			endStr.Printf("%04X", (int)end);
			p_Main->errorMessage("Attempt to load after address " + endStr);
		}
		setAddress(showFilename, start, last);
		return true;
	}
	else
	{
		p_Main->errorMessage("Error reading " + fileName);
		return false;
	}
}

bool Cdp1802::readLstFile(wxString fileName, int memoryType, long end, bool showFilename)
{
	wxTextFile inFile;
	wxString line, strValue;
	long address = 0;
	long value;
	bool overloaded = false;
	Word start = 0xffff;
	Word last = 0;

	if (inFile.Open(fileName))
	{
		for (line=inFile.GetFirstLine(); !inFile.Eof(); line=inFile.GetNextLine())
		{
			if (line.GetChar(0) != ' ')
			{
				strValue = line.Mid(0, 4);
				strValue.ToLong(&address, 16);
			}

			if (line.GetChar(4) != ' ')
			{
				size_t i=6;
				value = 0;
				Byte bit = 0x80;
				while ((line.GetChar(i) == ' ') || (line.GetChar(i) == 'x'))
				{
					if (line.GetChar(i) == 'x')
						value |= bit;
					bit >>= 1;
					i++;
				}
				if (memoryType != NOCHANGE)
					defineMemoryType(address, memoryType);
				writeMem(address,(Byte)value, true);
				address++;
/*				size_t i=6;
				for (int j=0; j<10;j++)
				{
					value = 0;
					Byte bit = 0x80;
					while ((line.GetChar(i) == '0') || (line.GetChar(i) == '1'))
					{
						if (line.GetChar(i) == '1')
							value |= bit;
						bit >>= 1;
						i++;
					}
					defineMemoryType(address, memoryType);
					writeMem(address,(Byte)value, true);
					address++;
					i+=2;
				}*/
			}
			else
			{
				size_t i=5;
				while (line.GetChar(i) != ' ')
				{
					strValue = line.Mid(i, 2);
					if (strValue.ToLong(&value, 16))
					{
						value &= 255;
						if (memoryType != NOCHANGE)
							defineMemoryType(address, memoryType);
						if (address < end)
							writeMem(address,(Byte)value, true);
						else
							overloaded = true;
						address++;
						i+=2;
					}
				}
			}
		}
		inFile.Close();
		if (overloaded)
		{
			wxString endStr;
			endStr.Printf("%04X", (int)end);
			p_Main->errorMessage("Attempt to load after address " + endStr);
		}
		setAddress(showFilename, start, last);
		return true;
	}
	else
	{
		p_Main->errorMessage("Error reading " + fileName);
		return false;
	}
}

void Cdp1802::saveIntelFile(wxString fileName, long start, long end)
{
	wxTextFile outputFile;
	wxString line, byteStr;
	int checkSum;

	if (!fileName.empty())
	{
		if (wxFile::Exists(fileName))
		{
			outputFile.Open(fileName);
			outputFile.Clear();
		}
		else
			outputFile.Create(fileName);

		while (start < end)
		{
			line.Printf(":%02X%04X%02X", 0x10, (int)start, 0x00);
			checkSum = 0x10+((start>>8)&0xff)+(start&0xff);
			for (int i = 0; i<16; i++)
			{
				checkSum += readMem(start);
				byteStr.Printf("%02X", readMem(start));
				line += byteStr;
				start++;
			}
			checkSum = ((checkSum ^ 0xff) + 1) & 0xff;
			byteStr.Printf("%02X", checkSum);
			line += byteStr;
			outputFile.AddLine(line);
		}
		outputFile.AddLine(":00000001FF");
		outputFile.Write();
	}
}

void Cdp1802::saveBinFile(wxString fileName, long start, long end)
{
	wxFile outputFile;
	size_t length;
	char buffer[65536];

	if (!fileName.empty())
	{
		if (outputFile.Create(fileName, true))
		{
			length = end-start+1;
			for (size_t i=0; i<length; i++)
			{
				buffer[i] = p_Computer->getRam(start);
				start++;
			}
			outputFile.Write(buffer, length);
			outputFile.Close();
		}
		else
		{
			p_Main->errorMessage("Error writing " + fileName);
			return;
		}
	}
}

bool Cdp1802::readBinFile(wxString fileName, int memoryType, Word address, long end, bool showFilename)
{
	wxFFile inFile;
	size_t length;
	char buffer[65535];
	bool overloaded = false;
	Word start;

	start = address;
	if (inFile.Open(fileName, "rb"))
	{
		length = inFile.Read(buffer, 65535);
		for (size_t i=0; i<length; i++)
		{
			if (memoryType != NOCHANGE)
				defineMemoryType(address, memoryType);
			if (address < end)
				writeMem(address,(Byte)buffer[i], true);
			else
				overloaded = true;
			address++;
		}
		inFile.Close();
		if (overloaded)
		{
			wxString endStr;
			endStr.Printf("%04X", (int)end);
			p_Main->errorMessage("Attempt to load after address " + endStr);
		}
		setAddress(showFilename, start, address-1);
		return true;
	}
	else
	{
		p_Main->errorMessage("Error reading " + fileName);
		return false;
	}
}

void Cdp1802::setAddress(bool showFilename, Word start, Word end)
{
	if (showFilename)
	{
		wxString gui = p_Main->getRunningComputerStr();
		wxString valueString;
		switch (computerType_) 
		{
			case ETI:
				valueString.Printf("%04X", (int)start);
				p_Main->setTextCtrl("SaveStartEti", valueString);
				writeMem(0x400, (start>>8) & 0xff, false);
				writeMem(0x401, (start & 0xff), false);
				valueString.Printf("%04X", (int)end);
				p_Main->setTextCtrl("SaveEndEti", valueString);
				writeMem(0x402, ((end)>>8) & 0xff, false);
				writeMem(0x403, ((end) & 0xff), false);
			break;

			case CIDELSA:
			case STUDIO:
			case VISICOM:
			case VICTORY:
			break;

			default:
				valueString.Printf("%04X", (int)start);
				p_Main->setTextCtrl("SaveStart"+gui, valueString);
				valueString.Printf("%04X", (int)end);
				p_Main->setTextCtrl("SaveEnd"+gui, valueString);
			break;

		}
	}
	if ((computerType_ == ELF) || (computerType_ == ELFII) || (computerType_ == SUPERELF))
	{
		if ((mainMemory_[start] == 0x90) && (mainMemory_[start+1] == 0xa1) && (mainMemory_[start+2] == 0xb3))
		{
			baseGiantBoard_ = start;
		}
		if ((mainMemory_[start+0x55] == 0xd5) && (mainMemory_[start+0x56] == 0xb8) && (mainMemory_[start+0x57] == 0xd5) && (mainMemory_[start+0x58] == 0xa8))
		{
			baseQuestLoader_ = start;
		}
	}
	checkLoadedSoftware();
}

void Cdp1802::checkLoadedSoftware()
{
	if (loadedProgram_ == NOPROGRAM)
	{
		if ((computerType_ == ELFII) || (computerType_ == SUPERELF) || (computerType_ == ELF))
		{
			if ((mainMemory_[0] == 0xc0) && (mainMemory_[1] == 0x25) && (mainMemory_[2] == 0xf4))
			{
				loadedProgram_ = SUPERBASICV1;
				basicExecAddress_[BASICADDR_KEY] = BASICADDR_KEY_SB1;
				basicExecAddress_[BASICADDR_READY] = BASICADDR_READY_SB1;
				basicExecAddress_[BASICADDR_KEY_VT_RESTART] = BASICADDR_VT_RESTART_SB1;
				basicExecAddress_[BASICADDR_KEY_VT_INPUT] = BASICADDR_VT_INPUT_SB1;
				p_Main->enableMemAccessGui(true);
			}
			if ((mainMemory_[0] == 0xc0) && (mainMemory_[1] == 0x1d) && (mainMemory_[2] == 0x39) && (mainMemory_[3] == 0xc0))
			{
				loadedProgram_ = SUPERBASICV3;
				basicExecAddress_[BASICADDR_KEY] = BASICADDR_KEY_SB3;
				basicExecAddress_[BASICADDR_READY] = BASICADDR_READY_SB3;
				basicExecAddress_[BASICADDR_KEY_VT_RESTART] = BASICADDR_VT_RESTART_SB3;
				basicExecAddress_[BASICADDR_KEY_VT_INPUT] = BASICADDR_VT_INPUT_SB3;
				p_Main->enableMemAccessGui(true);
			}
			if ((mainMemory_[0x100] == 0xc0) && (mainMemory_[0x101] == 0x18) && (mainMemory_[0x102] == 0x00) && (mainMemory_[0x103] == 0xc0))
			{
				loadedProgram_ = SUPERBASICV5;
				basicExecAddress_[BASICADDR_KEY] = BASICADDR_KEY_SB5;
				basicExecAddress_[BASICADDR_READY] = BASICADDR_READY_SB5;
				basicExecAddress_[BASICADDR_KEY_VT_RESTART] = BASICADDR_VT_RESTART_SB5;
				basicExecAddress_[BASICADDR_KEY_VT_INPUT] = BASICADDR_VT_INPUT_SB5;
				p_Main->enableMemAccessGui(true);
			}
			if ((mainMemory_[0x100] == 0xc0) && (mainMemory_[0x101] == 0x2f) && (mainMemory_[0x102] == 0x00) && (mainMemory_[0x103] == 0xc0))
			{
				loadedProgram_ = SUPERBASICV6;
				basicExecAddress_[BASICADDR_KEY] = BASICADDR_KEY_SB6;
				basicExecAddress_[BASICADDR_READY] = BASICADDR_READY_SB6;
				basicExecAddress_[BASICADDR_KEY_VT_RESTART] = BASICADDR_VT_RESTART_SB6;
				basicExecAddress_[BASICADDR_KEY_VT_INPUT] = BASICADDR_VT_INPUT_SB6;
				p_Main->enableMemAccessGui(true);
			}
			if ((mainMemory_[0x2202] == 0xc0) && (mainMemory_[0x2203] == 0x28) && (mainMemory_[0x2204] == 0x65) && (mainMemory_[0x226f] == 0x52))
			{
				loadedProgram_ = RCABASIC3;
				basicExecAddress_[BASICADDR_READY] = BASICADDR_READY_RCA3;
				basicExecAddress_[BASICADDR_KEY_VT_RESTART] = BASICADDR_VT_RESTART_RCA;
				basicExecAddress_[BASICADDR_KEY_VT_INPUT] = BASICADDR_VT_INPUT_RCA;
				p_Main->enableMemAccessGui(true);
			}
			if ((mainMemory_[0x2202] == 0xc0) && (mainMemory_[0x2203] == 0x28) && (mainMemory_[0x2204] == 0x65) && (mainMemory_[0x226f] == 0x55))
			{
				loadedProgram_ = RCABASIC4;
				basicExecAddress_[BASICADDR_READY] = BASICADDR_READY_RCA4;
				basicExecAddress_[BASICADDR_KEY_VT_RESTART] = BASICADDR_VT_RESTART_RCA;
				basicExecAddress_[BASICADDR_KEY_VT_INPUT] = BASICADDR_VT_INPUT_RCA;
				p_Main->enableMemAccessGui(true);
			}
			if ((mainMemory_[0xc000] == 0x90) && (mainMemory_[0xc001] == 0xb4) && (mainMemory_[0xc002] == 0xb5) && (mainMemory_[0xc003] == 0xfc))
			{
				loadedProgram_ = MINIMON;
				p_Main->enableMemAccessGui(true);
			}
			if ((mainMemory_[0xc000] == 0xc4) && (mainMemory_[0xc001] == 0xb4) && (mainMemory_[0xc002] == 0xf8) && (mainMemory_[0xc003] == 0xc0))
			{
				loadedProgram_ = GOLDMON;
				p_Main->enableMemAccessGui(true);
			}
			if ((mainMemory_[0x100] == 0xc4) && (mainMemory_[0x101] == 0x30) && (mainMemory_[0x102] == 0xb0))
			{
				loadedProgram_ = TINYBASIC;
				p_Main->enableMemAccessGui(true);
			}
		}
		if (computerType_ == COSMICOS)
		{
			if ((mainMemory_[0xc0f7] == 0x22) && (mainMemory_[0xc0f8] == 0x73) && (mainMemory_[0xc0f9] == 0x3e) && (mainMemory_[0xc0fa] == 0))
				loadedProgram_ = HEXMON;
			if ((mainMemory_[0xc084] == 0x4e) && (mainMemory_[0xc085] == 0x4f) && (mainMemory_[0xc086] == 0x20) && (mainMemory_[0xc087] == 0x43))
				loadedProgram_ = ASCIIMON;
		}
	}
	if (loadedOs_ == NOOS)
	{
		if ((computerType_ == ELFII) || (computerType_ == SUPERELF) || (computerType_ == ELF))
		{
			if ((mainMemory_[0xf900] == 0xf8) && (mainMemory_[0xf901] == 0xf9) && (mainMemory_[0xf902] == 0xb6))
			{
				loadedOs_ = ELFOS;
			}
		}
	}
}

bool Cdp1802::readProgram(wxString romDir, wxString FileRef, int memoryType, Word address, bool showFilename)
{
	wxString fileName = p_Main->getTextValue(FileRef);

	if (fileName.Len() != 0)
	{
		return readFile(romDir+fileName, memoryType, address, 0x10000, showFilename);
	}
	else return false;
}

bool Cdp1802::readProgramCombo(wxString romDir, wxString FileRef, int memoryType, Word address, bool showFilename)
{
	wxString fileName = p_Main->getComboValue(FileRef);
	bool ret;

	if (FileRef == "MainRomCidelsa")
	{
		if ((fileName == "des a 2.ic4") || (fileName == "des b 2.ic5") || (fileName == "des c 2.ic6") || (fileName == "des d 2.ic7"))
		{
			ret = readFile(romDir + "des a 2.ic4", memoryType, address, 0x10000, showFilename);
			ret = ret | readFile(romDir + "des b 2.ic5", memoryType, address+0x800, 0x10000, showFilename);
			ret = ret | readFile(romDir + "des c 2.ic6", memoryType, address+0x1000, 0x10000, showFilename);
			ret = ret | readFile(romDir + "des d 2.ic7", memoryType, address+0x1800, 0x10000, showFilename);
			return ret;
		}

		if ((fileName == "destryea_1") || (fileName == "destryea_2") || (fileName == "destryea_3") || (fileName == "destryea_4"))
		{
			ret = readFile(romDir + "destryea_1", memoryType, address, 0x10000, showFilename);
			ret = ret | readFile(romDir + "destryea_2", memoryType, address+0x800, 0x10000, showFilename);
			ret = ret | readFile(romDir + "destryea_3" , memoryType, address+0x1000, 0x10000, showFilename);
			ret = ret | readFile(romDir + "destryea_4", memoryType, address+0x1800, 0x10000, showFilename);
			return ret;
		}

		if ((fileName == "alt a 1.ic7") || (fileName == "alt b 1.ic8") || (fileName == "alt c 1.ic9") || (fileName == "alt d 1.ic10") || (fileName == "alt e 1.ic11") || (fileName == "alt f 1.ic12"))
		{
			ret = readFile(romDir + "alt a 1.ic7", memoryType, address, 0x10000, showFilename);
			ret = ret | readFile(romDir + "alt b 1.ic8", memoryType, address+0x800, 0x10000, showFilename);
			ret = ret | readFile(romDir + "alt c 1.ic9" , memoryType, address+0x1000, 0x10000, showFilename);
			ret = ret | readFile(romDir + "alt d 1.ic10" , memoryType, address+0x1800, 0x10000, showFilename);
			ret = ret | readFile(romDir + "alt e 1.ic11" , memoryType, address+0x2000, 0x10000, showFilename);
			ret = ret | readFile(romDir + "alt f 1.ic12", memoryType, address+0x2800, 0x10000, showFilename);
			return ret;
		}

		if ((fileName == "dra a 1.ic10") || (fileName == "dra b 1.ic11") || (fileName == "dra c 1.ic12") || (fileName == "dra d 1.ic13") || (fileName == "dra e 1.ic14") || (fileName == "dra f 1.ic15") || (fileName == "dra g 1.ic16") || (fileName == "dra h 1.ic17"))
		{
			ret = readFile(romDir + "dra a 1.ic10", memoryType, address, 0x10000, showFilename);
			ret = ret | readFile(romDir + "dra b 1.ic11", memoryType, address+0x800, 0x10000, showFilename);
			ret = ret | readFile(romDir + "dra c 1.ic12" , memoryType, address+0x1000, 0x10000, showFilename);
			ret = ret | readFile(romDir + "dra d 1.ic13" , memoryType, address+0x1800, 0x10000, showFilename);
			ret = ret | readFile(romDir + "dra e 1.ic14" , memoryType, address+0x2000, 0x10000, showFilename);
			ret = ret | readFile(romDir + "dra f 1.ic15" , memoryType, address+0x2800, 0x10000, showFilename);
			ret = ret | readFile(romDir + "dra g 1.ic16" , memoryType, address+0x3000, 0x10000, showFilename);
			ret = ret | readFile(romDir + "dra h 1.ic17", memoryType, address+0x3800, 0x10000, showFilename);
			return ret;
		}
	}
	if (FileRef == "MainRomTmc600")
	{
		if ((fileName == "sb30") || (fileName == "sb31") || (fileName == "sb32") || (fileName == "sb33") || (fileName == "151182"))
		{
			ret = readFile(romDir + "sb30", memoryType, address, 0x10000, showFilename);
			ret = ret | readFile(romDir + "sb31", memoryType, address+0x1000, 0x10000, showFilename);
			ret = ret | readFile(romDir + "sb32", memoryType, address+0x2000, 0x10000, showFilename);
			ret = ret | readFile(romDir + "sb33", memoryType, address+0x3000, 0x10000, showFilename);
			return ret;
		}
	}

	if (FileRef == "MainRomPecom")
	{
		if ((fileName == "pecom64-1.bin") || (fileName == "pecom64-2.bin"))
		{
			ret = readFile(romDir + "pecom64-1.bin", memoryType, address, 0x10000, showFilename);
			ret = ret | readFile(romDir + "pecom64-2.bin", memoryType, address+0x4000, 0x10000, showFilename);
			return ret;
		}

		if ((fileName == "170887-rom1.bin") || (fileName == "170887-rom2.bin"))
		{
			ret = readFile(romDir + "170887-rom1.bin", memoryType, address, 0x10000, showFilename);
			ret = ret | readFile(romDir + "170887-rom2.bin", memoryType, address+0x4000, 0x10000, showFilename);
			return ret;
		}
	}

	if (fileName.Len() != 0)
	{
		return readFile(romDir+fileName, memoryType, address, 0x10000, showFilename);
	}
	else return false;
}

bool Cdp1802::readFile(wxString fileName, int memoryType, Word address, long end, bool showFilename)
{
	wxFFile inFile;
	char buffer[4];

	if (wxFile::Exists(fileName))
	{
		if (inFile.Open(fileName, "rb"))
		{
			inFile.Read(buffer, 4);
			inFile.Close();

			if (showFilename)
			{
				wxFileName swFullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
				p_Main->setSwName (swFullPath.GetName());
			}

			if (buffer[0] == ':')
				return readIntelFile(fileName, memoryType, end, showFilename);
			else if (buffer[0] == '0' && buffer[1] == '0' && buffer[2] == '0' && buffer[3] == '0')
				return readLstFile(fileName, memoryType, end, showFilename);
			else
				return readBinFile(fileName, memoryType, address, end, showFilename);
		}
		else
		{
			p_Main->errorMessage("Error reading " + fileName);
			return false;
		}
	}
	else
	{
		p_Main->errorMessage("File " + fileName + " not found");
		return false;
	}
}

void Cdp1802::showTime()
{
	wxString print_buffer;
	int h,m,s, i1;
	double f1,f2;
	time_t endTime;

	if (cpuCycles_ != 0)
	{
		endTime = wxGetLocalTime();
		s = endTime - startTime_;
		h = s / 3600;
		s -= (h * 3600);
		m = s / 60;
		s -= (m * 60);
		f2 = endTime - startTime_;
		f1 = cpuCycles_;
		f1 /= f2;
		f1 = f1 / 1000000 * 8;

		print_buffer.Printf("Cycles executed: %ld", cpuCycles_);
		p_Main->message(print_buffer);
		print_buffer.Printf("Run Time: %02d:%02d:%02d",h,m,s);
		p_Main->message(print_buffer);
		print_buffer.Printf("Effective clock: %8.3f Mhz",f1);
		p_Main->message(print_buffer);
		if ((computerType_ == COMX) || (computerType_ == CIDELSA) || (computerType_ == TMC600) || (computerType_ == PECOM))
		{
			i1 = (int) (p_Video->getVideoSyncCount() / f2);
			print_buffer.Printf("CDP1870 Vertical Frequency: %d Hz",i1);
			p_Main->message(print_buffer);
		}
/*			if (computerType_ == ELFII)
			{
				i1 = (int) (p_Elf2->getVideoSyncCount() / f2);
				if (i1 != 0)
				{
					print_buffer.Printf("CDP1870 Vertical Frequency: %d Hz",i1);
					p_Main->message(print_buffer);
				}
			}*/
		p_Main->message("");
	}
}

void Cdp1802::setDebugMode (bool debugModeNew, bool trace, bool traceDma, bool traceInt, bitset<8> traceInp, bitset<8> traceOut)
{
	if (!debugMode_ && debugModeNew)
	{
		p_Main->resetDisplay();
	}

	if (debugMode_ && !debugModeNew)
	{
		trace_ = false;
		debugMode_ = false;
		return;
	}

	debugMode_ = debugModeNew;
	trace_ = trace;
	traceDma_ = traceDma;
	traceInt_ = traceInt;
	traceInp_ = traceInp;
	traceOut_ = traceOut;
}

void Cdp1802::debugTrace (wxString text)
{
	if (trace_)
		p_Main->debugTrace(text);
}
