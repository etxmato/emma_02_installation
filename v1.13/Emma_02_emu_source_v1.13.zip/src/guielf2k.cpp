/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guielf2k.h"

BEGIN_EVENT_TABLE(GuiElf2K, GuiCosmicos)

	EVT_BUTTON(XRCID("RomButtonElf2K"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("IDE_ButtonElf2K"), GuiMain::onIde)
	EVT_BUTTON(XRCID("Eject_IDEElf2K"), GuiMain::onIdeEject)
	EVT_BUTTON(XRCID("CharRomButtonElf2K"), GuiMain::onCharRom)
	EVT_BUTTON(XRCID("VtCharRomButtonElf2K"), GuiMain::onVtCharRom)
	EVT_BUTTON(XRCID("KeyFileButtonElf2K"), GuiMain::onKeyFile)
	EVT_BUTTON(XRCID("EjectKeyFileElf2K"), GuiMain::onKeyFileEject)
	EVT_CHOICE(XRCID("VTTypeElf2K"), GuiMain::onVT100)
	EVT_SPINCTRL(XRCID("ZoomElf2K"), GuiMain::onZoom)
	EVT_BUTTON(XRCID("FullScreenF3Elf2K"), GuiMain::onFullScreen)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeElf2K"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeElf2K"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonElf2K"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Elf2K"), GuiMain::onScreenDump)
	EVT_BUTTON(XRCID("DP_ButtonElf2K"), GuiMain::onDp)
	EVT_BUTTON(XRCID("VtSetupElf2K"), GuiMain::onVtSetup)
	EVT_BUTTON(XRCID("SaveButtonElf2K"), GuiMain::onSaveButton)
	EVT_BUTTON(XRCID("LoadButtonElf2K"), GuiMain::onLoadButton)
	EVT_TEXT(XRCID(_T("ClockElf2K")), GuiMain::onClock)
	EVT_CHECKBOX(XRCID("InterlaceElf2K"), GuiMain::onInterlace)
	EVT_CHECKBOX(XRCID("StretchDotElf2K"), GuiMain::onStretchDot)
	EVT_BUTTON(XRCID(_T("KeyMapElf2K")), Main::onHexKeyDef)
	EVT_BUTTON(XRCID(_T("ColoursElf2K")), Main::onColoursDef)

	EVT_CHOICE(XRCID("Elf2KVideoType"), GuiElf2K::onElf2KVideoType)
	EVT_CHOICE(XRCID("Elf2KKeyboard"), GuiElf2K::onElf2KKeyboard)
	EVT_CHECKBOX(XRCID("Elf2KForceUC"), GuiElf2K::onElf2KForceUpperCase)
	EVT_CHECKBOX(XRCID("Elf2KControlWindows"), GuiElf2K::onElf2KControlWindows)
	EVT_CHECKBOX(XRCID("Elf2KNvr"), GuiElf2K::onElf2KNvr)
	EVT_CHECKBOX(XRCID("Elf2KRtc"), GuiElf2K::onElf2KRtc)
	EVT_CHECKBOX(XRCID("Elf2KSwitch"), GuiElf2K::onElf2KSwitch)
	EVT_CHECKBOX(XRCID("Elf2KHex"), GuiElf2K::onElf2KHex)
	EVT_CHECKBOX(XRCID("UartElf2K"), GuiElf2K::onElf2KUart)

END_EVENT_TABLE()

GuiElf2K::GuiElf2K(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiCosmicos(title, pos, size)
{
}

void GuiElf2K::readElf2KConfig()
{
	bool Cpu1805, forceUpperCase, serialLog, interlace, stretchDot;
	selectedComputer_ = ELF2K;

	conf[ELF2K].romDir_[MAINROM] = configPointer->Read(_T("/Elf2K/RomDir"), dataDir_ + "Elf2K" + pathSeparator_);
	conf[ELF2K].ramDir_ = configPointer->Read(_T("/Elf2K/RamDir"), dataDir_ + "Elf2K" + pathSeparator_);
	conf[ELF2K].mainDir_ = configPointer->Read(_T("/Elf2K/Dir"), dataDir_ + "Elf2K" + pathSeparator_);
	conf[ELF2K].ideDir_ = configPointer->Read(_T("/Elf2K/IDEDir"), dataDir_ + "Elf2K" + pathSeparator_);
	conf[ELF2K].charRomDir_ = configPointer->Read(_T("/Elf2K/CharRomDir"), dataDir_ + "Elf2K" + pathSeparator_);
	conf[ELF2K].vtCharRomDir_ = configPointer->Read(_T("/Elf2K/VtCharRomDir"), dataDir_ + "Elf2K" + pathSeparator_);
	conf[ELF2K].keyFileDir_ = configPointer->Read(_T("/Elf2K/KeyFileDir"), dataDir_ + "Elf2K" + pathSeparator_);
	configPointer->Read(_T("/Elf2K/Uart"), &elfConfiguration[ELF2K].useUart, false);
	XRCCTRL(*this, "UartElf2K", wxCheckBox)->SetValue(elfConfiguration[ELF2K].useUart);
	XRCCTRL(*this, "VTTypeElf2K", wxChoice)->SetSelection(configPointer->Read(_T("/Elf2K/VTType"), 0l));
	setBaudChoiceElf2K();
	elfConfiguration[ELF2K].baudR = configPointer->Read(_T("/Elf2K/BaudR"), 0l);
	baudChoiceR[ELF2K]->SetSelection(elfConfiguration[ELF2K].baudR);
	elfConfiguration[ELF2K].baudT = configPointer->Read(_T("/Elf2K/BaudT"), 0l);
	baudChoiceT[ELF2K]->SetSelection(elfConfiguration[ELF2K].baudT);
	setVtType("Elf2K", ELF2K, XRCCTRL(*this, "VTTypeElf2K", wxChoice)->GetSelection());
	baudTextR[ELF2K]->Enable((elfConfiguration[ELF2K].vtType != VTNONE) && elfConfiguration[ELF2K].useUart);
	baudChoiceR[ELF2K]->Enable((elfConfiguration[ELF2K].vtType != VTNONE) && elfConfiguration[ELF2K].useUart);
	baudTextT[ELF2K]->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
	baudChoiceT[ELF2K]->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
	XRCCTRL(*this, "KeyFileElf2K", wxTextCtrl)->SetValue(configPointer->Read(_T("/Elf2K/KeyFile"), ""));
	configPointer->Read(_T("/Elf2K/ForceUC"), &forceUpperCase, false);
	XRCCTRL(*this, "Elf2KForceUC", wxCheckBox)->SetValue(forceUpperCase);
	configPointer->Read(_T("/Elf2K/CpuMode"), &Cpu1805, false);
	XRCCTRL(*this, "Elf2KCpuMode", wxCheckBox)->SetValue(Cpu1805);
	configPointer->Read(_T("/Elf2K/SerialLog"), &serialLog, false);
	XRCCTRL(*this, "SerialLogElf2K", wxCheckBox)->SetValue(serialLog);
	XRCCTRL(*this, "MainRomElf2K", wxComboBox)->SetValue(configPointer->Read(_T("/Elf2K/MainRom"), "v87a.bin"));
	XRCCTRL(*this, "IdeFileElf2K", wxTextCtrl)->SetValue(configPointer->Read(_T("/Elf2K/IdeFile"), "elf2k.ide"));
	XRCCTRL(*this, "CharRomElf2K", wxComboBox)->SetValue(configPointer->Read(_T("/Elf2K/I8275File"), "intel8275.bin"));
	XRCCTRL(*this, "VtCharRomElf2K", wxComboBox)->SetValue(configPointer->Read(_T("/Elf2K/VtCharRom"), "vt52.a.bin"));
	XRCCTRL(*this, "VtCharRomButtonElf2K", wxButton)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
	XRCCTRL(*this, "VtCharRomElf2K", wxComboBox)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
	XRCCTRL(*this, "SerialLogElf2K", wxCheckBox)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
	XRCCTRL(*this, "VtSetupElf2K", wxButton)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
	XRCCTRL(*this, "UartElf2K", wxCheckBox)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
	XRCCTRL(*this, "Elf2KVideoType", wxChoice)->SetSelection(configPointer->Read(_T("/Elf2K/VideoType"), 2l));
	setElf2KVideoType(XRCCTRL(*this, "Elf2KVideoType", wxChoice)->GetSelection());
	XRCCTRL(*this, "Elf2KKeyboard", wxChoice)->SetSelection(configPointer->Read(_T("/Elf2K/ElfKeyboard"), 2l));
	setElf2KKeyboard(XRCCTRL(*this, "Elf2KKeyboard", wxChoice)->GetSelection());
	XRCCTRL(*this, "ZoomElf2K", wxSpinCtrl)->SetValue(configPointer->Read(_T("/Elf2K/Zoom"), 1l));
	XRCCTRL(*this, "Elf2KShowAddress", wxTextCtrl)->SetValue(configPointer->Read(_T("/Elf2K/ShowAddressMs"), "100"));
	configPointer->Read(_T("/Elf2K/ControlWindows"), &elfConfiguration[ELF2K].useElfControlWindows, true);
	XRCCTRL(*this, "Elf2KControlWindows", wxCheckBox)->SetValue(elfConfiguration[ELF2K].useElfControlWindows);
	XRCCTRL(*this,_T("Elf2KShowAddress"),wxTextCtrl)->Enable(elfConfiguration[ELF2K].useElfControlWindows);
	XRCCTRL(*this,_T("Elf2KAddressText1"),wxStaticText)->Enable(elfConfiguration[ELF2K].useElfControlWindows);
	XRCCTRL(*this,_T("Elf2KAddressText2"),wxStaticText)->Enable(elfConfiguration[ELF2K].useElfControlWindows);
	configPointer->Read(_T("/Elf2K/Interlace"), &interlace, true);
	XRCCTRL(*this, "InterlaceElf2K", wxCheckBox)->SetValue(interlace);
	configPointer->Read(_T("/Elf2K/StretchDot"), &stretchDot, false);
	XRCCTRL(*this, "StretchDotElf2K", wxCheckBox)->SetValue(stretchDot);

	configPointer->Read(_T("/Elf2K/Nvr"), &elfConfiguration[ELF2K].nvr, true);
	XRCCTRL(*this, "Elf2KNvr", wxCheckBox)->SetValue(elfConfiguration[ELF2K].nvr);
	XRCCTRL(*this, "Elf2KClearRam", wxCheckBox)->Enable(elfConfiguration[ELF2K].nvr);
	configPointer->Read(_T("/Elf2K/Rtc"), &elfConfiguration[ELF2K].rtc, true);
	XRCCTRL(*this, "Elf2KRtc", wxCheckBox)->SetValue(elfConfiguration[ELF2K].rtc);
	XRCCTRL(*this, "Elf2KClearRtc", wxCheckBox)->Enable(elfConfiguration[ELF2K].rtc);
	configPointer->Read(_T("/Elf2K/Switch"), &elfConfiguration[ELF2K].useSwitch, false);
	XRCCTRL(*this, "Elf2KSwitch", wxCheckBox)->SetValue(elfConfiguration[ELF2K].useSwitch);
	configPointer->Read(_T("/Elf2K/Hex"), &elfConfiguration[ELF2K].useHex, false);
	XRCCTRL(*this, "Elf2KHex", wxCheckBox)->SetValue(elfConfiguration[ELF2K].useHex);

	XRCCTRL(*this, "ScreenDumpFileElf2K", wxComboBox)->SetValue(configPointer->Read(_T("/Elf2K/ScreenDumpFile"), "screendump.bmp"));
	conf[ELF2K].screenDumpFileDir_ = configPointer->Read(_T("/Elf2K/ScreenDumpFileDir"), dataDir_ + "Elf2K" + pathSeparator_);
	conf[ELF2K].volume_ = configPointer->Read(_T("/Elf2K/Volume"), 25l);
	XRCCTRL(*this, "VolumeElf2K", wxSlider)->SetValue(conf[ELF2K].volume_);

	conf[ELF2K].i8275X_ = configPointer->Read(_T("/Elf2K/I8275X"), mainWindowX_+windowInfo.mainwX);
	conf[ELF2K].i8275Y_ = configPointer->Read(_T("/Elf2K/I8275Y"), mainWindowY_);
	conf[ELF2K].pixieX_ = configPointer->Read(_T("/Elf2K/PixieX"), mainWindowX_+windowInfo.mainwX);
	conf[ELF2K].pixieY_ = configPointer->Read(_T("/Elf2K/PixieY"), mainWindowY_);
	conf[ELF2K].vtX_ = configPointer->Read(_T("/Elf2K/VtX"), mainWindowX_+windowInfo.mainwX);
	conf[ELF2K].vtY_ = configPointer->Read(_T("/Elf2K/VtY"), mainWindowY_);
	conf[ELF2K].mainX_ = configPointer->Read(_T("/Elf2K/Elf2KX"), mainWindowX_);
	conf[ELF2K].mainY_ = configPointer->Read(_T("/Elf2K/Elf2KY"), mainWindowY_+windowInfo.mainwY);
	switchX_ = configPointer->Read(_T("/Elf2K/SwitchX"), mainWindowX_+507+windowInfo.xBorder2);
	switchY_ = configPointer->Read(_T("/Elf2K/SwitchY"), mainWindowY_+478+windowInfo.yBorder2);
	conf[ELF2K].keypadX_ = configPointer->Read(_T("/Elf2K/HexX"), mainWindowX_+507+windowInfo.xBorder2);
	conf[ELF2K].keypadY_ = configPointer->Read(_T("/Elf2K/HexY"), mainWindowY_+478+windowInfo.yBorder2);

	conf[ELF2K].clock_ = configPointer->Read(_T("/Elf2K/Clock"), "3.5795");
	XRCCTRL(*this, _T("ClockElf2K"), wxTextCtrl)->ChangeValue(conf[ELF2K].clock_);

	elfConfiguration[ELF2K].usePortExtender = false;
	elfConfiguration[ELF2K].ideEnabled = true;
	elfConfiguration[ELF2K].fdcEnabled = false;
	elfConfiguration[ELF2K].useLedModule = false;
	elfConfiguration[ELF2K].useTape = false;
	conf[ELF2K].realCassetteLoad_ = false;
}

void GuiElf2K::writeElf2KConfig()
{
	configPointer->Write(_T("/Elf2K/RomDir"), conf[ELF2K].romDir_[MAINROM]);
	configPointer->Write(_T("/Elf2K/RamDir"), conf[ELF2K].ramDir_);
	configPointer->Write(_T("/Elf2K/Dir"), conf[ELF2K].mainDir_);
	configPointer->Write(_T("/Elf2K/IDEDir"), conf[ELF2K].ideDir_);
	configPointer->Write(_T("/Elf2K/CharRomDir"), conf[ELF2K].charRomDir_);
	configPointer->Write(_T("/Elf2K/VtCharRomDir"), conf[ELF2K].vtCharRomDir_);
	configPointer->Write(_T("/Elf2K/KeyFileDir"), conf[ELF2K].keyFileDir_);
	configPointer->Write(_T("/Elf2K/IdeFile"), XRCCTRL(*this, "IdeFileElf2K", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Elf2K/MainRom"), XRCCTRL(*this, "MainRomElf2K", wxComboBox)->GetValue());
	configPointer->Write(_T("/Elf2K/I8275File"), XRCCTRL(*this, "CharRomElf2K", wxComboBox)->GetValue());
	configPointer->Write(_T("/Elf2K/VtCharRom"), XRCCTRL(*this, "VtCharRomElf2K", wxComboBox)->GetValue());
	configPointer->Write(_T("/Elf2K/KeyFile"), XRCCTRL(*this, "KeyFileElf2K", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Elf2K/VTType"), XRCCTRL(*this, "VTTypeElf2K", wxChoice)->GetSelection());
	configPointer->Write(_T("/Elf2K/BaudR"), baudChoiceR[ELF2K]->GetSelection());
	configPointer->Write(_T("/Elf2K/BaudT"), baudChoiceT[ELF2K]->GetSelection());
	configPointer->Write(_T("/Elf2K/SerialLog"), XRCCTRL(*this, "SerialLogElf2K", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Elf2K/Uart"), XRCCTRL(*this, "UartElf2K", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Elf2K/VideoType"), XRCCTRL(*this, "Elf2KVideoType", wxChoice)->GetSelection());
	configPointer->Write(_T("/Elf2K/ElfKeyboard"), XRCCTRL(*this, "Elf2KKeyboard", wxChoice)->GetSelection());
	configPointer->Write(_T("/Elf2K/Zoom"), XRCCTRL(*this, "ZoomElf2K", wxSpinCtrl)->GetValue());
	configPointer->Write(_T("/Elf2K/ForceUC"), XRCCTRL(*this, "Elf2KForceUC", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Elf2K/ShowAddressMs"), XRCCTRL(*this, "Elf2KShowAddress", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Elf2K/Rtc"), XRCCTRL(*this, "Elf2KRtc", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Elf2K/Nvr"), XRCCTRL(*this, "Elf2KNvr", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Elf2K/Switch"), XRCCTRL(*this, "Elf2KSwitch", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Elf2K/Hex"), XRCCTRL(*this, "Elf2KHex", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Elf2K/ControlWindows"), XRCCTRL(*this, "Elf2KControlWindows", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Elf2K/Interlace"), XRCCTRL(*this, "InterlaceElf2K", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Elf2K/StretchDot"), XRCCTRL(*this, "StretchDotElf2K", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Elf2K/ScreenDumpFile"), XRCCTRL(*this, "ScreenDumpFileElf2K", wxComboBox)->GetValue());
	configPointer->Write(_T("/Elf2K/ScreenDumpFileDir"), conf[ELF2K].screenDumpFileDir_);
	configPointer->Write(_T("/Elf2K/CpuMode"), XRCCTRL(*this, "Elf2KCpuMode", wxCheckBox)->GetValue() );
	configPointer->Write(_T("/Elf2K/ForceUC"), XRCCTRL(*this, "Elf2KForceUC", wxCheckBox)->GetValue() );

	configPointer->Write(_T("/Elf2K/Volume"), XRCCTRL(*this, "VolumeElf2K", wxSlider)->GetValue());

	if (conf[ELF2K].i8275X_ > 0)
		configPointer->Write(_T("/Elf2K/I8275X"), conf[ELF2K].i8275X_);
	if (conf[ELF2K].i8275Y_ > 0)
		configPointer->Write(_T("/Elf2K/I8275Y"), conf[ELF2K].i8275Y_);
	if (conf[ELF2K].pixieX_ > 0)
		configPointer->Write(_T("/Elf2K/PixieX"), conf[ELF2K].pixieX_);
	if (conf[ELF2K].pixieY_ > 0)
		configPointer->Write(_T("/Elf2K/PixieY"), conf[ELF2K].pixieY_);
	if (conf[ELF2K].vtX_ > 0)
		configPointer->Write(_T("/Elf2K/VtX"), conf[ELF2K].vtX_);
	if (conf[ELF2K].vtY_ > 0)
		configPointer->Write(_T("/Elf2K/VtY"), conf[ELF2K].vtY_);
	if (switchX_ > 0)
		configPointer->Write(_T("/Elf2K/SwitchX"), switchX_);
	if (switchY_ > 0)
		configPointer->Write(_T("/Elf2K/SwitchY"), switchY_);
	if (conf[ELF2K].keypadX_ > 0)
		configPointer->Write(_T("/Elf2K/HexX"), conf[ELF2K].keypadX_);
	if (conf[ELF2K].keypadY_ > 0)
		configPointer->Write(_T("/Elf2K/HexY"), conf[ELF2K].keypadY_);
	if (conf[ELF2K].mainX_ > 0)
		configPointer->Write(_T("/Elf2K/Elf2KX"), conf[ELF2K].mainX_);
	if (conf[ELF2K].mainY_ > 0)
		configPointer->Write(_T("/Elf2K/Elf2KY"), conf[ELF2K].mainY_);

	configPointer->Write(_T("/Elf2K/Clock"), conf[ELF2K].clock_);

	delete baudChoiceR[ELF2K];
	delete baudChoiceT[ELF2K];
}

void GuiElf2K::onElf2KVideoType(wxCommandEvent&event)
{
	setElf2KVideoType(event.GetSelection());
}

void GuiElf2K::onElf2KKeyboard(wxCommandEvent&event)
{
	setElf2KKeyboard(event.GetSelection());
}

void GuiElf2K::onElf2KBaudR(wxCommandEvent&event)
{
	if (elfConfiguration[ELF2K].baudR != event.GetSelection())
	{
		XRCCTRL(*this, "Elf2KClearRam", wxCheckBox)->SetValue(true);
		elfConfiguration[ELF2K].baudR = event.GetSelection();
	}
}

void GuiElf2K::onElf2KBaudT(wxCommandEvent&event)
{
	if (elfConfiguration[ELF2K].baudT != event.GetSelection())
	{
		XRCCTRL(*this, "Elf2KClearRam", wxCheckBox)->SetValue(true);
		elfConfiguration[ELF2K].baudT = event.GetSelection();
		if (!elfConfiguration[ELF2K].useUart)
		{
			elfConfiguration[ELF2K].baudR = event.GetSelection();
			baudChoiceR[ELF2K]->SetSelection(elfConfiguration[ELF2K].baudR);
		}
	}
}

void GuiElf2K::onElf2KUart(wxCommandEvent&event)
{
	XRCCTRL(*this, "Elf2KClearRam", wxCheckBox)->SetValue(true);
	elfConfiguration[ELF2K].useUart = event.IsChecked();

	wxStaticText *TextR;
	TextR = baudTextR[ELF2K];
	wxChoice *baudR;
	baudR = baudChoiceR[ELF2K];
	wxStaticText *TextT;
	TextT = baudTextT[ELF2K];
	wxChoice *baudT;
	baudT = baudChoiceT[ELF2K];

	setBaudChoiceElf2K();

	delete TextR;
	delete baudR;
	delete TextT;
	delete baudT;

	if (elfConfiguration[ELF2K].useUart)
	{
		elfConfiguration[ELF2K].baudR += 3;
		elfConfiguration[ELF2K].baudT += 3;
		baudChoiceR[ELF2K]->SetSelection(elfConfiguration[ELF2K].baudR);
		baudChoiceT[ELF2K]->SetSelection(elfConfiguration[ELF2K].baudT);
	}
	else
	{
//		if (elfConfiguration[ELF2K].baudR < 3)  elfConfiguration[ELF2K].baudR = 3;
		if (elfConfiguration[ELF2K].baudT < 3)  elfConfiguration[ELF2K].baudT = 3;
//		if (elfConfiguration[ELF2K].baudR > 9)  elfConfiguration[ELF2K].baudR = 9;
		if (elfConfiguration[ELF2K].baudT > 9)  elfConfiguration[ELF2K].baudT = 9;
//		elfConfiguration[ELF2K].baudR -= 3;
		elfConfiguration[ELF2K].baudT -= 3;
		elfConfiguration[ELF2K].baudR = elfConfiguration[ELF2K].baudT;
		baudChoiceR[ELF2K]->SetSelection(elfConfiguration[ELF2K].baudR);
		baudChoiceT[ELF2K]->SetSelection(elfConfiguration[ELF2K].baudT);
	}
}

void GuiElf2K::onElf2KForceUpperCase(wxCommandEvent&event)
{
	if (runningComputer_ == ELF2K)
	{
		p_Elf2K->setForceUpperCase(event.IsChecked());
	}
}

void GuiElf2K::onElf2KControlWindows(wxCommandEvent&event)
{
	elfConfiguration[ELF2K].useElfControlWindows = event.IsChecked();
	XRCCTRL(*this,_T("Elf2KShowAddress"),wxTextCtrl)->Enable(elfConfiguration[ELF2K].useElfControlWindows);
	XRCCTRL(*this,_T("Elf2KAddressText1"),wxStaticText)->Enable(elfConfiguration[ELF2K].useElfControlWindows);
	XRCCTRL(*this,_T("Elf2KAddressText2"),wxStaticText)->Enable(elfConfiguration[ELF2K].useElfControlWindows);
	if (runningComputer_ == ELF2K)
		p_Elf2K->Show(elfConfiguration[ELF2K].useElfControlWindows);
}

void GuiElf2K::setElf2KKeyboard(int Selection)
{
	switch(Selection)
	{
		case KEYBOARDNONE:
			elfConfiguration[ELF2K].useHexKeyboardEf3 = false;
			elfConfiguration[ELF2K].useKeyboard = false;
			elfConfiguration[ELF2K].UsePS2 = false;
			elfConfiguration[ELF2K].usePs2gpio = false;
			XRCCTRL(*this,_T("KeyMapElf2K"), wxButton)->Enable(false);
			XRCCTRL(*this,_T("KeyFileButtonElf2K"), wxButton)->Enable(false);
			XRCCTRL(*this,_T("KeyFileElf2K"), wxTextCtrl)->Enable(false);
			XRCCTRL(*this,_T("EjectKeyFileElf2K"), wxBitmapButton)->Enable(false);
		break;
		case KEYBOARDELF2KHEX:
			elfConfiguration[ELF2K].useHexKeyboardEf3 = true;
			elfConfiguration[ELF2K].useKeyboard = false;
			elfConfiguration[ELF2K].UsePS2 = false;
			elfConfiguration[ELF2K].usePs2gpio = false;
			XRCCTRL(*this,_T("KeyMapElf2K"), wxButton)->Enable(true);
			XRCCTRL(*this,_T("KeyFileButtonElf2K"), wxButton)->Enable(false);
			XRCCTRL(*this,_T("KeyFileElf2K"), wxTextCtrl)->Enable(false);
			XRCCTRL(*this,_T("EjectKeyFileElf2K"), wxBitmapButton)->Enable(false);
		break;
		case KEYBOARDPS2:
			elfConfiguration[ELF2K].useHexKeyboardEf3 = false;
			elfConfiguration[ELF2K].useKeyboard = false;
			elfConfiguration[ELF2K].UsePS2 = false;
			elfConfiguration[ELF2K].usePs2gpio = true;
			XRCCTRL(*this,_T("KeyMapElf2K"), wxButton)->Enable(false);
			XRCCTRL(*this,_T("KeyFileButtonElf2K"), wxButton)->Enable(true);
			XRCCTRL(*this,_T("KeyFileElf2K"), wxTextCtrl)->Enable(true);
			XRCCTRL(*this,_T("EjectKeyFileElf2K"), wxBitmapButton)->Enable(true);
		break;
		case KEYBOARD2KPS2GPIOJP4:
			elfConfiguration[ELF2K].useHexKeyboardEf3 = false;
			elfConfiguration[ELF2K].useKeyboard = false;
			elfConfiguration[ELF2K].UsePS2 = true;
			elfConfiguration[ELF2K].usePs2gpio = true;
			XRCCTRL(*this,_T("KeyMapElf2K"), wxButton)->Enable(false);
			XRCCTRL(*this,_T("KeyFileButtonElf2K"), wxButton)->Enable(true);
			XRCCTRL(*this,_T("KeyFileElf2K"), wxTextCtrl)->Enable(true);
			XRCCTRL(*this,_T("EjectKeyFileElf2K"), wxBitmapButton)->Enable(true);
		break;
	}
}

void GuiElf2K::setElf2KVideoType(int Selection)
{
	switch(Selection)
	{
		case VIDEONONE:
			elfConfiguration[ELF2K].usePixie = false;
			elfConfiguration[ELF2K].use6845 = false;
			elfConfiguration[ELF2K].useS100 = false;
			elfConfiguration[ELF2K].use6847 = false;
			elfConfiguration[ELF2K].useTMS9918 = false;
			elfConfiguration[ELF2K].use8275 = false;
			XRCCTRL(*this, _T("VTTypeElf2K"), wxChoice)->Enable(true);
			XRCCTRL(*this, _T("VTTextElf2K"), wxStaticText)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			baudTextR[ELF2K]->Enable((elfConfiguration[ELF2K].vtType != VTNONE) && elfConfiguration[ELF2K].useUart);
			baudChoiceR[ELF2K]->Enable((elfConfiguration[ELF2K].vtType != VTNONE) && elfConfiguration[ELF2K].useUart);
			baudTextT[ELF2K]->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			baudChoiceT[ELF2K]->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			XRCCTRL(*this, _T("VtSetupElf2K"), wxButton)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			XRCCTRL(*this, _T("SerialLogElf2K"), wxCheckBox)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			XRCCTRL(*this, _T("UartElf2K"), wxCheckBox)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			XRCCTRL(*this, _T("ZoomElf2K"), wxSpinCtrl)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			XRCCTRL(*this, _T("ZoomTextElf2K"), wxStaticText)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			XRCCTRL(*this, _T("InterlaceElf2K"), wxCheckBox)->Enable(false);
			XRCCTRL(*this,_T("CharRomButtonElf2K"), wxButton)->Enable(false);
			XRCCTRL(*this,_T("CharRomElf2K"), wxComboBox)->Enable(false);
		break;

		case VIDEOPIXIE:
			elfConfiguration[ELF2K].usePixie = true;
			elfConfiguration[ELF2K].use6845 = false;
			elfConfiguration[ELF2K].useS100 = false;
			elfConfiguration[ELF2K].use6847 = false;
			elfConfiguration[ELF2K].useTMS9918 = false;
			elfConfiguration[ELF2K].use8275 = false;
			XRCCTRL(*this, _T("VTTypeElf2K"), wxChoice)->Enable(true);
			XRCCTRL(*this, _T("VTTextElf2K"), wxStaticText)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			baudTextR[ELF2K]->Enable((elfConfiguration[ELF2K].vtType != VTNONE) && elfConfiguration[ELF2K].useUart);
			baudChoiceR[ELF2K]->Enable((elfConfiguration[ELF2K].vtType != VTNONE) && elfConfiguration[ELF2K].useUart);
			baudTextT[ELF2K]->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			baudChoiceT[ELF2K]->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			XRCCTRL(*this, _T("VtSetupElf2K"), wxButton)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			XRCCTRL(*this, _T("SerialLogElf2K"), wxCheckBox)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			XRCCTRL(*this, _T("UartElf2K"), wxCheckBox)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			XRCCTRL(*this, _T("ZoomElf2K"), wxSpinCtrl)->Enable(true);
			XRCCTRL(*this, _T("ZoomTextElf2K"), wxStaticText)->Enable(true);
			XRCCTRL(*this, _T("InterlaceElf2K"), wxCheckBox)->Enable(false);
			XRCCTRL(*this,_T("CharRomButtonElf2K"), wxButton)->Enable(false);
			XRCCTRL(*this,_T("CharRomElf2K"), wxComboBox)->Enable(false);
		break;

		case VIDEO2KI8275:
			elfConfiguration[ELF2K].usePixie = false;
			elfConfiguration[ELF2K].use6845 = false;
			elfConfiguration[ELF2K].useS100 = false;
			elfConfiguration[ELF2K].use6847 = false;
			elfConfiguration[ELF2K].useTMS9918 = false;
			elfConfiguration[ELF2K].use8275 = true;
			elfConfiguration[ELF2K].vtType = 0;
			XRCCTRL(*this, _T("VTTypeElf2K"), wxChoice)->Enable(false);
			XRCCTRL(*this, _T("VTTextElf2K"), wxStaticText)->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			XRCCTRL(*this, _T("VTTypeElf2K"), wxChoice)->SetSelection(0);
			baudTextR[ELF2K]->Enable((elfConfiguration[ELF2K].vtType != VTNONE) && elfConfiguration[ELF2K].useUart);
			baudChoiceR[ELF2K]->Enable((elfConfiguration[ELF2K].vtType != VTNONE) && elfConfiguration[ELF2K].useUart);
			baudTextT[ELF2K]->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			baudChoiceT[ELF2K]->Enable(elfConfiguration[ELF2K].vtType != VTNONE);
			XRCCTRL(*this, _T("VtSetupElf2K"), wxButton)->Enable(false);
			XRCCTRL(*this, _T("SerialLogElf2K"), wxCheckBox)->Enable(false);
			XRCCTRL(*this, _T("UartElf2K"), wxCheckBox)->Enable(false);
			XRCCTRL(*this, _T("ZoomElf2K"), wxSpinCtrl)->Enable(true);
			XRCCTRL(*this, _T("ZoomTextElf2K"), wxStaticText)->Enable(true);
			XRCCTRL(*this, _T("InterlaceElf2K"), wxCheckBox)->Enable(true);
			XRCCTRL(*this,_T("CharRomButtonElf2K"), wxButton)->Enable(true);
			XRCCTRL(*this,_T("CharRomElf2K"), wxComboBox)->Enable(true);
		break;
	}
}

wxPoint GuiElf2K::getElf2KswitchPos()
{
	return wxPoint(switchX_, switchY_);
}

void GuiElf2K::setElf2KswitchPos(wxPoint position)
{
	if (position.x > 0)
		switchX_ = position.x;
	if (position.y > 0)
		switchY_ = position.y;
}

void GuiElf2K::onElf2KNvr(wxCommandEvent&event)
{
	elfConfiguration[ELF2K].nvr = event.IsChecked();
	XRCCTRL(*this, "Elf2KClearRam", wxCheckBox)->Enable(event.IsChecked());
}

void GuiElf2K::onElf2KRtc(wxCommandEvent&event)
{
	elfConfiguration[ELF2K].rtc = event.IsChecked();
	XRCCTRL(*this, "Elf2KClearRtc", wxCheckBox)->Enable(event.IsChecked());
}

void GuiElf2K::onElf2KSwitch(wxCommandEvent&event)
{
	elfConfiguration[ELF2K].useSwitch = event.IsChecked();
	if (elfConfiguration[ELF2K].useSwitch)
	{
		elfConfiguration[ELF2K].useHex = false;
		XRCCTRL(*this, "Elf2KHex", wxCheckBox)->SetValue(false);
	}
	if (runningComputer_ == ELF2K)
		p_Elf2K->showModules(elfConfiguration[ELF2K].useSwitch, elfConfiguration[ELF2K].useHex);
}

void GuiElf2K::onElf2KHex(wxCommandEvent&event)
{
	elfConfiguration[ELF2K].useHex = event.IsChecked();
	if (elfConfiguration[ELF2K].useHex)
	{
		elfConfiguration[ELF2K].useSwitch = false;
		XRCCTRL(*this, "Elf2KSwitch", wxCheckBox)->SetValue(false);
	}
	if (runningComputer_ == ELF2K)
		p_Elf2K->showModules(elfConfiguration[ELF2K].useSwitch, elfConfiguration[ELF2K].useHex);
}

void GuiElf2K::setBaudChoiceElf2K()
{
	wxString choices[16];
	if (elfConfiguration[ELF2K].useUart)
	{
		choices[0] = "19200";
		choices[1] = "9600";
		choices[2] = "4800";
		choices[3] = "3600";
		choices[4] = "2400";
		choices[5] = "2000";
		choices[6] = "1800";
		choices[7] = "1200";
		choices[8] = "600";
		choices[9] = "300";
		choices[10] = "200";
		choices[11] = "150";
		choices[12] = "134";
		choices[13] = "110";
		choices[14] = "75";
		choices[15] = "50";
		baudTextT[ELF2K] = new wxStaticText(XRCCTRL(*this, "PanelElf2K", wxPanel), wxID_ANY, "T:", wxPoint(90,222));
		baudChoiceT[ELF2K] = new wxChoice(XRCCTRL(*this, "PanelElf2K", wxPanel), GUI_ELF2K_BAUDT, wxPoint(100,218), wxSize(54,23), 16, choices);
		baudTextR[ELF2K] = new wxStaticText(XRCCTRL(*this, "PanelElf2K", wxPanel), wxID_ANY, "R:", wxPoint(158,222));
		baudChoiceR[ELF2K] = new wxChoice(XRCCTRL(*this, "PanelElf2K", wxPanel), GUI_ELF2K_BAUDR, wxPoint(168,218), wxSize(54,23), 16, choices);
	}
	else
	{
		choices[0] = "3600";
		choices[1] = "2400";
		choices[2] = "2000";
		choices[3] = "1800";
		choices[4] = "1200";
		choices[5] = "600";
		choices[6] = "300";
		baudTextT[ELF2K] = new wxStaticText(XRCCTRL(*this, "PanelElf2K", wxPanel), wxID_ANY, "T/R:", wxPoint(80,222));
		baudChoiceT[ELF2K] = new wxChoice(XRCCTRL(*this, "PanelElf2K", wxPanel), GUI_ELF2K_BAUDT, wxPoint(100,218), wxSize(54,23), 7, choices);
		baudTextR[ELF2K] = new wxStaticText(XRCCTRL(*this, "PanelElf2K", wxPanel), wxID_ANY, "R:", wxPoint(158,222));
		baudChoiceR[ELF2K] = new wxChoice(XRCCTRL(*this, "PanelElf2K", wxPanel), GUI_ELF2K_BAUDR, wxPoint(168,218), wxSize(54,23), 7, choices);
		baudTextR[ELF2K]->Enable(false);
		baudChoiceR[ELF2K]->Enable(false);
	}
	this->Connect(GUI_ELF2K_BAUDR, wxEVT_COMMAND_CHOICE_SELECTED , wxCommandEventHandler(GuiElf2K::onElf2KBaudR) );
	this->Connect(GUI_ELF2K_BAUDT, wxEVT_COMMAND_CHOICE_SELECTED , wxCommandEventHandler(GuiElf2K::onElf2KBaudT) );
}

