#ifndef VIDEO_H
#define VIDEO_H

class Video : public wxFrame
{
public:
	Video(const wxString& title, const wxPoint& pos, const wxSize& size);
	~Video() {};

	virtual void onF3();
	virtual void onF5();
	virtual void setInterlace(bool status);
	virtual void setStretchDot(bool status);
	virtual void setReBlit();
	virtual long getVideoSyncCount();
	virtual void focus();
	virtual void updateStatusLed(bool status);
	virtual void dataAvailable();
	virtual void framingError(bool data);
	virtual bool isFullScreenSet() {return false;};
	virtual Byte getVtMemory(int address);
	virtual void setVtMemory(int address, Byte value);
	virtual bool charPressed(wxKeyEvent& event);
	virtual void keyDownPressed(wxKeyEvent& event);
	virtual void keyUpPressed();
	virtual void uartOut(Byte value); 
	virtual Byte uartIn(); 
	virtual void ResetIo();

	void defineColours(int type);
	void setColour(int colourNumber, wxString colour);
	void reColour() {reColour_ = true;};

protected:
	wxColour colour_[66];
	wxPen penColour_[66];
	wxBrush brushColour_[66];

	wxColour colourNew_[66];
	wxPen penColourNew_[66];
	wxBrush brushColourNew_[66];

	int numberOfColours_;
	bool reBlit_;
	bool reDraw_;
	bool reColour_;

private:

};

#endif	// VIDEO_H
