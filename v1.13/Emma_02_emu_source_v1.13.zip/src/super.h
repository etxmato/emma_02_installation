#ifndef SUPER_H
#define SUPER_H

#include "elf.h"
#include "til311.h"
#include "led.h"
#include "tms9918.h"
#include "pixie.h"
#include "mc6847.h"
#include "mc6845.h"
#include "i8275.h"
#include "ledmodule.h"
#include "printer.h"
#include "elfconfiguration.h"

class RunSuper : public wxThread
{
public:
	RunSuper() {};
	virtual void *Entry();
};

class Super : public wxFrame, public MainElf
{
public:
	Super(const wxString& title, const wxPoint& pos, const wxSize& size, int computerType, double clock, ElfConfiguration conf);
	~Super();

	void onClose(wxCloseEvent&WXUNUSED(event));
	void onPaint(wxPaintEvent&event);
	void onChar(wxKeyEvent& event);
	void charEvent(int keycode);
	void onKeyDown(wxKeyEvent& event);
	bool keyDownPressed(int keycode);
	void onKeyUp(wxKeyEvent& event);
	bool keyUpReleased(int keycode);
	void onButtonRelease(wxCommandEvent& event);
	void onButtonPress(wxCommandEvent& event);
	void addressTimeout(wxTimerEvent&WXUNUSED(event));

	void onRun();
	void onInButtonPress();
	void onInButtonRelease();
	void onHexKeyDown(int keycode);
	void onHexKeyUp();

	void configureComputer();
	void initComputer();
	Byte ef(int flag);
	Byte ef4();
	Byte in(Byte port, Word address);
	Byte getData();
	void out(Byte port, Word address, Byte value);
	void showData(Byte value);
	void showAddr(Word adr);
	void cycle(int type);
	void cycleA();
	void cycleB();

	void autoBoot();
	void updateQState();
	void redLedSetState(int i, int status);
	int getMpButtonState();

	void onRunButton(wxCommandEvent&WXUNUSED(event));
	void onPause(wxCommandEvent&WXUNUSED(event));
	void onMpButton(wxCommandEvent&WXUNUSED(event));
	void onMonitor(wxCommandEvent&WXUNUSED(event));
	void onLoadButton(wxCommandEvent&WXUNUSED(event));
	void onSingleStep(wxCommandEvent&WXUNUSED(event));
	void onResetButton(wxCommandEvent&WXUNUSED(event));
	void onPowerButton(wxCommandEvent&WXUNUSED(event));
	void onNumberKeyDown(wxCommandEvent& event);
	void onNumberKeyUp(wxCommandEvent& event);

	void startComputer();
	void stopComputer();
	Byte readMem(Word addr);
	void writeMem(Word addr, Byte value, bool writeRom);
	void cpuInstruction();
	void configureElfExtensions();
	void tmsAndPixieZoom(int zoom);
	void moveWindows();
	void updateTitle(wxString Title);
	void setForceUpperCase(bool status);
	void onReset();
	void sleepComputer(long ms);

	Byte getTmsMemory(int address) {return tmsPointer->getTmsMemory(address);};
	void setTmsMemory(int address, Byte value) {tmsPointer->setTmsMemory(address, value);};
//	void setReBlit();
	Byte read8275CharRom(Word addr);
	void write8275CharRom(Word addr, Byte value);
	Byte read6845CharRom(Word addr);
	void write6845CharRom(Word addr, Byte value);
	Byte read6847CharRom(Word addr);
	void write6847CharRom(Word addr, Byte value);
	int readDirect6847(Word addr);
	Word get6847RamMask();
	void writeDirect6847(Word addr, int value);

private:
	RunSuper *threadPointer;
	Tms9918 *tmsPointer;
	Pixie *pixiePointer;
	MC6845 *mc6845Pointer;
	mc6847 *mc6847Pointer;
	i8275 *i8275Pointer;
	wxTimer *addressTimerPointer;

	wxBitmap *superBitmapPointer;
	wxBitmap *upBitmapPointer;
	wxBitmap *downBitmapPointer;

	wxMask *maskUp;
	wxMask *maskDown;

	wxBitmapButton *powerButtonPointer;
	wxButton *inButtonPointer;
	wxButton *runButtonPointer;
	wxButton *pauseButtonPointer;
	wxButton *stepButtonPointer;
	wxButton *resetButtonPointer;
	wxButton *mpButtonPointer;
	wxButton *loadButtonPointer;
	wxButton *monitorButtonPointer;
	wxButton *buttonPointer[16];

	Til311 *addressPointer[4];
	Til311 *dataPointer[2];

	Led *qLedPointer;
	Led *superLedPointer[8];
	Byte qLed_;

	Byte switches_;
	int mpButtonState_;
	Byte lastMode_;
	char state_;
	Byte ef3State_;
	Byte ef4State_;
	char singleStep_;
	bool monitor_;
	int computerType_;
	bool resetPressed_;
	Word lastAddress_;

	int hexKeyDefA_[16];
	double elfClockSpeed_;

	bool load_;

	DECLARE_EVENT_TABLE()
};

#endif  // SUPER_H
