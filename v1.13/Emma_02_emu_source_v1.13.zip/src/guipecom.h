#ifndef GUIPECOM_H
#define GUIPECOM_H

#include "guimain.h"

class GuiPecom : public GuiMain
{
public:

	GuiPecom(const wxString& title, const wxPoint& pos, const wxSize& size);
	~GuiPecom() {};

	void readPecomConfig();
	void writePecomConfig();

private:

	DECLARE_EVENT_TABLE()
};

#endif // GUIPECOM_H