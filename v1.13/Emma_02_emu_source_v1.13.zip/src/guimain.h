#ifndef GUIMAIN_H
#define GUIMAIN_H

#define NO_COMPUTER 17

#define MAINROM 0

// Studio II
#define CARTROM 1

// Elf
#define MAINROM2 1

// Telmac 600
//#define EXPROM 1

// Comx
#define EXPROM 1
#define CARTROM1 2
#define CARTROM2 3
#define CARTROM3 4
#define CARTROM4 5

#define MAXROM 6

DECLARE_EVENT_TYPE(OPEN_PRINTER_WINDOW, 800) 

class Conf
{
public:
	wxString mainDir_;

	wxString romDir_[MAXROM];
	wxString ramDir_;
	wxString chip8SWDir_;
	wxString wavFileDir_;
	wxString charRomDir_;
	wxString vtCharRomDir_;
	wxString ideDir_;
	wxString keyFileDir_;
	wxString screenDumpFileDir_;
	wxString printFileDir_;
	int printMode_;

	wxString loadFileName_;
	wxString loadFileNameFull_;

	char pLoadSaveName_[4];
	WORD defus_;
	WORD eop_;
	WORD string_;
	WORD arrayValue_;
	WORD eod_;
	WORD basicRamAddress_;

	int volume_;
	int tempo_;
	int vipSound_;
	double clockSpeed_;
	wxString clock_;
	int fdcCpms_;

	bool printerOn_;
	bool useLoadLocation_;
	bool autoCassetteLoad_;
	bool realCassetteLoad_;
	wxString turboClock_;

	int pixieX_, pixieY_;
	int tmsX_, tmsY_;
	int vtX_, vtY_;
	int mc6845X_, mc6845Y_;
	int mc6847X_, mc6847Y_;
	int i8275X_, i8275Y_;
	int mainX_, mainY_;
	int keypadX_, keypadY_;

};

class ComputerInfo
{
public:
	wxString gui;
	wxString name;
//	wxString extension;
	wxString ploadExtension;
};

class GuiMain : public wxFrame
{
public:

	GuiMain(const wxString& title, const wxPoint& pos, const wxSize& size);
	~GuiMain() {};

	void onMainRom1(wxCommandEvent& event);
	void onMainRom2(wxCommandEvent& event);
	void onCartRom(wxCommandEvent& event);
	void onRamSW(wxCommandEvent& event);
	void onChip8SW(wxCommandEvent& event);
	void onEjectChip8SW(wxCommandEvent& event);
	void onPrintFile(wxCommandEvent& event);
	void onPrintFileText(wxCommandEvent& event);
	void onPrintButton(wxCommandEvent& event);
	void onPrintMode(wxCommandEvent& event);
	void openPrinterFrame(wxCommandEvent &event);
	void onF4();
	void setPrintMode();
	int getPrintMode();
	void onIde(wxCommandEvent& event);
	void onIdeEject(wxCommandEvent& event);
	void onCharRom(wxCommandEvent& event);
	void onVtCharRom(wxCommandEvent& event);
	void onKeyFile(wxCommandEvent& event);
	void onKeyFileEject(wxCommandEvent& event);
	void onVT100(wxCommandEvent& event);
	void onZoom(wxSpinEvent& event);
	void onFullScreen(wxCommandEvent&event);
	void onInterlace(wxCommandEvent& event);
	void onStretchDot(wxCommandEvent& event);
	void onScreenDumpFile(wxCommandEvent& event);
	void onScreenDump(wxCommandEvent& event);
	void onDp(wxCommandEvent& event);
	void onVolume(wxScrollEvent&event);
	void onCassette(wxCommandEvent& event);
	void onCassetteEject(wxCommandEvent& event);
	void onAutoLoad(wxCommandEvent& event);
	void onRealCas(wxCommandEvent& event);
	void onWavFile(wxCommandEvent& event);
	void onTurbo(wxCommandEvent&event);
	void onTurboClock(wxCommandEvent& event);
	void onUseLocation(wxCommandEvent& event);
	void onCassetteLoad(wxCommandEvent& event);
	void onCassetteSave(wxCommandEvent& event);
	void onCassetteStop(wxCommandEvent& event);
	void onKeyboard(wxCommandEvent& event);
	void onPsave(wxString fileName);
	void onDsave(wxCommandEvent& event);
	void onPloadRun(wxCommandEvent& event);
	void onLoadButton(wxCommandEvent& event);
	void onLoad(bool load);
	void onSaveButton(wxCommandEvent& event);
	void onClock(wxCommandEvent& event);
	void onBaudR(wxCommandEvent& event);
	void onBaudT(wxCommandEvent& event);

	void onPsaveMenu(wxCommandEvent& event);
	void onVtSetup(wxCommandEvent& event);

	wxString getMainDir() {return conf[runningComputer_].mainDir_;};

	wxString getRomDir(int computerType, int romType) {return conf[computerType].romDir_[romType];};
	wxString getRamDir(int computerType) {return conf[computerType].ramDir_;};
	wxString getChip8Dir(int computerType){return conf[computerType].chip8SWDir_;};
	wxString getIdeDir(int computerType) {return conf[computerType].ideDir_;};
	wxString getCharRomDir(int computerType) {return conf[computerType].charRomDir_;};
	wxString getVtCharRomDir(int computerType) {return conf[computerType].vtCharRomDir_;};
	wxString getWaveDir(int computerType) {return conf[computerType].wavFileDir_;};
	bool getAutCassetteLoad() {return conf[runningComputer_].autoCassetteLoad_;};
	bool getPrinterStatus() {return conf[runningComputer_].printerOn_;};

	wxString getSelectedComputerStr() {return computerInfo[selectedComputer_].gui;};
	wxString getRunningComputerStr() {return computerInfo[runningComputer_].gui;};
	wxString getSelectedComputerText() {return computerInfo[selectedComputer_].name;};
	int getSelectedComputerId() {return selectedComputer_;};

	wxString getKeyFile();
	wxString getScreenDumpFile();
	wxString getPrintFile();
	ElfConfiguration getElfConfiguration();

	long getBitValue(wxString reference);
	long get8BitValue(wxString reference);
	long get16BitValue(wxString reference);

	void setClock(int computerType);
	void setClockRate();
	void setPloadFileName(wxString fileName) {conf[runningComputer_].loadFileName_ = fileName + ".comx";};

	int getConfigItem(wxString Item, long DefaultValue);
	void setConfigItem(wxString Item, int Value);
	wxString getConfigItem(wxString Item, wxString DefaultValue);
	void setConfigItem(wxString Item, wxString Value);
	int getSpinValue(wxString info);
	wxString getTextValue(wxString info);
	void setTextValue(wxString info, wxString value);
	wxString getComboValue(wxString info);
	int getChoiceSelection(wxString info);
	void setChoiceSelection(wxString info, int value);
	bool getCheckBox(wxString info);
	void setCheckBox(wxString info, bool status);
	void setGauge(wxString info, short value);
	void setTextCtrl(wxString info, wxString value);
	void onHexKeyDef(wxCommandEvent&event);
	void onColoursDef(wxCommandEvent&event);

	wxPoint getMainPos(int computerType);
	void setMainPos(int computerType, wxPoint position);
	wxPoint getPixiePos(int computerType);
	void setPixiePos(int computerType, wxPoint position);
	wxPoint getTmsPos(int computerType);
	void setTmsPos(int computerType, wxPoint position);
	wxPoint getVtPos(int computerType);
	void setVtPos(int computerType, wxPoint position);
	wxPoint get6845Pos(int computerType);
	void set6845Pos(int computerType, wxPoint position);
	wxPoint get6847Pos(int computerType);
	void set6847Pos(int computerType, wxPoint position);
	wxPoint get8275Pos(int computerType);
	void set8275Pos(int computerType, wxPoint position);
	wxPoint getKeypadPos(int computerType);
	void setKeypadPos(int computerType, wxPoint position);

	wxString getDataDir() {return dataDir_;};

	int pload();
	void startCassetteLoad();
	void startLoad();
	void stopCassette();
	void startCassetteSave();
	void setSaveAddress(wxString textCtrl, WORD address);
	void startSave();
	void turboOn();
	void turboOff();
	void enableStartButtonGui(bool status);
	void enableLocationGui();
	void enableMemAccessGui(bool status);
	void enableTapeGui(bool status, int computerType);
	void enableLoadGui(bool status);
	void turboGui(wxString computerString);
	void setComputerInfo(int id, wxString gui, wxString name, wxString ploadExtension);
	void setScreenInfo(int id, int start, int end, wxString colour[]);
	void setSaveLocation(Word saveStart, Word saveEnd);
	void setSaveLocation(Word saveStart, Word saveEnd, Word saveExec);
	void setVtType(wxString elfTypeStr, int elfType, int Selection);
	void setBaudChoice(int computerType);
	void setRealCas(int computerType);
	void setRealCas2(int computerType);
	void setPrinterState(int computerType);
	void setBaud(int baudR, int baudT);
	ScreenInfo getScreenInfo(int id);

protected:
	Vip *p_Vip;
	Nano *p_Nano;
	Tmc1800 *p_Tmc1800;
	Tmc2000 *p_Tmc2000;
	Studio2 *p_Studio2;
	Visicom *p_Visicom;
	Victory *p_Victory;
	Eti *p_Eti;
	Cidelsa *p_Cidelsa;
	Comx *p_Comx;
	Tmc600 *p_Tmc600;
	Pecom *p_Pecom;
	Elf2 *p_Elf2;
	Super *p_Super;
	Elf2K *p_Elf2K;
	Cosmicos *p_Cosmicos;
	Elf *p_Elf;

	ElfConfiguration elfConfiguration[5];
	wxConfigBase *configPointer;

	Conf conf[NO_COMPUTER];
	ComputerInfo computerInfo[NO_COMPUTER];
	ScreenInfo screenInfo[NO_COMPUTER];

	wxString comxPalClock_;
	wxString comxNtscClock_;

	wxString applicationDirectory_;
	wxChar pathSeparator_;
	int mainWindowX_, mainWindowY_;

	int elfChoice_;
	int studioChoice_;
	int telmacChoice_;
	int selectedComputer_;
	int runningComputer_;

	WindowInfo windowInfo;
	wxString workingDir_;
	wxString dataDir_;
	int psaveData_[8];

	bool debugMode_;

	bool recOff_;
	bool playBlack_;

	bool computerRunning_;

	wxChoice *baudChoiceR[5];
	wxChoice *baudChoiceT[5];
	wxStaticText *baudTextR[5];
	wxStaticText *baudTextT[5];

private:
	wxBitmap playBlackBitmap;
	wxBitmap playGreenBitmap;
	wxBitmap recOffBitmap;
	wxBitmap recOnBitmap;
	wxBitmap realCasOffBitmap;
	wxBitmap realCasOnBitmap;
	wxBitmap printerOffBitmap;
	wxBitmap printerOnBitmap;

	double savedSpeed_;
	bool turboOn_;

	DECLARE_EVENT_TABLE()
};

#endif // GUIMAIN_H