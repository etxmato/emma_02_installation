/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "main.h"
#include "tmc2000.h"

Tmc2000::Tmc2000(const wxString& title, const wxPoint& pos, const wxSize& size, int zoom, int computerType)
:Pixie(title, pos, size, zoom, computerType)
{
	threadPointer = new RunTMC2000();
	if ( threadPointer->Create() != wxTHREAD_NO_ERROR )
	{
		p_Main->message("Can't create thread");
	}
	threadPointer->SetPriority(WXTHREAD_MAX_PRIORITY);
}

Tmc2000::~Tmc2000()
{
	p_Main->setMainPos(TMC2000, GetPosition());
}

void Tmc2000::stopComputer()
{
	threadPointer->Delete();
}

void Tmc2000::configureComputer()
{
	outType_[1] = VIPKEYOUT;
	outType_[3] = VIPOUT4;
	efType_[2] = VIPEF2;
	efType_[3] = VIPKEYEF;

	p_Main->message("Configuring Telmac TMC-2000");
	p_Main->message("	Output 2: key latch, output 4: address, colour and CDP 1864 tone latch");
	p_Main->message("	EF 2: cassette in, EF 3: keyboard\n");

	for (int i=0; i<64; i++)
		keyDef_[i] = 0;
	if (!p_Main->getCheckBox("KeyboardTMC2000"))
	{
		keyDef_[0] = p_Main->getConfigItem(_T("/TMC2000/HexKeyA0"), 48);
		keyDef_[1] = p_Main->getConfigItem(_T("/TMC2000/HexKeyA1"), 49);
		keyDef_[2] = p_Main->getConfigItem(_T("/TMC2000/HexKeyA2"), 50);
		keyDef_[3] = p_Main->getConfigItem(_T("/TMC2000/HexKeyA3"), 51);
		keyDef_[4] = p_Main->getConfigItem(_T("/TMC2000/HexKeyA4"), 52);
		keyDef_[5] = p_Main->getConfigItem(_T("/TMC2000/HexKeyA5"), 53);
		keyDef_[6] = p_Main->getConfigItem(_T("/TMC2000/HexKeyA6"), 54);
		keyDef_[7] = p_Main->getConfigItem(_T("/TMC2000/HexKeyA7"), 55);
		keyDef_[8] = p_Main->getConfigItem(_T("/TMC2000/HexKeyA8"), 56);
		keyDef_[9] = p_Main->getConfigItem(_T("/TMC2000/HexKeyA9"), 57);
		keyDef_[10] = p_Main->getConfigItem(_T("/TMC2000/HexKeyAA"), 65);
		keyDef_[11] = p_Main->getConfigItem(_T("/TMC2000/HexKeyAB"), 66);
		keyDef_[12] = p_Main->getConfigItem(_T("/TMC2000/HexKeyAC"), 67);
		keyDef_[13] = p_Main->getConfigItem(_T("/TMC2000/HexKeyAD"), 68);
		keyDef_[14] = p_Main->getConfigItem(_T("/TMC2000/HexKeyAE"), 69);
		keyDef_[15] = p_Main->getConfigItem(_T("/TMC2000/HexKeyAF"), 70);
	}
	else
	{
		for (int i=48; i<58; i++)
			keyDef_[i-48] = i;
		for (int i=65; i<91; i++)
			keyDef_[i-55] = i;
	}
	
	resetCpu();
}

void Tmc2000::initComputer()
{
	setClear(1);
	setWait(1);
	cassetteEf2_ = 0;

	telmac2000KeyPort_ = 0;
	for (int i=0; i<64; i++)
		telmac2000KeyState_[i] = 0;

	addressLatch_ = 0x8000;
	colorLatch_ = false;
	runPressed_ = false;
}

void Tmc2000::keyDown(int keycode)
{
	for (int i=0; i<36; i++)
	{
		if (keycode == keyDef_[i])
		{
			telmac2000KeyState_[i] = 1;
		}
	}
}

void Tmc2000::keyUp(int keycode)
{
	for (int i=0; i<36; i++)
	{
		if (keycode == keyDef_[i])
			telmac2000KeyState_[i] = 0;
	}
}

void Tmc2000::onRun()
{
	runPressed_ = true;
}

Byte Tmc2000::ef(int flag)
{
	switch(efType_[flag])
	{
		case 0:
			return 1;
		break;

		case PIXIEEF:
			return efPixie();
		break;

		case VIPEF2:
			return cassetteEf2_;
		break;

		case VIPKEYEF:
			return ef3();
		break;

		default:
			return 1;
	}
}

Byte Tmc2000::ef3()
{
	return (telmac2000KeyState_[telmac2000KeyPort_]) ? 0 : 1;
}

Byte Tmc2000::in(Byte port, Word WXUNUSED(address))
{
	Byte ret;

	switch(inType_[port-1])
	{
		case 0:
			ret = 255;
		break;

		case PIXIEIN:
			ret = inPixie();
		break;

		case PIXIEOUT:
			outPixie();
			return 0;
		break;

		default:
			ret = 255;
	}
	inValues_[port] = ret;
	return ret;
}

void Tmc2000::out(Byte port, Word WXUNUSED(address), Byte value)
{
	outValues_[port] = value;

	switch(outType_[port-1])
	{
		case 0:
			return;
		break;

		case PIXIEOUT:
			outPixie();
		break;

		case PIXIEBACKGROUND:
			outPixieBackGround();
		break;

		case VIPKEYOUT:
			outTMC2000(value);
		break;

		case VIPOUT4:
			if (value & 1)
				colorLatch_ = true;
			else
			{
				colorLatch_ = false;
				addressLatch_ = 0;
			}
			tone1864Latch(value);
		break;
	}
}

void Tmc2000::outTMC2000(Byte value)
{
	telmac2000KeyPort_ = value&0x3f;
}

void Tmc2000::cycle(int type)
{
	switch(cycleType_[type])
	{
		case 0:
			return;
		break;

		case PIXIECYCLE:
			cyclePixieTelmac();
		break;
	}
}

void Tmc2000::startComputer()
{
	resetPressed_ = false;

	p_Main->setSwName("");
	p_Main->updateTitle();

	readProgramCombo(p_Main->getRomDir(TMC2000, MAINROM), "MainRomTMC2000", ROM, 0x8000, NONAME);

	switch(p_Main->getChoiceSelection("RamTMC2000"))
	{
		case 0:
			defineMemoryType(0x0, 0xfff, RAM);
			ramMask_ = 0xfff;
		break;

		case 1:
			defineMemoryType(0x0, 0x3fff, RAM);
			ramMask_ = 0x3fff;
		break;

		case 2:
			defineMemoryType(0x0, 0x7fff, RAM);
			ramMask_ = 0x7fff;
		break;
	}

	readProgramCombo(p_Main->getRamDir(TMC2000), "RamSWTMC2000", RAM, 0, SHOWNAME);
	readProgram(p_Main->getChip8Dir(TMC2000), "Chip8SWTMC2000", RAM, 0x200, SHOWNAME);
	int	zoom = p_Main->getSpinValue("ZoomTMC2000");

	configurePixieTelmac();
	setZoom(zoom);
	Show(true);
	initPixie();

	p_Main->updateTitle();


	cpuCycles_ = 0;
	startTime_ = wxGetLocalTime();

	threadPointer->Run();
}

Byte Tmc2000::readMem(Word addr)
{
	if (addr < 0x8000)
		address_ = (addr | addressLatch_) & (ramMask_ | 0x8000);
	else
		address_ = addr & 0x81ff;

	if (memoryType_[address_/256] == UNDEFINED) return 255;
	return mainMemory_[address_| addressLatch_];
}

void Tmc2000::writeMem(Word addr, Byte value, bool writeRom)
{
	address_ = addr;

	if (!writeRom)
	{
		if (colorLatch_ && (addr >= 0x8000) && (addr < 0x8400))
		{
			colorMemory1864_[addr&0x3ff] = value &0xf;
			return;
		}
		address_ = addr & ramMask_;
	}
	else
		address_ = addr;

	if (!writeRom)
		if (memoryType_[address_/256] != RAM)  return;

	mainMemory_[address_]=value;
}

Byte Tmc2000::read1864ColorDirect(Word addr)
{
	return colorMemory1864_[addr] & 0xf;
}

void Tmc2000::write1864ColorDirect(Word addr, Byte value)
{
	colorMemory1864_[addr] = value & 0xf;
}

void Tmc2000::cpuInstruction()
{
	if (debugMode_)
		p_Main->updateWindow();
	if (cpuMode_ == RUN)
	{
		if (steps_ != 0)
		{
			cycle0_=0;
			machineCycle();
			if (cycle0_ == 0) machineCycle();
			if (cycle0_ == 0 && steps_ != 0)
			{
				cpuCycle();
				cpuCycles_ += 2;
			}
		}
		playSaveLoad();
		checkTMC2000Function();

		if (resetPressed_)
		{
			resetCpu();
			resetPressed_ = false;
			addressLatch_ = 0x8000;
			initPixie();
		}
		if (runPressed_)
		{
			setClear(0);
			p_Main->updateTitle();
			runPressed_ = false;
		}
		if (debugMode_)
			p_Main->cycleDebug();
	}
	else
	{
		if (runPressed_)
		{
			setClear(1);
			addressLatch_ = 0x8000;
			initPixie();
			p_Main->updateTitle();
			runPressed_ = false;
		}
	}
}

void Tmc2000::onReset()
{
	resetPressed_ = true;
}

void Tmc2000::cassette(short val)
{
	if (val < 0)
	{
		cassetteEf2_ = 0;
	}
	else
		cassetteEf2_ = 1;
}

void Tmc2000::cassette(char val)
{
	if (val < 0)
	{
		cassetteEf2_ = 0;
	}
	else
		cassetteEf2_ = 1;
}

void Tmc2000::checkTMC2000Function()
{
	switch(scratchpadRegister_[programCounter_])
	{
		case 0x80c0:
			p_Main->stopCassette();
		break;

		case 0x80ed:
			p_Main->stopCassette();
		break;

		case 0x8091:	// SAVE
			p_Main->startCassetteSave();
		break;

		case 0x80c2:	// LOAD
			p_Main->startCassetteLoad();
		break;
	}
}

void *RunTMC2000::Entry()
{
	while(!TestDestroy())
	{
		p_Computer->cpuInstruction();
	}
	return NULL;
}
