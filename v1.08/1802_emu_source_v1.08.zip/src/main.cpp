/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#define MAIN

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/stdpaths.h"

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "app_icon.xpm"
#endif

#include "main.h"
#include "ports.h"
#include "psave.h"
#include "printer.h"
#include "about.h"
//#include "guicomx.h"
//#include "guielf.h"
//#include "guistudio2.h"
//#include "guicidelsa.h"

//#define _CRTDBG_MAP_ALLOC
//#include <stdlib.h>
//#include <crtdbg.h>

DEFINE_EVENT_TYPE(OPEN_PRINTER_WINDOW)
DEFINE_EVENT_TYPE(OPEN_TELMAC_PRINTER_WINDOW)
DEFINE_EVENT_TYPE(OPEN_PECOM_PRINTER_WINDOW)

BEGIN_EVENT_TABLE(Main, DebugWindow)

	EVT_CLOSE(Main::onClose)

	EVT_MENU(XRCID(_T(GUIQUIT)), Main::onQuit)
	EVT_MENU(XRCID(_T(GUIABOUT)), Main::onAbout)
	EVT_MENU(XRCID(_T(GUIHELP)), Main::onHelp)
	EVT_MENU(XRCID(_T(GUISAVECONFIG)), Main::onSaveConfig)
	EVT_MENU(XRCID(_T(GUISAVEONEXIT)), Main::onSaveOnExit)
	EVT_MENU(XRCID(_T(GUIDEFAULTWINDOWPOS)), Main::onDefaultWindowPosition)
	EVT_MENU(XRCID(_T(GUIDEFAULT)), Main::onDefaultSettings)
	EVT_MENU(XRCID(_T("Flat")), Main::onFlat)
	EVT_MENU(XRCID(_T("Crisp")), Main::onCrisp)
	EVT_MENU(XRCID(_T("Default")), Main::onDefault)
	EVT_MENU(XRCID(_T("TV Speaker")), Main::onTvSpeaker)
	EVT_MENU(XRCID(_T("Handheld")), Main::onHandheld)

	EVT_BUTTON(XRCID(_T("StartButtonComx")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonElf")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonElfII")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonSuperElf")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonElf2K")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonStudio2")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonVisicom")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonVictory")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonVip")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonCidelsa")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonTmc600")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonTMC1800")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonTMC2000")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonNano")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonPecom")), Main::onStart)
	EVT_BUTTON(XRCID(_T("StartButtonEti")), Main::onStart)

	EVT_CHOICEBOOK_PAGE_CHANGED(XRCID(_T("StudioChoiceBook")), Main::onStudioChoiceBook)
	EVT_CHOICEBOOK_PAGE_CHANGED(XRCID(_T("TelmacChoiceBook")), Main::onTelmacChoiceBook)
	EVT_CHOICEBOOK_PAGE_CHANGED(XRCID(_T("CosmacChoiceBook")), Main::onCosmacChoiceBook)

END_EVENT_TABLE()

IMPLEMENT_APP(Emu1802)

WindowInfo getWinSizeInfo()
{
	int major, minor;

	WindowInfo returnValue;

	wxOperatingSystemId operatingSystemId;
	operatingSystemId = wxGetOsVersion(&major, &minor);

	if (operatingSystemId == wxOS_UNIX_LINUX)
	{
		returnValue.xBorder = 6;
		returnValue.yBorder = 27;
		returnValue.xBorder2 = 6;
		returnValue.yBorder2 = 54;
		returnValue.mainwY = 457;
		returnValue.mainwX = 535;
		returnValue.xPrint = 11;
	}
	else
	{
		if (major == 6) // Vista
		{
			returnValue.xBorder2 = 16;
			returnValue.yBorder2 = 36;
			returnValue.mainwY = 491;
		}
		else
		{
			if (minor == 1) // XP
			{
				returnValue.xBorder2 = 8;
				returnValue.yBorder2 = 36;
				returnValue.mainwY = 489;
			}
			else // 2000
			{
				returnValue.xBorder2 = 8;
				returnValue.yBorder2 = 36;
				returnValue.mainwY = 489;
			}
		}
		returnValue.xPrint = 21;
		returnValue.xBorder = 0;
		returnValue.yBorder = 0;
		returnValue.mainwX = 550;
	}


	return returnValue;
}

bool Emu1802::OnInit()
{
	wxInitAllImageHandlers();
	wxXmlResource::Get()->InitAllHandlers();
	wxXmlResource::Get()->Load(_T("main.xrc"));

	wxConfigBase *configPointer = wxConfigBase::Get();
	configPointer->SetRecordDefaults();

	PrintDataPointer = new wxPrintData;
	PrintDataPointer->SetPaperId(wxPAPER_A4);

	p_PageSetupData = new wxPageSetupDialogData;
	(*p_PageSetupData) = *PrintDataPointer;
	p_PageSetupData->SetMarginTopLeft(wxPoint(9, 9));
	p_PageSetupData->SetMarginBottomRight(wxPoint(9, 9));

	int mainWindowX = configPointer->Read(_T("/Xpos"), 30);
	int mainWindowY = configPointer->Read(_T("/Ypos"), 30);

	WindowInfo windowInfo = getWinSizeInfo();

	p_Main = new Main(_T("1802 Emulator"), wxPoint(mainWindowX, mainWindowY), wxSize(windowInfo.mainwX, windowInfo.mainwY));
	p_Main->Show(true);

	return true;
}

int Emu1802::OnExit()
{
	delete wxConfigBase::Set((wxConfigBase *) NULL);
	delete PrintDataPointer;
	delete p_PageSetupData;
	return 0;
}

Main::Main(const wxString& title, const wxPoint& pos, const wxSize& size)
: DebugWindow(title, pos, size)
{
//	_CrtSetDbgFlag ( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
	windowInfo = getWinSizeInfo();
	xmlLoaded_ = false;
	SetIcon(wxICON(app_icon));

	SetMenuBar(wxXmlResource::Get()->LoadMenuBar(_T("Main_Menu")));
	wxXmlResource::Get()->LoadPanel(this, _T("1802_emu"));

	xmlLoaded_ = true;
	computerRunning_ = false;
	runningComputer_ = NO_COMPUTER;

	workingDir_ = wxGetCwd();
	wxStandardPaths stPath;
	dataDir_ = stPath.GetUserDataDir();
	wxFileName applicationFile = wxFileName::wxFileName(workingDir_, _T(""), wxPATH_NATIVE);
	pathSeparator_ = applicationFile.GetPathSeparator(wxPATH_NATIVE);
	applicationDirectory_ = applicationFile.GetPath(wxPATH_GET_VOLUME|wxPATH_GET_SEPARATOR, wxPATH_NATIVE);
	dataDir_ = dataDir_ + pathSeparator_;

	wxString helpFile = applicationDirectory_ + _T("Helpfiles") + pathSeparator_ + _T("1802EmuHelp.hhp");
	if (!helpController_.Initialize(helpFile))
	{
		(void)wxMessageBox( _T("Failed adding book " + helpFile + "\n"),
							_T("1802 Emulator"), wxICON_ERROR | wxOK );
	}

	this->Connect(XRCID(_T(GUICOMPUTERNOTEBOOK)), wxEVT_COMMAND_NOTEBOOK_PAGE_CHANGED, wxNotebookEventHandler(Main::onComputer) );

	wxString text;
	for (int i=0; i<16; i++)
	{
		text.Printf("R%d",i);
		registerTextPointer[i] = XRCCTRL(*this,_T(text), wxTextCtrl);
	}
	for (int i=1; i<8; i++)
	{
		text.Printf("I%d",i);
		inTextPointer[i] = XRCCTRL(*this,_T(text), wxTextCtrl);
		text.Printf("O%d",i);
		outTextPointer[i] = XRCCTRL(*this,_T(text), wxTextCtrl);
	}
	for (int i=1; i<5; i++)
	{
		text.Printf("EF%d",i);
		efTextPointer[i] = XRCCTRL(*this,_T(text), wxTextCtrl);
	}
	dfTextPointer = XRCCTRL(*this,_T("DF"), wxTextCtrl);
	qTextPointer = XRCCTRL(*this,_T("Q"), wxTextCtrl);
	ieTextPointer = XRCCTRL(*this,_T("IE"), wxTextCtrl);
	dTextPointer = XRCCTRL(*this,_T("D"), wxTextCtrl);
	pTextPointer = XRCCTRL(*this,_T("P"), wxTextCtrl);
	xTextPointer = XRCCTRL(*this,_T("X"), wxTextCtrl);
	tTextPointer = XRCCTRL(*this,_T("T"), wxTextCtrl);

	assemblerWindowPointer = XRCCTRL(*this,_T("AssemblerWindow"), wxTextCtrl);
	disassemblerWindowPointer = XRCCTRL(*this,_T("DisassemblerWindow"), wxTextCtrl);
	traceWindowPointer = XRCCTRL(*this,_T("TraceWindow"), wxTextCtrl);
	inputWindowPointer = XRCCTRL(*this,_T("InputWindow"), wxTextCtrl);
	breakPointWindowPointer = XRCCTRL(*this,_T("BreakPointWindow"), wxListCtrl);
	tregWindowPointer = XRCCTRL(*this,_T("TregWindow"), wxListCtrl);
	trapWindowPointer = XRCCTRL(*this,_T("TrapWindow"), wxListCtrl);

	readConfig();
}

Main::~Main()
{
	if (configPointer == NULL || !saveOnExit_)
		return;

	this->GetPosition(&mainWindowX_, &mainWindowY_);
	writeConfig();
}

void Main::writeConfig()
{
	wxMenuBar *menubarPointer = GetMenuBar();

	if (mainWindowX_ > 0)
		configPointer->Write(_T("/Xpos"), mainWindowX_);
	if (mainWindowY_ > 0)
		configPointer->Write(_T("/Ypos"), mainWindowY_);

	configPointer->Write(_T("/SelectedNotebook"), XRCCTRL(*this, _T(GUICOMPUTERNOTEBOOK), wxNotebook)->GetSelection());
	configPointer->Write(_T("StudioChoiceBook"), XRCCTRL(*this, _T("StudioChoiceBook"), wxChoicebook)->GetSelection());
	configPointer->Write(_T("TelmacChoiceBook"), XRCCTRL(*this, _T("TelmacChoiceBook"), wxChoicebook)->GetSelection());
	configPointer->Write(_T("DebuggerChoiceBook"), XRCCTRL(*this, _T("DebuggerChoiceBook"), wxChoicebook)->GetSelection());
	configPointer->Write(_T("CosmacChoiceBook"), XRCCTRL(*this, _T("CosmacChoiceBook"), wxChoicebook)->GetSelection());

	if (menubarPointer->IsChecked(XRCID("Flat")))
		configPointer->Write(_T("Equalization"), "Flat");
	if (menubarPointer->IsChecked(XRCID("Crisp")))
		configPointer->Write(_T("Equalization"), "Crisp");
	if (menubarPointer->IsChecked(XRCID("Default")))
		configPointer->Write(_T("Equalization"), "Default");
	if (menubarPointer->IsChecked(XRCID("TV Speaker")))
		configPointer->Write(_T("Equalization"), "TV Speaker");
	if (menubarPointer->IsChecked(XRCID("Handheld")))
		configPointer->Write(_T("Equalization"), "Handheld");

	configPointer->Write(_T("/SaveOnExit"), saveOnExit_);
	configPointer->Write(_T("/PsaveVolume"), psaveData_[0]);
	configPointer->Write(_T("/PsaveBitRate"), psaveData_[1]);
	configPointer->Write(_T("/PsaveBitsPerSample"), psaveData_[2]);

	writeDebugConfig();
	writeComxConfig();
	writeElfConfig(ELF, "Elf");
	writeElfConfig(ELFII, "ElfII");
	writeElfConfig(SUPERELF, "SuperElf");
	writeElf2KConfig();
	writeStudioConfig();
	writeVisicomConfig();
	writeVictoryConfig();
	writeVipConfig();
	writeCidelsaConfig();
	writeTelmacConfig();
	writeTMC2000Config();
	writeTMC1800Config();
	writeNanoConfig();
	writePecomConfig();
	writeEtiConfig();
}

void Main::readConfig()
{
	wxMenuBar *menubarPointer = GetMenuBar();
	Byte brightness [8] = { 0, 28, 77, 105, 150, 194, 227, 0xff };

	mainWindowX_ = configPointer->Read(_T("/Xpos"), 30);
	mainWindowY_ = configPointer->Read(_T("/Ypos"), 30);

	wxString colour[66];

	for (int i=0; i<8; i++)
	{
		colour[i*8].Printf("#%02X%02X%02X", (brightness[i]^0xff)&0xff, (brightness[i]^0xff)&0xff, (brightness[i]^0xff)&0xff);
		colour[i*8+1].Printf("#%02X%02X%02X", 0, brightness[i], 0);
		colour[i*8+2].Printf("#%02X%02X%02X", 0, 0, brightness[i]);
		colour[i*8+3].Printf("#%02X%02X%02X", 0, brightness[i], brightness[i]);
		colour[i*8+4].Printf("#%02X%02X%02X", brightness[i], 0, 0);
		colour[i*8+5].Printf("#%02X%02X%02X", brightness[i], brightness[i], 0);
		colour[i*8+6].Printf("#%02X%02X%02X", brightness[i], 0, brightness[i]);
		colour[i*8+7].Printf("#%02X%02X%02X", brightness[i], brightness[i], brightness[i]);
	}
	colour[64] = "#00ff00";	// foreground i8275
	colour[65] = "#004000";	// background i8275
	setScreenInfo(COMX, 0, 66, colour);
	setComputerInfo(COMX, "Comx", "COMX-35", "comx");

	setScreenInfo(CIDELSA, 56, 64, colour);
	setComputerInfo(CIDELSA, "Cidelsa", "Cidelsa", "");

	setScreenInfo(TMC600, 56, 64, colour);
	setComputerInfo(TMC600, "Tmc600", "Telmac 600", "tmc600");

	setScreenInfo(PECOM, 56, 64, colour);
	setComputerInfo(PECOM, "Pecom", "Pecom 64", "pecom");

	colour[0] = "#ffffff";	// foreground pixie
	colour[1] = "#000000";	// background pixie
	colour[2] = "#00ff00";	// foreground i8275
	colour[3] = "#004000";	// background i8275
	colour[4] = "#00ff00";	// highlight i8275
	setScreenInfo(ELF2K, 0, 5, colour);
	setComputerInfo(ELF2K, "Elf2K", "Elf 2000", "");

	colour[5] = "#000000";	// background mc6847
	colour[6] = "#00ff00";	// text green
	colour[7] = "#ffc418";	// text orange
	colour[8] = "#00ff00";	// graphic Green
	colour[9] = "#ffff00";	// graphic Yellow 
	colour[10] = "#0000ff";	// graphic Blue
	colour[11] = "#ff0000";	// graphic Red
	colour[12] = "#ffffff";	// graphic Buff
	colour[13] = "#00ffff";	// graphic Cyan
	colour[14] = "#ff00ff";	// graphic Magenta
	colour[15] = "#ffc418";	// graphic Orange
	colour[16] = "#000000";
	colour[17] = "#000000";
	colour[18] = "#007f00";
	colour[19] = "#00ff00";
	colour[20] = "#00003f";
	colour[21] = "#0000ff";
	colour[22] = "#3f0000";
	colour[23] = "#007f7f";
	colour[24] = "#7f0000";
	colour[25] = "#ff0000";
	colour[26] = "#7f7f00";
	colour[27] = "#ffff00";
	colour[28] = "#003f00";
	colour[29] = "#7f007f";
	colour[30] = "#7f7f7f";
	colour[31] = "#ffffff";
	setScreenInfo(ELF, 0, 32, colour);
	setComputerInfo(ELF, "Elf", "Cosmac Elf", "");

	setScreenInfo(ELFII, 0, 32, colour);
	setComputerInfo(ELFII, "ElfII", "Netronics Elf II", "super");

	setScreenInfo(SUPERELF, 0, 32, colour);
	setComputerInfo(SUPERELF, "SuperElf", "Quest Super Elf", "super");

	setScreenInfo(STUDIO, 0, 2, colour);
	setComputerInfo(STUDIO, "Studio2", "Studio II", "");

	setScreenInfo(NANO, 0, 2, colour);
	setComputerInfo(NANO, "Nano", "Telmac Nano", "");

	setScreenInfo(TMC1800, 0, 2, colour);
	setComputerInfo(TMC1800, "TMC1800", "Telmac 1800", "");

	colour[0] = "#004000";
	colour[1] = "#70d0ff";
	colour[2] = "#d0ff70";
	colour[3] = "#ff7070";
	setScreenInfo(VISICOM, 0, 4, colour);
	setComputerInfo(VISICOM, "Visicom", "Visicom COM-100", "");

	colour[0] = "#141414";
	colour[1] = "#ff0000";
	colour[2] = "#0000ff";
	colour[3] = "#ff00ff";
	colour[4] = "#00ff00";
	colour[5] = "#ffff00";
	colour[6] = "#00ffff";
	colour[7] = "#ffffff";
	colour[8] = "#000080";
	colour[9] = "#000000";
	colour[10] = "#008000";
	colour[11] = "#800000";
	setScreenInfo(VIP, 0, 12, colour);
	setComputerInfo(VIP, "Vip", "Cosmac VIP", "");

	setScreenInfo(ETI, 0, 12, colour);
	setComputerInfo(ETI, "Eti", "ETI 660", "");

	colour[0] = "#ffffff";
	colour[1] = "#ff00ff";
	colour[2] = "#00ffff";
	colour[3] = "#0000ff";
	colour[4] = "#ffff00";
	colour[5] = "#ff0000";
	colour[6] = "#00ff00";
	colour[7] = "#141414";
	setScreenInfo(TMC2000, 0, 12, colour);
	setComputerInfo(TMC2000, "TMC2000", "Telmac 2000", "");

	colour[0] = "#ffffff";
	colour[1] = "#ff40ff";
	colour[2] = "#40ffff";
	colour[3] = "#4040ff";
	colour[4] = "#ffff40";
	colour[5] = "#ff4040";
	colour[6] = "#40ff40";
	colour[7] = "#141414";
	colour[8] = "#d0a0ff";
	colour[9] = "#a0a0a0";
	colour[10] = "#a0ffa0";
	colour[11] = "#d0a0a0";
	setScreenInfo(VICTORY, 0, 12, colour);
	setComputerInfo(VICTORY, "Victory", "Victory MPT-02", "");

	readDebugConfig();
	readComxConfig();
	readElfConfig(ELF, "Elf");
	readElfConfig(ELFII, "ElfII");
	readElfConfig(SUPERELF, "SuperElf");
	readElf2KConfig();
	readVipConfig();
	readStudioConfig();
	readVisicomConfig();
	readVictoryConfig();
	readCidelsaConfig();
	readTelmacConfig();
	readTMC1800Config();
	readTMC2000Config();
	readNanoConfig();
	readPecomConfig();
	readEtiConfig();

	configPointer->Read(_T("/SaveOnExit"), &saveOnExit_, true);
	menubarPointer->Check(XRCID(GUISAVEONEXIT), saveOnExit_);
	menubarPointer->Check(XRCID(configPointer->Read(_T("Equalization"), "TV Speaker")), true);

	if (configPointer->Read(_T("Equalization")) == "Flat")
	{
		bass_ = 1;
		treble_ = 0;
	}

	if (configPointer->Read(_T("Equalization")) == "Crisp")
	{
		bass_ = 1;
		treble_ = 5;
	}

	if (configPointer->Read(_T("Equalization")) == "Default")
	{
		bass_ = 16;
		treble_ = -8;
	}

	if (configPointer->Read(_T("Equalization")) == "TV Speaker")
	{
		bass_ = 180;
		treble_ = -8;
	}

	if (configPointer->Read(_T("Equalization")) == "Handheld")
	{
		bass_ = 2000;
		treble_ = -47;
	}

	XRCCTRL(*this, _T(GUICOMPUTERNOTEBOOK), wxNotebook)->SetSelection(COMXTAB);
	XRCCTRL(*this, _T(GUICOMPUTERNOTEBOOK), wxNotebook)->SetSelection(MESSAGETAB);

	XRCCTRL(*this, _T("StudioChoiceBook"), wxChoicebook)->SetSelection(configPointer->Read(_T("StudioChoiceBook"), 0l));
	XRCCTRL(*this, _T("CosmacChoiceBook"), wxChoicebook)->SetSelection(configPointer->Read(_T("CosmacChoiceBook"), 0l));
	XRCCTRL(*this, _T("TelmacChoiceBook"), wxChoicebook)->SetSelection(configPointer->Read(_T("TelmacChoiceBook"), 0l));
	XRCCTRL(*this, _T("DebuggerChoiceBook"), wxChoicebook)->SetSelection(configPointer->Read(_T("DebuggerChoiceBook"), 0l));

	XRCCTRL(*this, _T(GUICOMPUTERNOTEBOOK), wxNotebook)->SetSelection(configPointer->Read(_T("SelectedNotebook"), 0l));

	psaveData_[0] = configPointer->Read(_T("/PsaveVolume"), 15l);
	psaveData_[1] = configPointer->Read(_T("/PsaveBitRate"), 0l);
	psaveData_[2] = configPointer->Read(_T("/PsaveBitsPerSample"), 1l);
}

void Main::onHelp(wxCommandEvent& WXUNUSED(event))
{
	helpController_.DisplayContents();
	helpController_.SetFrameParameters(_T("1802 Emulator Help"), wxSize(windowInfo.mainwX, windowInfo.mainwY), wxPoint(mainWindowX_, mainWindowY_ + windowInfo.mainwY));
}

void Main::onQuit(wxCommandEvent&WXUNUSED(event))
{
	stopComputer();
	Destroy();
}

void Main::onSaveOnExit(wxCommandEvent&event)
{
	saveOnExit_ = event.IsChecked();
}

void Main::onSaveConfig(wxCommandEvent&WXUNUSED(event))
{
	writeConfig();
}

void Main::onClose(wxCloseEvent&WXUNUSED(event))
{
	stopComputer();
	Destroy();
}

void Main::onAbout(wxCommandEvent&WXUNUSED(event))
{
	MyAboutDialog MyAboutDialog(this);
 	MyAboutDialog.ShowModal();
}

void Main::onDefaultSettings(wxCommandEvent&WXUNUSED(event))
{
	for (int i=0; i<4; i++)
	{
		delete baudTextT[i];
		delete baudChoiceT[i];
		delete baudTextR[i];
		delete baudChoiceR[i];
	}
	configPointer->DeleteAll();
	readConfig();
}

void Main::onFlat(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 1;
	treble_ = 0;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onCrisp(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 1;
	treble_ = 5;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onDefault(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 16;
	treble_ = -8;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onTvSpeaker(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 180;
	treble_ = -8;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onHandheld(wxCommandEvent&WXUNUSED(event))
{
	bass_ = 2000;
	treble_ = -47;
	if (computerRunning_)
		p_Computer->setEqualization(bass_, treble_);
}

void Main::onDefaultWindowPosition(wxCommandEvent&WXUNUSED(event))
{
	mainWindowX_ = 30;
	mainWindowY_ = 30;
	conf[COMX].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[COMX].mainY_ = mainWindowY_;
	conf[CIDELSA].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[CIDELSA].mainY_ = mainWindowY_;
	conf[TMC600].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[TMC600].mainY_ = mainWindowY_;
	conf[VIP].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[VIP].mainY_ = mainWindowY_;
	conf[TMC1800].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[TMC1800].mainY_ = mainWindowY_;
	conf[TMC2000].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[TMC2000].mainY_ = mainWindowY_;
	conf[ETI].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[ETI].mainY_ = mainWindowY_;
	conf[NANO].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[NANO].mainY_ = mainWindowY_;
	conf[PECOM].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[PECOM].mainY_ = mainWindowY_;
	conf[STUDIO].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[STUDIO].mainY_ = mainWindowY_;
	conf[VISICOM].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[VISICOM].mainY_ = mainWindowY_;
	conf[VICTORY].mainX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
	conf[VICTORY].mainY_ = mainWindowY_;

	for (int i=0; i<4; i++)
	{
		conf[i].pixieX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].pixieY_ = mainWindowY_;
		conf[i].tmsX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].tmsY_ = mainWindowY_;
		conf[i].mc6845X_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].mc6845Y_ = mainWindowY_;
		conf[i].mc6847X_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].mc6847Y_ = mainWindowY_;
		conf[i].i8275X_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].i8275Y_ = mainWindowY_;
		conf[i].vtX_ = mainWindowX_+windowInfo.mainwX+windowInfo.xBorder;
		conf[i].vtY_ = mainWindowY_;

		conf[i].mainX_ = mainWindowX_;
		conf[i].mainY_ = mainWindowY_+windowInfo.mainwY+windowInfo.yBorder;
	}

	conf[ELF2K].keypadX_ = mainWindowX_+507+windowInfo.xBorder2;
	conf[ELF2K].keypadY_ = mainWindowY_+478+windowInfo.yBorder2;
	conf[ELF].keypadX_ = mainWindowX_+346+windowInfo.xBorder2;
	conf[ELF].keypadY_ = mainWindowY_+windowInfo.mainwY+windowInfo.yBorder;
	ledModuleX_ = mainWindowX_+346+windowInfo.xBorder2;
	ledModuleY_ = mainWindowY_+windowInfo.mainwY+229+windowInfo.yBorder2;
	switchX_ = mainWindowX_+507+windowInfo.xBorder2;
	switchY_ = mainWindowY_+478+windowInfo.yBorder2;

	this->Move(mainWindowX_, mainWindowY_);
	switch (runningComputer_)
	{
		case COMX:
			p_Comx->Move(conf[COMX].mainX_, conf[COMX].mainY_);
		break;

		case CIDELSA:
			p_Cidelsa->Move(conf[CIDELSA].mainX_, conf[CIDELSA].mainY_);
		break;

		case TMC600:
			p_Tmc600->Move(conf[TMC600].mainX_, conf[TMC600].mainY_);
		break;

		case TMC2000:
			p_Tmc2000->Move(conf[TMC2000].mainX_, conf[TMC2000].mainY_);
		break;

		case TMC1800:
			p_Tmc1800->Move(conf[TMC1800].mainX_, conf[TMC1800].mainY_);
		break;

		case ETI:
			p_Eti->Move(conf[ETI].mainX_, conf[ETI].mainY_);
		break;

		case NANO:
			p_Nano->Move(conf[NANO].mainX_, conf[NANO].mainY_);
		break;

		case PECOM:
			p_Pecom->Move(conf[PECOM].mainX_, conf[PECOM].mainY_);
		break;

		case STUDIO:
			p_Studio2->Move(conf[STUDIO].mainX_, conf[STUDIO].mainY_);
		break;

		case VISICOM:
			p_Visicom->Move(conf[VISICOM].mainX_, conf[VISICOM].mainY_);
		break;

		case VICTORY:
			p_Victory->Move(conf[VICTORY].mainX_, conf[VICTORY].mainY_);
		break;

		case VIP:
			p_Vip->Move(conf[VIP].mainX_, conf[VIP].mainY_);
		break;

		case ELF2K:
			p_Elf2K->moveWindows();
			p_Elf2K->Move(conf[ELF2K].mainX_, conf[ELF2K].mainY_);
		break;

		case ELF:
			p_Elf->moveWindows();
			p_Elf->Move(conf[ELF].mainX_, conf[ELF].mainY_);
		break;

		case ELFII:
			p_Elf2->moveWindows();
			p_Elf2->Move(conf[ELFII].mainX_, conf[ELFII].mainY_);
		break;

		case SUPERELF:
			p_Super->moveWindows();
			p_Super->Move(conf[SUPERELF].mainX_, conf[SUPERELF].mainY_);
		break;
	}
}

void Main::onStart(wxCommandEvent&WXUNUSED(event))
{
	int zoom;
	int comxy;
	int stereo = 1;
	int toneChannels = 1;

	emuClosing_ = false;
	if (computerRunning_)
	{
		p_Computer->onReset();
		return;
	}

	p_Video = NULL;
	p_Vt100 = NULL;

	runningComputer_ = selectedComputer_;
	wxSetWorkingDirectory(workingDir_);
	setClock(runningComputer_);
	zoom = getSpinValue(_T("Zoom"+computerInfo[runningComputer_].gui));

	switch (runningComputer_)
	{
		case COMX:
			p_Main->setComxExpLedOn (false);
			if (getChoiceSelection("VidModeComx") == PAL)
				comxy = 216;
			else
				comxy = 192;
			p_Comx = new Comx(computerInfo[COMX].name, wxPoint(conf[COMX].mainX_, conf[COMX].mainY_), wxSize(240 * zoom, comxy * zoom), zoom, COMX, conf[COMX].clockSpeed_);
			p_Video = p_Comx;
			p_Computer = p_Comx;
		break;

		case ELF:
			p_Elf = new Elf(computerInfo[ELF].name, wxPoint(conf[ELF].mainX_, conf[ELF].mainY_), wxSize(346, 464), conf[ELF].clockSpeed_, elfConfiguration[ELF]);
			p_Computer = p_Elf;
		break;

		case ELFII:
			p_Elf2 = new Elf2(computerInfo[ELFII].name, wxPoint(conf[ELFII].mainX_, conf[ELFII].mainY_), wxSize(534, 386), conf[ELFII].clockSpeed_, elfConfiguration[ELFII]);
			p_Computer = p_Elf2;
		break;

		case SUPERELF:
			p_Super = new Super(computerInfo[SUPERELF].name, wxPoint(conf[SUPERELF].mainX_, conf[SUPERELF].mainY_), wxSize(534, 386), selectedComputer_, conf[SUPERELF].clockSpeed_, elfConfiguration[SUPERELF]);
			p_Computer = p_Super;
		break;

		case ELF2K:
			p_Elf2K = new Elf2K(computerInfo[ELF2K].name, wxPoint(conf[ELF2K].mainX_, conf[ELF2K].mainY_), wxSize(507, 459), conf[ELF2K].clockSpeed_, elfConfiguration[ELF2K]);
			p_Computer = p_Elf2K;
		break;

		case STUDIO:
			p_Studio2 = new Studio2(computerInfo[STUDIO].name, wxPoint(conf[STUDIO].mainX_, conf[STUDIO].mainY_), wxSize(192*zoom, 128*zoom), zoom, STUDIO);
			p_Video = p_Studio2;
			p_Computer = p_Studio2;
		break;

		case VISICOM:
			p_Visicom = new Visicom(computerInfo[VISICOM].name, wxPoint(conf[VISICOM].mainX_, conf[VISICOM].mainY_), wxSize(192*zoom, 128*zoom), zoom, VISICOM);
			p_Video = p_Visicom;
			p_Computer = p_Visicom;
		break;

		case VICTORY:
			p_Victory = new Victory(computerInfo[VICTORY].name, wxPoint(conf[VICTORY].mainX_, conf[VICTORY].mainY_), wxSize(192*zoom, 192*zoom), zoom, VICTORY);
			p_Video = p_Victory;
			p_Computer = p_Victory;
		break;

		case VIP:
			p_Vip = new Vip(computerInfo[VIP].name, wxPoint(conf[VIP].mainX_, conf[VIP].mainY_), wxSize(192*zoom, 128*zoom), zoom, VIP, conf[VIP].clockSpeed_, conf[VIP].tempo_);
			p_Video = p_Vip;
			p_Computer = p_Vip;
			if (XRCCTRL(*this, "StereoVip", wxCheckBox)->GetValue())
				stereo = 2;
			if (conf[VIP].vipSound_ == VIP_SUPER2)
				toneChannels = 2;
			if (conf[VIP].vipSound_ == VIP_SUPER4)
				toneChannels = 4;
		break;

		case TMC1800:
			p_Tmc1800 = new Tmc1800(computerInfo[TMC1800].name, wxPoint(conf[TMC1800].mainX_, conf[TMC1800].mainY_), wxSize(192*zoom, 128*zoom), zoom, TMC1800);
			p_Video = p_Tmc1800;
			p_Computer = p_Tmc1800;
		break;

		case TMC2000:
			p_Tmc2000 = new Tmc2000(computerInfo[TMC2000].name, wxPoint(conf[TMC2000].mainX_, conf[TMC2000].mainY_), wxSize(192*zoom, 192*zoom), zoom, TMC2000);
			p_Video = p_Tmc2000;
			p_Computer = p_Tmc2000;
		break;

		case ETI:
			p_Eti = new Eti(computerInfo[ETI].name, wxPoint(conf[ETI].mainX_, conf[ETI].mainY_), wxSize(192*zoom, 192*zoom), zoom, ETI);
			p_Video = p_Eti;
			p_Computer = p_Eti;
		break;

		case NANO:
			p_Nano = new Nano(computerInfo[NANO].name, wxPoint(conf[NANO].mainX_, conf[NANO].mainY_), wxSize(192*zoom, 192*zoom), zoom, NANO);
			p_Video = p_Nano;
			p_Computer = p_Nano;
		break;

		case CIDELSA:
			p_Cidelsa = new Cidelsa(computerInfo[CIDELSA].name, wxPoint(conf[CIDELSA].mainX_, conf[CIDELSA].mainY_), wxSize(200*zoom, 240*zoom), zoom, CIDELSA, conf[CIDELSA].clockSpeed_);
			p_Video = p_Cidelsa;
			p_Computer = p_Cidelsa;
		break;

		case TMC600:
			p_Tmc600 = new Tmc600(computerInfo[TMC600].name, wxPoint(conf[TMC600].mainX_, conf[TMC600].mainY_), wxSize(240*zoom, 216*zoom), zoom, TMC600, conf[TMC600].clockSpeed_);
			p_Video = p_Tmc600;
			p_Computer = p_Tmc600;
		break;

		case PECOM:
			p_Pecom = new Pecom(computerInfo[PECOM].name, wxPoint(conf[PECOM].mainX_, conf[PECOM].mainY_), wxSize(240*zoom, 216*zoom), zoom, PECOM, conf[PECOM].clockSpeed_);
			p_Video = p_Pecom;
			p_Computer = p_Pecom;
		break;
	}
	enableGui(false);
	computerRunning_ = true;
	enableDebugGuiMemory();
	p_Computer->initCpu(selectedComputer_);
	p_Computer->configureComputer();
	p_Computer->initSound(conf[runningComputer_].clockSpeed_, runningComputer_, conf[runningComputer_].volume_, bass_, treble_, toneChannels, stereo);
	p_Computer->initComputer();
	p_Computer->startComputer();
}

void Main::stopComputer()
{
	if (emuClosing_)  return;
	emuClosing_ = true;
	switch (runningComputer_)
	{
		case COMX:
			setComxStatusLedOn (false);
		break;
		case ELF:
		case ELFII:
		case SUPERELF:
			enableMemAccessGui(false);
		break;
		case NO_COMPUTER:
			return;
		break;
	}
	p_Computer->stopComputer();
	p_Computer->showTime();
	delete p_Computer;
	p_Computer = NULL;
	p_Video = NULL;
	p_Vt100 = NULL;
	computerRunning_ = false;
	enableGui(true);
	runningComputer_ = NO_COMPUTER;
}

void Main::onComputer(wxNotebookEvent&event)
{
	switch(event.GetSelection())
	{
		case COMXTAB:
			selectedComputer_ = COMX;
		break;

		case ELFTAB:
			selectedComputer_ = elfChoice_;
		break;

		case STUDIOTAB:
			selectedComputer_ = studioChoice_;
		break;

		case CIDELSATAB:
			selectedComputer_ = CIDELSA;
		break;

		case TELMACTAB:
			selectedComputer_ = telmacChoice_;
		break;

		case PECOMTAB:
			selectedComputer_ = PECOM;
		break;

		case ETITAB:
			selectedComputer_ = ETI;
		break;

		case DEBUGGERTAB:
			selectedComputer_ = DEBUGGER;
		break;

		case MESSAGETAB:
			selectedComputer_ = MESSAGE;
		break;
	}
	enableElfConfig(selectedComputer_ < 3);
}

void Main::onStudioChoiceBook(wxChoicebookEvent&event)
{
	switch(event.GetSelection())
	{
		case 0:
			studioChoice_ = STUDIO;
		break;

		case 1:
			studioChoice_ = VISICOM;
		break;

		case 2:
			studioChoice_ = VICTORY;
		break;
	}
	selectedComputer_ = studioChoice_;
}

void Main::onTelmacChoiceBook(wxChoicebookEvent&event)
{
	switch(event.GetSelection())
	{
		case 0:
			telmacChoice_ = TMC600;
		break;

		case 1:
			telmacChoice_ = TMC1800;
		break;

		case 2:
			telmacChoice_ = TMC2000;
		break;

		case 3:
			telmacChoice_ = NANO;
		break;
	}
	selectedComputer_ = telmacChoice_;
}

void Main::onCosmacChoiceBook(wxChoicebookEvent&event)
{
	switch(event.GetSelection())
	{
		case 0:
			elfChoice_ = ELF2K;
		break;

		case 1:
			elfChoice_ = VIP;
		break;

		case 2:
			elfChoice_ = ELF; 
		break;

		case 3:
			elfChoice_ = ELFII;
		break;

		case 4:
			elfChoice_ = SUPERELF;
		break;
	}
	selectedComputer_ = elfChoice_;
	enableElfConfig(selectedComputer_ < 3);
}

void Main::enableElfConfig(bool status)
{
	wxMenuBar *menubarPointer = GetMenuBar();

	menubarPointer->Enable(XRCID(_T("MI_GameMode")), status);
	menubarPointer->Enable(XRCID(_T("MI_GiantBoard")), status);
	menubarPointer->Enable(XRCID(_T("MI_SuperBasic")), status);
	menubarPointer->Enable(XRCID(_T("MI_SuperBasicSerial")), status);
	menubarPointer->Enable(XRCID(_T("MI_RcaBasic")), status);
	menubarPointer->Enable(XRCID(_T("MI_RcaBasicSerial")), status);
	menubarPointer->Enable(XRCID(_T("MI_RcaBasicElfOsInstall")), status);
	menubarPointer->Enable(XRCID(_T("MI_Music")), status);
	menubarPointer->Enable(XRCID(_T("MI_TinyBasicPixie")), status);
	menubarPointer->Enable(XRCID(_T("MI_TinyBasicSerial")), status);
	menubarPointer->Enable(XRCID(_T("MI_TinyBasic6847")), status);
	menubarPointer->Enable(XRCID(_T("MI_SetElfOsInstallConfig")), status);
	menubarPointer->Enable(XRCID(_T("MI_SetElfOsConfig")), status);
	menubarPointer->Enable(XRCID(_T("MI_SetElfOsInstallConfig25")), status);
	menubarPointer->Enable(XRCID(_T("MI_SetElfOsConfig25")), status);
	menubarPointer->Enable(XRCID(_T("MI_SetElfOsIoInstallConfigPixie")), status);
	menubarPointer->Enable(XRCID(_T("MI_SetElfOsIoConfigPixie")), status);
	menubarPointer->Enable(XRCID(_T("MI_SetElfOsIoInstallConfig6845")), status);
	menubarPointer->Enable(XRCID(_T("MI_SetElfOsIoConfig6845")), status);
	menubarPointer->Enable(XRCID(_T("MI_SetElfOsIoInstallConfig6847")), status);
	menubarPointer->Enable(XRCID(_T("MI_SetElfOsIoConfig6847")), status);
	menubarPointer->Enable(XRCID(_T("MI_SetElfOsIoInstallConfigTms")), status);
	menubarPointer->Enable(XRCID(_T("MI_SetElfOsIoConfigTms")), status);
}

void Main::enableGui(bool status)
{
	wxMenuBar *menubarPointer = GetMenuBar();

	menubarPointer->Enable(XRCID(_T(GUIDEFAULT)), status);

	if (runningComputer_ == COMX)
	{
		XRCCTRL(*this,_T("ColoursElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElfII"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursSuperElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursCidelsa"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursPecom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursEti"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("MainRomComx"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonComx"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ExpRomComx"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("ExpRomButtonComx"), wxButton)->Enable(status);
		XRCCTRL(*this, _T("Cart1RomComx"), wxComboBox)->Enable(status);
		XRCCTRL(*this, _T("Cart1RomButtonComx"), wxButton)->Enable(status);
		if (expansionRomLoaded_)
		{
			XRCCTRL(*this,_T("Cart2RomComx"), wxComboBox)->Enable(status);
			XRCCTRL(*this,_T("Cart2RomButtonComx"), wxButton)->Enable(status);
			XRCCTRL(*this,_T("Cart3RomComx"), wxComboBox)->Enable(status);
			XRCCTRL(*this,_T("Cart3RomButtonComx"), wxButton)->Enable(status);
			XRCCTRL(*this,_T("Cart4RomComx"), wxComboBox)->Enable(status);
			XRCCTRL(*this,_T("Cart4RomButtonComx"), wxButton)->Enable(status);
		}
		XRCCTRL(*this,_T("VidModeComx"), wxChoice)->Enable(status);
		XRCCTRL(*this,_T("VidModeTextComx"), wxStaticText)->Enable(status);
		XRCCTRL(*this,_T("PrintButtonComx"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("ScreenDumpF5Comx"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("FullScreenF3Comx"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("ExpRamComx"), wxCheckBox)->Enable(status);
		enableLoadGui(!status);
		enableDiskRomGui(diskRomLoaded_);
		enableComxGui(status);
	}
	if (runningComputer_ == CIDELSA)
	{
		XRCCTRL(*this,_T("ColoursComx"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElfII"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursSuperElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursPecom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursEti"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("MainRomCidelsa"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonCidelsa"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ScreenDumpF5Cidelsa"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("FullScreenF3Cidelsa"), wxButton)->Enable(!status);
	}
	if (runningComputer_ == TMC600)
	{
		XRCCTRL(*this,_T("ColoursComx"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElfII"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursSuperElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursCidelsa"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursPecom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursEti"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("PrintButtonTmc600"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("ScreenDumpF5Tmc600"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("FullScreenF3Tmc600"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("MainRomTmc600"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ExpRomTmc600"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("ExpRomButtonTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("CharRomTmc600"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("CharRomButtonTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("RamTmc600"), wxChoice)->Enable(status);
		XRCCTRL(*this,_T("RamTextTmc600"), wxStaticText)->Enable(status);
		if (status == true)
		{
			XRCCTRL(*this,_T("AdiInputText"), wxStaticText)->Enable(!status);
			XRCCTRL(*this,_T("AdiChannel"), wxSpinCtrl)->Enable(!status);
			XRCCTRL(*this,_T("AdiVolt"), wxSpinCtrl)->Enable(!status);
			XRCCTRL(*this,_T("AdiVoltText"), wxStaticText)->Enable(!status);
			XRCCTRL(*this,_T("AdsInputText"), wxStaticText)->Enable(!status);
			XRCCTRL(*this,_T("AdsChannel"), wxSpinCtrl)->Enable(!status);
			XRCCTRL(*this,_T("AdsVolt"), wxSpinCtrl)->Enable(!status);
			XRCCTRL(*this,_T("AdsVoltText"), wxStaticText)->Enable(!status);
		}
		enableLoadGui(!status);
	}
	if (runningComputer_ == PECOM)
	{
		XRCCTRL(*this,_T("ColoursComx"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElfII"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursSuperElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursCidelsa"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursEti"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("PrintButtonPecom"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("ScreenDumpF5Pecom"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("FullScreenF3Pecom"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("MainRomPecom"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonPecom"), wxButton)->Enable(status);
		enableLoadGui(!status);
	}
	if (runningComputer_ == VIP)
	{
		XRCCTRL(*this,_T("ColoursComx"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElfII"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursSuperElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursCidelsa"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursPecom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursEti"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("KeyMapVip"), wxButton)->Enable(status&!getCheckBox("KeyboardVip"));
		XRCCTRL(*this,_T("MainRomVip"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("RamSWVip"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RamSWButtonVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("Chip8SWVip"), wxTextCtrl)->Enable(status);
		XRCCTRL(*this,_T("Chip8SWButtonVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("EjectChip8SWVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("VP580"),wxCheckBox)->Enable(status);
		XRCCTRL(*this,_T("VP590"),wxCheckBox)->Enable(status);
		XRCCTRL(*this,_T("KeyboardVip"),wxCheckBox)->Enable(status);
		XRCCTRL(*this,_T("SoundVip"),wxChoice)->Enable(status);
		XRCCTRL(*this,_T("StereoVip"),wxCheckBox)->Enable(status);
		XRCCTRL(*this,_T("FullScreenF3Vip"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("RamVip"), wxSpinCtrl)->Enable(status);
		XRCCTRL(*this,_T("RamTextVip"), wxStaticText)->Enable(status);
		XRCCTRL(*this,_T("RamKbVip"), wxStaticText)->Enable(status);
		XRCCTRL(*this,_T("ScreenDumpF5Vip"), wxButton)->Enable(!status);
		enableLoadGui(!status);
	}
	if (runningComputer_ == STUDIO)
	{
		XRCCTRL(*this,_T("KeyMapStudio2"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("MainRomStudio2"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonStudio2"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("CartRomStudio2"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("CartRomButtonStudio2"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("FullScreenF3Studio2"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("ScreenDumpF5Studio2"), wxButton)->Enable(!status);
	}
	if (runningComputer_ == VISICOM)
	{
		XRCCTRL(*this,_T("KeyMapVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("MainRomVisicom"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("CartRomVisicom"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("CartRomButtonVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("FullScreenF3Visicom"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("ScreenDumpF5Visicom"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("ColoursComx"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElfII"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursSuperElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursCidelsa"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursPecom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursEti"), wxButton)->Enable(status);
	}
	if (runningComputer_ == VICTORY)
	{
		XRCCTRL(*this,_T("KeyMapVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("MainRomVictory"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("CartRomVictory"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("CartRomButtonVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("FullScreenF3Victory"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("ScreenDumpF5Victory"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("ColoursComx"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElfII"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursSuperElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursCidelsa"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursPecom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursEti"), wxButton)->Enable(status);
	}
	if (runningComputer_ == TMC2000)
	{
		XRCCTRL(*this,_T("KeyMapTMC2000"), wxButton)->Enable(status&!getCheckBox("KeyboardTMC2000"));
		XRCCTRL(*this,_T("MainRomTMC2000"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("RamSWTMC2000"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RamSWButtonTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("Chip8SWTMC2000"), wxTextCtrl)->Enable(status);
		XRCCTRL(*this,_T("EjectChip8SWTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("Chip8SWButtonTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("FullScreenF3TMC2000"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("RamTMC2000"), wxChoice)->Enable(status);
		XRCCTRL(*this,_T("RamTextTMC2000"), wxStaticText)->Enable(status);
		XRCCTRL(*this,_T("ScreenDumpF5TMC2000"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("ColoursComx"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElfII"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursSuperElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursCidelsa"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursPecom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursEti"), wxButton)->Enable(status);
		enableLoadGui(!status);
	}
	if (runningComputer_ == TMC1800)
	{
		XRCCTRL(*this,_T("KeyMapTMC1800"), wxButton)->Enable(status&!getCheckBox("KeyboardTMC1800"));
		XRCCTRL(*this,_T("MainRomTMC1800"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonTMC1800"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("RamSWTMC1800"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RamSWButtonTMC1800"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("Chip8SWTMC1800"), wxTextCtrl)->Enable(status);
		XRCCTRL(*this,_T("EjectChip8SWTMC1800"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("Chip8SWButtonTMC1800"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("FullScreenF3TMC1800"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("RamTMC1800"), wxChoice)->Enable(status);
		XRCCTRL(*this,_T("RamTextTMC1800"), wxStaticText)->Enable(status);
		XRCCTRL(*this,_T("ScreenDumpF5TMC1800"), wxButton)->Enable(!status);
		enableLoadGui(!status);
	}
	if (runningComputer_ == ETI)
	{
		XRCCTRL(*this,_T("ColoursComx"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElfII"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursSuperElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursCidelsa"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursPecom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("KeyMapEti"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("MainRomEti"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonEti"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("Chip8SWEti"), wxTextCtrl)->Enable(status);
		XRCCTRL(*this,_T("EjectChip8SWEti"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("Chip8SWButtonEti"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("FullScreenF3Eti"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("ScreenDumpF5Eti"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("RamEti"), wxChoice)->Enable(status);
		XRCCTRL(*this,_T("RamTextEti"), wxStaticText)->Enable(status);
		enableLoadGui(!status);
	}
	if (runningComputer_ == NANO)
	{
		XRCCTRL(*this,_T("KeyMapNano"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("MainRomNano"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonNano"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("RamSWNano"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RamSWButtonNano"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("Chip8SWNano"), wxTextCtrl)->Enable(status);
		XRCCTRL(*this,_T("EjectChip8SWNano"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("Chip8SWButtonNano"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("FullScreenF3Nano"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("ScreenDumpF5Nano"), wxButton)->Enable(!status);
		XRCCTRL(*this,_T("SoundNano"), wxChoice)->Enable(status);
		XRCCTRL(*this,_T("SoundTextNano"), wxStaticText)->Enable(status);
		enableLoadGui(!status);
	}

	if (runningComputer_ == ELF || runningComputer_ == ELFII || runningComputer_ == SUPERELF)
	{
		XRCCTRL(*this,_T("ColoursComx"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursCidelsa"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursPecom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursEti"), wxButton)->Enable(status);
		wxString elfTypeStr;
		switch (runningComputer_)
		{
			case ELF:
				XRCCTRL(*this,_T("ColoursElfII"), wxButton)->Enable(status);
				XRCCTRL(*this,_T("ColoursSuperElf"), wxButton)->Enable(status);
				XRCCTRL(*this, _T("ShowAddressElf"), wxTextCtrl)->Enable(status&elfConfiguration[ELF].useElfControlWindows);
				XRCCTRL(*this,_T("AddressText1Elf"),wxStaticText)->Enable(status&elfConfiguration[ELF].useElfControlWindows);
				XRCCTRL(*this,_T("AddressText2Elf"),wxStaticText)->Enable(status&elfConfiguration[ELF].useElfControlWindows);
				XRCCTRL(*this,_T("UseLedModule"), wxCheckBox)->Enable(status);
				elfTypeStr = "Elf";
			break;
			case ELFII:
				XRCCTRL(*this,_T("ColoursElf"), wxButton)->Enable(status);
				XRCCTRL(*this,_T("ColoursSuperElf"), wxButton)->Enable(status);
				elfTypeStr = "ElfII";
			break;
			case SUPERELF:
				XRCCTRL(*this,_T("ColoursElf"), wxButton)->Enable(status);
				XRCCTRL(*this,_T("ColoursElfII"), wxButton)->Enable(status);
				XRCCTRL(*this, _T("ShowAddressSuperElf"), wxTextCtrl)->Enable(status&elfConfiguration[SUPERELF].useElfControlWindows);
				XRCCTRL(*this,_T("AddressText1SuperElf"),wxStaticText)->Enable(status&elfConfiguration[SUPERELF].useElfControlWindows);
				XRCCTRL(*this,_T("AddressText2SuperElf"),wxStaticText)->Enable(status&elfConfiguration[SUPERELF].useElfControlWindows);
				elfTypeStr = "SuperElf";
			break;
		}
		enableLoadGui(!status);
		enableElfConfig(status);
		XRCCTRL(*this,_T("Tape"+elfTypeStr), wxCheckBox)->Enable(status);
		XRCCTRL(*this,_T("MainRom"+elfTypeStr), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("MainRom2"+elfTypeStr), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButton"+elfTypeStr), wxButton)->Enable(status);
		XRCCTRL(*this,_T("Rom1"+elfTypeStr), wxButton)->Enable(status);
		XRCCTRL(*this,_T("RomButton2"+elfTypeStr), wxButton)->Enable(status);
		XRCCTRL(*this,_T("Rom2"+elfTypeStr), wxButton)->Enable(status);
		XRCCTRL(*this,_T("DP_Button"+elfTypeStr), wxButton)->Enable(status);
		XRCCTRL(*this,_T("KeyMap"+elfTypeStr), wxButton)->Enable(status&elfConfiguration[runningComputer_].useHexKeyboard);
		if (elfConfiguration[runningComputer_].ideEnabled)
		{
			XRCCTRL(*this,_T("IDE_Button"+elfTypeStr), wxButton)->Enable(status);
			XRCCTRL(*this,_T("IdeFile"+elfTypeStr), wxTextCtrl)->Enable(status);
			XRCCTRL(*this,_T("Eject_IDE"+elfTypeStr), wxButton)->Enable(status);
		}
		XRCCTRL(*this,_T("AutoBoot"+elfTypeStr), wxCheckBox)->Enable(status);
		XRCCTRL(*this,_T("BootAddress"+elfTypeStr), wxTextCtrl)->Enable(status);
		XRCCTRL(*this,_T("Printer"+elfTypeStr),wxCheckBox)->Enable(status);
		XRCCTRL(*this,_T("CpuMode"+elfTypeStr), wxCheckBox)->Enable(status);
		XRCCTRL(*this,_T("Memory"+elfTypeStr), wxChoice)->Enable(status);
		XRCCTRL(*this,_T("MemoryText"+elfTypeStr),wxStaticText)->Enable(status);
		if (elfConfiguration[runningComputer_].usePager)
			XRCCTRL(*this,_T("PortExt"+elfTypeStr), wxCheckBox)->Enable(false);
		else
			XRCCTRL(*this,_T("PortExt"+elfTypeStr), wxCheckBox)->Enable(status);

		if (elfConfiguration[runningComputer_].usePager || elfConfiguration[runningComputer_].useEms)
		{
			XRCCTRL(*this, "StartRamText"+computerInfo[runningComputer_].gui, wxStaticText)->Enable(false);
			XRCCTRL(*this, "StartRam"+computerInfo[runningComputer_].gui, wxTextCtrl)->Enable(false);
			XRCCTRL(*this, "EndRamText"+computerInfo[runningComputer_].gui, wxStaticText)->Enable(false);
			XRCCTRL(*this, "EndRam"+computerInfo[runningComputer_].gui, wxTextCtrl)->Enable(false);
		}
		else
		{
			XRCCTRL(*this, "StartRamText"+computerInfo[runningComputer_].gui, wxStaticText)->Enable(status);
			XRCCTRL(*this, "StartRam"+computerInfo[runningComputer_].gui, wxTextCtrl)->Enable(status);
			XRCCTRL(*this, "EndRamText"+computerInfo[runningComputer_].gui, wxStaticText)->Enable(status);
			XRCCTRL(*this, "EndRam"+computerInfo[runningComputer_].gui, wxTextCtrl)->Enable(status);
		}
		XRCCTRL(*this,_T("VTType"+elfTypeStr),wxChoice)->Enable(status);
		if (XRCCTRL(*this,_T("VTType"+elfTypeStr),wxChoice)->GetSelection() != VTNONE)
		{
			if (elfConfiguration[runningComputer_].useUart)
			{
				baudTextR[runningComputer_]->Enable(status);
				baudChoiceR[runningComputer_]->Enable(status);
			}
			baudTextT[runningComputer_]->Enable(status);
			baudChoiceT[runningComputer_]->Enable(status);
			XRCCTRL(*this,_T("SerialLog"+elfTypeStr), wxCheckBox)->Enable(status);
			XRCCTRL(*this, "Uart"+elfTypeStr, wxCheckBox)->Enable(status);
			XRCCTRL(*this,_T("VTText"+elfTypeStr),wxStaticText)->Enable(status);
		}
		XRCCTRL(*this,_T("VideoType"+elfTypeStr),wxChoice)->Enable(status);
		XRCCTRL(*this,_T("VideoTypeText"+elfTypeStr),wxStaticText)->Enable(status);
		XRCCTRL(*this,_T("DiskType"+elfTypeStr),wxChoice)->Enable(status);
		XRCCTRL(*this,_T("DiskTypeText"+elfTypeStr),wxStaticText)->Enable(status);
		XRCCTRL(*this,_T("Keyboard"+elfTypeStr),wxChoice)->Enable(status);
		XRCCTRL(*this,_T("KeyboardText"+elfTypeStr),wxStaticText)->Enable(status);
		XRCCTRL(*this,_T("CharRomButton"+elfTypeStr), wxButton)->Enable(status&(elfConfiguration[runningComputer_].use6847||elfConfiguration[runningComputer_].use8275||elfConfiguration[runningComputer_].use6845||elfConfiguration[runningComputer_].useS100));
		XRCCTRL(*this,_T("VtCharRomButton"+elfTypeStr), wxButton)->Enable(status&(elfConfiguration[runningComputer_].vtType != VTNONE));
		XRCCTRL(*this,_T("VtCharRom"+elfTypeStr), wxComboBox)->Enable(elfConfiguration[runningComputer_].vtType != VTNONE);
		XRCCTRL(*this,_T("CharRom"+elfTypeStr), wxComboBox)->Enable(status&(elfConfiguration[runningComputer_].use6847||elfConfiguration[runningComputer_].use8275||elfConfiguration[runningComputer_].use6845||elfConfiguration[runningComputer_].useS100));
		XRCCTRL(*this,_T("FullScreenF3"+elfTypeStr), wxButton)->Enable(!status&(elfConfiguration[runningComputer_].usePixie||elfConfiguration[runningComputer_].useTMS9918||elfConfiguration[runningComputer_].use6847||elfConfiguration[runningComputer_].use6845||elfConfiguration[runningComputer_].use8275||elfConfiguration[runningComputer_].useS100||(elfConfiguration[ELF2K].vtType != VTNONE)));
		XRCCTRL(*this,_T("ScreenDumpF5"+elfTypeStr), wxButton)->Enable(!status&(elfConfiguration[runningComputer_].usePixie||elfConfiguration[runningComputer_].useTMS9918||elfConfiguration[runningComputer_].use6847||elfConfiguration[runningComputer_].use6845||elfConfiguration[runningComputer_].use8275||elfConfiguration[runningComputer_].useS100||(elfConfiguration[ELF2K].vtType != VTNONE)));
		enableMemAccessGui(!status);
	}
	if (runningComputer_ == ELF2K)
	{
		XRCCTRL(*this,_T("ColoursComx"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVip"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursElfII"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursSuperElf"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVisicom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursVictory"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursCidelsa"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTmc600"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursTMC2000"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursPecom"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("ColoursEti"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("MainRomElf2K"), wxComboBox)->Enable(status);
		XRCCTRL(*this,_T("RomButtonElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("IDE_ButtonElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("IdeFileElf2K"), wxTextCtrl)->Enable(status);
		XRCCTRL(*this,_T("Eject_IDEElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("Elf2KCpuMode"),wxCheckBox)->Enable(status);
		XRCCTRL(*this,_T("Elf2KShowAddress"),wxTextCtrl)->Enable(status);
		XRCCTRL(*this,_T("Elf2KAddressText1"),wxStaticText)->Enable(status);
		XRCCTRL(*this,_T("Elf2KAddressText2"),wxStaticText)->Enable(status);
		XRCCTRL(*this,_T("DP_ButtonElf2K"), wxButton)->Enable(status);
		XRCCTRL(*this,_T("KeyMapElf2K"), wxButton)->Enable(status&elfConfiguration[ELF2K].useHexKeyboardEf3);
		enableMemAccessGui(!status);
		if (!elfConfiguration[ELF2K].use8275)
		{
			XRCCTRL(*this, _T("VTTypeElf2K"), wxChoice)->Enable(status);
			if (XRCCTRL(*this,_T("VTTypeElf2K"),wxChoice)->GetSelection() != VTNONE)
			{
				if (elfConfiguration[ELF2K].useUart)
				{
					baudTextR[ELF2K]->Enable(status);
					baudChoiceR[ELF2K]->Enable(status);
				}
				baudTextT[ELF2K]->Enable(status);
				baudChoiceT[ELF2K]->Enable(status);
				XRCCTRL(*this, _T("VTTextElf2K"), wxStaticText)->Enable(status);
				XRCCTRL(*this,_T("SerialLogElf2K"), wxCheckBox)->Enable(status);
				XRCCTRL(*this,_T("UartElf2K"), wxCheckBox)->Enable(status);
			}
		}
		XRCCTRL(*this,_T("Elf2KVideoType"),wxChoice)->Enable(status);
		XRCCTRL(*this,_T("Elf2KVideoType_Text"),wxStaticText)->Enable(status);
		XRCCTRL(*this,_T("Elf2KKeyboard"),wxChoice)->Enable(status);
		XRCCTRL(*this,_T("Elf2KKeyboard_Text"),wxStaticText)->Enable(status);
		XRCCTRL(*this,_T("CharRomButtonElf2K"), wxButton)->Enable(status&elfConfiguration[ELF2K].use8275);
		XRCCTRL(*this,_T("VtCharRomButtonElf2K"), wxButton)->Enable(status&(elfConfiguration[ELF2K].vtType != VTNONE));
		XRCCTRL(*this,_T("VtCharRomElf2K"), wxComboBox)->Enable(status&(elfConfiguration[ELF2K].vtType != VTNONE));
		XRCCTRL(*this,_T("CharRomElf2K"), wxComboBox)->Enable(status&elfConfiguration[ELF2K].use8275);
		XRCCTRL(*this,_T("FullScreenF3Elf2K"), wxButton)->Enable(!status&(elfConfiguration[ELF2K].usePixie||elfConfiguration[ELF2K].use8275||(elfConfiguration[ELF2K].vtType != VTNONE)));
		XRCCTRL(*this,_T("ScreenDumpF5Elf2K"), wxButton)->Enable(!status&(elfConfiguration[ELF2K].usePixie||elfConfiguration[ELF2K].use8275||(elfConfiguration[ELF2K].vtType != VTNONE)));
		XRCCTRL(*this,_T("Elf2KRtc"), wxCheckBox)->Enable(status);
	}
	enableDebugGui(!status);
	enableStartButtonGui(status);
}

void Main::message(wxString buffer)
{
	XRCCTRL(*this,_T("Message_Window"),wxTextCtrl)->AppendText(buffer);
	XRCCTRL(*this,_T("Message_Window"),wxTextCtrl)->AppendText(_T("\n"));
}

void Main::messageInt(int value)
{
	wxString buffer;

	buffer.Printf(_T("%d"), value);
	XRCCTRL(*this,_T("Message_Window"),wxTextCtrl)->AppendText(buffer);
	XRCCTRL(*this,_T("Message_Window"),wxTextCtrl)->AppendText(_T("\n"));
}

void Main::messageHex(int value)
{
	wxString buffer;

	buffer.Printf(_T("%04X"), value);
	XRCCTRL(*this,_T("Message_Window"),wxTextCtrl)->AppendText(buffer);
	XRCCTRL(*this,_T("Message_Window"),wxTextCtrl)->AppendText(_T("\n"));
}

wxString Main::getApplicationDir()
{
	return applicationDirectory_;
}

wxChar Main::getPathSep()
{
	return pathSeparator_;
}

int Main::setFdcStepRate(int rate)
{
	switch(rate)
	{
		case 0: return conf[runningComputer_].fdcCpms_ * 6;
		case 1: return conf[runningComputer_].fdcCpms_ * 12;
		case 2: return conf[runningComputer_].fdcCpms_ * 20;
		case 3: return conf[runningComputer_].fdcCpms_ * 30;
	}
	return conf[runningComputer_].fdcCpms_ * 12;
}

int Main::getPsaveData(int item)
{
	return psaveData_[item];
}

void Main::setPsaveData(int item, int data)
{
	psaveData_[item] = data;
}
