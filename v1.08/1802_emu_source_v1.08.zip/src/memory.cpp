/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "main.h"
#include "memory.h"

Memory::Memory()
{
	mainMemory_ = (Byte*)malloc(65536);
	for (int i=0; i<65536; i++)
	{
//		if (i&0x40)
//			mainMemory_[i] = 0;
//		else
		mainMemory_[i] = 0;
	}
	for (int i=0; i<256; i++) memoryType_[i] = 0;
	for (int i=0; i<1024; i++) colorMemory1864_[i] = 0; 
	for (int i=0; i<2048; i++) mc6845ram_[i] = 0;

	comxExpansionMemoryDefined_ = false;
	emsMemoryDefined_ = false;
	pagerDefined_ = false;
}

Memory::~Memory()
{
	free(mainMemory_);
	if (comxExpansionMemoryDefined_)
	{
		free(expansionRom_);	
		free(expansionRam_);	
	}
	if (emsMemoryDefined_)
		free(emsRam_);
} 

void Memory::allocPagerMemory()
{
	mainMemory_ = (Byte*)realloc(mainMemory_, 1048576);
	pagerDefined_ = true;

	for (int i=0; i<16; i++) 
	{
		pager_[i] = i;
	}

	for (int i=0; i<4096; i++) pagerMemoryType_[i] = RAM;

	for (int i=0; i<1048576; i++)	mainMemory_[i] = 0;
}

void Memory::allocComxExpansionMemory()
{
	expansionRom_ = (Byte*)malloc(32768);
	expansionRam_ = (Byte*)malloc(32768);

	for (int i=0; i<128; i++) expansionMemoryType_[i] = 0;
	for (int i=0; i<128; i++) bankMemoryType_[i] = RAM;

	comxExpansionMemoryDefined_ = true;

	for (int i=0; i<32768; i++) expansionRom_[i] = 0xff;
	for (int i=0; i<32768; i++) expansionRam_[i] = 0;
}

void Memory::allocEmsMemory()
{
	emsRam_ = (Byte*)malloc(524288);
	emsPage_ = 0;

	for (int i=0; i<2048; i++) emsMemoryType_[i] = RAM;

	emsMemoryDefined_ = true;

	for (int i=0; i<524288; i++) emsRam_[i] = 0;
}

void Memory::setEmsPage(Byte value)
{
	emsPage_ = value & 0x1f;
}

void Memory::setPager(int page, Byte value)
{
	pager_[page] = value;
}

void Memory::randomMemory(long start, long end)
{
	for (int i=start; i<=end; i++)
	{
		mainMemory_[i] = rand() % 255 + 1;
	}
}

void Memory::defineMemoryType(long start, long end, int type) 
{
	start /= 256;
	end /= 256;
	for (long i=start; i<=end; i++)
	{
		memoryType_[i] = type;
	}
} 

void Memory::defineMemoryType(long address, int type) 
{
	if (pagerDefined_)
	{
		definePagerMemoryType(address, type);
		return;
	}
	if (emsMemoryDefined_ && (address >= 0x8000) && (address < 0xc000))
	{
		address /= 256;
		emsMemoryType_[emsPage_*64+(address&0x3f)] = type;
		return;
	}
	memoryType_[address/256] = type;
} 

void Memory::defineExpansionMemoryType(int slot, long start, long end, int type) 
{
	start /= 256;
	end /= 256;
	for (long i=start; i<=end; i++)
	{
		expansionMemoryType_[slot*32+i] = type;
	}
} 

void Memory::defineExpansionMemoryType(int slot, long address, int type) 
{
	address /= 256;
	expansionMemoryType_[slot*32+address] = type;
} 

void Memory::defineBankMemoryType(int bank, long address, int type) 
{
	address /= 256;
	bankMemoryType_[bank*32+address] = type;
} 

void Memory::defineEmsMemoryType(long address, int type) 
{
	address /= 256;
	emsMemoryType_[emsPage_*64+address] = type;
} 

void Memory::definePagerMemoryType(long address, int type) 
{
	address /= 256;
	pagerMemoryType_[pager_[(address>>4)&0xf] * 16 + (address&0xf)] = type;
} 