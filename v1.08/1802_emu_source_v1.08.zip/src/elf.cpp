/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "main.h"

MainElf::MainElf()
{
}

void MainElf::cassette(short val)
{
	if (val < 0)
	{
		cassetteEf2_ = 0;
	}
	else
		cassetteEf2_ = 1;
}

void MainElf::cassette(char val)
{
	if (val < 0)
	{
		cassetteEf2_ = 0;
	}
	else
		cassetteEf2_ = 1;
}

void MainElf::checkElfFunction()
{
	if (baseGiantBoard_ != 0x10000)
	{
		if (scratchpadRegister_[programCounter_] == baseGiantBoard_ + 0x29)
			p_Main->stopCassette();

		if (scratchpadRegister_[programCounter_] == baseGiantBoard_ + 0x8d)
			p_Main->startCassetteSave();

		if (scratchpadRegister_[programCounter_] == baseGiantBoard_ + 0xcd)
			p_Main->startCassetteLoad();
	}

	if (loadedOs_ == ELFOS)
	{
		if (scratchpadRegister_[programCounter_] == 0x7c40)
		{
			if ((mainMemory_[0x7c00] == 0x30) && (mainMemory_[0x7c01] == 0x06) && (mainMemory_[0x7c02] == 0x0c))
			{
				Word saveStart = (mainMemory_[0x7cae] << 8) + mainMemory_[0x7caf] ;
				Word saveEnd = saveStart + (mainMemory_[0x7cb0] << 8) + mainMemory_[0x7cb1];
				Word saveExec = (mainMemory_[0x7cb2] << 8) + mainMemory_[0x7cb3];
				p_Main->setSaveLocation (saveStart, saveEnd, saveExec);
			}
		}
	}

	switch (loadedProgram_)
	{
		case NOPROGRAM:
			switch (scratchpadRegister_[programCounter_])
			{
				case 0x3f:			// READY SUPER BASIC
				case 0x2257:		// READY RCA BASIC
				case 0xfc0b:		// START KEY INPUT ELFOS
					checkLoadedSoftware();
				break;
			}
		break;

		case RCABASIC3:
		case RCABASIC4:
			switch (scratchpadRegister_[programCounter_])
			{
				case 0x2257:	
					if (elfRunState_ != BASICSTATE)
						elfRunState_ = BASICSTATE;
				break;

				case 0x3276:	// RUN
					if (elfRunState_ != RUNSTATE)
						elfRunState_ = RUNSTATE;
				break;

		/*		case 0x529f: 
				case 0x52a3: 
						p_Main->messageHex(mainMemory_[scratchpadRegister_[programCounter_]+1]*256+mainMemory_[scratchpadRegister_[programCounter_]+2]);
				break; */
			}
		break;

		case SUPERBASIC:
			switch (scratchpadRegister_[programCounter_])
			{
				case 0x3f:	
					p_Main->stopCassette();
					if (elfRunState_ != BASICSTATE)
						elfRunState_ = BASICSTATE;
				break;

				case 0x16a3:	// RUN
					if (elfRunState_ != RUNSTATE)
						elfRunState_ = RUNSTATE;
				break;

				case 0x1082:	// CALL
					if (elfRunState_ != RUNSTATE)
						elfRunState_ = RUNSTATE;
				break;

				case 0x0107:	// CSAVE
				case 0x010a:	// DSAVE
					p_Main->startCassetteSave();
				break;

				case 0x0101:	// CLOAD
				case 0x0104:	// DLOAD
					p_Main->setSwName ("");
					p_Main->startCassetteLoad();
				break;
 			}
		break;

		case TINYBASIC:
			switch (scratchpadRegister_[programCounter_])
			{
				case 0x0A28:	// SAVE
				case 0x0A59:	// LOAD
					p_Main->stopCassette();
				break;

				case 0x09FD:	// SAVE
					p_Main->startCassetteSave();
				break;

				case 0x09FA:	// LOAD
					p_Main->setSwName ("");
					p_Main->startCassetteLoad();
				break;
			}
		break;
	}
}

void MainElf::startComputerRun(bool load)
{
	if (elfConfiguration.useKeyboard)
		startElfRun(load);
	if (elfConfiguration.vtType != VTNONE)
	{
		if (cpuMode_ != RUN)
		{
			onInButtonPress();
			onRun();
			vtPointer->startElfRun(load, true);
		}
		else
			vtPointer->startElfRun(load, false);
	}
}

bool MainElf::isComputerRunning()
{
	if (elfRunState_ == RUNSTATE)
		return true;
	else
		return false;
}

