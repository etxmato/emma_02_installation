/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "main.h"
#include "psave.h"

#include "wx/xrc/xmlres.h"             
#include <wx/spinctrl.h>

BEGIN_EVENT_TABLE(PsaveDialog, wxDialog)
    EVT_BUTTON(XRCID("PsaveSave"), PsaveDialog::onSaveButton)
END_EVENT_TABLE()

PsaveDialog::PsaveDialog(wxWindow* parent)
{
	wxXmlResource::Get()->LoadDialog(this, parent, wxT("PsaveDialog"));

	XRCCTRL(*this, "PsaveVolume", wxSpinCtrl)->SetValue(p_Main->getPsaveData(0));
	XRCCTRL(*this, "PsaveBitRate", wxChoice)->SetSelection(p_Main->getPsaveData(1));
	XRCCTRL(*this, "PsaveBitsPerSample", wxChoice)->SetSelection(p_Main->getPsaveData(2));
}

void PsaveDialog::onSaveButton( wxCommandEvent& WXUNUSED(event) )
{
	if (p_Main->isSaving())
		return;

	p_Main->setPsaveData(0, XRCCTRL(*this, "PsaveVolume", wxSpinCtrl)->GetValue());
	p_Main->setPsaveData(1, XRCCTRL(*this, "PsaveBitRate", wxChoice)->GetSelection());
	p_Main->setPsaveData(2, XRCCTRL(*this, "PsaveBitsPerSample", wxChoice)->GetSelection());

	EndModal( wxID_OK );
}

