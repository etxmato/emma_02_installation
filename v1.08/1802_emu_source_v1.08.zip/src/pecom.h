#ifndef PECOM_H
#define PECOM_H

#include "v1870.h"

#define PECOMPRINT 1
#define PECOMTEMP 2
#define PECOMSELECT 3

class RunPecom : public wxThread
{
public:
	RunPecom() {};
	virtual void *Entry();
};

class Pecom : public V1870
{
public:
	Pecom(const wxString& title, const wxPoint& pos, const wxSize& size, int zoomLevel, int computerType, double clock);
	~Pecom();

	void charEvent(int keycode);
	bool keyDownExtended(int keycode, wxKeyEvent& event);
	void keyUpExtended(int keycode, wxKeyEvent& event);
	void keyDownFile();
	void keyUpFile();

	void configureComputer();
	void initComputer();
	Byte ef(int flag);
	Byte in(Byte port, Word address);
	void out(Byte port, Word address, Byte value);
	void cycle(int type);
	void cyclePecom();

	void startComputer();
	void stopComputer();
	Byte readMem(Word address);
	void writeMem(Word address, Byte value, bool writeRom);
	void cpuInstruction();
	void onReset();
	void cassette(short val);
	void cassette(char val);
	void printOutPecom(int q);
	void finishStopTape();
	void checkPecomFunction();
	void setPecomPrintfileName(wxString fileName);
	void onPecomF4();
	void startPecomKeyFile();
	void closePecomKeyFile();
	void sleepComputer(long ms);
	void charFinished();
	bool isComputerRunning();
	void startComputerRun(bool load);

private:
	RunPecom *threadPointer;

	Byte keyValue_[26];

	Byte ctrlEf1_;
	Byte cassetteEf2_;
	Byte shiftEf2_;
	Byte shiftEf3_;
	Byte escEf4_;

	bool videoRAM_;

	bool capsPressedOnStart_;
	bool resetPressed_;

	wxFile pecomKeyFile_;
	bool pecomKeyFileOpened_;
	bool keyDown_;
	unsigned char keyboardCode_;
	int keyboardCount_;

	int cycleValue_;

	bool tapeRunning_;
	Word addressLatch_;
	int dmaCounter_;
	int printerStatus_;
	int cycleCount_;

	wxString commandText_; 
	size_t pecomRunCommand_; 
	int pecomRunState_;
	bool load_;
};

#endif  // PECOM_H
