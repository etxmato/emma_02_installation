#ifndef LEDMODULE_H
#define LEDMODULE_H

#include "led.h"

class LedModule : public wxFrame
{
public:
	LedModule(const wxString& title, const wxPoint& pos, const wxSize& size, int computerType);
	~LedModule();

	void onClose(wxCloseEvent&WXUNUSED(event));
	void onPaint(wxPaintEvent&event);

	void configure();
	void write(Byte value); 

private:
	wxBitmap *ledBitmapPointer;
	Led *ledPointer [8];

	DECLARE_EVENT_TABLE()
};

#endif  // LEDMODULE_H