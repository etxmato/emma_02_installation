/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "main.h"
#include "sound.h"

Sound::Sound()
{
	soundBufferPointerLeft = new Blip_Buffer();
	soundBufferPointerRight = new Blip_Buffer();
	tapeBufferPointer = new Blip_Buffer();
	audioPointer = new Sync_Audio();

	for (int i=0; i<4; i++)
	{
		toneSynthPointer[i] = new Blip_Synth<blip_high_quality,30>;
		frequencySuper_[i] = 0;
		toneAmplitude_[i] = 0;
		octaveSuper_[i] = 4;
		tonePeriod_[i] = 32;
	}
	noiseSynthPointer = new Blip_Synth<blip_high_quality,30>;
	psaveSynthPointer = new Blip_Synth<blip_high_quality,30>;
	tapeSynthPointer = new Blip_Synth<blip_high_quality,30>;

	vipSound_ = VIP_BEEP;
	followQ_ = false;
}

Sound::~Sound()
{
	delete soundBufferPointerLeft;
	delete soundBufferPointerRight;
	delete tapeBufferPointer;
	delete audioPointer;
	for (int i=0; i<4; i++)
		delete toneSynthPointer[i];
	delete noiseSynthPointer;
	delete psaveSynthPointer;
	delete tapeSynthPointer;
}

void Sound::initSound(double clock, int computerType, int volume, int bass, int treble, int toneChannels, int stereo)
{
	computerType_ = computerType;
	gain_ = (float) volume / 100;
	channels_ = stereo;
	toneChannels_ = toneChannels;

	psaveVolume_ = p_Main->getPsaveData(0);
	psaveBitRate_ = p_Main->getPsaveData(1);
	psaveBitsPerSample_ = p_Main->getPsaveData(2);

	for (int i=0; i<4; i++)
		toneOn_[i] = false;
	noiseOn_ = false;
	psaveOn_ = false;
	ploadOn_ = false;
	stopTheTape_ = false;
	soundTime_ = 0;

	audioLatch1864_ = 128;
	toneAmplitude_[0] = 8;

	psaveAmplitude_ = 0;

	tapeBufferPointer->clock_rate((clock * 1000000));
	beepPeriod_ = (int) (clock * 2345);
	tapeSynthPointer->volume(1);
	tapeSynthPointer->output(tapeBufferPointer);

	if (SDL_Init(SDL_INIT_AUDIO) < 0)
		p_Main->message("SDL_Init() failed");
	atexit(SDL_Quit);

	setClockRate(clock);
	if (soundBufferPointerLeft->set_sample_rate(44100))
		p_Main->message("Sound error: out of memory");
	if (channels_ == 2)
	{
		if (soundBufferPointerRight->set_sample_rate(44100))
			p_Main->message("Sound error: out of memory");
	}

	if (channels_ == 2)
	{
		soundBufferPointerLeft->bass_freq(bass);
		soundBufferPointerRight->bass_freq(bass);
		toneSynthPointer[0]->treble_eq(treble);
		toneSynthPointer[0]->volume(gain_);
		toneSynthPointer[0]->output(soundBufferPointerLeft);
		toneSynthPointer[1]->treble_eq(treble);
		toneSynthPointer[1]->volume(gain_);
		toneSynthPointer[1]->output(soundBufferPointerRight);
		toneSynthPointer[2]->treble_eq(treble);
		toneSynthPointer[2]->volume(gain_);
		toneSynthPointer[2]->output(soundBufferPointerLeft);
		toneSynthPointer[3]->treble_eq(treble);
		toneSynthPointer[3]->volume(gain_);
		toneSynthPointer[3]->output(soundBufferPointerRight);
	}
	else
	{
		soundBufferPointerLeft->bass_freq(bass);
		for (int i=0; i<toneChannels_; i++)
		{
			toneSynthPointer[i]->treble_eq(treble);
			toneSynthPointer[i]->volume(gain_);
			toneSynthPointer[i]->output(soundBufferPointerLeft);
		}
	}

	noiseSynthPointer->treble_eq(treble);
	noiseSynthPointer->volume(gain_);
	noiseSynthPointer->output(soundBufferPointerLeft);

	psaveSynthPointer->treble_eq(treble);
	psaveSynthPointer->volume(gain_);
	psaveSynthPointer->output(soundBufferPointerLeft);

	audioPointer->start(44100, channels_, 0);

	for (int i=0; i<toneChannels_; i++)
		toneSynthPointer[i]->update(soundTime_, 0);
	noiseSynthPointer->update(soundTime_, 0);
	psaveSynthPointer->update(soundTime_, 0);
}

void Sound::tone(short reg4)
{
	if (toneOn_[0])
		if (toneAmplitude_[0] >= 0)
			toneAmplitude_[0] = reg4 & 0xf;
		else
			toneAmplitude_[0] = -(reg4 & 0xf);
	else
		toneAmplitude_[0] = reg4 & 0xf;

	if ((reg4 & 0x80) == 0x80 ||(toneAmplitude_[0] == 0))
	{
		toneOn_[0] = false;
	}
	else
 	{
		int ToneFreqSel = (reg4 & 0x70) >> 4;
		int ToneDiv = (2 <<((ToneFreqSel ^ 0x7) + 1));
		int ToneN = ((reg4) & 0x7f00) >> 8;
		tonePeriod_[0] = (ToneDiv *(ToneN + 1));
		if (!toneOn_[0])
		{
			toneTime_[0] = tonePeriod_[0];
			toneSynthPointer[0]->update(soundTime_, toneAmplitude_[0]);
		}
		toneOn_[0] = true;
 	}
}

void Sound::tone1864Latch(Byte audioLatch1864)
{
	if (audioLatch1864 == 0)  audioLatch1864 = 128;
	audioLatch1864_ = audioLatch1864;
}

void Sound::tone1864On()
{
	tonePeriod_[0] = (32 *(audioLatch1864_ + 1));
	if (!toneOn_[0])
	{
		toneTime_[0] = tonePeriod_[0];
		toneSynthPointer[0]->update(soundTime_, toneAmplitude_[0]);
	}
	toneOn_[0] = true;
}

void Sound::amplitudeSuper(int channel, int amplitude)
{
	if (toneAmplitude_[channel] < 0)
		toneAmplitude_[channel] = -(amplitude & 0xf);
	else
		toneAmplitude_[channel] = amplitude & 0xf;
}

void Sound::frequencySuper(int channel, int frequency)
{
	frequencySuper_[channel] = frequency;
	tonePeriod_[channel] = (32 * octaveSuper_[channel] * (frequencySuper_[channel] + 1));
}

void Sound::octaveSuper(int channel, int octave)
{
	octaveSuper_[channel] = ((octave&0x3) ^ 3) + 1;
	tonePeriod_[channel] = (32 * octaveSuper_[channel] * (frequencySuper_[channel] + 1));
}

void Sound::toneSuper()
{
	for (int i=0; i<toneChannels_; i++)
	{
		if (!toneOn_[i])
		{
			toneTime_[i] = tonePeriod_[i];
			toneSynthPointer[i]->update(soundTime_, toneAmplitude_[i]);
		}
		toneOn_[i] = true;
	}
}

void Sound::beepOn()
{
//	toneAmplitude_[0] = 8;
//	tonePeriod_[0] = (32 *(audioLatch1864_ + 1));
	tonePeriod_[0] = beepPeriod_;
	if (!toneOn_[0])
	{
		toneTime_[0] = tonePeriod_[0];
		toneSynthPointer[0]->update(soundTime_, toneAmplitude_[0]);
	}
	toneOn_[0] = true;
}

void Sound::beepOff()
{
	for (int i=0; i<toneChannels_; i++)
		toneOn_[i] = false;
}

void Sound::toneElf2KOn()
{
	toneAmplitude_[0] = 8;
	toneSynthPointer[0]->update(soundTime_, toneAmplitude_[0]);
}

void Sound::toneElf2KOff()
{
	toneAmplitude_[0] = 0;
	toneSynthPointer[0]->update(soundTime_, toneAmplitude_[0]);
}

void Sound::noise(short reg5)
{
	noiseAmplitude_ = (reg5 & 0xf00) >> 8;

	if ((reg5 & 0x8000) == 0x8000 ||(noiseAmplitude_ == 0))
	{
		noiseOn_ = false;
	}
	else
	{
		int freq = (reg5 >> 12) & 0x7;
		noisePeriod_ = (32 <<((freq ^ 0x7) +4));
		if (!noiseOn_)
		{
			noiseTime_ = rand() % noisePeriod_ + 1;
			noiseSynthPointer->update(soundTime_, noiseAmplitude_);
		}
		noiseOn_ = true;
	}
}

void Sound::soundCycle()
{
	for (int i=0; i<toneChannels_; i++)
	{
		if (toneOn_[i])
		{
			toneTime_[i]-=8;
			if (toneTime_[i] <= 0)
			{
				toneAmplitude_[i] =- toneAmplitude_[i];
				toneSynthPointer[i]->update(soundTime_, toneAmplitude_[i]);
				toneTime_[i] = tonePeriod_[i];
			}
		}
	}
	if (noiseOn_)
	{
		noiseTime_-=8;
		if (noiseTime_ <= 0)
		{
			noiseAmplitude_ =- noiseAmplitude_;
			noiseSynthPointer->update(soundTime_, noiseAmplitude_);
			noiseTime_ = rand() % noisePeriod_ + 1;
		}
	}
	soundTime_+=8;
	if ((computerType_ != COMX) && (computerType_ != CIDELSA) && (computerType_ != TMC600) && (computerType_ != PECOM))
		playSound();
}

void Sound::playSound()
{
	if (psaveOn_ || ploadOn_)
		return;

	playSoundBuffer();
}

void Sound::playSoundBuffer()
{
	if (channels_ == 2)
	{
		soundBufferPointerLeft->end_frame(soundTime_);
		soundBufferPointerRight->end_frame(soundTime_);

		int const soundBufferSize = 2048;
		short samples [soundBufferSize];
		while(true)
		{
			// Read as many samples as possible
			int sample_count = soundBufferPointerLeft->read_samples(samples, soundBufferSize/2, 1);
			sample_count = soundBufferPointerRight->read_samples(samples + 1, sample_count, 1);

			// Stop if no more samples are avialable
			if (sample_count == 0)
				break;

			// Play the samples
			audioPointer->write(samples, sample_count*2);
		}
	}
	else
	{
		soundBufferPointerLeft->end_frame(soundTime_);

		int const soundBufferSize = 2048;
		short samples [soundBufferSize];
		while(true)
		{
			// Read as many samples as possible
			int sample_count = soundBufferPointerLeft->read_samples(samples, soundBufferSize);

			// Stop if no more samples are avialable
			if (sample_count == 0)
				break;

			// Play the samples
			audioPointer->write(samples, sample_count);
		}
	}
	soundTime_ = 0;
}

void Sound::psaveAmplitudeChange(int q)
{
	if (!psaveOn_)
	{
		switch (computerType_)
		{
			case VIP:
				if (q)
				{
					switch(vipSound_)
					{
						case VIP_BEEP:
							beepOn();
						break;
						case VIP_1864:
							tone1864On();
						break;
						case VIP_SUPER2:
						case VIP_SUPER4:
							toneSuper();
						break;
					}
				}
				else
					beepOff();
			break;

			case TMC1800:
			case VISICOM:
			case STUDIO:
				if (q)
					beepOn();
				else
					beepOff();
			break;

			case TMC2000:
			case ETI:
			case VICTORY:
				if (q)
					tone1864On();
				else
					beepOff();
			break;

			case NANO:
				if (followQ_)
				{
					if (q)
						toneElf2KOn();
					else
						toneElf2KOff();
				}
				else
				{
					if (q)
						tone1864On();
					else
						beepOff();
				}
			break;

			case ELF:
			case ELFII:
			case ELF2K:
			case SUPERELF:
				if (followQ_)
				{
					if (q)
						toneElf2KOn();
					else
						toneElf2KOff();
				}
			break;

			case PECOM:
				p_Computer->printOutPecom(q);
			break;
		}
	}
	else
	{
		if (q == 0)
			psaveAmplitude_ = psaveVolume_;
		else
			psaveAmplitude_ = -psaveVolume_;
		tapeSynthPointer->update(soundTime_, psaveAmplitude_);
		psaveSynthPointer->update(soundTime_,(int)(psaveAmplitude_/2));
	}
}

void Sound::playSaveLoad()
{
	if (!psaveOn_ && !ploadOn_)
		return;

	if (stopTheTape_)
	{
		stopTape();
		return;
	}

	tapeBufferPointer->end_frame(soundTime_);

	int const soundBufferSize = 256;
	short samples [soundBufferSize];
	short ploadSamples [soundBufferSize];
	while(true)
	{
		// Read as many samples as possible
		int sample_count = tapeBufferPointer->read_samples(samples, soundBufferSize);

		// Stop if no more samples are avialable
		if (sample_count == 0)
			break;

		if (ploadOn_)
		{
			long in = ploadWavePointer->read(ploadSamples, sample_count, gain_);
			soundBufferPointerLeft->mix_samples(ploadSamples, in);
			if (ploadWavePointer->eof())
				stopTape();
		}

		if (psaveOn_)
		{
			if (psaveBitsPerSample_ == 0)
			{
				unsigned char samples8bit [soundBufferSize/2];
				convertTo8Bit(samples, sample_count, samples8bit);
				psaveWavePointer->write(samples8bit, sample_count);
			}
			else
				psaveWavePointer->write(samples, sample_count);
		}
	}
	playSoundBuffer();
}

void Sound::convertTo8Bit(const short* in, int count, unsigned char* out)
{
	for (int i=0; i<count; i++)
		out[i]= (unsigned char) ((in[i] >> 8) ^ 0x80);
}

void Sound::ploadStartTape(wxString fileName)
{
	long sampleRate;

	ploadWavePointer = new WaveReader();

	sampleRate = ploadWavePointer->openFile(fileName);
	if (sampleRate != 0)
	{
		if (tapeBufferPointer->set_sample_rate(sampleRate))
		{
			p_Main->message("Cassette sound error: out of memory");
			delete ploadWavePointer;
			p_Main->enableLoadGui(true);
		}
		else
		{
			ploadOn_ = true;
			p_Main->turboOn();
		}
	}
	else
	{
		delete ploadWavePointer;
		p_Main->enableLoadGui(true);
	}
}

void Sound::psaveStartTape(wxString fileName)
{
	long sampleRate;

	if (psaveBitRate_ == 0)
		sampleRate = 22050;
	else
		sampleRate = 44100;

	if (tapeBufferPointer->set_sample_rate(sampleRate))
		p_Main->message("Cassette sound error: out of memory");
	if (psaveBitsPerSample_ == 0)
		psaveWavePointer = new WaveWriter(sampleRate, 8);
	else
		psaveWavePointer = new WaveWriter(sampleRate, 16);

	if (psaveWavePointer->openFile(fileName))
	{
		psaveOn_ = true;
		p_Main->turboOn();
	}
	else
	{
		p_Main->message("Cassette sound error: Can't open file");
		delete psaveWavePointer;
		p_Main->enableLoadGui(true);
	}
}

void Sound::stopTape()
{
	if (!ploadOn_ && !psaveOn_)
		return;

	stopTheTape_ = false;
	if (ploadOn_)
	{
		p_Main->turboOff();
		delete ploadWavePointer;
		ploadOn_ = false;
		p_Computer->checkLoadedSoftware();
		if (computerType_ == ETI)
			p_Computer->finishStopTape();
	}
	if (psaveOn_)
	{
		p_Main->turboOff();
		psaveWavePointer->closeFile();
		delete psaveWavePointer;
		psaveOn_ = false;
	}
	p_Main->enableLoadGui(true);
	if (computerType_ == PECOM)
		p_Computer->finishStopTape();
}

void Sound::stopSaveLoad()
{
	stopTheTape_ = true;
}

void Sound::setVolume(int volume)
{
	gain_ = (float) volume / 100;
	for (int i=0; i<toneChannels_; i++)
		toneSynthPointer[i]->volume(gain_);
	noiseSynthPointer->volume(gain_);
	psaveSynthPointer->volume(gain_);
}

void Sound::setClockRate(double clock)
{
	soundBufferPointerLeft->clock_rate(clock * 1000000);
	if (channels_ == 2)
		soundBufferPointerRight->clock_rate(clock * 1000000);
}

bool Sound::isSaving()
{
	return(psaveOn_);
}

bool Sound::isLoading()
{
	return(ploadOn_);
}

void Sound::setEqualization(int bass, int treble)
{
	if (channels_ == 2)
		soundBufferPointerRight->bass_freq(bass);
	soundBufferPointerLeft->bass_freq(bass);
	for (int i=0; i<toneChannels_; i++)
		toneSynthPointer[i]->treble_eq(treble);
	noiseSynthPointer->treble_eq(treble);
	psaveSynthPointer->treble_eq(treble);
}
