/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "elf2k_icon.xpm"
#endif

#include "main.h"
#include "elf2khex.h"

BEGIN_EVENT_TABLE(Elf2Khex, wxFrame)
	EVT_CLOSE (Elf2Khex::onClose)
	EVT_PAINT(Elf2Khex::onPaint)
	EVT_CHAR(Elf2Khex::onChar)
	EVT_KEY_DOWN(Elf2Khex::onKeyDown)
	EVT_KEY_UP(Elf2Khex::onKeyUp)
	EVT_BUTTON(0, Elf2Khex::onNumberKey)
	EVT_BUTTON(1, Elf2Khex::onNumberKey)
	EVT_BUTTON(2, Elf2Khex::onNumberKey)
	EVT_BUTTON(3, Elf2Khex::onNumberKey)
	EVT_BUTTON(4, Elf2Khex::onNumberKey)
	EVT_BUTTON(5, Elf2Khex::onNumberKey)
	EVT_BUTTON(6, Elf2Khex::onNumberKey)
	EVT_BUTTON(7, Elf2Khex::onNumberKey)
	EVT_BUTTON(8, Elf2Khex::onNumberKey)
	EVT_BUTTON(9, Elf2Khex::onNumberKey)
	EVT_BUTTON(10, Elf2Khex::onNumberKey)
	EVT_BUTTON(11, Elf2Khex::onNumberKey)
	EVT_BUTTON(12, Elf2Khex::onNumberKey)
	EVT_BUTTON(13, Elf2Khex::onNumberKey)
	EVT_BUTTON(14, Elf2Khex::onNumberKey)
	EVT_BUTTON(15, Elf2Khex::onNumberKey)
	EVT_BUTTON(20, Elf2Khex::onRunButton)
	EVT_BUTTON(21, Elf2Khex::onMpButton)
	EVT_BUTTON(22, Elf2Khex::onLoadButton)
	EVT_BUTTON(23, Elf2Khex::onResetButton)
	EVT_BUTTON(24, Elf2Khex::onInButton)
	EVT_TIMER(950, Elf2Khex::onInButtonTimer)
END_EVENT_TABLE()

Elf2Khex::Elf2Khex(const wxString& title, const wxPoint& pos, const wxSize& size)
: wxFrame((wxFrame *)NULL, -1, title, pos, size)
{
	wxString buttonText;
	int x, y;

	SetIcon(wxICON(elf2k_icon));

	wxClientDC dc(this);
	dc.SetBackground(wxBrush(wxColour(255,255,255)));
	dc.DrawRectangle(0, 0, 186, 126);

	resetUpBitmapPointer = new wxBitmap("images/resetButtonUp.bmp", wxBITMAP_TYPE_BMP);
	resetDownBitmapPointer = new wxBitmap("images/resetButtonDown.bmp", wxBITMAP_TYPE_BMP);
	loadUpBitmapPointer = new wxBitmap("images/loadButtonUp.bmp", wxBITMAP_TYPE_BMP);
	loadDownBitmapPointer = new wxBitmap("images/loadButtonDown.bmp", wxBITMAP_TYPE_BMP);
	mpUpBitmapPointer = new wxBitmap("images/mpButtonUp.bmp", wxBITMAP_TYPE_BMP);
	mpDownBitmapPointer = new wxBitmap("images/mpButtonDown.bmp", wxBITMAP_TYPE_BMP);
	runUpBitmapPointer = new wxBitmap("images/runButtonUp.bmp", wxBITMAP_TYPE_BMP);
	runDownBitmapPointer = new wxBitmap("images/runButtonDown.bmp", wxBITMAP_TYPE_BMP);
	inUpBitmapPointer = new wxBitmap("images/inButtonUp.bmp", wxBITMAP_TYPE_BMP);
	inDownBitmapPointer = new wxBitmap("images/inButtonDown.bmp", wxBITMAP_TYPE_BMP);

	runButtonPointer = new wxBitmapButton(this, 20, *runUpBitmapPointer, wxPoint(153, 63), wxSize(-1, -1), wxBU_AUTODRAW, wxDefaultValidator, "RunButton");
	mpButtonPointer = new wxBitmapButton(this, 21, *mpUpBitmapPointer, wxPoint(123, 63), wxSize(-1, -1), wxBU_AUTODRAW, wxDefaultValidator, "MPButton");
	loadButtonPointer = new wxBitmapButton(this, 22, *loadUpBitmapPointer, wxPoint(153, 33), wxSize(-1, -1), wxBU_AUTODRAW, wxDefaultValidator, "LoadButton");
	resetButtonPointer = new wxBitmapButton(this, 23, *resetUpBitmapPointer, wxPoint(153, 3), wxSize(-1, -1), wxBU_AUTODRAW, wxDefaultValidator, "ResetButton");
	inButtonPointer = new wxBitmapButton(this, 24, *inUpBitmapPointer, wxPoint(123, 93), wxSize(-1, -1), wxBU_AUTODRAW, wxDefaultValidator, "InButton");
	inButtonTimerPointer = new wxTimer(this, 950);

	for (int i=0;i<16;i++)
	{
		buttonText.Printf("%01X", i);
		x = 3+(i&0x3)*30;
		y = 93 -(int)i/4*30;
		buttonPointer[i] = new wxButton(this, i, buttonText, wxPoint(x, y), wxSize(30, 30));
	}
	keypadValue_ = 0;
	nextNybble_ = 'H';
	this->SetClientSize(size);
}

Elf2Khex::~Elf2Khex()
{
	for (int i=0;i<16;i++)
	{
		delete buttonPointer[i];
	}
	delete runButtonPointer;
	delete mpButtonPointer;
	delete loadButtonPointer;
	delete resetButtonPointer;
	delete inButtonPointer;
	inButtonTimerPointer->Stop();
	delete inButtonTimerPointer;
}

void Elf2Khex::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxPaintDC dc(this);
	dc.SetBackground(wxBrush(wxColour(255,255,255)));
	dc.DrawRectangle(0, 0, 186, 126);
}

void Elf2Khex::onClose(wxCloseEvent&WXUNUSED(event))
{
	p_Computer->removeElfHex();
	Destroy();
}

void Elf2Khex::onKeyDown(wxKeyEvent& event)
{
	if (!p_Computer->keyDownPressed(event.GetKeyCode()))
		event.Skip();
}

void Elf2Khex::onKeyUp(wxKeyEvent& event)
{
	if (!p_Computer->keyUpReleased(event.GetKeyCode()))
		event.Skip();
}

void Elf2Khex::onChar(wxKeyEvent& event)
{
	p_Computer->charEvent(event.GetKeyCode());
}

void Elf2Khex::onNumberKey(wxCommandEvent&event)
{
	wxClientDC dc(this);

	int i = event.GetId();
	keypadValue_= (nextNybble_ == 'H')?(keypadValue_&15)+(i<<4):(keypadValue_&0xf0)+i;
	if (nextNybble_ == 'H')
	{
		nextNybble_ = 'L';
	}
	else
	{
		nextNybble_ = 'H';
	}
	inButtonPointer->SetBitmapLabel(*inDownBitmapPointer);
}

Byte Elf2Khex::getData()
{
	return keypadValue_;
}

void Elf2Khex::onInButton(wxCommandEvent&WXUNUSED(event))
{
	inButtonTimerPointer->Start(1000, wxTIMER_ONE_SHOT );
	p_Computer->onInButtonPress(keypadValue_);
}

void Elf2Khex::onInButtonTimer(wxTimerEvent&WXUNUSED(event))
{
	p_Computer->onInButtonRelease();
}


void Elf2Khex::onRunButton(wxCommandEvent&WXUNUSED(event))
{
	p_Computer->onRun();
}

void Elf2Khex::onLoadButton(wxCommandEvent&WXUNUSED(event))
{
	p_Computer->onLoadButton();
}

void Elf2Khex::onMpButton(wxCommandEvent&WXUNUSED(event))
{
	p_Computer->onMpButton();
}

void Elf2Khex::setRunButtonUp(int up)
{
	if (up == 1)
		runButtonPointer->SetBitmapLabel(*runDownBitmapPointer);
	else
		runButtonPointer->SetBitmapLabel(*runUpBitmapPointer);
}

void Elf2Khex::setInButtonUp(bool up)
{
	if (up)
		inButtonPointer->SetBitmapLabel(*inUpBitmapPointer);
	else
		inButtonPointer->SetBitmapLabel(*inDownBitmapPointer);
}

void Elf2Khex::setLoadButtonUp(int up)
{
	if (up)
		loadButtonPointer->SetBitmapLabel(*loadUpBitmapPointer);
	else
		loadButtonPointer->SetBitmapLabel(*loadDownBitmapPointer);
}

void Elf2Khex::setMpButtonUp(int up)
{
	if (up)
		mpButtonPointer->SetBitmapLabel(*mpUpBitmapPointer);
	else
		mpButtonPointer->SetBitmapLabel(*mpDownBitmapPointer);
}

void Elf2Khex::onResetButton(wxCommandEvent&WXUNUSED(event))
{
	p_Computer->onReset();
}

