/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "main.h"
#include "led.h"
#include "ledon.xpm"
#include "ledoff.xpm"
#include "ledon2.xpm"
#include "ledoff2.xpm"
#include "ledons.xpm"
#include "ledoffs.xpm"

Led::Led(wxDC& dc, int x, int y, int computerType)
{
	status_ = 0;

	x_ = x;
	y_ = y;

	switch(computerType)
	{
		case ELF:
			ledOnBitmapPointer = new wxBitmap(ledon_xpm);
			ledOffBitmapPointer = new wxBitmap(ledoff_xpm);
		break;

		case ELFII:
			ledOnBitmapPointer = new wxBitmap(ledon2_xpm);
			ledOffBitmapPointer = new wxBitmap(ledoff2_xpm);
		break;

		case ELF2K:
			ledOnBitmapPointer = new wxBitmap("images/Elf2Kredledon.bmp", wxBITMAP_TYPE_BMP);
			ledOffBitmapPointer = new wxBitmap("images/Elf2Kredledoff.bmp", wxBITMAP_TYPE_BMP);
		break;

		case 4:
			ledOnBitmapPointer = new wxBitmap("images/Elf2Kgreenledon.bmp", wxBITMAP_TYPE_BMP);
			ledOffBitmapPointer = new wxBitmap("images/Elf2Kgreenledoff.bmp", wxBITMAP_TYPE_BMP);
		break;

		case 5:
			ledOnBitmapPointer = new wxBitmap("images/Elf2Korangeledon.bmp", wxBITMAP_TYPE_BMP);
			ledOffBitmapPointer = new wxBitmap("images/Elf2Korangeledoff.bmp", wxBITMAP_TYPE_BMP);
		break;

		case SUPERELF:
			ledOnBitmapPointer = new wxBitmap(ledons_xpm);
			ledOffBitmapPointer = new wxBitmap(ledoffs_xpm);
		break;
	}

	dc.DrawBitmap(*ledOnBitmapPointer, x_, y_);
}

Led::~Led()
{
	delete ledOnBitmapPointer;
	delete ledOffBitmapPointer;
}

void Led::onPaint(wxDC& dc)
{
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
#endif
	if (status_)
		dc.DrawBitmap(*ledOnBitmapPointer, x_, y_);
	else
		dc.DrawBitmap(*ledOffBitmapPointer, x_, y_);
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#endif
}

void Led::setStatus(wxDC& dc, int status)
{
	if (status_ != status)
	{
		status_ = status;
		onPaint(dc);
	}
}


