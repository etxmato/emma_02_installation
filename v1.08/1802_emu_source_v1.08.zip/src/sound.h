#ifndef SOUND_H
#define SOUND_H

#include "waveWriter.h"
#include "waveReader.h"
#include "Blip_Buffer.h"
#include "Sync_Audio.h"

class Sound
{
public: 

	Sound();
	~Sound();

	void initSound(double clock, int computerType, int volume, int bass, int treble, int toneChannels, int stereo);  
	void tone(short reg4);  
	void tone1864Latch(Byte audioLatch1864);
	void tone1864On();  
	void setVipSound (int vipSound){vipSound_ = vipSound;};
	void amplitudeSuper(int channel, int amplitude);
	void frequencySuper(int channel, int frequency);
	void octaveSuper(int channel, int octave);
	void toneSuper();  
	void beepOn();  
	void beepOff();  
	void toneElf2KOn();
	void toneElf2KOff();
	void noise(short reg5); 
	void soundCycle();

	void playSound();
	void playSoundBuffer();
	void psaveAmplitudeChange(int q);
	void playSaveLoad();
	void convertTo8Bit(const short* in, int count, unsigned char* out);
	void ploadStartTape(wxString fileName);
	void psaveStartTape(wxString fileName);
	void stopTape();
	void stopSaveLoad();
	void setVolume(int volume);
	void setClockRate(double clock);
	bool isSaving();
	bool isLoading();
	void setEqualization(int bass, int treble);
	void setSoundFollowQ(bool status) {followQ_ = status;};

protected:
	Byte flipFlopQ_;
	int vipSound_;

private:
	Blip_Buffer *soundBufferPointerLeft;
	Blip_Buffer *soundBufferPointerRight;
	Blip_Buffer *tapeBufferPointer;
	Blip_Synth<blip_high_quality,30> *toneSynthPointer[4];
	Blip_Synth<blip_high_quality,30> *noiseSynthPointer;
	Blip_Synth<blip_high_quality,30> *psaveSynthPointer;
	Blip_Synth<blip_high_quality,30> *tapeSynthPointer;
	Sync_Audio *audioPointer;

	WaveWriter *psaveWavePointer;
	WaveReader *ploadWavePointer;

	int computerType_;
	int soundTime_;
	float gain_;

	int tonePeriod_[4];
	int toneTime_[4];
	bool toneOn_[4];
	int toneAmplitude_[4];

	int noisePeriod_;
	int noiseTime_;
	bool noiseOn_;
	int noiseAmplitude_;

	bool stopTheTape_;
	bool psaveOn_;
	bool ploadOn_;
	int psaveAmplitude_;
	int psaveVolume_;
	int psaveBitRate_;
	int psaveBitsPerSample_;
	bool followQ_;
	int beepPeriod_;

	Byte audioLatch1864_;

	Byte frequencySuper_[4];
	int octaveSuper_[4];

	int channels_;
	int toneChannels_;
};

#endif  // SOUND_H