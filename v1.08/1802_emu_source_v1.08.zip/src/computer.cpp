/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "wx/frame.h"

#include "main.h"
#include "computer.h"

Computer::Computer()
{
	loadedProgram_ = NOPROGRAM;
	loadedOs_ = NOOS;
}

bool Computer::isComputerRunning()
{
	return false;
}

void Computer::startComputerRun(bool WXUNUSED(load))
{
	p_Main->message("Illegal request to start Computer");
}

void Computer::onReset()
{
	p_Main->message("Illegal request to reuqest reset Computer");
}

void Computer::onRun()
{
	p_Main->message("Illegal request to run Computer");
}

void Computer::keyDown(int WXUNUSED(keycode))
{
}

bool Computer::keyDownExtended(int WXUNUSED(keycode), wxKeyEvent& WXUNUSED(event))
{
	return false;
}

bool Computer::keyDownPressed(int WXUNUSED(keycode))
{
	return false;
}

void Computer::keyUp(int WXUNUSED(keycode))
{
}

void Computer::keyUpExtended(int WXUNUSED(keycode), wxKeyEvent& WXUNUSED(event))
{
}

bool Computer::keyUpReleased(int WXUNUSED(keycode))
{
	return false;
}

void Computer::charEvent(int WXUNUSED(keycode))
{
}

void Computer::cid1Bit8(bool WXUNUSED(set))
{
	p_Main->message("Illegal call to Cidelsa video bit set/reset");
}

int Computer::getComxExpansionType(int WXUNUSED(card))
{
	p_Main->message("Illegal call to fetch Comx expansion type");
	return 0;
}

void Computer::sleepComputer(long WXUNUSED(ms))
{
	p_Main->message("Illegal call to sleep computer");
}

void Computer::checkCaps()
{
}

void Computer::charFinished()
{
	p_Main->message("Illegal call that PECOM print is finished");
}

void Computer::finishStopTape()
{
	p_Main->message("Illegal call to stop PECOM/ETI tape");
}

void Computer::printOutPecom(int WXUNUSED(q))
{
	p_Main->message("Illegal call to send Q bit to PECOM printer");
}

void Computer::setElf2KDivider(Byte WXUNUSED(value))
{
	p_Main->message("Illegal call to set Elf 2000 divider value");
}

void Computer::removeElf2KSwitch()
{
	p_Main->message("Illegal call to stop Elf 2000 swicth panel");
}

void Computer::removeElfHex()
{
	p_Main->message("Illegal call to stop Elf hex panel");
}

void Computer::removeElfLedModule()
{
	p_Main->message("Illegal call to stop Elf led panel");
}

void Computer::showData(Byte WXUNUSED(val))
{
	p_Main->message("Illegal call to display TIL311 data display");
}

void Computer::showAddr(Word WXUNUSED(address))
{
	p_Main->message("Illegal call to display TIL311 address display");
}

void Computer::resetVideo()
{
	p_Main->message("Illegal call to reset video");
}

void Computer::resetComputer()
{
	p_Main->message("Illegal call to reset computer");
}

void Computer::clearBootstrap()
{
	p_Main->message("Illegal call to clear bootstrap");
}

void Computer::onInButtonRelease()
{
	p_Main->message("Illegal call to release Elf IN button");
}

void Computer::onInButtonPress()
{
	p_Main->message("Illegal call to press Elf IN button");
}

void Computer::onInButtonPress(Byte WXUNUSED(value))
{
	p_Main->message("Illegal call to press Elf IN button");
}

void Computer::cassette(short WXUNUSED(val))
{
}

void Computer::cassette(char WXUNUSED(val))
{
}

void Computer::keyClear()
{
}

void Computer::startComputer()
{
}

void Computer::initComputer()
{
}

void Computer::configureComputer()
{
}

void Computer::stopComputer()
{
}

void Computer::onLoadButton()
{
}

void Computer::onMpButton()
{
}

void Computer::dataSwitch(int WXUNUSED(number))
{
}

Byte Computer::getData()
{
	return 0;
}

void Computer::onHexDown(int WXUNUSED(hex))
{
}

void Computer::onHexKeyUp()
{
}

int Computer::getRunState()
{
	return 0;
}

void Computer::checkLoadedSoftware()
{
}

void Computer::dataAvailable(bool WXUNUSED(data))
{
}

void Computer::thrStatus(bool WXUNUSED(data))
{
}

void Computer::setTempo(int WXUNUSED(tempo))
{
}

