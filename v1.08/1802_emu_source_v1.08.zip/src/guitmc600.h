#ifndef GUITELMAC_H
#define GUITELMAC_H

#include "guipecom.h"

DECLARE_EVENT_TYPE(OPEN_TELMAC_PRINTER_WINDOW, 800) 

class GuiTelmac : public GuiPecom
{
public:

	GuiTelmac(const wxString& title, const wxPoint& pos, const wxSize& size);
	~GuiTelmac() {};

	void readTelmacConfig();
	void writeTelmacConfig();

	void onTelmacExpRom(wxCommandEvent& event);
	void onTelmacPrintFileText(wxCommandEvent& event);
	void onTelmacPrintButton(wxCommandEvent& event);
	void onTelmacPrintMode(wxCommandEvent& event);
	void openPrinterFrame(wxCommandEvent &event);
	void onTelmacAdsChannel(wxSpinEvent&event);
	void onTelmacAdsVolt(wxSpinEvent&event);
	void onTelmacAdsChannelText(wxCommandEvent& event);
	void onTelmacAdsVoltText(wxCommandEvent& event);
	void onTelmacAdiChannel(wxSpinEvent&event);
	void onTelmacAdiVolt(wxSpinEvent&event);
	void onTelmacAdiChannelText(wxCommandEvent& event);
	void onTelmacAdiVoltText(wxCommandEvent& event);

	void enableIoGui();

	void onTelmacF4();
	void setTelmacPrintMode();
	int getTelmacPrintMode();

private:
	int telmacPrintMode_;

	DECLARE_EVENT_TABLE()
};

#endif // GUITELMAC_H