/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guipecom.h"
#include "psave.h"

BEGIN_EVENT_TABLE(GuiPecom, GuiMain)

	EVT_BUTTON(XRCID("RomButtonPecom"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonPecom"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Pecom"), GuiMain::onScreenDump)
	EVT_SPINCTRL(XRCID("ZoomPecom"), GuiMain::onZoom)
	EVT_BUTTON(XRCID("FullScreenF3Pecom"), GuiMain::onFullScreen)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumePecom"), GuiMain::onVolume) 
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumePecom"), GuiMain::onVolume) 
	EVT_TEXT(XRCID(_T("ClockPecom")), GuiMain::onClock)
	EVT_BUTTON(XRCID("CasButtonPecom"), GuiMain::onCassette)
	EVT_BUTTON(XRCID("EjectCasPecom"), GuiMain::onCassetteEject)
	EVT_BUTTON(XRCID("CasLoadPecom"), GuiMain::onCassetteLoad)
	EVT_BUTTON(XRCID("CasSavePecom"), GuiMain::onCassetteSave)
	EVT_BUTTON(XRCID("CasStopPecom"), GuiMain::onCassetteStop)
	EVT_CHECKBOX(XRCID("TurboPecom"), GuiMain::onTurbo)
	EVT_TEXT(XRCID("TurboClockPecom"), GuiMain::onTurboClock)
	EVT_CHECKBOX(XRCID("AutoCasLoadPecom"), GuiMain::onAutoLoad)
	EVT_BUTTON(XRCID("PrintFileButtonPecom"), GuiMain::onPrintFile)
	EVT_TEXT(XRCID("PrintFilePecom"), GuiPecom::onPecomPrintFileText)
	EVT_BUTTON(XRCID("PrintButtonPecom"), GuiPecom::onPecomPrintButton)
	EVT_CHOICE(XRCID("PrintModePecom"), GuiPecom::onPecomPrintMode)
	EVT_BUTTON(XRCID("KeyFileButtonPecom"), GuiMain::onKeyFile)
	EVT_BUTTON(XRCID("EjectKeyFilePecom"), GuiMain::onKeyFileEject)
	EVT_CHECKBOX(XRCID("UseLocationPecom"), GuiMain::onUseLocation)
	EVT_BUTTON(XRCID("SaveButtonPecom"), GuiMain::onSaveButton) 
	EVT_BUTTON(XRCID("LoadButtonPecom"), GuiMain::onLoadButton)
	EVT_BUTTON(XRCID("RunButtonPecom"), GuiMain::onPloadRun)
	EVT_BUTTON(XRCID("DsaveButtonPecom"), GuiMain::onDsave)
	EVT_COMMAND(wxID_ANY, OPEN_PECOM_PRINTER_WINDOW, GuiPecom::openPrinterFrame) 
	EVT_BUTTON(XRCID(_T("ColoursPecom")), Main::onColoursDef)

END_EVENT_TABLE()

GuiPecom::GuiPecom(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiMain(title, pos, size)
{
	conf[PECOM].loadFileNameFull_ = "";
	conf[PECOM].loadFileName_ = "";

	conf[PECOM].pLoadSaveName_[0] = 'P';
	conf[PECOM].pLoadSaveName_[1] = '-';
	conf[PECOM].pLoadSaveName_[2] = '6';
	conf[PECOM].pLoadSaveName_[3] = '4';

	conf[PECOM].defus_ = 0x81;
	conf[PECOM].eop_ = 0x83;
	conf[PECOM].string_ = 0x92;
	conf[PECOM].arrayValue_ = 0x94;
	conf[PECOM].eod_ = 0x99;
	conf[PECOM].basicRamAddress_ = 0x200;
}

void GuiPecom::readPecomConfig()
{
	bool turbo;
	selectedComputer_ = PECOM;

	XRCCTRL(*this, "MainRomPecom", wxComboBox)->SetValue(configPointer->Read(_T("/Pecom/PecomMainRom"), "pecom64.v4.bin"));
	XRCCTRL(*this, "ZoomPecom", wxSpinCtrl)->SetValue(configPointer->Read(_T("/Pecom/PecomZoom"), 2l));
	conf[PECOM].volume_ = configPointer->Read(_T("/Pecom/PecomVolume"), 25l);
	XRCCTRL(*this, "VolumePecom", wxSlider)->SetValue(conf[PECOM].volume_);
	conf[PECOM].romDir_[MAINROM] = configPointer->Read(_T("/Pecom/PecomRomDir"), dataDir_ + "Pecom" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFilePecom", wxTextCtrl)->SetValue(configPointer->Read(_T("/Pecom/PecomScreenDumpFile"), "screendump.bmp"));
	conf[PECOM].screenDumpFileDir_ = configPointer->Read(_T("/Pecom/PecomScreenDumpFileDir"), dataDir_ + "Pecom" + pathSeparator_); 
	conf[PECOM].ramDir_ = configPointer->Read(_T("/Pecom/PecomSWDir"), dataDir_ + "Pecom" + pathSeparator_); 

	conf[PECOM].mainX_ = configPointer->Read(_T("/Pecom/PecomX"), mainWindowX_+windowInfo.mainwX); 
	conf[PECOM].mainY_ = configPointer->Read(_T("/Pecom/PecomY"), mainWindowY_); 

	conf[PECOM].clock_ = configPointer->Read(_T("/Pecom/Clock"), "2.813");
	XRCCTRL(*this, _T("ClockPecom"), wxTextCtrl)->ChangeValue(conf[PECOM].clock_);
	XRCCTRL(*this, "WavFilePecom", wxTextCtrl)->SetValue(configPointer->Read(_T("/Pecom/PecomWavFile"), ""));
	conf[PECOM].wavFileDir_ = configPointer->Read(_T("/Pecom/WavFileDir"), dataDir_ + "Pecom" + pathSeparator_); 
	configPointer->Read(_T("/Pecom/PecomTurbo"), &turbo, true);
	XRCCTRL(*this, "TurboPecom", wxCheckBox)->SetValue(turbo);
	turboGui("Pecom");
	conf[PECOM].turboClock_ = configPointer->Read(_T("/Pecom/PecomTurboClock"), "15"); 
	XRCCTRL(*this, "TurboClockPecom", wxTextCtrl)->SetValue(conf[PECOM].turboClock_);
	configPointer->Read(_T("/Pecom/PecomAutoCasLoad"), &conf[PECOM].autoCassetteLoad_, true);
	XRCCTRL(*this, "AutoCasLoadPecom", wxCheckBox)->SetValue(conf[PECOM].autoCassetteLoad_);

	XRCCTRL(*this, "PrintFilePecom", wxTextCtrl)->SetValue(configPointer->Read(_T("/Pecom/PecomPrintFile"), "printerout.txt"));
	conf[PECOM].printFileDir_ = configPointer->Read(_T("/Pecom/PecomPrintFileDir"), dataDir_ + "Pecom" + pathSeparator_); 
	XRCCTRL(*this, "PrintModePecom", wxChoice)->SetSelection(configPointer->Read(_T("/Pecom/PecomPrintMode"), 1l));
	pecomPrintMode_ = configPointer->Read(_T("/Pecom/PecomPrintMode"), 1l);
	setPecomPrintMode();
	conf[PECOM].keyFileDir_ = configPointer->Read(_T("/Pecom/PecomKeyFileDir"), dataDir_ + "Pecom" + pathSeparator_);
	XRCCTRL(*this, "KeyFilePecom", wxTextCtrl)->SetValue(configPointer->Read(_T("/Pecom/PecomKeyFile"), ""));
	XRCCTRL(*this, "UseLocationPecom", wxCheckBox)->SetValue(false);
	conf[PECOM].useLoadLocation_ = false;
}

void GuiPecom::writePecomConfig()
{
	configPointer->Write(_T("/Pecom/PecomMainRom"), XRCCTRL(*this, "MainRomPecom", wxComboBox)->GetValue());
	configPointer->Write(_T("/Pecom/PecomZoom"), XRCCTRL(*this, "ZoomPecom", wxSpinCtrl)->GetValue());
	configPointer->Write(_T("/Pecom/PecomVolume"), XRCCTRL(*this, "VolumePecom", wxSlider)->GetValue());
	configPointer->Write(_T("/Pecom/PecomRomDir"), conf[PECOM].romDir_[MAINROM]);
	configPointer->Write(_T("/Pecom/PecomScreenDumpFile"), XRCCTRL(*this, "ScreenDumpFilePecom", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Pecom/PecomScreenDumpFileDir"), conf[PECOM].screenDumpFileDir_);
	configPointer->Write(_T("/Pecom/PecomSWDir"), conf[PECOM].ramDir_);

	if (conf[PECOM].mainX_ > 0)
		configPointer->Write(_T("/Pecom/PecomX"), conf[PECOM].mainX_);
	if (conf[PECOM].mainY_ > 0)
		configPointer->Write(_T("/Pecom/PecomY"), conf[PECOM].mainY_);

	configPointer->Write(_T("/Pecom/Clock"), conf[PECOM].clock_);
	configPointer->Write(_T("/Pecom/PecomWavFile"), XRCCTRL(*this, "WavFilePecom", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Pecom/WavFileDir"), conf[PECOM].wavFileDir_);
	configPointer->Write(_T("/Pecom/PecomTurbo"), XRCCTRL(*this, "TurboPecom", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Pecom/PecomTurboClock"), conf[PECOM].turboClock_); 
	configPointer->Write(_T("/Pecom/PecomAutoCasLoad"), XRCCTRL(*this, "AutoCasLoadPecom", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Pecom/PecomPrintFileDir"), conf[PECOM].printFileDir_);
	configPointer->Write(_T("/Pecom/PecomPrintMode"), pecomPrintMode_);
	configPointer->Write(_T("/Pecom/PecomKeyFileDir"), conf[PECOM].keyFileDir_);
	configPointer->Write(_T("/Pecom/PecomKeyFile"), XRCCTRL(*this, "KeyFilePecom", wxTextCtrl)->GetValue());
}

void GuiPecom::onPecomPrintFileText(wxCommandEvent&WXUNUSED(event))
{
	wxString printFile;

	if (runningComputer_ == PECOM)
	{
		printFile = XRCCTRL(*this, "PrintFilePecom", wxTextCtrl)->GetValue();
		if (printFile.Len() == 0)
		{
			p_Pecom->setPecomPrintfileName("");
		}
		else
		{
			printFile = conf[PECOM].printFileDir_;
			printFile.operator += (XRCCTRL(*this, "PrintFilePecom", wxTextCtrl)->GetValue());
			p_Pecom->setPecomPrintfileName(printFile);
		}
	}
}

void GuiPecom::onPecomPrintButton(wxCommandEvent&WXUNUSED(event))
{
	onPecomF4();
}

void GuiPecom::onPecomF4()
{
	if (runningComputer_ == PECOM)
	{
		p_Pecom->onPecomF4();
		if (pecomPrintMode_ == PRINTFILE)
		{
			pecomPrintMode_ = PRINTWINDOW;
			XRCCTRL(*this, "PrintModePecom", wxChoice)->SetSelection(pecomPrintMode_);
			setPecomPrintMode();
		}
	}
}

void GuiPecom::onPecomPrintMode(wxCommandEvent&event)
{
	pecomPrintMode_ = event.GetSelection();
	setPecomPrintMode();
	
	if (runningComputer_ == PECOM)
		p_PrinterPecom->setPecomPrintMode(pecomPrintMode_);
}

void GuiPecom::setPecomPrintMode()
{
	if (pecomPrintMode_ == PRINTFILE)
	{
		XRCCTRL(*this, "PrintFileButtonPecom", wxButton)->Enable(true);
		XRCCTRL(*this, "PrintFilePecom", wxTextCtrl)->Enable(true);
	}
	else
	{
		XRCCTRL(*this, "PrintFileButtonPecom", wxButton)->Enable(false);
		XRCCTRL(*this, "PrintFilePecom", wxTextCtrl)->Enable(false);
	}
}

int GuiPecom::getPecomPrintMode()
{
	return pecomPrintMode_;
}

void GuiPecom::openPrinterFrame(wxCommandEvent&WXUNUSED(event))
{
	if (runningComputer_ != PECOM)  return;
	onPecomF4();
}