/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "elf2k_icon.xpm"
#endif

#include "main.h"

#include "elf2kswitch.h"
#include "elf2kswitches.xpm"
#include "swup2k.xpm"
#include "swdn2k.xpm"
#include "pushup2k.xpm"
#include "pushdn2k.xpm"

BEGIN_EVENT_TABLE(Elf2Kswitch, wxFrame)
	EVT_CLOSE (Elf2Kswitch::onClose)
	EVT_PAINT(Elf2Kswitch::onPaint)
	EVT_CHAR(Elf2Kswitch::onChar)
	EVT_KEY_DOWN(Elf2Kswitch::onKeyDown)
	EVT_KEY_UP(Elf2Kswitch::onKeyUp)
	EVT_LEFT_DOWN(Elf2Kswitch::onButtonPress)
	EVT_LEFT_UP(Elf2Kswitch::onButtonRelease)
	EVT_BUTTON(1, Elf2Kswitch::onRunButton)
	EVT_BUTTON(2, Elf2Kswitch::onMpButton)
	EVT_BUTTON(4, Elf2Kswitch::onLoadButton)
	EVT_BUTTON(10, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(11, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(12, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(13, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(14, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(15, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(16, Elf2Kswitch::dataSwitch)
	EVT_BUTTON(17, Elf2Kswitch::dataSwitch)
END_EVENT_TABLE()

Elf2Kswitch::Elf2Kswitch(const wxString& title, const wxPoint& pos, const wxSize& size)
: wxFrame((wxFrame *)NULL, -1, title, pos, size)
{
	wxClientDC dc(this);

	wxString switchNumber;

	SetIcon(wxICON(elf2k_icon));
	this->SetClientSize(size);

	elfBitmapPointer = new wxBitmap(elf2kswitches_xpm);
	upBitmapPointer = new wxBitmap(swup2k_xpm);
	downBitmapPointer = new wxBitmap(swdn2k_xpm);
	pushUpBitmapPointer = new wxBitmap(pushup2k_xpm);
	pushDownBitmapPointer = new wxBitmap(pushdn2k_xpm);

	runButtonPointer = new wxBitmapButton(this, 1, *downBitmapPointer, wxPoint(380, 31), wxSize(25, 25), 0, wxDefaultValidator, "onRunButton");
	mpButtonPointer = new wxBitmapButton(this, 2, *downBitmapPointer, wxPoint(332, 31), wxSize(25, 25), 0, wxDefaultValidator, "MPButton");
	loadButtonPointer = new wxBitmapButton(this, 4, *downBitmapPointer, wxPoint(93, 31), wxSize(25, 25), 0, wxDefaultValidator, "LoadButton");
//	inButtonPointer = new wxBitmapButton(this, 5, *downBitmapPointer, wxPoint(45, 31), wxSize(25, 25), 0, wxDefaultValidator, "InButton");

	for (int i=0; i<8; i++)
	{
		switchNumber.Printf("%i", i);
		dataSwitchPointer[i] = new wxBitmapButton(this, i+10, *downBitmapPointer, wxPoint(45+48*(7-i), 111), wxSize(25, 25), 0, wxDefaultValidator, switchNumber);
	}
}

Elf2Kswitch::~Elf2Kswitch()
{
	p_Main->setElf2KswitchPos(GetPosition());

	delete elfBitmapPointer;
	delete upBitmapPointer;
	delete downBitmapPointer;

	delete runButtonPointer;
	delete mpButtonPointer;
	delete loadButtonPointer;
//	delete inButtonPointer;
	delete pushUpBitmapPointer;
	delete pushDownBitmapPointer;

	for (int i=0; i<8; i++)
	{
		delete dataSwitchPointer[i];
	}
}

void Elf2Kswitch::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxPaintDC dc(this);
	dc.DrawBitmap(*elfBitmapPointer, 0, 0);
	dc.DrawBitmap(*pushUpBitmapPointer, 45, 31);
}

void Elf2Kswitch::onClose(wxCloseEvent&WXUNUSED(event) )
{
	p_Computer->removeElf2KSwitch();
	Destroy();
}

void Elf2Kswitch::onKeyDown(wxKeyEvent& event)
{
	if (!p_Computer->keyDownPressed(event.GetKeyCode()))
		event.Skip();
}

void Elf2Kswitch::onKeyUp(wxKeyEvent& event)
{
	if (!p_Computer->keyUpReleased(event.GetKeyCode()))
		event.Skip();
}

void Elf2Kswitch::onChar(wxKeyEvent& event)
{
	p_Computer->charEvent(event.GetKeyCode());
}

void Elf2Kswitch::onButtonRelease(wxMouseEvent& event)
{
	p_Computer->onInButtonRelease();
	event.Skip();
}

void Elf2Kswitch::onButtonPress(wxMouseEvent& event)
{
	int x, y;
	event.GetPosition(&x, &y);

	if ((x >= 45) &&(x <= 75) &&(y >= 31) &&(y <= 61))
	{
		p_Computer->onInButtonPress(p_Computer->getData());
	}
	event.Skip();
}

void Elf2Kswitch::onLoadButton(wxCommandEvent&WXUNUSED(event))
{
	p_Computer->onLoadButton();
}

void Elf2Kswitch::onMpButton(wxCommandEvent&WXUNUSED(event))
{
	p_Computer->onMpButton();
}

void Elf2Kswitch::onRunButton(wxCommandEvent&WXUNUSED(event))
{
	p_Computer->onRun();
}

void Elf2Kswitch::setRunButtonUp(int up)
{
	if (up == 1)
		runButtonPointer->SetBitmapLabel(*upBitmapPointer);
	else
		runButtonPointer->SetBitmapLabel(*downBitmapPointer);
}

void Elf2Kswitch::setInButtonUp(bool up)
{
	wxClientDC dc(this);
	if (up)
		dc.DrawBitmap(*pushUpBitmapPointer, 45, 31);
	else
		dc.DrawBitmap(*pushDownBitmapPointer, 45, 31);
}

void Elf2Kswitch::setLoadButtonUp(int up)
{
	if (up)
		loadButtonPointer->SetBitmapLabel(*upBitmapPointer);
	else
		loadButtonPointer->SetBitmapLabel(*downBitmapPointer);
}

void Elf2Kswitch::setMpButtonUp(int up)
{
	if (up)
		mpButtonPointer->SetBitmapLabel(*upBitmapPointer);
	else
		mpButtonPointer->SetBitmapLabel(*downBitmapPointer);
}

void Elf2Kswitch::setDataSwitchUp(int number, int up)
{
	if (up)
		dataSwitchPointer[number]->SetBitmapLabel(*upBitmapPointer);
	else
		dataSwitchPointer[number]->SetBitmapLabel(*downBitmapPointer);
}

void Elf2Kswitch::dataSwitch(wxCommandEvent&event)
{
	int i;

	i = event.GetId() - 10;

	p_Computer->dataSwitch(i);
}
