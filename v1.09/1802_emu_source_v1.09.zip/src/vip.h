#ifndef VIP_H
#define VIP_H

#include "cdp1802.h"
#include "pixie.h"
#include "keyboard.h"

class RunVip : public wxThread
{
public:
	RunVip() {};
	virtual void *Entry();
};

class Vip : public Cdp1802, public Pixie
{
public:
	Vip(const wxString& title, const wxPoint& pos, const wxSize& size, int zoom, int computerType, double clock, int tempo);
	~Vip();

	void configureComputer();
	void configureKeyboard();
	void initComputer();
	void charEvent(int keycode);
	void keyDown(int keycode);
	void keyUp(int keycode);

	void onRun();

	Byte ef(int flag);
	Byte ef3();
	Byte ef4();
	Byte in(Byte port, Word address);
	void out(Byte port, Word address, Byte value);
	void outVip(Byte value);
	void cycle(int type);
	void cycleVP550();

	void startComputer();
	void stopComputer();
	void setTempo(int tempo);
	Byte readMem(Word addr);
	void writeMem(Word addr, Byte value, bool writeRom);
	void cpuInstruction();
	void onReset();
	void cassette(short val);
	void cassette(char val);
	void checkVipFunction();

	Byte read1864ColorDirect(Word addr);
	void write1864ColorDirect(Word addr, Byte value);

private:
	RunVip *threadPointer;

	Byte vipKeyPort_;
	Byte vipKeyState_[2][16];
	bool resetPressed_;
	bool runPressed_;
	Byte cassetteEf2_;
	Word addressLatch_;

	bool cdp1862_;
	bool vp550IntOn_;
	Word ramMask_;

	int hexKeyDefA_[16];
	int hexKeyDefB_[16];

	int cycleValue_;
	int cycleSize_;
	double clock_;
	int colourMask_;
	bool useKeyboard_;

	char keyboardValue_;
	Byte keyboardEf_;

	KeyDef keyDefinition[512];
};

#endif  // VIP_H
