#ifndef ELF2_H
#define ELF2_H

#include "elf.h"
#include "til311.h"
#include "led.h"
#include "tms9918.h"
#include "pixie.h"
#include "mc6847.h"
#include "mc6845.h"
#include "i8275.h"
#include "ledmodule.h"
#include "printer.h"
#include "elfconfiguration.h"

class RunElf2 : public wxThread
{
public:
	RunElf2() {};
	virtual void *Entry();
};

class Elf2 : public wxFrame, public MainElf 
{
public:
	Elf2(const wxString& title, const wxPoint& pos, const wxSize& size, double clock, ElfConfiguration conf);
	Elf2() {};
	~Elf2();

	void onClose(wxCloseEvent&WXUNUSED(event));
	void onPaint(wxPaintEvent&event);
	void onChar(wxKeyEvent& event);
	void charEvent(int keycode);
	void onKeyDown(wxKeyEvent& event);
	bool keyDownPressed(int keycode);
	void onKeyUp(wxKeyEvent& event);
	bool keyUpReleased(int keycode);
	void onButtonRelease(wxCommandEvent& event);
	void onButtonPress(wxCommandEvent& event);
//	void psave(Byte value);

	void onRun();
	void onInButtonPress();
	void onInButtonRelease();
	void onHexKeyDown(int keycode);
	void onHexKeyUp();

	void configureComputer();
	void initComputer();
	Byte ef(int flag);
	Byte ef4();
	Byte in(Byte port, Word address);
	Byte getData();
	void out(Byte port, Word address, Byte value);
	void cycle(int type);
	void showData(Byte value);

	void autoBoot();
	void updateQState();
	int getMpButtonState();
	void onRunButton(wxCommandEvent& event);
	void onMpButton(wxCommandEvent& event);
	void onPowerButton(wxCommandEvent& event);
	void onLoadButton(wxCommandEvent& event);
	void onNumberKeyDown(wxCommandEvent& event);
	void onNumberKeyUp(wxCommandEvent& event);

	void startComputer();
	void stopComputer();
	Byte readMem(Word addr);
	void writeMem(Word addr, Byte value, bool writeRom);
	void cpuInstruction();
	void configureElfExtensions();
	void tmsAndPixieZoom(int zoom);
	void moveWindows();
	void updateTitle(wxString Title);
	void setForceUpperCase(bool status);
	void onReset();

	Byte getTmsMemory(int address) {return tmsPointer->getTmsMemory(address);};
	void setTmsMemory(int address, Byte value) {tmsPointer->setTmsMemory(address, value);};
	Byte read8275CharRom(Word addr);
	void write8275CharRom(Word addr, Byte value);
	Byte read6845CharRom(Word addr);
	void write6845CharRom(Word addr, Byte value);
	Byte read6847CharRom(Word addr);
	void write6847CharRom(Word addr, Byte value);
	int readDirect6847(Word addr); 
	Word get6847RamMask();
	void writeDirect6847(Word addr, int value); 
	long getVideoSyncCount();

private:
	RunElf2 *threadPointer;
	Tms9918 *tmsPointer;
	Pixie *pixiePointer;
	MC6845 *mc6845Pointer;
	mc6847 *mc6847Pointer;
	i8275 *i8275Pointer;
	Printer *elfPrinterPointer;

	wxBitmapButton *runButtonPointer;
	wxBitmapButton *mpButtonPointer;
	wxBitmapButton *powerButtonPointer;
	wxBitmapButton *loadButtonPointer;

	wxBitmap *Elf2BitmapPointer;
	wxBitmap *upBitmapPointer;
	wxBitmap *downBitmapPointer;

	wxButton *inButtonPointer;
	wxButton *buttonPointer[16];

	Til311 *dataPointer[2];

	Led *qLedPointer;
	Byte qLed_;

	Byte switches_;
	int runButtonState_;
	int mpButtonState_;
	int loadButtonState_;
	Byte ef4State_;
	Byte ef3State_;
	bool resetPressed_;

	int hexKeyDefA_[16];
	double elfClockSpeed_;

	long offset_;

	DECLARE_EVENT_TABLE()

};

#endif  // ELF2_H
