/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

/*
 *******************************************************************
 *** This software is copyright 2006 by Michael H Riley          ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "elf_icon.xpm"
#endif

#include "main.h"
#include "mc6847.h"

#define NTSCINT 60
#define PALINT 50
#define MC_INV 1
#define MC_EXT 2
#define MC_CSS 3
#define MC_AS 4
#define MC_AG 5
#define MC_GM0 6
#define MC_GM1 7
#define MC_GM2 8

#define TEXTCOL 6
#define GRAPHIC 8
#define BACKGROUND 5

BEGIN_EVENT_TABLE(mc6847Screen, wxWindow)
	EVT_PAINT(mc6847Screen::onPaint)
	EVT_CHAR(mc6847Screen::onChar)
	EVT_KEY_DOWN(mc6847Screen::onKeyDown)
	EVT_KEY_UP(mc6847Screen::onKeyUp)
END_EVENT_TABLE()

mc6847Screen::mc6847Screen(wxWindow *parent, const wxSize& size, int zoom, int computerType)
: wxWindow(parent, wxID_ANY, wxDefaultPosition, size)
{
	zoom_ = zoom;
	computerType_ = computerType;
}

void mc6847Screen::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxPaintDC dcWindow(this);
	p_Video->setReBlit();
}

void mc6847Screen::onChar(wxKeyEvent& event)
{
	p_Computer->charEvent(event.GetKeyCode());
}

void mc6847Screen::onKeyDown(wxKeyEvent& event)
{
	if (!p_Computer->keyDownPressed(event.GetKeyCode()))
		event.Skip();
}

void mc6847Screen::onKeyUp(wxKeyEvent& event)
{
	if (!p_Computer->keyUpReleased(event.GetKeyCode()))
		event.Skip();
}

void mc6847Screen::blit(wxCoord xdest, wxCoord ydest, wxCoord width, wxCoord height, wxDC *source, wxCoord xsrc, wxCoord ysrc)
{
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
#endif
	wxClientDC dcWindow(this);
	dcWindow.SetUserScale(zoom_, zoom_);
	dcWindow.Blit(xdest, ydest, width, height, source, xsrc, ysrc);
#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#endif
}

void mc6847Screen::setZoom(int zoom)
{
	zoom_ = zoom;
}

void mc6847Screen::drawBackground(int x, int y, wxCoord offsetX, wxCoord offsetY)
{
#if defined(__WXGTK__)
	wxMutexGuiEnter();
#endif
	wxClientDC dcWindow(this);
	wxSize size = wxGetDisplaySize();

	dcWindow.SetUserScale(zoom_, zoom_);
	dcWindow.SetBrush(wxBrush(wxColour(0, 0, 0)));
	dcWindow.SetPen(wxPen(wxColour(0, 0, 0)));
	dcWindow.DrawRectangle(0, 0, size.x/zoom_, offsetY);
	dcWindow.DrawRectangle(0, offsetY, offsetX, y);
	dcWindow.DrawRectangle(offsetX+ x, offsetY, offsetX+1, y);
	dcWindow.DrawRectangle(0, offsetY+ y, size.x/zoom_, offsetY+1);
#if defined(__WXGTK__)
	wxMutexGuiLeave();
#endif
}

BEGIN_EVENT_TABLE(mc6847, wxFrame)
	EVT_CLOSE (mc6847::onClose)
END_EVENT_TABLE()

mc6847::mc6847(const wxString& title, const wxPoint& pos, const wxSize& size, int zoom, int computerType, double clock)
: Video(title, pos, size)
{
	computerType_ = computerType;

	switch(computerType_)
	{
		case ELF:
			elfTypeStr_ = "Elf";
		break;

		case ELFII:
			elfTypeStr_ = "ElfII";
		break;

		case SUPERELF:
			elfTypeStr_ = "SuperElf";
		break;
	}
	readCharRomFile(p_Main->getCharRomDir(computerType_), "CharRom"+elfTypeStr_);
	mc6847RamStart_ = p_Main->getConfigItem(_T(elfTypeStr_+"/mc6847StartRam"),0xE000l);
	Word end = p_Main->getConfigItem(_T(elfTypeStr_+"/mc6847EndRam"), 0xE3FFl);
	p_Computer->defineMemoryType(mc6847RamStart_, end, MC6847RAM);
	mc6847RamMask_ = end - mc6847RamStart_;

	for (int i=0; i<=mc6847RamMask_; i++) mc6847ram_[i] = 0;

	SetIcon(wxICON(elf_icon));

	screenHeight_ = size.GetHeight() / zoom;
	screenWidth_ = size.GetWidth() / zoom;

	charHeight_ = 12;
	charWidth_ = 8;

	charLine_ = screenWidth_ / charWidth_;
	rows_ = screenHeight_ / charHeight_;

	fullScreenSet_ = false;

	if (screenHeight_ == 192)
		addLine_ = 1;
	else
		addLine_ = 2;

	offsetX_ = 0;
	offsetY_ = 0;
	reDraw_ = true;
	reBlit_ = false;
	newBackGround_ = false;
	updateCharacter_ = false;
	f3Pressed_ = false;

	for (int i=0; i<(rows_*charLine_); i++)
		mc6847ram_[i] = 32;

	screenCopyPointer = new wxBitmap(charLine_*charWidth_, screenHeight_);
	dcMemory.SelectObject(*screenCopyPointer);

	mc6847ScreenPointer = new mc6847Screen(this, size, zoom, computerType);

	cycleSize_ = (int) (((clock * 1000000) / charWidth_) / PALINT);
	float factor = (float) cycleSize_ / 312 * 96;
	nonDisplay_ = (int) factor;

	defineColours(computerType_);

	cycleValue_ = cycleSize_;
	zoom_ = zoom;
	restoreZoomAfterFullScreen_ = zoom;
	characterListPointer6847 = NULL;
	ag_ = 0;
	inv_ = 0;
	ext_ = 0;
	css_ = 0;
	as_ = 0;
	gm0_ = 0;
	gm1_ = 0;
	gm2_ = 0;
	outLatch_ = 0;

	this->SetClientSize(size);
}

mc6847::~mc6847()
{
	CharacterList6847 *temp;

	dcMemory.SelectObject(wxNullBitmap);
	delete screenCopyPointer;
	delete mc6847ScreenPointer;
	if (updateCharacter_)
	{
		while(characterListPointer6847 != NULL)
		{
			temp = characterListPointer6847;
			characterListPointer6847 = temp->nextCharacter;
			delete temp;
		}
	}
}

void mc6847::onClose(wxCloseEvent&WXUNUSED(event) )
{
	p_Main->stopComputer();
//	Destroy();
}

void mc6847::setReBlit()
{
	newBackGround_ = true;
	reBlit_ = true;
}

void mc6847::reDrawScreen()
{
	reDraw_ = true;
	copyScreen();
}

void mc6847::drawScreen()
{
	for (int addr=0; addr<(rows_*charLine_); addr++)
		draw(addr);
}

void mc6847::configure()
{
	int mc6847Out;
	wxString printBuffer;

	mc6847Out = p_Main->getConfigItem(elfTypeStr_+"/MC6847Output", 5l);

	invBit_ = 16;
	extBit_ = 16;
	cssBit_ = 16;
	asBit_ = 16;
	agBit_ = 16;
	gm0Bit_ = 16;
	gm1Bit_ = 16;
	gm2Bit_ = 16;
	
	setMCBit(15, p_Main->getConfigItem(elfTypeStr_+"/MC6847-B7", 0l));
	setMCBit(14, p_Main->getConfigItem(elfTypeStr_+"/MC6847-B6", 0l));
	setMCBit(13, p_Main->getConfigItem(elfTypeStr_+"/MC6847-B5", 0l));
	setMCBit(12, p_Main->getConfigItem(elfTypeStr_+"/MC6847-B4", 0l));
	setMCBit(11, p_Main->getConfigItem(elfTypeStr_+"/MC6847-B3", 3l));
	setMCBit(10, p_Main->getConfigItem(elfTypeStr_+"/MC6847-B2", 4l));
	setMCBit(9, p_Main->getConfigItem(elfTypeStr_+"/MC6847-B1", 6l));
	setMCBit(8, p_Main->getConfigItem(elfTypeStr_+"/MC6847-B0", 5l));
	setMCBit(7, p_Main->getConfigItem(elfTypeStr_+"/MC6847-DD7", 1l));
	setMCBit(6, p_Main->getConfigItem(elfTypeStr_+"/MC6847-DD6", 0l));

	p_Computer->setOutType(mc6847Out - 1, MC6847OUT);

	p_Computer->setCycleType(VIDEOCYCLE, MC6847CYCLE);

	p_Main->message("Configuring MC6847");

	printBuffer.Printf("	Output %d: video mode\n", mc6847Out);
	p_Main->message(printBuffer);
}

void mc6847::init6847()
{
	cycleValue_ = cycleSize_;
	offsetX_ = 0;
	offsetY_ = 0;
	f3Pressed_ = false;
	reDraw_ = true;
	reBlit_ = false;
	newBackGround_ = false;
	updateCharacter_ = false;
}

void mc6847::setMCBit(int bit, int selection)
{
	switch (selection)
	{
		case MC_INV:
			invBit_ = bit;
		break;

		case MC_EXT:
			extBit_ = bit;
		break;

		case MC_CSS:
			cssBit_ = bit;
		break;

		case MC_AS:
			asBit_ = bit;
		break;

		case MC_AG:
			agBit_ = bit;
		break;

		case MC_GM0:
			gm0Bit_ = bit;
		break;

		case MC_GM1:
			gm1Bit_ = bit;
		break;

		case MC_GM2:
			gm2Bit_ = bit;
		break;
	}
}

void mc6847::outMc6847(Byte v)
{
	int newMode, value;

	value = v * 256;

	newMode = (((value >> agBit_) & 1) == 1);
	if (newMode != ag_)
		reDraw_ = true;
	ag_ = newMode;

	inv_ = (value >> invBit_) & 1;
	ext_ = (value >> extBit_) & 1;
	css_ = (value >> cssBit_) & 1;
	as_ = (value >> asBit_) & 1;
	gm0_ = (value >> gm0Bit_) & 1;
	gm1_ = (value >> gm1Bit_) & 1;
	gm2_ = (value >> gm2Bit_) & 1;

	newMode = gm0_ + (gm1_ << 1) + (gm2_ << 2);
	if (newMode != graphicMode_)
		reDraw_ = true;
	graphicMode_ = newMode;

	if (ag_ == 0)
	{
		charHeight_ = 12;
		charWidth_ = 8;
	}
	else
	{
		switch(graphicMode_)
		{
			case 0:
				charHeight_ = 3;
				charWidth_ = 16;
				elementWidth_ = 4;
			break;

			case 1:
				charHeight_ = 3;
				charWidth_ = 16;
				elementWidth_ = 2;
			break;

			case 2:
				charHeight_ = 3;
				charWidth_ = 8;
				elementWidth_ = 2;
			break;

			case 3:
				charHeight_ = 2;
				charWidth_ = 16;
				elementWidth_ = 2;
			break;

			case 4:
				charHeight_ = 2;
				charWidth_ = 8;
				elementWidth_ = 2;
			break;

			case 5:
				charHeight_ = 1;
				charWidth_ = 16;
				elementWidth_ = 2;
			break;

			case 6:
				charHeight_ = 1;
				charWidth_ = 8;
				elementWidth_ = 2;
			break;

			case 7:
				charHeight_ = 1;
				charWidth_ = 8;
				elementWidth_ = 1;
			break;
		}
	}
	charLine_ = screenWidth_ / charWidth_;
	rows_ = screenHeight_ / charHeight_;

//	p_Main->messageInt(charLine_*rows_);
	outLatch_ = value & 0xf00;
}

void mc6847::setZoom(int zoom)
{
	zoom_ = zoom;
	restoreZoomAfterFullScreen_ = zoom;

	this->SetClientSize(charLine_*charWidth_*zoom_, rows_*charHeight_*addLine_*zoom_);
	mc6847ScreenPointer->SetClientSize(charLine_*charWidth_*zoom_, rows_*charHeight_*addLine_*zoom_);

	mc6847ScreenPointer->setZoom(zoom_);
	reBlit_ = true;
}

void mc6847::cycle6847()
{
	cycleValue_--;
	if (cycleValue_ == (cycleSize_ - (int)(nonDisplay_/2)))
	{
		if (f3Pressed_)
		{
			fullScreenSet_ = !fullScreenSet_;
			this->ShowFullScreen(fullScreenSet_);
			if (fullScreenSet_)
			{
				setFullScreen();
			}
			else
			{
				zoom_ = restoreZoomAfterFullScreen_;
				this->SetClientSize(charLine_*charWidth_*zoom_, rows_*charHeight_*addLine_*zoom_);
				mc6847ScreenPointer->SetClientSize(charLine_*charWidth_*zoom_, rows_*charHeight_*addLine_*zoom_);
				mc6847ScreenPointer->setZoom(zoom_);
				offsetX_ = 0;
				offsetY_ = 0;
			}
			reDraw_ = true;
			f3Pressed_ = false;
		}
		copyScreen();
	}
	if (cycleValue_ <= 0)
	{
		cycleValue_ = cycleSize_;
	}
}

void mc6847::copyScreen()
{
	CharacterList6847 *temp;

	if (reColour_)
	{
		for (int i=0; i<numberOfColours_; i++)
		{
			colour_[i] = colourNew_[i];
			brushColour_[i] = brushColourNew_[i];
			penColour_[i] = penColourNew_[i];
		}
		reDraw_ = true;
		reBlit_ = true;
		reColour_ = false;
	}

	if (reDraw_)
		drawScreen();

	if (fullScreenSet_ && newBackGround_)
		drawBackground();
	if (reBlit_ || reDraw_)
	{
		mc6847ScreenPointer->blit(offsetX_, offsetY_, charLine_*charWidth_, rows_*charHeight_*addLine_, &dcMemory, 0, 0);
		reBlit_ = false;
		reDraw_ = false;
		if (updateCharacter_)
		{
			updateCharacter_ = false;
			while(characterListPointer6847 != NULL)
			{
				temp = characterListPointer6847;
				characterListPointer6847 = temp->nextCharacter;
				delete temp;
			}
		}
	}
	if (updateCharacter_)
	{
		updateCharacter_ = false;
		while(characterListPointer6847 != NULL)
		{
			mc6847ScreenPointer->blit(offsetX_+(characterListPointer6847->x), offsetY_+(characterListPointer6847->y), charWidth_, charHeight_*addLine_, &dcMemory, characterListPointer6847->x, characterListPointer6847->y);
			temp = characterListPointer6847;
			characterListPointer6847 = temp->nextCharacter;
			delete temp;
		}
	}
}

void mc6847::onF3()
{
	f3Pressed_ = true;
}

void mc6847::write(Word addr, Byte value)
{
	mc6847ram_[addr-mc6847RamStart_] = value + outLatch_;
	draw(addr-mc6847RamStart_);
}

Byte mc6847::read6847(Word addr)
{
	return (mc6847ram_[addr-mc6847RamStart_] & 0xff);
}

int mc6847::readDirect6847(Word addr)
{
	if (addr > mc6847RamMask_)
		return ((mc6847ram_[addr - mc6847RamMask_ - 1] >> 8) & 0xf);
	else
		return (mc6847ram_[addr] &0xff);
}

void mc6847::writeDirect6847(Word addr, int value)
{
	if (addr > mc6847RamMask_)
	{
		mc6847ram_[addr - mc6847RamMask_ - 1] = (mc6847ram_[addr - mc6847RamMask_ - 1]&0x0ff) | ((value&0xf) << 8);
		draw(addr - mc6847RamMask_ - 1);
	}
	else
	{
		mc6847ram_[addr] = (mc6847ram_[addr]&0xf00) | value;
		draw(addr);
	}
}

Byte mc6847::read6847CharRom(Word addr)
{
	return mc6847CharRom_[addr];
}

void mc6847::write6847CharRom(Word addr, Byte value)
{
	mc6847CharRom_[addr] = value;
	reDraw_ = true;
}

Word mc6847::get6847RamMask()
{
 	return mc6847RamMask_;
}

void mc6847::draw(Word addr)
{
	int y = (addr/charLine_)*charHeight_*addLine_;
	int x = (addr%charLine_)*charWidth_;
	if (ag_ == 1)
		drawGraphic(x, y, mc6847ram_[addr]);
	else
		drawCharacter(x, y, mc6847ram_[addr]);
}

void mc6847::drawCharacter(wxCoord x, wxCoord y, int v)
{
	int line_byte, line;
	wxColour backGroundClr;
	wxColour foreGroundClr;

	if (cssBit_ < 12) 
		css_ = (v >> cssBit_) & 1;
	if (asBit_ < 12) 
		as_ = (v >> asBit_) & 1;
	if (invBit_ < 12) 
		inv_ = (v >> invBit_) & 1;
	if (extBit_ < 12) 
		ext_ = (v >> extBit_) & 1;

#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
#endif

	if (as_ == 0)
	{
		if (inv_)
		{
			backGroundClr = colour_[TEXTCOL+css_];
			foreGroundClr = colour_[BACKGROUND];
		}
		else
		{
			backGroundClr = colour_[BACKGROUND];
			foreGroundClr = colour_[TEXTCOL+css_];
		}

		if (ext_ == 1)
			v &= 0x7f;
		else
			v &= 0x3f;

		dcMemory.SetBrush(wxBrush(backGroundClr));
		dcMemory.SetPen(wxPen(backGroundClr));
		dcMemory.DrawRectangle(x, y, charWidth_, charHeight_*addLine_);

		dcMemory.SetBrush(wxBrush(foreGroundClr));
		dcMemory.SetPen(wxPen(foreGroundClr));

		line = 0;
		for (wxCoord j=y; j<y+charHeight_*addLine_; j+=addLine_)
		{
			if (ext_ == 1)
				line_byte = mc6847CharRom_[v*charHeight_+ line + 0x200];
			else
			{
				if ((line == 0) || (line == 1) || (line == 9) || (line == 10) || (line == 11))
					line_byte = 0;
				else
					line_byte = mc6847CharRom_[v*8 + line - 2];
			}
			for (wxCoord i=x; i<x+charWidth_; i++)
			{
				if (line_byte & 128)
				{
					dcMemory.DrawPoint(i, j);
				}
				line_byte <<= 1;
			}
			line++;
		}
	}
	else
	{
		if (ext_ == 0)
		{
			foreGroundClr = colour_[GRAPHIC +((v >> 4) & 0x7)];

			v &= 0x0f;
			for (wxCoord j=y; j<y+charHeight_*addLine_; j+=6)
			{
				for (wxCoord i=x; i<x+charWidth_; i+=4)
				{
					if (v & 8)
					{
						dcMemory.SetBrush(wxBrush(foreGroundClr));
						dcMemory.SetPen(wxPen(foreGroundClr));
					}
					else
					{
						dcMemory.SetBrush(wxBrush(brushColour_[BACKGROUND]));
						dcMemory.SetPen(wxPen(penColour_[BACKGROUND]));
					}
					dcMemory.DrawRectangle(i, j, 4, 6*addLine_);
					v = v << 1;
				}
			}
		}
		else
		{
			foreGroundClr = colour_[GRAPHIC+(((v >> 6) & 0x3) + (css_ << 2))];

			v &= 0x3f;
			for (wxCoord j=y; j<y+charHeight_*addLine_; j+=4)
			{
				for (wxCoord i=x; i<x+charWidth_; i+=4)
				{
					if (v & 0x20)
					{
						dcMemory.SetBrush(wxBrush(foreGroundClr));
						dcMemory.SetPen(wxPen(foreGroundClr));
					}
					else
					{
						dcMemory.SetBrush(wxBrush(brushColour_[BACKGROUND]));
						dcMemory.SetPen(wxPen(penColour_[BACKGROUND]));
					}
					dcMemory.DrawRectangle(i, j, 4, 4*addLine_);
					v = v << 1;
				}
			}
		}
	}
#if defined(__WXGTK__)
		reBlit_ = true;
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#else
		CharacterList6847 *temp = new CharacterList6847;
		temp->x = x;
		temp->y = y;
		temp->nextCharacter = characterListPointer6847;
		characterListPointer6847 = temp;
		updateCharacter_ = true;
#endif
}

void mc6847::drawGraphic(wxCoord x, wxCoord y, int v)
{
	wxColour clr;

	if (css_ < 12) 
		css_ = (v >> cssBit_) & 1;

#if defined(__WXGTK__)
	if (!wxIsMainThread())
		wxMutexGuiEnter();
#endif
	if (gm0_ == 0)
	{
		for (wxCoord i=x; i<x+charWidth_; i+=elementWidth_)
		{
			clr = colour_[GRAPHIC+(((v & 0xc0) >> 6) + (css_ << 2))];
			dcMemory.SetBrush(wxBrush(clr));
			dcMemory.SetPen(wxPen(clr));
			dcMemory.DrawRectangle(i, y, elementWidth_, charHeight_*addLine_);
			v = v << 2;
		}
	}
	else
	{
		for (wxCoord i=x; i<x+charWidth_; i+=elementWidth_)
		{
			if ((v & 0x80) == 0)
				clr = colour_[BACKGROUND];
			else
				clr = colour_[GRAPHIC+(css_ << 2)];
			dcMemory.SetBrush(wxBrush(clr));
			dcMemory.SetPen(wxPen(clr));
			if ((elementWidth_ == 1) && (addLine_ == 1))
				dcMemory.DrawPoint(i, y);
			else
				dcMemory.DrawRectangle(i, y, elementWidth_, charHeight_*addLine_);
			v = v << 1;
		}
	}

#if defined(__WXGTK__)
		reBlit_ = true;
	if (!wxIsMainThread())
		wxMutexGuiLeave();
#else
		CharacterList6847 *temp = new CharacterList6847;
		temp->x = x;
		temp->y = y;
		temp->nextCharacter = characterListPointer6847;
		characterListPointer6847 = temp;
		updateCharacter_ = true;
#endif
}

void mc6847::setFullScreen()
{
	int zoomx, zoomy;
	wxSize size;

#if defined(__WXGTK__)
	wxMutexGuiEnter();
#endif
	size = wxGetDisplaySize();
	zoomx = (int) (size.x/(charLine_*charWidth_));
	zoomy = (int) (size.y/(rows_*charHeight_*addLine_));
	if (zoomx <= zoomy)
		zoom_ = zoomx;
	else
		zoom_ = zoomy;
	offsetX_ = (size.x/zoom_ - (charLine_*charWidth_)) / 2;
	offsetY_ = (size.y/zoom_ - (rows_*charHeight_*addLine_)) / 2;
	mc6847ScreenPointer->setZoom(zoom_);
	mc6847ScreenPointer->SetClientSize(size.x, size.y);
	newBackGround_ = true;
#if defined(__WXGTK__)
	wxMutexGuiLeave();
#endif
}

void mc6847::drawBackground()
{
	mc6847ScreenPointer->drawBackground(charLine_*charWidth_, rows_*charHeight_*addLine_, offsetX_, offsetY_);
	newBackGround_ = false;
}

void mc6847::onF5()
{
	int num = 0;
	wxFile screenDump;
	wxString number;
	wxString fileName;

	fileName = p_Main->getScreenDumpFile();

	wxFileName FullPath = wxFileName::wxFileName(fileName, wxPATH_NATIVE);
	wxString Name = FullPath.GetName();
	wxString Path = FullPath.GetPath();
	wxString Ext = FullPath.GetExt();

	while(wxFile::Exists(fileName))
	{
		num++;
		number.Printf("%d", num);
		fileName = Path + p_Main->getPathSep() + Name + "." + number + "." + Ext;
	}
	screenDump.Create(fileName);
	if (Ext == "bmp")
	{
		screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_BMP);
		return;
	}
	if (Ext == "jpeg")
	{
		screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_JPEG);
		return;
	}
	if (Ext == "png")
	{
		screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_PNG);
		return;
	}
	if (Ext == "pcx")
	{
		screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_PCX);
		return;
	}
	screenCopyPointer->SaveFile(fileName, wxBITMAP_TYPE_BMP);
}

bool mc6847::readCharRomFile(wxString romDir, wxString FileRef)
{
	wxFFile inFile;
	size_t length, number;
	char buffer[2048];

	if (p_Main->getComboValue(FileRef) == "")
	{
		(void)wxMessageBox( _T("No font filename specified"),
						    _T("1802 Emulator"), wxICON_ERROR | wxOK );
		return false;
	}

	wxString fileName = romDir + p_Main->getComboValue(FileRef);

	for (size_t i=0x000; i<0x800; i++)
	{
		mc6847CharRom_[i] = 0;
	}
	if (inFile.Open(fileName, "rb"))
	{
		length = inFile.Read(buffer, 2048);
		number = 0;
		for (size_t i=0; i<length; i++)
		{
			mc6847CharRom_[i] = (Byte)buffer[i];
			number++;
		}
		inFile.Close();
/*		int addr=0;
		for (int c=0; c<64; c++)
			for (int l=0; l<12; l++)
			{
				if ((l!=0) && (l!=1) && (l!=10) && (l!=11))
				{
					mc6847CharRom_[addr] = mc6847CharRom_[c*12+l+0x200]>>1;
					addr++;
				}
			}*/
		return true;
	}
	else
	{
		(void)wxMessageBox( _T("Error reading " + fileName),
						    _T("1802 Emulator"), wxICON_ERROR | wxOK );
		return false;
	}
}



