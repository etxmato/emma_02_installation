/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "main.h"
#include "comxstatusbar.h"
#include "comxledon.xpm"
#include "comxledoff.xpm"

ComxStatusBar::ComxStatusBar(wxWindow *parent, int size)
: wxStatusBar(parent, wxID_ANY, 0)
{
	ledOffPointer = new wxBitmap(comxledoff_xpm);
	ledOnPointer = new wxBitmap(comxledon_xpm);
	statusBarSize_ = size;
	ledsDefined_ = false;
}

ComxStatusBar::~ComxStatusBar()
{
	delete ledOffPointer;
	delete ledOnPointer;
	deleteBitmaps();
}

void ComxStatusBar::initComxBar(int zoom, bool expansionRomLoaded)
{
	expansionRomLoaded_ = expansionRomLoaded;
	SetFieldsCount(5);
	displayLeds(zoom);
	displayText(zoom);
}

void ComxStatusBar::updateLedStatus(int card, int i, bool status)
{
	if (status)
	{
		ledBitmapPointers [card][i]->SetBitmapLabel(*ledOnPointer);
	}
	else
	{
		ledBitmapPointers [card][i]->SetBitmapLabel(*ledOffPointer);
	}
}

void ComxStatusBar::displayText(int zoom)
{
	if (expansionRomLoaded_)
	{
		if (zoom == 1 && !(statusBarSize_ == 128))
			SetStatusText("E-Box", 0);
		else
			SetStatusText("Expansion Box", 0);
	}
	else
	{
		if (zoom == 1 && !(statusBarSize_ == 128))
			SetStatusText("E-Card", 0);
		else
			SetStatusText("Expansion Card", 0);
	}

}

void ComxStatusBar::displayLeds(int zoom)
{
	deleteBitmaps();

	for (int card = 0; card < 4; card++)
	{
		for (int i = 0; i < 2; i++)
		{
#if defined(__WXGTK__)
			ledBitmapPointers [card][i] = new wxBitmapButton(this, wxID_ANY, *ledOffPointer,
							         wxPoint((card+1)*statusBarSize_*zoom+i*14+16, 4), wxSize(-1, -1),
							         wxNO_BORDER | wxBU_EXACTFIT | wxBU_TOP);
#else
			ledBitmapPointers [card][i] = new wxBitmapButton(this, wxID_ANY, *ledOffPointer,
							         wxPoint((card+1)*statusBarSize_*zoom+i*14+16, 9), wxSize(LED_SIZE_X, LED_SIZE_Y),
							         wxBU_EXACTFIT);
#endif
			if (p_Computer->getComxExpansionType(card) == COMXEMPTY)
				ledBitmapPointers[card][i]->Hide();
			if ((!expansionRomLoaded_) &&(card >0))
				ledBitmapPointers[card][i]->Hide();
		}
	}
	ledsDefined_ = true;
}

void ComxStatusBar::deleteBitmaps()
{
	if (!ledsDefined_)  return;
	for (int card = 0; card < 4; card++)
	{
		for (int i = 0; i < 2; i++)
		{
			delete ledBitmapPointers [card][i];
		}
	}
	ledsDefined_ = false;
}

void ComxStatusBar::reDrawBar(int zoom)
{
	displayText(zoom);
	updateStatusBarText(zoom);
//	deleteBitmaps();
	displayLeds(zoom);
}

void ComxStatusBar::setBarSize(int size, int zoom)
{
	statusBarSize_ = size;
	displayText(zoom);
	updateStatusBarText(zoom);
//	deleteBitmaps();
	displayLeds(zoom);
}

void ComxStatusBar::updateStatusBarText(int zoom)
{
	wxString buf;

	for (int slot = 0; slot < 4; slot++)
	{
		if (!((slot > 0) && !expansionRomLoaded_))
		{
			switch(p_Computer->getComxExpansionType(slot))
			{
				case COMXRAM:
					if (zoom == 1 && !(statusBarSize_ == 128))
						buf.Printf("%d:", slot+1);
					else
						buf.Printf("%d:           Ram 32K", slot+1);
					SetStatusText(buf, slot+1);
				break;

				case COMXFLOP:
					if (zoom == 1 && !(statusBarSize_ == 128))
						buf.Printf("%d:", slot+1);
					else
						buf.Printf("%d:           FDC", slot+1);
					SetStatusText(buf, slot+1);
				break;

				case COMXPRINTER:
					if (zoom == 1 && !(statusBarSize_ == 128))
						buf.Printf("%d:", slot+1);
					else
						buf.Printf("%d:           Printer", slot+1);
					SetStatusText(buf, slot+1);
				break;

				case COMXRS232:
					if (zoom == 1 && !(statusBarSize_ == 128))
						buf.Printf("%d:", slot+1);
					else
						buf.Printf("%d:           RS232", slot+1);
					SetStatusText(buf, slot+1);
				break;

				case COMXTHPRINTER:
					if (zoom == 1 && !(statusBarSize_ == 128))
						buf.Printf("%d:", slot+1);
					else
						buf.Printf("%d:           Thermal", slot+1);
					SetStatusText(buf, slot+1);
				break;

				case COMX80COLUMN:
					if (zoom == 1 && !(statusBarSize_ == 128))
						buf.Printf("%d:", slot+1);
					else
						buf.Printf("%d:           80 COL", slot+1);
					SetStatusText(buf, slot+1);
				break;

				case COMXJOY:
					if (zoom == 1 && !(statusBarSize_ == 128))
						buf.Printf("%d:", slot+1);
					else
						buf.Printf("%d:           JoyCard", slot+1);
					SetStatusText(buf, slot+1);
				break;
			}
		}
	}
}
