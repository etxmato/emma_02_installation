/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#include "wx/xrc/xmlres.h"
#include "wx/spinctrl.h"

#include "main.h"
#include "guinano.h"
#include "pixie.h"

#include "psave.h"

BEGIN_EVENT_TABLE(GuiNano, GuiCidelsa)

	EVT_BUTTON(XRCID("RomButtonNano"), GuiMain::onMainRom1)
	EVT_BUTTON(XRCID("RamSWButtonNano"), GuiMain::onRamSW)
	EVT_BUTTON(XRCID("Chip8SWButtonNano"), GuiMain::onChip8SW)
	EVT_BUTTON(XRCID("EjectChip8SWNano"), GuiMain::onEjectChip8SW)
	EVT_SPINCTRL(XRCID("ZoomNano"), GuiMain::onZoom)
	EVT_BUTTON(XRCID("FullScreenF3Nano"), GuiMain::onFullScreen)
	EVT_BUTTON(XRCID("ScreenDumpFileButtonNano"), GuiMain::onScreenDumpFile)
	EVT_BUTTON(XRCID("ScreenDumpF5Nano"), GuiMain::onScreenDump)
	EVT_COMMAND_SCROLL_THUMBTRACK(XRCID("VolumeNano"), GuiMain::onVolume)
	EVT_COMMAND_SCROLL_CHANGED(XRCID("VolumeNano"), GuiMain::onVolume)
	EVT_BUTTON(XRCID("CasButtonNano"), GuiMain::onCassette)
	EVT_BUTTON(XRCID("EjectCasNano"), GuiMain::onCassetteEject)
	EVT_CHECKBOX(XRCID("AutoCasLoadNano"), GuiMain::onAutoLoad)
	EVT_CHECKBOX(XRCID("TurboNano"), GuiMain::onTurbo)
	EVT_TEXT(XRCID("TurboClockNano"), GuiMain::onTurboClock)
	EVT_BUTTON(XRCID("CasLoadNano"), GuiMain::onCassetteLoad)
	EVT_BUTTON(XRCID("CasSaveNano"), GuiMain::onCassetteSave)
	EVT_BUTTON(XRCID("CasStopNano"), GuiMain::onCassetteStop)
	EVT_BUTTON(XRCID("SaveButtonNano"), GuiMain::onSaveButton)
	EVT_BUTTON(XRCID("LoadButtonNano"), GuiMain::onLoadButton)
	EVT_TEXT(XRCID(_T("ClockNano")), GuiMain::onClock)
	EVT_BUTTON(XRCID(_T("KeyMapNano")), Main::onHexKeyDef)

END_EVENT_TABLE()

GuiNano::GuiNano(const wxString& title, const wxPoint& pos, const wxSize& size)
: GuiCidelsa(title, pos, size)
{
}

void GuiNano::readNanoConfig()
{
	bool turbo;
	selectedComputer_ = NANO;

	XRCCTRL(*this, "MainRomNano", wxComboBox)->SetValue(configPointer->Read(_T("/Nano/NanoMainRom"), "nano.rom"));
	XRCCTRL(*this, "RamSWNano", wxComboBox)->SetValue(configPointer->Read(_T("/Nano/NanoRamSW"), "chip8.ram"));
	XRCCTRL(*this, "Chip8SWNano", wxTextCtrl)->SetValue(configPointer->Read(_T("/Nano/NanoChip8SW"), "Breakout.c8"));
	XRCCTRL(*this, "ZoomNano", wxSpinCtrl)->SetValue(configPointer->Read(_T("/Nano/NanoZoom"), 2l));
	conf[NANO].romDir_[MAINROM] = configPointer->Read(_T("/Nano/NanoRomDir"), dataDir_ + "Nano"  + pathSeparator_);
	conf[NANO].ramDir_ = configPointer->Read(_T("/Nano/NanoRamDir"), dataDir_ + "Nano"  + pathSeparator_);
	conf[NANO].chip8SWDir_ = configPointer->Read(_T("/Nano/Chip8SWDir"), dataDir_ + "Chip-8"  + pathSeparator_);

	XRCCTRL(*this, "WavFileNano", wxTextCtrl)->SetValue(configPointer->Read(_T("/Nano/NanoWavFile"), ""));
	conf[NANO].wavFileDir_ = configPointer->Read(_T("/Nano/WavFileDir"), dataDir_ + "Nano" + pathSeparator_);
	XRCCTRL(*this, "ScreenDumpFileNano", wxTextCtrl)->SetValue(configPointer->Read(_T("/Nano/NanoScreenDumpFile"), "screendump.bmp"));
	conf[NANO].screenDumpFileDir_ = configPointer->Read(_T("/Nano/NanoScreenDumpFileDir"), dataDir_ + "Nano" + pathSeparator_);

	configPointer->Read(_T("/Nano/NanoTurbo"), &turbo, true);
	XRCCTRL(*this, "TurboNano", wxCheckBox)->SetValue(turbo);
	turboGui("Nano");
	conf[NANO].turboClock_ = configPointer->Read(_T("/Nano/NanoTurboClock"), "15");
	XRCCTRL(*this, "TurboClockNano", wxTextCtrl)->SetValue(conf[NANO].turboClock_);
	configPointer->Read(_T("/Nano/NanoAutoCasLoad"), &conf[NANO].autoCassetteLoad_, true);
	XRCCTRL(*this, "AutoCasLoadNano", wxCheckBox)->SetValue(conf[NANO].autoCassetteLoad_);
	conf[NANO].volume_ = configPointer->Read(_T("/Nano/NanoVolume"), 25l);
	XRCCTRL(*this, "VolumeNano", wxSlider)->SetValue(conf[NANO].volume_);

	conf[NANO].mainX_ = configPointer->Read(_T("/Nano/NanoX"), mainWindowX_+windowInfo.mainwX);
	conf[NANO].mainY_ = configPointer->Read(_T("/Nano/NanoY"), mainWindowY_);

	conf[NANO].clock_ = configPointer->Read(_T("/Nano/Clock"), "1.75");
	XRCCTRL(*this, _T("ClockNano"), wxTextCtrl)->ChangeValue(conf[NANO].clock_);

	XRCCTRL(*this, "SoundNano", wxChoice)->SetSelection(configPointer->Read(_T("/Nano/Sound"), 0l));
}

void GuiNano::writeNanoConfig()
{
	configPointer->Write(_T("/Nano/NanoMainRom"), XRCCTRL(*this, "MainRomNano", wxComboBox)->GetValue());
	configPointer->Write(_T("/Nano/NanoRamSW"), XRCCTRL(*this, "RamSWNano", wxComboBox)->GetValue());
	configPointer->Write(_T("/Nano/NanoChip8SW"), XRCCTRL(*this, "Chip8SWNano", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Nano/NanoZoom"), XRCCTRL(*this, "ZoomNano", wxSpinCtrl)->GetValue());
	configPointer->Write(_T("/Nano/NanoRomDir"), conf[NANO].romDir_[MAINROM]);
	configPointer->Write(_T("/Nano/NanoRamDir"), conf[NANO].ramDir_);
	configPointer->Write(_T("/Nano/Chip8SWDir"), conf[NANO].chip8SWDir_);

	if (conf[NANO].mainX_ > 0)
		configPointer->Write(_T("/Nano/NanoX"), conf[NANO].mainX_);
	if (conf[NANO].mainY_ > 0)
		configPointer->Write(_T("/Nano/NanoY"), conf[NANO].mainY_);

	configPointer->Write(_T("/Nano/NanoWavFile"), XRCCTRL(*this, "WavFileNano", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Nano/WavFileDir"), conf[NANO].wavFileDir_);
	configPointer->Write(_T("/Nano/NanoScreenDumpFile"), XRCCTRL(*this, "ScreenDumpFileNano", wxTextCtrl)->GetValue());
	configPointer->Write(_T("/Nano/NanoScreenDumpFileDir"), conf[NANO].screenDumpFileDir_);
	configPointer->Write(_T("/Nano/NanoTurbo"), XRCCTRL(*this, "TurboNano", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Nano/NanoTurboClock"), conf[NANO].turboClock_);
	configPointer->Write(_T("/Nano/NanoAutoCasLoad"), XRCCTRL(*this, "AutoCasLoadNano", wxCheckBox)->GetValue());
	configPointer->Write(_T("/Nano/NanoVolume"), XRCCTRL(*this, "VolumeNano", wxSlider)->GetValue());

	configPointer->Write(_T("/Nano/Clock"), conf[NANO].clock_);
	configPointer->Write(_T("/Nano/Sound"), XRCCTRL(*this, "SoundNano", wxChoice)->GetSelection());
}
