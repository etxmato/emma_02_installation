/***************************************************************************
 *   Copyright (C) 2004 by Tyler Montbriand, tsm@accesscomm.ca             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************
 *      SDL_rwring -- A threadsafe ring-buffer using SDL and SDL_RWops     *
 ***************************************************************************/

#include <stdlib.h>
#include <string.h>

#include <SDL_types.h>
#include <SDL_thread.h>
#include "SDL_rwring.h"

#define SDL_RING_TYPE 0xdeadbeef

typedef struct ringbuf
{
  int length, blocksize,timeout;
  Uint8 *buffer;
  Uint32 rdpos,wrpos;
  SDL_sem *rd,*wr;
} ringbuf;

static int ring_seek (SDL_RWops *c, int off, int whence);
static int ring_read (SDL_RWops *c, void *vp, int size, int maxnum);
static int ring_write(SDL_RWops *c, const void *vp, int size, int maxnum);
static int ring_close(SDL_RWops *c);

static void ring_free(ringbuf *rb);

void my_memcpy(void *dest, const void *src, Uint32 len)
{
  fprintf(stderr,"my_memcpy(%p,%p,%u)\n",dest,src,len);
  memcpy(dest,src,len);
}

SDL_RWops *SDL_RWringbuf(int size,int blocksize, int timeout)
{
  ringbuf   *rb=NULL;
  SDL_RWops *rw=NULL;

  if((size<=0)||(blocksize<=0))
  {
    SDL_SetError("ringbuf: size or blocksize too small");
    goto RING_ALLOC_ERROR;
  }
  else if((size%blocksize)!=0)
  {
    SDL_SetError("ringbuf: size not a multiple of blocksize");
    goto RING_ALLOC_ERROR;
  }
  else if((size/blocksize)<2)
  {
    SDL_SetError("ringbuf: size not at least 2x blocksize");
    goto RING_ALLOC_ERROR;
  }

  rw=(SDL_RWops *)malloc(sizeof(SDL_RWops));
  if(rw==NULL)
  {
    SDL_SetError("ringbuf: couldn't allocate RWops structure");
    goto RING_ALLOC_ERROR;
  }
  memset(rw,0,sizeof(SDL_RWops));
  rw->seek =ring_seek;
  rw->read =ring_read;
  rw->write=ring_write;
  rw->close=ring_close;
  rw->type =SDL_RING_TYPE;

  rb=(ringbuf *)malloc(sizeof(ringbuf));
  if(rb==NULL)
  {
    SDL_SetError("ringbuf:  couldn't allocate buffer structure");
    goto RING_ALLOC_ERROR;
  }
  memset(rb,0,sizeof(ringbuf));

  rb->length=size;
  rb->blocksize=blocksize;
  rb->timeout=timeout;
  rb->rdpos=0;
  rb->wrpos=0;

  rb->buffer=(Uint8 *)malloc(size);
  if(rb->buffer==NULL)
  {
    SDL_SetError("ringbuf:  couldn't allocate data buffer");
    goto RING_ALLOC_ERROR;
  }
  memset(rb->buffer,0,size);

  rb->rd=SDL_CreateSemaphore(0);
  if(rb->rd==NULL)
  {
    SDL_SetError("ringbuf:  couldn't allocate read semaphore");
    goto RING_ALLOC_ERROR;
  }

  rb->wr=SDL_CreateSemaphore(size/blocksize);
  if(rb->wr==NULL)
  {
    SDL_SetError("ringbuf:  couldn't alloc write semaphore");
    goto RING_ALLOC_ERROR;
  }

  rw->hidden.unknown.data1=rb;
  return(rw);  

RING_ALLOC_ERROR:
  if(rw!=NULL) free(rw);
  if(rb!=NULL) ring_free(rb);

  return(NULL);  
}

// Seeking not implemented in a ring buffer!
static int ring_seek(SDL_RWops *c, int off, int whence)
{
  SDL_SetError("ring_seek:  Unimplimented");
  return(-1);
}

static int ring_read(SDL_RWops *c, void *vp, int size, int maxnum)
{
  int blocks=0;
  Uint8 *ptr=(Uint8 *)vp;

  ringbuf *rb=(ringbuf *)c->hidden.unknown.data1;

  if((size<rb->blocksize)||((size%rb->blocksize)!=0))
  {
    SDL_SetError("ring_read:  size is not a multiple of blocksize");
    return(-1);
  }

  maxnum*=(size/rb->blocksize);

  while(blocks<maxnum)
  {
    if(rb->timeout<0)
    {
      if(SDL_SemWait(rb->rd)<0)
      {
        SDL_SetError("ring_read:  error waiting on sem");
        return(-1);
      }
    }
    else if(SDL_SemWaitTimeout(rb->rd,rb->timeout)!=0)
    {
      if(blocks==0)
        SDL_SetError("ring_read:  semaphore timed out");

      return((blocks*rb->blocksize)/size);
    }

    memcpy(ptr+(blocks*rb->blocksize),rb->buffer+rb->rdpos,rb->blocksize);
    rb->rdpos=(rb->rdpos+rb->blocksize)%rb->length;
    SDL_SemPost(rb->wr);
    blocks++;
  }
  
  return((blocks*rb->blocksize)/size);
}

static int ring_write(SDL_RWops *c, const void *vp, int size, int maxnum)
{
  int blocks=0;
  const Uint8 *ptr=(const Uint8 *)vp;
  ringbuf *rb=(ringbuf *)c->hidden.unknown.data1;

  if((size<rb->blocksize)||((size%rb->blocksize)!=0))
  {
    SDL_SetError("ring_write:  size is not a multiple of blocksize");
    return(-1);
  }

  maxnum*=(size/rb->blocksize);

  while(blocks<maxnum)
  {
    if(rb->timeout<0)
    {
      if(SDL_SemWait(rb->wr)<0)
      {
        SDL_SetError("ring_write:  error waiting on sem");
        return(-1);
      }
    }
    else if(SDL_SemWaitTimeout(rb->wr,rb->timeout)!=0)
    {
      if(blocks==0)
        SDL_SetError("ring_write:  semaphore timed out");

      return((blocks*rb->blocksize)/size);
    }

    memcpy(rb->buffer+rb->wrpos,ptr+(blocks*rb->blocksize),rb->blocksize);
    rb->wrpos=(rb->wrpos+rb->blocksize)%rb->length;
    SDL_SemPost(rb->rd);
    blocks++;
  }
  
  return((blocks*rb->blocksize)/size);
}

static int ring_close(SDL_RWops *c)
{
  if(c==NULL) return(-1);
  else if(c->type!=SDL_RING_TYPE)
  {
    SDL_SetError("ring_close:  not a ring buffer!");
    return(-1);
  }

  ring_free((ringbuf *)c->hidden.unknown.data1);
  free(c);
  return(0);
}

static void ring_free(ringbuf *rb)
{
  if(rb==NULL) return;

  if(rb->buffer!=NULL) 
  if(rb->rd!=NULL)     SDL_DestroySemaphore(rb->rd);
  if(rb->wr!=NULL)     SDL_DestroySemaphore(rb->wr);

  free(rb);
}

int SDL_RWringbuf_settimeout(SDL_RWops *rw, int timeout)
{
  if(rw==NULL) return(-1);
  else if(rw->type != SDL_RING_TYPE)
  {
    SDL_SetError("SDL_RWringbuf_settimeout:  Not a ring buffer!");
    return(-1);
  }
  else
  {
    ringbuf *r=(ringbuf *)rw->hidden.unknown.data1;
    r->timeout=timeout;
    return(0);
  }
}

int SDL_RWringbuf_empty(SDL_RWops *rw)
{
  if(rw==NULL) return(-1);
  else if(rw->type != SDL_RING_TYPE)
  {
    SDL_SetError("SDL_RWringbuf_empty:  Not a ring buffer!");
    return(-1);
  }
  else
  {
    ringbuf *r=(ringbuf *)rw->hidden.unknown.data1;
    return(SDL_SemValue(r->rd) == 0);
  }
}
