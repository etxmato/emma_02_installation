#ifndef COMX35_H
#define COMX35_H

#include "expansion.h"

class RunComx : public wxThread
{
public:
	RunComx() {};
	virtual void *Entry();
};

class Comx : public Expansion
{
public:
	Comx(const wxString& title, const wxPoint& pos, const wxSize& size, int zoomLevel, int computerType, double clock);
	~Comx();

	void configureComputer();
	void initComputer();
	Byte ef(int flag);
	Byte ef2();
	Byte ef3();
	Byte ef4();
	Byte in();
	Byte in(Byte port, Word address);
	void out(Byte port, Word address, Byte value);
	void cycle(int type);
	void cycleComx();

	void startComputer();
	void stopComputer();
	Byte readMem(Word address);
	void writeMem(Word address, Byte value, bool writeRom);
	void cpuInstruction();

	void charEvent(int keycode);
	bool keyDownExtended(int keycode, wxKeyEvent& event);
	void keyUp(int keycode);
	void keyClear();

	void checkComxFunction();
	void cassette(short val);
	void cassette(char val);
	void sleepComputer(long ms);
	void startComputerRun(bool load);
	void startComxKeyFile();
	void closeComxKeyFile();
	void onReset();
	bool isFAndMBasicRunning();
	bool isComputerRunning();
	void setDosFileName(int addr);

private:
	RunComx *threadPointer;

	Byte keyboardEf2_;
	Byte keyboardEf3_;
	Byte cassetteEf4_;

	Byte qMode_;

	Byte lastKeyCode_;
	int keyboardCode_;
	wxKeyCode previousKeyCode_;

	int dmaCounter_;
	wxFile comxKeyFile_;
	bool comxKeyFileOpened_;
	size_t comxRunCommand_;
	wxString commandText_; 
	int comxRunState_;

	bool load_;
	bool resetPressed_;
	bool fAndMBasicRunning_;
};

#endif  // COMX35_H
