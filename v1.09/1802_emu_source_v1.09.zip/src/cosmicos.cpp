/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include "wx/msw/private.h"
#endif

#if !wxUSE_COMBOCTRL
    #error "Please set wxUSE_COMBOCTRL to 1 and rebuild the library."
#endif

#if defined(__WXGTK__) || defined(__WXX11__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__)
#include "elf2k_icon.xpm"
#endif

#include "main.h"
#include "pushbutton.h"

#include "cosmicos.h"
#include "swleft.xpm"
#include "swright.xpm"

BEGIN_EVENT_TABLE(Cosmicos, wxFrame)
	EVT_CLOSE (Cosmicos::onClose)
	EVT_PAINT(Cosmicos::onPaint)
	EVT_CHAR(Cosmicos::onChar)
	EVT_KEY_DOWN(Cosmicos::onKeyDown)
	EVT_KEY_UP(Cosmicos::onKeyUp)
	EVT_BUTTON(1, Cosmicos::onRunButton)
	EVT_BUTTON(2, Cosmicos::onMpButton)
	EVT_BUTTON(3, Cosmicos::onRamButton)
	EVT_BUTTON(4, Cosmicos::onLoadButton)
	EVT_BUTTON(5, Cosmicos::onResetButton)
	EVT_BUTTON(6, Cosmicos::onPause)
	EVT_BUTTON(7, Cosmicos::onClearButton)
	EVT_COMMAND(8, wxEVT_ButtonDownEvent, Cosmicos::onButtonPress)
	EVT_COMMAND(8, wxEVT_ButtonUpEvent, Cosmicos::onButtonRelease)
	EVT_BUTTON(9, Cosmicos::onSingleStep)

	EVT_BUTTON(10, Cosmicos::dataButton)
	EVT_BUTTON(11, Cosmicos::dataButton)
	EVT_BUTTON(12, Cosmicos::dataButton)
	EVT_BUTTON(13, Cosmicos::dataButton)
	EVT_BUTTON(14, Cosmicos::dataButton)
	EVT_BUTTON(15, Cosmicos::dataButton)
	EVT_BUTTON(16, Cosmicos::dataButton)
	EVT_BUTTON(17, Cosmicos::dataButton)
END_EVENT_TABLE()

Cosmicos::Cosmicos(const wxString& title, const wxPoint& pos, const wxSize& size, double clock, ElfConfiguration conf)
: wxFrame((wxFrame *)NULL, -1, title, pos, size)
{
	wxString switchNumber;

	cosmicosConfiguration = conf;

	wxClientDC dc(this);
	cosmicosClockSpeed_ = clock;
	data_ = 0;
	lastAddress_ = 0;

//	SetIcon(wxICON(elf2k_icon));
	this->SetClientSize(size);

	int offsetX = 10;
	int offsetY = 8;

	cosmicosBitmapPointer = new wxBitmap("images/cosmicos.bmp", wxBITMAP_TYPE_BMP);
	upBitmapPointer = new wxBitmap(swright_xpm);
	downBitmapPointer = new wxBitmap(swleft_xpm);

	mpButtonPointer = new wxBitmapButton(this, 2, *downBitmapPointer, wxPoint(offsetX, offsetY+10), wxSize(25, 25), 0, wxDefaultValidator, "MPButton");
	ramButtonPointer = new wxBitmapButton(this, 3, *downBitmapPointer, wxPoint(offsetX+140, offsetY+10), wxSize(25, 25), 0, wxDefaultValidator, "RamButton");

	ssButtonPointer = new wxButton(this, 9, "S", wxPoint(offsetX, offsetY+40), wxSize(25, 25), 0, wxDefaultValidator, "SSButton");
	clearButtonPointer = new wxButton(this, 7, "C", wxPoint(offsetX, offsetY+70), wxSize(25, 25), 0, wxDefaultValidator, "ClearButton");
	enterButtonPointer = new PushButton(this, 8, "E", wxPoint(offsetX, offsetY+100), wxSize(25, 25));

	resetLedPointer = new Led(dc, offsetX+77+30*(7-0), offsetY+20, COSMICOSLED);
	resetButtonPointer = new wxButton(this, 5, "R", wxPoint(offsetX+70+30*(7-0), offsetY+40), wxSize(25, 25), 0, wxDefaultValidator, "ResetButton");

	pauseLedPointer = new Led(dc, offsetX+77+30*(7-1), offsetY+20, COSMICOSLED);
	pauseButtonPointer = new wxButton(this, 6, "S", wxPoint(offsetX+70+30*(7-1), offsetY+40), wxSize(25, 25), 0, wxDefaultValidator, "PauseButton");

	loadLedPointer = new Led(dc, offsetX+77+30*(7-2), offsetY+20, COSMICOSLED);
	loadButtonPointer = new wxButton(this, 4, "L", wxPoint(offsetX+70+30*(7-2), offsetY+40), wxSize(25, 25), 0, wxDefaultValidator, "LoadButton");

	runLedPointer = new Led(dc, offsetX+77+30*(7-3), offsetY+20, COSMICOSLED);
	runButtonPointer = new wxButton(this, 1, "G", wxPoint(offsetX+70+30*(7-3), offsetY+40), wxSize(25, 25), 0, wxDefaultValidator, "RunButton");

	for (int i=0; i<8; i++)
	{
		switchNumber.Printf("%i", i);
		dataLedPointer[i] = new Led(dc, offsetX+77+30*(7-i), offsetY+80, COSMICOSLED);
		dataButtonPointer[i] = new wxButton(this, i+10, switchNumber, wxPoint(offsetX+70+30*(7-i), offsetY+100), wxSize(25, 25));
		if (i == 3)
			offsetX -= 10;
	}
	offsetX += 10;
	for (int i=0; i<2; i++)
	{
		dataPointer[i] = new Til313();
		dataPointer[i]->init(dc, offsetX+45+i*28, offsetY+20);
	}
	qLedPointer = new Led(dc, offsetX+100, offsetY+20, COSMICOSLED);

	cycleSize_ = (int) (((clock * 1000000) / 8) / (50/3));
	cycleValue_ = cycleSize_;
	bootstrap_ = 0;

	threadPointer = new RunCosmicos();
	if ( threadPointer->Create() != wxTHREAD_NO_ERROR )
	{
		p_Main->message("Can't create thread");
	}
	threadPointer->SetPriority(WXTHREAD_MAX_PRIORITY);
}

Cosmicos::~Cosmicos()
{
	saveRam();
	if (cosmicosConfiguration.usePixie)
	{
		p_Main->setPixiePos(COSMICOS, pixiePointer->GetPosition());
		pixiePointer->Destroy();
	}
	if (cosmicosConfiguration.vtType != VTNONE)
	{
		p_Main->setVtPos(COSMICOS, vtPointer->GetPosition());
		vtPointer->Destroy();
	}
	p_Main->setMainPos(COSMICOS, GetPosition());

	if (cosmicosConfiguration.useHex)
	{
		p_Main->setKeypadPos(COSMICOS, p_Cosmicoshex->GetPosition());
	}
	p_Cosmicoshex->Destroy();
	delete cosmicosBitmapPointer;
	delete upBitmapPointer;
	delete downBitmapPointer;

 	delete mpButtonPointer;
 	delete ramButtonPointer;
 	delete ssButtonPointer;
 	delete clearButtonPointer;
 	delete enterButtonPointer;

 	delete loadLedPointer;
	delete loadButtonPointer;

 	delete resetLedPointer;
	delete resetButtonPointer;

 	delete pauseLedPointer;
	delete pauseButtonPointer;

 	delete runLedPointer;
	delete runButtonPointer;

	for (int i=0; i<8; i++)
	{
		delete dataLedPointer[i];
		delete dataButtonPointer[i];
	}
	for (int i=0; i<2; i++)
	{
		delete dataPointer[i];
	}
 	delete qLedPointer;
}

void Cosmicos::stopComputer()
{
	threadPointer->Delete();
}

void Cosmicos::onPaint(wxPaintEvent&WXUNUSED(event))
{
	wxPaintDC dc(this);
	dc.DrawBitmap(*cosmicosBitmapPointer, 0, 0);

	for (int i=0; i<8; i++)
	{
		dataLedPointer[i]->onPaint(dc);
	}
	for (int i=0; i<2; i++)
	{
		dataPointer[i]->onPaint(dc);
	}
	runLedPointer->onPaint(dc);
	loadLedPointer->onPaint(dc);
	pauseLedPointer->onPaint(dc);
	resetLedPointer->onPaint(dc);
	qLedPointer->onPaint(dc);
}

void Cosmicos::onClose(wxCloseEvent&WXUNUSED(event) )
{
	threadPointer->Pause();
	p_Main->stopComputer();
}

void Cosmicos::onKeyDown(wxKeyEvent& event)
{
	if (!keyDownPressed(event.GetKeyCode()))
		event.Skip();
}

bool Cosmicos::keyDownPressed(int key)
{
	switch(key)
	{
		case WXK_F1:
			p_Main->onF1();
			return true;
		break;

		case WXK_F2:
			showTime();
			return true;
		break;

		case WXK_F3:
			if ((cosmicosConfiguration.vtType != VTNONE) || cosmicosConfiguration.usePixie)
			{
				if ((p_Video != NULL) && (p_Vt100 != NULL))
				{
					if (!p_Video->isFullScreenSet() && !p_Vt100->isFullScreenSet())
						p_Vt100->onF3();
					else if (p_Vt100->isFullScreenSet())
					{
						p_Vt100->onF3();
						while (p_Vt100->isFullScreenSet()) 
						{
							threadPointer->Sleep(1);
						}
						p_Video->onF3();
					}
					else
					{
						p_Video->onF3();
					}

					return true;
				}
				if (p_Video != NULL)
					p_Video->onF3();
				if (p_Vt100 != NULL)
					p_Vt100->onF3();
				return true;
			}
		break;

		case WXK_F5:
			if ((cosmicosConfiguration.vtType != VTNONE) || cosmicosConfiguration.usePixie)
			{
				if (p_Video != NULL)
					p_Video->onF5();
				if (p_Vt100 != NULL)
					p_Vt100->onF5();
				return true;
			}
		break;

		case WXK_INSERT:
			onInButtonKeyboard();
			return true;
		break;

		case WXK_F12:
			onRun();
			return true;
		break;
	}
	if (cosmicosConfiguration.useHexKeyboardEf3)
		onHexKeyDown(key);
	return false;
}

void Cosmicos::onKeyUp(wxKeyEvent& event)
{
	if (!keyUpReleased(event.GetKeyCode()))
		event.Skip();
}

bool Cosmicos::keyUpReleased(int key)
{
	if (key == WXK_INSERT)
	{
		onInButtonRelease();
		return true;
	}
	if (cosmicosConfiguration.useHexKeyboardEf3)
		onHexKeyUp(key);
	return false;
}

void Cosmicos::onChar(wxKeyEvent& event)
{
}

void Cosmicos::charEvent(int keycode)
{
}

void Cosmicos::onButtonRelease(wxCommandEvent& event)
{
	onInButtonRelease();
	event.Skip();
}

void Cosmicos::onButtonPress(wxCommandEvent& event)
{
	onInButtonPress(getData());
	event.Skip();
}

void Cosmicos::onInButtonKeyboard()
{
	onInButtonPress(getData());
}

void Cosmicos::onHexKeyDown(int keycode)
{
	for (int i=0; i<16; i++)
	{
		if (keycode == hexKeyDefA_[i])
		{
			p_Cosmicoshex->onNumberKeyPress(i);
		}
	}
}

void Cosmicos::onHexKeyUp(int keycode)
{
	for (int i=0; i<16; i++)
	{
		if (keycode == hexKeyDefA_[i])
		{
			p_Cosmicoshex->onNumberKeyRelease(i);
		}
	}
}

void Cosmicos::onPause(wxCommandEvent&WXUNUSED(event))
{
	setClear(1);
	setWait(0);
	p_Main->updateTitle();
	singleStep_ = 0;
}

void Cosmicos::onSingleStep(wxCommandEvent&WXUNUSED(event))
{
	singleStep_ = 1;
}

void Cosmicos::onResetButton(wxCommandEvent&WXUNUSED(event))
{
	lastMode_ = cpuMode_;
	setClear(0);
	setWait(1);
	segNumber_ = 0;
	if (cosmicosConfiguration.usePixie)
	{
		pixiePointer->outPixie();
		pixieOn_ = false;
	}
	if (lastMode_ == RUN && cpuMode_ != RUN)  showTime();
	singleStep_ = 0;
	state_ = 'F';
}

void Cosmicos::onRunButton(wxCommandEvent&WXUNUSED(event))
{
	setClear(1);
	setWait(1);
	p_Main->updateTitle();
	startTime_ = wxGetLocalTime();
}

void Cosmicos::onRun() 
{
	stopTape();
	if (getClear()==0)
	{
		setClear(1);
		setWait(1);
		p_Main->updateTitle();
		startTime_ = wxGetLocalTime();
	}
	else
	{
		lastMode_ = cpuMode_;
		setClear(0);
		setWait(1);
		segNumber_ = 0;
		if (cosmicosConfiguration.usePixie)
		{
			pixiePointer->outPixie();
			pixieOn_ = false;
		}
		p_Main->updateTitle();
		if (lastMode_ == RUN && cpuMode_ != RUN)  showTime();
		singleStep_ = 0;
		state_ = 'F';
	}
}

void Cosmicos::autoBoot()
{
	runButtonState_ = 1;

	setClear(runButtonState_);
	segNumber_ = 0;
	if (cpuMode_ != RUN)  showTime();
}

Byte Cosmicos::inPressed()
{
	return !inPressed_;
}

void Cosmicos::onInButtonPress(Byte value)
{
	if (inPressed_ == 1)  return;
	inPressed_ = 1;
	if (getCpuMode() == LOAD)
	{
		dmaIn(value);
		showData(value);
		wxClientDC dc(this);
		for (int i=0; i<8; i++)
		{
			dataSwitchState_[i] = 0;
			dataLedPointer[i]->setStatus(dc, 0);
		}
	}
}

void Cosmicos::onInButtonRelease()
{
	if (inPressed_ == 0)  return;
	inPressed_ = 0;
}

void Cosmicos::onLoadButton(wxCommandEvent&WXUNUSED(event))
{
	lastMode_ = cpuMode_;
	setClear(0);
	setWait(0);
	segNumber_ = 0;
	if (cosmicosConfiguration.usePixie)
	{
		pixiePointer->outPixie();
		pixieOn_ = false;
	}
	if (lastMode_ == RUN && cpuMode_ != RUN)  showTime();
}

void Cosmicos::onMpButton(wxCommandEvent&WXUNUSED(event))
{
	if (mpButtonState_)
	{
		mpButtonPointer->SetBitmapLabel(*downBitmapPointer);
		mpButtonState_ = 0;
	}
	else
	{
		mpButtonPointer->SetBitmapLabel(*upBitmapPointer);
		mpButtonState_ = 1;
	}
}

void Cosmicos::onRamButton(wxCommandEvent&WXUNUSED(event))
{
	if (ramButtonState_)
	{
		ramButtonPointer->SetBitmapLabel(*downBitmapPointer);
		ramButtonState_ = 0;
	}
	else
	{
		ramButtonPointer->SetBitmapLabel(*upBitmapPointer);
		ramButtonState_ = 1;
	}
}

void Cosmicos::dataButton(wxCommandEvent&event)
{
	int i;

	i = event.GetId() - 10;

	if (dataSwitchState_[i])
		dataSwitchState_[i] = 0;
	else
		dataSwitchState_[i] = 1;

	wxClientDC dc(this);
	dataLedPointer[i]->setStatus(dc, dataSwitchState_[i]);
}

void Cosmicos::onClearButton(wxCommandEvent&WXUNUSED(event))
{
	wxClientDC dc(this);
	for (int i=0; i<8; i++)
	{
		dataSwitchState_[i] = 0;
		dataLedPointer[i]->setStatus(dc, 0);
	}
}

Byte Cosmicos::getData()
{
	return(dataSwitchState_[7]?128:0) +(dataSwitchState_[6]?64:0) +(dataSwitchState_[5]?32:0) +(dataSwitchState_[4]?16:0) +(dataSwitchState_[3]?8:0) +(dataSwitchState_[2]?4:0) +(dataSwitchState_[1]?2:0) +(dataSwitchState_[0]?1:0);
}

void Cosmicos::configureComputer()
{
	inType_[6] = COSMICOSIN;
	outType_[6] = COSMICOSOUT;

	p_Main->message("Configuring Cosmicos");
	p_Main->message("	Output 7: display output, input 7: data input");
	if (cosmicosConfiguration.useHexKeyboardEf3 || cosmicosConfiguration.useHex)
	{
		efType_[1] = COSMICOSRET;
		efType_[2] = COSMICOSDEC;
		efType_[3] = COSMICOSREQ;
		inType_[4] = COSMICOSHEX;
		inType_[5] = COSMICOS7SEG;
		outType_[4] = COSMICOSHEX;
		outType_[5] = COSMICOS7SEG;
		cycleType_[5] = COSMICOS7SEG;
		p_Main->message("	Output 5: select hex row, input 5: hex column");
		p_Main->message("	Output 6: 7 segment display, input 6: reset 7 segment");
		p_Main->message("	EF 1: hex RET, EF2: hex DEC/SEQ, EF3: hex REQ/SEQ");
	}
	if (cosmicosConfiguration.vtType == VTNONE)
	{
		efType_[4] = COSMICOSEF;
		p_Main->message("	EF 4: 0 when in button pressed");
	}
	p_Main->message("");

	hexKeyDefA_[0] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyA0"), 48);
	hexKeyDefA_[1] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyA1"), 49);
	hexKeyDefA_[2] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyA2"), 50);
	hexKeyDefA_[3] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyA3"), 51);
	hexKeyDefA_[4] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyA4"), 52);
	hexKeyDefA_[5] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyA5"), 53);
	hexKeyDefA_[6] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyA6"), 54);
	hexKeyDefA_[7] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyA7"), 55);
	hexKeyDefA_[8] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyA8"), 56);
	hexKeyDefA_[9] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyA9"), 57);
	hexKeyDefA_[10] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyAA"), 65);
	hexKeyDefA_[11] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyAB"), 66);
	hexKeyDefA_[12] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyAC"), 67);
	hexKeyDefA_[13] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyAD"), 68);
	hexKeyDefA_[14] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyAE"), 69);
	hexKeyDefA_[15] = p_Main->getConfigItem(_T("/Cosmicos/HexKeyAF"), 70);

	runButtonState_ = 0;
	ramButtonState_ = 0;
	for (int i=0; i<8; i++)  dataSwitchState_[i]=0;

	resetCpu();
}

void Cosmicos::initComputer()
{
	Show(cosmicosConfiguration.useElfControlWindows);
	lastMode_ = UNDEFINDEDMODE;

	qState_ = flipFlopQ_ + 1;
	switches_ = 0;
	inPressed_ = 0;
 	singleStep_ = 0;
	segNumber_ = 0;
	cassetteEf_ = 0;
	pixieOn_ = false;
}

Byte Cosmicos::ef(int flag)
{
	switch(efType_[flag])
	{
		case 0:
			return 1;
		break;

		case VT100EF:
			return vtPointer->ef();
		break;

		case COSMICOSEF:
			return inPressed();
		break;

		case COSMICOSREQ:
			if (pixieOn_)
			{
				if (cosmicosConfiguration.usePixie)
					return pixiePointer->efPixie();
			}
			else
			{
				if (cosmicosConfiguration.useHexKeyboardEf3 || cosmicosConfiguration.useHex)
					return (p_Cosmicoshex->reqState() & p_Cosmicoshex->seqState());
			}
			return 1;
		break;

		case COSMICOSDEC:
			if (isLoading())
				return cassetteEf_;
			else
				return (p_Cosmicoshex->decState() & p_Cosmicoshex->seqState());
		break;

		case COSMICOSRET:
			return p_Cosmicoshex->retState();
		break;

		default:
			return 1;
	}
}

Byte Cosmicos::in(Byte port, Word WXUNUSED(address))
{
	Byte ret;
	ret = 0;

	switch(inType_[port-1])
	{
		case 0:
			ret = 255;
		break;

		case PIXIEIN:
			if (qState_ == 0)
			{
				ret = pixiePointer->inPixie();
				pixieOn_ = true;
			}
		break;

		case PIXIEOUT:
			if (qState_ == 0)
			{
				pixiePointer->outPixie();
				pixieOn_ = false;
			}
		break;

		case COSMICOSIN:
			ret = getData();
		break;

		case COSMICOSHEX:
			ret = p_Cosmicoshex->getKeyinput();
		break;

		case COSMICOS7SEG:
			segNumber_ = 0;
			ret = 255;
		break;

		default:
			ret = 255;
	}
	inValues_[port] = ret;
	return ret;
}

void Cosmicos::out(Byte port, Word WXUNUSED(address), Byte value)
{
	outValues_[port] = value;

	switch(outType_[port-1])
	{
		case 0:
			return;
		break;

		case VT100OUT:
			vtPointer->out(value);
		break;

		case COSMICOSOUT:
			showData(value);
		break;

		case COSMICOSHEX:
			p_Cosmicoshex->keyLatch(value);
		break;

		case COSMICOS7SEG:
			p_Cosmicoshex->segUpdate(segNumber_, value);
			segNumber_++;
			segNumber_&=0x7;
		break;

		case COSMICOSTONE:
			if (qState_ == 10)
				tone1864Latch(value);
		break;
	}
}

void Cosmicos::switchQ()
{
	if (qState_ != flipFlopQ_)
	{
		wxClientDC dc(this);
		qLedPointer->setStatus(dc, flipFlopQ_);
		qState_ = flipFlopQ_;
	}
	if (bootstrap_ != 0 && flipFlopQ_ == 1)
		bootstrap_ = 0;
}

void Cosmicos::showData(Byte val)
{
	wxClientDC dc(this);

	dataPointer[0]->update(dc,(val>>4)&15);
	dataPointer[1]->update(dc, val&15);
}

void Cosmicos::cycle(int type)
{
	switch(cycleType_[type])
	{
		case 0:
			return;
		break;

		case PIXIECYCLE:
			pixiePointer->cyclePixieTelmac();
		break;

		case COSMICOS7SEG:
				cycleValue_ --;
				if (cycleValue_ <= 0)
				{
					if (!pixieOn_)
						interrupt();
					cycleValue_ = cycleSize_;
				}
		break;

		case VT100CYCLE:
			vtPointer->cycleVt();
		break;
	}
}

void Cosmicos::startTime()
{
	startTime_ = wxGetLocalTime();
}

void Cosmicos::startComputer()
{
	resetPressed_ = false;

	p_Cosmicoshex = new Cosmicoshex("Hex Panel", p_Main->getKeypadPos(COSMICOS), wxSize(185, 160));
	p_Cosmicoshex->Show(cosmicosConfiguration.useHex);

	if (p_Main->getSpinValue("RamCosmicos")==0)
	{
		mainRamAddress_ = 0;
		defineMemoryType(0, 0xff, MAPPEDRAM);
		mpButtonPointer->SetBitmapLabel(*downBitmapPointer);
		mpButtonState_ = 0;
	}
	else
	{
		mainRamAddress_ = 0xFF00;
		defineMemoryType(0, p_Main->getSpinValue("RamCosmicos")*0x400-1, RAM);
		defineMemoryType(0xff00, 0xffff, MAPPEDRAM);
		mpButtonPointer->SetBitmapLabel(*upBitmapPointer);
		mpButtonState_ = 1;
	}
	
	readProgramCombo(p_Main->getRomDir(COSMICOS, MAINROM), "MainRomCosmicos", ROM, 0xc000, NONAME);
	loadRam();

	configureElfExtensions();
	if (cosmicosConfiguration.autoBoot)
	{
		bootstrap_ = 0xC0C0;
		autoBoot();
	}
	else
		bootstrap_ = 0;

	if (cosmicosConfiguration.vtType != VTNONE)
		setEf(4,0);

	p_Main->setSwName("");
	p_Main->updateTitle();

	cpuCycles_ = 0;
	startTime_ = wxGetLocalTime();

	threadPointer->Run();
}

Byte Cosmicos::readMem(Word addr)
{
	address_ = addr | bootstrap_;

	switch (memoryType_[addr / 256])
	{
		case UNDEFINED:
			return 255;
		break;

		case ROM:
		case RAM:
		case MAPPEDRAM:
			return mainMemory_[addr | bootstrap_];
		break;

		default:
			return 255;
		break;
	}
}

void Cosmicos::writeMem(Word addr, Byte value, bool writeRom)
{
	address_ = addr | bootstrap_;

	switch (memoryType_[addr/256])
	{
		case UNDEFINED:
		case ROM:
			if (writeRom)
				mainMemory_[addr]=value;
		break;

		case MAPPEDRAM:
			if (mpButtonState_ == 0)
				mainMemory_[addr | bootstrap_]=value;
		break;

		case RAM:
			mainMemory_[addr | bootstrap_]=value;
		break;
	}
}

void Cosmicos::cpuInstruction()
{
	if (cpuMode_ != lastMode_)
	{
		wxClientDC dc(this);
		runLedPointer->setStatus(dc, 0);
		loadLedPointer->setStatus(dc, 0);
		resetLedPointer->setStatus(dc, 0);
		pauseLedPointer->setStatus(dc, 0);
		switch(cpuMode_)
		{
			case LOAD: loadLedPointer->setStatus(dc, 1); break;
			case RESET: resetLedPointer->setStatus(dc, 1); break;
			case RUN: runLedPointer->setStatus(dc, 1); break;
			case PAUSE: pauseLedPointer->setStatus(dc, 0); break;
		}
		lastMode_ = cpuMode_;
	}
	if (cpuMode_ == RUN && singleStep_ != 0 && state_ == 'F')
	{
		state_ = 'E';
		setWait(0);
	}
	if (debugMode_)
		p_Main->updateWindow();
	if (cpuMode_ == RUN)
	{
		if (steps_ != 0)
		{
			cycle0_=0;
			machineCycle();
			if (cycle0_ == 0) machineCycle();
			if (cycle0_ == 0 && steps_ != 0)
			{
				cpuCycle();
				cpuCycles_ += 2;
			}
		}
		else
			soundCycle();
		playSaveLoad();
		checkCosmicosFunction();
		if (resetPressed_)
		{
			resetCpu();
			initComputer();
			if (cosmicosConfiguration.autoBoot)
			{
				bootstrap_ = 0xC0C0;
				autoBoot();
			}
			else
				bootstrap_ = 0;
			resetPressed_ = false;
			p_Main->setSwName("");
		}
		if (debugMode_)
			p_Main->cycleDebug();

		state_ = 'F';
		if (singleStep_ != 0)
		{
			setWait(0);
		}
	}
	else
	{
		machineCycle();
		machineCycle();
		cpuCycles_ = 0;
		startTime_ = wxGetLocalTime();
		if (cpuMode_ == LOAD)
		{
			showData(readMem(address_));
//			threadPointer->Sleep(1);
		}
	}
}

void Cosmicos::configureElfExtensions()
{
	wxString path, fileName1, fileName2;

	p_Computer->setSoundFollowQ(!cosmicosConfiguration.usePixie);
	if (cosmicosConfiguration.usePixie)
	{
		int zoom = p_Main->getSpinValue("ZoomCosmicos");
		pixiePointer = new Pixie( "Cosmicos - CDP1864", p_Main->getPixiePos(COSMICOS), wxSize(192*zoom, 192*zoom), zoom, COSMICOS);
		p_Video = pixiePointer;
		pixiePointer->setZoom(zoom);
		pixiePointer->configurePixieCosmicos();
		pixiePointer->initPixie();
		pixiePointer->Show(true);
	}

	if (cosmicosConfiguration.vtType != VTNONE)
	{
		int zoom = p_Main->getSpinValue("ZoomCosmicos");
		vtPointer = new Vt100("Cosmicos - VT 100", p_Main->getVtPos(COSMICOS), wxSize(640*zoom, 400*zoom), zoom, COSMICOS, cosmicosClockSpeed_, cosmicosConfiguration.vtType);
		p_Vt100 = vtPointer;
		vtPointer->configureCosmicos(cosmicosConfiguration.baudR, cosmicosConfiguration.baudT);
		vtPointer->Show(true);
	}

}

void Cosmicos::tmsAndPixieZoom(int zoom)
{
	if (cosmicosConfiguration.usePixie)
	{
		pixiePointer->setZoom(zoom);
		pixiePointer->reDrawScreen();
	}
	if (cosmicosConfiguration.vtType != VTNONE)
	{
		vtPointer->setZoom(zoom);
	}
}

void Cosmicos::moveWindows()
{
	if (cosmicosConfiguration.usePixie)
		pixiePointer->Move(p_Main->getPixiePos(COSMICOS));
	if (cosmicosConfiguration.vtType != VTNONE)
		vtPointer->Move(p_Main->getVtPos(COSMICOS));
	if (cosmicosConfiguration.useHex)
		p_Cosmicoshex->Move(p_Main->getKeypadPos(COSMICOS));
}

void Cosmicos::updateTitle(wxString Title)
{
	if (cosmicosConfiguration.usePixie)
		pixiePointer->SetTitle("Cosmicos - CDP1864"+Title);
	if (cosmicosConfiguration.vtType != VTNONE)
		vtPointer->SetTitle("Cosmicos - VT 100"+Title);
	if (cosmicosConfiguration.useHex)
		p_Cosmicoshex->SetTitle("Hex Panel"+Title);
}

void Cosmicos::setForceUpperCase(bool status)
{
	if (cosmicosConfiguration.vtType != VTNONE)
		vtPointer->setForceUCVt(status);
}

void Cosmicos::onReset()
{
	resetPressed_ = true;
}

void Cosmicos::removeCosmicosHex() 
{
	cosmicosConfiguration.useHex = false;
	p_Main->setCheckBox("HexCosmicos", false);
	p_Cosmicoshex->Show(false);
}

void Cosmicos::showModules(bool useHex)
{
	p_Cosmicoshex->Show(useHex);
}

void Cosmicos::saveRam()
{
	if (ramButtonState_ == 0)
		return;

	Byte value;
	wxFile outputFile;
	wxString fileName;

	fileName = p_Main->getMainDir()+"ramdump.bin";

	if (wxFile::Exists(fileName))
		outputFile.Open(fileName, wxFile::write);
	else
		outputFile.Create(fileName);
	for (long address = 0; address <= 0xff; address++)
	{
		value = mainMemory_[address+mainRamAddress_];
		outputFile.Write(&value, 1);
	}
	outputFile.Close();
}

void Cosmicos::loadRam()
{
	wxFFile inFile;
	size_t length;
	char buffer[0x100];

	if (wxFile::Exists(p_Main->getMainDir()+"ramdump.bin"))
	{
		if (inFile.Open(p_Main->getMainDir()+"ramdump.bin", "rb"))
		{
			length = inFile.Read(buffer, 0x100);
			for (size_t i=0; i<length; i++)
				mainMemory_[i+mainRamAddress_] = (Byte)buffer[i];
			inFile.Close();
		}
	}
}

void Cosmicos::cassette(short val)
{
	if (val < 0)
	{
		cassetteEf_ = 0;
	}
	else
		cassetteEf_ = 1;
}

void Cosmicos::cassette(char val)
{
	if (val < 0)
	{
		cassetteEf_ = 0;
	}
	else
		cassetteEf_ = 1;
}

void Cosmicos::checkCosmicosFunction()
{
	switch (loadedProgram_)
	{
		case NOPROGRAM:
		break;

		case HEXMON:
			switch (scratchpadRegister_[programCounter_])
			{
				case 0xc366:	// SAVE
				case 0xc3b7:	// LOAD
					p_Main->stopCassette();
				break;

				case 0xc2f0:	// SAVE
					p_Main->startCassetteSave();
				break;

				case 0xc37d:	// LOAD
					p_Main->setSwName ("");
					p_Main->startCassetteLoad();
				break;
			}
		break;

		case ASCIIMON:
			switch (scratchpadRegister_[programCounter_])
			{
				case 0xc5d3:	// SAVE ASCII MON
				case 0xc6c3:	// LOAD ASCII MON
					p_Main->stopCassette();
				break;

				case 0xc571:	// SAVE ASCII MON
					p_Main->startCassetteSave();
				break;

				case 0xc643:	// LOAD ASCII MON
					p_Main->setSwName ("");
					p_Main->startCassetteLoad();
				break;
			}
		break;
	}
}
void *RunCosmicos::Entry()
{
	while(!TestDestroy())
	{
		p_Computer->cpuInstruction();
	}
	return NULL;
}
