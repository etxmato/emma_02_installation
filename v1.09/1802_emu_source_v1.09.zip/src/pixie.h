#ifndef PIXIE_H
#define PIXIE_H

#include "video.h"

class PlotList
{
public: 
	wxCoord x;
	wxCoord y;
	PlotList *nextPlot;
};

class PixieScreen : public wxWindow
{
public:
	PixieScreen(wxWindow *parent, const wxSize& size, int zoom, int computerType);
	~PixieScreen() {};

	void onPaint(wxPaintEvent&event);
	void onChar(wxKeyEvent&event);
	void onKeyDown(wxKeyEvent&event);
	void onKeyUp(wxKeyEvent&event);

	void blit(wxCoord xdest, wxCoord ydest, wxCoord width, wxCoord height, wxDC *source, wxCoord xsrc, wxCoord ysrc);
	void drawBackground(wxColour clr, int v1870X, int v1870Y, wxCoord offsetX, wxCoord offsetY);
	void disableScreen(wxColour clr, int xSize, int ySize, wxCoord offsetX, wxCoord offsetY);
	void setZoom(int zoom);

private:
	int zoom_;
	int computerType_;

	DECLARE_EVENT_TABLE()
};

class Pixie : public Video
{
public:

	Pixie(const wxString& title, const wxPoint& pos, const wxSize& size, int zoom, int computerType);
	~Pixie();

	void onClose(wxCloseEvent&WXUNUSED(event));
	void setReBlit();

	void configurePixie();
	void configurePixieStudio2();
	void configurePixieVisicom();
	void configurePixieVip();
	void configurePixieTmc1800();
	void configurePixieTelmac();
	void configurePixieVictory();
	void configurePixieEti();
	void initiateColour(bool colour);
	void configurePixieNano();
	void configurePixieCosmicos();
	void initPixie(); 
	Byte efPixie();
	Byte inPixie();
	void outPixie(); 
	void outPixieBackGround(); 
	void cyclePixie(); 
	void cyclePixieTelmac(); 

	void setZoom(int zoom);
	void reDrawScreen();
	void copyScreen();
	void drawScreen();
	void plot(int x, int y, int c, int color);

	void onF3();
	void onF5();
	bool isFullScreenSet() {return fullScreenSet_;};

private:
	void setFullScreen();
	void drawBackground();

	wxBitmap *screenCopyPointer;
	wxBitmap *screenFilePointer;
	PlotList *plotListPointer;
    class PixieScreen *pixieScreenPointer;
	wxString runningComputer_;

	wxMemoryDC dcMemory;

	int computerType_;
	Byte pbacking_[64][192];
	Byte color_[64][192];
	Byte vidInt_;
	Byte vidCycle_;

	int zoom_; 
	int restoreZoomAfterFullScreen_; 
	bool graphicsOn_;
	long graphicsMode_;
	long graphicsNext_;
	Byte pixieEf_;

	int backGround_;
	int backGroundInit_;

	int ySize_;

	wxCoord offsetX_;
	wxCoord offsetY_;
	bool fullScreenSet_;
	bool f3Pressed_;
	bool newBackGround_;
	int updatePlot_;
	int colourMask_;
	
	DECLARE_EVENT_TABLE()
};

#endif  // PIXIE_H