#ifndef GUIELF_H
#define GUIELF_H

#include "guielf2k.h"
#include "elfconfiguration.h"

class GuiElf: public GuiElf2K
{
public:

	GuiElf(const wxString& title, const wxPoint& pos, const wxSize& size);
	~GuiElf() {};

	void readElfConfig(int elfType, wxString elfTypeStr);
	void writeElfConfig(int elfType, wxString elfTypeStr);

	void onDiskType(wxCommandEvent& event);
	void onMemory(wxCommandEvent& event);
	void onAutoBoot(wxCommandEvent& event);
	void onBootAddress(wxCommandEvent& event);
	void onStartRam(wxCommandEvent& event);
	void onEndRam(wxCommandEvent& event);
	void onVideoType(wxCommandEvent& event);
	void onElfKeyboard(wxCommandEvent& event);
	void onForceUpperCase(wxCommandEvent& event);
 	void onUsePrinter(wxCommandEvent& event);
 	void onUsePortExtender(wxCommandEvent& event);
	void onLedModule(wxCommandEvent& event);
	void onElfControlWindows(wxCommandEvent& event);
	void onRom1(wxCommandEvent& event);
	void onRom2(wxCommandEvent& event);
	void setGameModeConfig(wxCommandEvent& event);
	void setGiantBoard(wxCommandEvent& event);
	void setSuperBasic(wxCommandEvent& event);
	void setSuperBasicSerial(wxCommandEvent& event);
	void setRcaBasic(wxCommandEvent& event);
	void setRcaBasicPixie(wxCommandEvent& event);
	void setRcaBasicSerial(wxCommandEvent& event);
	void setRcaBasicElfOsInstall(wxCommandEvent& event);
	void setTinyBasicSerial(wxCommandEvent& event);
	void setTinyBasicPixie(wxCommandEvent& event);
	void setTinyBasic6847(wxCommandEvent& event);
	void setFigForth(wxCommandEvent& event);
	void setSuperGoldMonitor(wxCommandEvent& event);
	void setMonitorBasic(wxCommandEvent& event);
	void setMusic(wxCommandEvent& event);
	void setElfOsInstallConfig(wxCommandEvent& event);
	void setElfOsConfig(wxCommandEvent& event);
	void setElfOsInstallConfig25(wxCommandEvent& event);
	void setElfOsConfig25(wxCommandEvent& event);
	void setElfOsIoInstallConfigPixie(wxCommandEvent& event);
	void setElfOsIoConfigPixie(wxCommandEvent& event);
	void setElfOsIoInstallConfig6845(wxCommandEvent& event);
	void setElfOsIoConfig6845(wxCommandEvent& event);
	void setElfOsIoInstallConfig6847(wxCommandEvent& event);
	void setElfOsIoConfig6847(wxCommandEvent& event);
	void setElfOsIoInstallConfigTms(wxCommandEvent& event);
	void setElfOsIoConfigTms(wxCommandEvent& event);
	void setElfOsConfigMain();
	void setElfOsIoConfigMain();
	void onElfScreenDump(wxCommandEvent& event);
	void onTape(wxCommandEvent& event);
	void onUart(wxCommandEvent& event);
	void switchUart();

	int getLoadromMode(int elfType, int num);
	long getBootAddress(wxString elfTypeStr, int elfType);
	long getStartRam(wxString elfTypeStr, int elfType);
	long getEndRam(wxString elfTypeStr, int elfType);
	void setDiskType(wxString elfTypeStr, int elfType, int Selection);
	void setMemory(wxString elfTypeStr, int elfType, int Selection);
	void setElfKeyboard(wxString elfTypeStr, int elfType, int Selection);
	void setVideoType(wxString elfTypeStr, int elfType, int Selection);

	wxPoint getLedModulePos();
	void setLedModulePos(wxPoint position);
	void reset6847ConfigItem(int num);

protected:
	int ledModuleX_, ledModuleY_;

private:

	int loadromMode_[3][2];
	long bootAddress_[5];
	long startRam_[3];
	long endRam_[3];

	DECLARE_EVENT_TABLE()
};

#endif // GUIELF_H