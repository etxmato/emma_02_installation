#ifndef GUISTUDIO2_H
#define GUISTUDIO2_H

#include "guivip.h"

class GuiStudio2: public GuiVip
{
public:

	GuiStudio2(const wxString& title, const wxPoint& pos, const wxSize& size, Mode mode, wxString dataDir);
	~GuiStudio2() {};

	void readStudioConfig();
    void writeStudioDirConfig();
    void writeStudioConfig();
    void readStudioWindowConfig();
    void writeStudioWindowConfig();
    
	void readVisicomConfig();
    void writeVisicomDirConfig();
    void writeVisicomConfig();
    void readVisicomWindowConfig();
    void writeVisicomWindowConfig();
    
	void readVictoryConfig();
    void writeVictoryDirConfig();
    void writeVictoryConfig();
    void readVictoryWindowConfig();
    void writeVictoryWindowConfig();

	void onSt2Rom(wxCommandEvent& event);
	void onSt2RomEject(wxCommandEvent& event);

private:
	wxString studio2St2RomDir_;

	DECLARE_EVENT_TABLE()
};

#endif // GUISTUDIO2_H
