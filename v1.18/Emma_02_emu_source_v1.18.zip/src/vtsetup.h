#ifndef VTSETUPDLG_H
#define VTSETUPDLG_H

class VtSetupDialog : public wxDialog
{
public:
    VtSetupDialog(wxWindow* parent);
    ~VtSetupDialog() {};

private:
    void onSaveButton(wxCommandEvent &event);

 	wxString computerTypeStr_;
	int computerType_;
	bitset<16> SetUpFeature_;
	ElfConfiguration elfConfiguration_;

	DECLARE_EVENT_TABLE()

};

#endif  // VTSETUPDLG_H
