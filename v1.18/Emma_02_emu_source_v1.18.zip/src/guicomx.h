#ifndef GUICOMX_H
#define GUICOMX_H

#include "guielf.h"

DECLARE_EVENT_TYPE(OPEN_COMX_PRINTER_WINDOW, 800)
DECLARE_EVENT_TYPE(STATUS_LED_ON, 801)
DECLARE_EVENT_TYPE(STATUS_LED_OFF, 802)
DECLARE_EVENT_TYPE(STATUS_BAR_1870, 803)
DECLARE_EVENT_TYPE(EXP_LED_ON, 805)
DECLARE_EVENT_TYPE(EXP_LED_OFF, 806)
DECLARE_EVENT_TYPE(KILL_COMPUTER, 809)

class GuiComx: public GuiElf
{
public:

	GuiComx(const wxString& title, const wxPoint& pos, const wxSize& size, Mode mode, wxString dataDir);
	~GuiComx();

	void readComxConfig();
	void writeComxConfig();

	void onExpansionRom(wxCommandEvent& event);
	void onExpansionRomText(wxCommandEvent& event);
	void onCard1Rom(wxCommandEvent& event);
	void onCard1RomText(wxCommandEvent& event);
	void onCard2Rom(wxCommandEvent& event);
	void onCard2RomText(wxCommandEvent& event);
	void onCard3Rom(wxCommandEvent& event);
	void onCard3RomText(wxCommandEvent& event);
	void onCard4Rom(wxCommandEvent& event);
	void onCard4RomText(wxCommandEvent& event);
	void onComxDisk1(wxCommandEvent& event);
	void onComxDiskText1(wxCommandEvent& event);
	void onComxDiskEject1(wxCommandEvent& event);
	void onComxDisk2(wxCommandEvent& event);
	void onComxDiskText2(wxCommandEvent& event);
	void onComxDiskEject2(wxCommandEvent& event);
	void onComxPrintFileText(wxCommandEvent& event);
	void onComxPrintMode(wxCommandEvent& event);
	void onComxPrintButton(wxCommandEvent& event);
	void onComxVideoMode(wxCommandEvent& event);
	void onComxExpansionRam(wxCommandEvent& event);
	void onComxExpansionRamSlot(wxSpinEvent&event);
	void setLocation(bool state, Word saveStart, Word saveEnd, Word saveExec);
	void onEpromDialog(wxCommandEvent& event);

	void statusLedOn(wxCommandEvent &event);
	void statusLedOff(wxCommandEvent &event);
	void statusLedOnDirect();
	void statusLedOffDirect();
	void v1870BarSize(wxCommandEvent &event);
	void expLedOn(wxCommandEvent &event);
	void expLedOff(wxCommandEvent &event);
	void expLedOnDirect();
	void expLedOffDirect();
	void openComxPrinterFrame(wxCommandEvent &event);

	wxString getFloppyDir(int drive);
	wxString getFloppyFile(int drive);
	wxString getPL80Data(int item);
	void setPL80Data(int item, wxString data);
	void enableComxGui(bool status);
	void setComxExpRamSlot();
	void resetCardText();
	bool isSaving();
	void setComxPrintMode();
	void onComxF4();
	void setFandMBasicGui();
	void enableDiskRomGui(bool DiskRom);
	void setExtRomStatus(bool expansionRomLoaded);
	void setComxPrintMode(int mode);
	int getComxPrintMode();
	int getExpansionRamSlot() {return expansionRamSlot_;};
	bool getUseExpansionRam() {return useExpansionRam_;};

	void setComxStatusLedOn (bool status) {isComxStatusLedOn_ = status;};
	void setComxExpLedOn (bool status) {isComxExpLedOn_ = status;};

	void statusLedOnEvent();
	void statusLedOffEvent();
	void expLedOnEvent();
	void expLedOffEvent();
	void v1870BarSizeEvent();

protected:
	bool expansionRomLoaded_;
	bool diskRomLoaded_;

private:
	wxString Pl80Data_[3];
	wxString floppyDir_[2];
	wxString floppy_[2];
	bool useExpansionRam_;
	int expansionRamSlot_;
	wxString saveCardText_;

	int comxPrintMode_;
	bool isComxStatusLedOn_;
	bool isComxExpLedOn_;

	DECLARE_EVENT_TABLE()
};

#endif // GUICOMX_H
