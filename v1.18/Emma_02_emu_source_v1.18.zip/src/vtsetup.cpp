/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "main.h"
#include "vtsetup.h"

#include "wx/xrc/xmlres.h"             
#include "wx/spinctrl.h"

BEGIN_EVENT_TABLE(VtSetupDialog, wxDialog)
    EVT_BUTTON(XRCID("VtSetupSave"), VtSetupDialog::onSaveButton)
END_EVENT_TABLE()

VtSetupDialog::VtSetupDialog(wxWindow* parent)
{
	wxXmlResource::Get()->Load(p_Main->getApplicationDir()+p_Main->getPathSep()+"vt.xrc");
	wxXmlResource::Get()->LoadDialog(this, parent, "VtSetupDialog");

	elfConfiguration_ = p_Main->getElfConfiguration();
	computerTypeStr_ = p_Main->getSelectedComputerStr();
	computerType_ = p_Main->getSelectedComputerId();

	this->SetTitle("Video Terminal Setup "+p_Main->getSelectedComputerText());

	switch (elfConfiguration_.vtType)
	{
		case VT52:
			SetUpFeature_ = p_Main->getConfigItem(computerTypeStr_+"/VT52Setup", 0x4092l);
			XRCCTRL(*this, "VtSetupBit5", wxChoice)->Hide();
			XRCCTRL(*this, "VtSetupBit5Text", wxStaticText)->Hide();
			XRCCTRL(*this, "VtSetupBit9", wxChoice)->Hide();
			XRCCTRL(*this, "VtSetupBit9Text", wxStaticText)->Hide();
		break;

		case VT100:
			if (computerType_ == COSMICOS)
			{
				SetUpFeature_ = p_Main->getConfigItem(computerTypeStr_+"/VT100Setup", 0xcad2l);
			}
			else
				SetUpFeature_ = p_Main->getConfigItem(computerTypeStr_+"/VT100Setup", 0xca52l);
		break;
	}

	XRCCTRL(*this, "SerialLog", wxCheckBox)->SetValue(p_Main->getConfigBool(computerTypeStr_+"/SerialLog", false));
	switch (computerType_)
	{
		case ELF:
		case ELFII:
		case SUPERELF:
			XRCCTRL(*this, "Uart", wxCheckBox)->SetValue(p_Main->getConfigBool(computerTypeStr_+"/Uart", false));
			XRCCTRL(*this, "Uart", wxCheckBox)->SetLabel("Uart CDP1854");
			XRCCTRL(*this, "VtEf", wxCheckBox)->Hide();
		break;

		case ELF2K:
			XRCCTRL(*this, "Uart", wxCheckBox)->SetValue(p_Main->getConfigBool(computerTypeStr_+"/Uart", false));
			XRCCTRL(*this, "Uart", wxCheckBox)->SetLabel("Uart 16450");
			XRCCTRL(*this, "VtEf", wxCheckBox)->Hide();
		break;

		case COSMICOS:
		case MEMBER:
			XRCCTRL(*this, "VtEf", wxCheckBox)->SetValue(p_Main->getConfigBool(computerTypeStr_+"/VtEf", false));
			XRCCTRL(*this, "Uart", wxCheckBox)->Hide();
		break;
	}

	wxString box;
	for (int i=0; i<16; i++)
	{
		box.Printf("%d", i);
		XRCCTRL(*this, "VtSetupBit"+box, wxChoice)->SetSelection(SetUpFeature_[i]);
	}
}

void VtSetupDialog::onSaveButton( wxCommandEvent& WXUNUSED(event) )
{
	wxString box;
	wxCommandEvent uartEvent(ON_UART, 807);
	wxCommandEvent uartElf2KEvent(ON_UART_ELF2K, 808);

	for (int i=0; i<16; i++)
	{
		box.Printf("%d", i);
		if (XRCCTRL(*this, "VtSetupBit"+box, wxChoice)->GetSelection() == 0)
			SetUpFeature_[i]  = 0;
		else
			SetUpFeature_[i]  = 1;
	}

	p_Main->setConfigBool(computerTypeStr_+"/SerialLog", XRCCTRL(*this, "SerialLog", wxCheckBox)->GetValue());

	switch (computerType_)
	{
		case ELF:
		case ELFII:
		case SUPERELF:
			p_Main->setConfigBool(computerTypeStr_+"/Uart", XRCCTRL(*this, "Uart", wxCheckBox)->GetValue());
			uartEvent.SetEventObject(this);
			wxPostEvent(p_Main, uartEvent);
		break;

		case ELF2K:
			p_Main->setConfigBool(computerTypeStr_+"/Uart", XRCCTRL(*this, "Uart", wxCheckBox)->GetValue());
			uartElf2KEvent.SetEventObject(this);
			wxPostEvent(p_Main, uartElf2KEvent);
		break;

		case COSMICOS:
		case MEMBER:
			p_Main->setConfigBool(computerTypeStr_+"/VtEf", XRCCTRL(*this, "VtEf", wxCheckBox)->GetValue());
		break;
	}

	long value = SetUpFeature_.to_ulong();
	switch (elfConfiguration_.vtType)
	{
		case VT52:
			p_Main->setConfigItem(computerTypeStr_+"/VT52Setup", value); 
		break;

		case VT100:
			p_Main->setConfigItem(computerTypeStr_+"/VT100Setup", value); 
		break;
	}

	EndModal(wxID_OK);
}

