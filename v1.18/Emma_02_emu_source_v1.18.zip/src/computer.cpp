/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 ***                                                             ***
 *** 1802 Code based on elf emulator by Michael H Riley with     ***
 *** copyright as below                                          ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "wx/frame.h"

#include "main.h"
#include "computer.h"

SwitchButton::SwitchButton(wxDC& dc, int type, wxColour bkgrClr, bool state, wxCoord x, wxCoord y)
{
	wxBitmap *upBitmap;
	wxBitmap *downBitmap;

	switch (type)
	{
		case VERTICAL_BUTTON:
			upBitmap = new wxBitmap (p_Main->getApplicationDir() + "images/swup.png", wxBITMAP_TYPE_PNG);
			downBitmap = new wxBitmap (p_Main->getApplicationDir() + "images/swdown.png", wxBITMAP_TYPE_PNG);
		break;

		case HORIZONTAL_BUTTON:
			upBitmap = new wxBitmap(p_Main->getApplicationDir() + "images/swright.png", wxBITMAP_TYPE_PNG);
			downBitmap = new wxBitmap(p_Main->getApplicationDir() + "images/swleft.png", wxBITMAP_TYPE_PNG);
		break;

		case PUSH_BUTTON:
			upBitmap = new wxBitmap(p_Main->getApplicationDir() + "images/pushup.png", wxBITMAP_TYPE_PNG);
			downBitmap = new wxBitmap(p_Main->getApplicationDir() + "images/pushdown.png", wxBITMAP_TYPE_PNG);
		break;

		case ELF2K_POWER_BUTTON:
			upBitmap = new wxBitmap(p_Main->getApplicationDir() + "images/Elf2Kon.png", wxBITMAP_TYPE_PNG);
			downBitmap = new wxBitmap(p_Main->getApplicationDir() + "images/Elf2Koff.png", wxBITMAP_TYPE_PNG);
		break;

		default:
			upBitmap = new wxBitmap (p_Main->getApplicationDir() + "images/swup.png", wxBITMAP_TYPE_PNG);
			downBitmap = new wxBitmap (p_Main->getApplicationDir() + "images/swdown.png", wxBITMAP_TYPE_PNG);
		break;
	}

	wxColour maskColour(255, 0, 255);

	maskUp = new wxMask (*upBitmap, maskColour);
	upBitmap->SetMask(maskUp);
	maskDown = new wxMask (*downBitmap, maskColour);
	downBitmap->SetMask(maskDown);

	upBitmapPointer = new wxBitmap(upBitmap->GetWidth(), upBitmap->GetHeight());  
	downBitmapPointer = new wxBitmap(downBitmap->GetWidth(), downBitmap->GetHeight());  

	wxMemoryDC memDC(*upBitmapPointer); 
	memDC.SetBackground(*wxTheBrushList->FindOrCreateBrush(bkgrClr)); 
	memDC.Clear(); 
	memDC.DrawBitmap(*upBitmap, 0, 0, true);
	memDC.SelectObject(wxNullBitmap); 

	memDC.SelectObject(*downBitmapPointer); 
	memDC.SetBackground(*wxTheBrushList->FindOrCreateBrush(bkgrClr)); 
	memDC.Clear(); 
	memDC.DrawBitmap(*downBitmap, 0, 0, true); 
	memDC.SelectObject(wxNullBitmap); 

	delete upBitmap;
	delete downBitmap;

	x_ = x;
	y_ = y;
	state_ = state;
	type_ = type;

	if (state == BUTTON_UP)
	{
		dc.DrawBitmap(*upBitmapPointer, x, y);
	}
	else
	{
		dc.DrawBitmap(*downBitmapPointer, x, y);
	}
}

SwitchButton::~SwitchButton()
{
	delete upBitmapPointer;
	delete downBitmapPointer;
}

void SwitchButton::onPaint(wxDC& dc)
{
	if (state_ == BUTTON_UP)
	{
		dc.DrawBitmap(*upBitmapPointer, x_, y_);
	}
	else
	{
		dc.DrawBitmap(*downBitmapPointer, x_, y_);
	}
}

bool SwitchButton::onMousePress(wxDC& dc, wxCoord x, wxCoord y)
{
	if (type_ != PUSH_BUTTON)
		return false;

	if ((x >= x_) &&(x <= (x_+30)) &&(y >= y_) &&(y <= (y_+30)))
	{
		state_ = !state_;
		if (state_ == BUTTON_UP)
		{
			dc.DrawBitmap(*upBitmapPointer, x_, y_);
		}
		else
		{
			dc.DrawBitmap(*downBitmapPointer, x_, y_);
		}
		return true;
	}
	return false;
}

bool SwitchButton::onMouseRelease(wxDC& dc, wxCoord x, wxCoord y)
{
	if ((x >= x_) &&(x <= (x_+30)) &&(y >= y_) &&(y <= (y_+30)))
	{
		state_ = !state_;
		if (state_ == BUTTON_UP)
		{
			dc.DrawBitmap(*upBitmapPointer, x_, y_);
		}
		else
		{
			dc.DrawBitmap(*downBitmapPointer, x_, y_);
		}
		return true;
	}
	return false;
}

void SwitchButton::setState(wxDC& dc, bool state)
{
	state_ = state;
	if (state_ == BUTTON_UP)
	{
		dc.DrawBitmap(*upBitmapPointer, x_, y_);
	}
	else
	{
		dc.DrawBitmap(*downBitmapPointer, x_, y_);
	}
}

void *RunComputer::Entry()
{
	while(!p_Main->emuClosing())
	{
		p_Computer->cpuInstruction();
	}
	wxCommandEvent event(KILL_COMPUTER, 809);
	event.SetEventObject(p_Main);
	wxPostEvent(p_Main, event);
	return NULL;
}

BEGIN_EVENT_TABLE(Panel, wxWindow)
	EVT_PAINT(Panel::onPaint)
	EVT_CHAR(Panel::onChar)
	EVT_KEY_DOWN(Panel::onKeyDown)
	EVT_KEY_UP(Panel::onKeyUp)
	EVT_LEFT_DOWN(Panel::onMousePress)
	EVT_LEFT_UP(Panel::onMouseRelease)
END_EVENT_TABLE()

Panel::Panel(wxWindow *parent, const wxSize& size)
: wxWindow(parent, wxID_ANY, wxDefaultPosition, size)
{
	updateQLed_ = false;
	updateResetLed_ = false;
	updatePauseLed_ = false;
	updateRunLed_ = false;
	updateLoadLed_ = false;
	for (int i=0; i<8; i++)
	{
		ledStatus[i] = 0;
		updateLed_[i] = false;
		segStatus[i] = 0;
		updateSeg_[i] = false;
	}
	updateAddress_ = false;
	updateData_ = false;
	updateDataTil313_ = false;

	qLedStatus = 0;
	resetLedStatus = 0;
	pauseLedStatus = 0;
	runLedStatus = 0;
	loadLedStatus = 0;
	addressStatus = 0;
	dataStatus = 0;
	dataTil313Status = 0;
	ms_ = 100;
}

Panel::~Panel()
{
}

void Panel::init()
{
}

void Panel::init(int WXUNUSED(computerType))
{
}

void Panel::connectKeyEvent(wxWindow* pclComponent)
{
  if(pclComponent)
  {
    pclComponent->Connect(wxID_ANY,
                          wxEVT_KEY_DOWN,
                          wxKeyEventHandler(Panel::onKeyDown),
                          (wxObject*) NULL,
                          this);
    pclComponent->Connect(wxID_ANY,
                          wxEVT_KEY_UP,
                          wxKeyEventHandler(Panel::onKeyUp),
                          (wxObject*) NULL,
                          this);
    pclComponent->Connect(wxID_ANY,
                          wxEVT_CHAR,
                          wxKeyEventHandler(Panel::onChar),
                          (wxObject*) NULL,
                          this);

	wxWindowListNode* pclNode = pclComponent->GetChildren().GetFirst();
    while(pclNode)
    {
      wxWindow* pclChild = pclNode->GetData();
      this->connectKeyEvent(pclChild);
     
      pclNode = pclNode->GetNext();
    }
  }
}
 
void Panel::onPaint(wxPaintEvent&WXUNUSED(event))
{
}

void Panel::onChar(wxKeyEvent& event)
{
	if (p_Vt100 != NULL)
	{
		int key = event.GetKeyCode();
		if (!p_Vt100->charPressed(event))
		{	
			if (forceUpperCase_ && key >= 'a' && key <= 'z')
				key -= 32;
			if (key > 255) key = 0;
			if (key !=0 && key < 128)
			{
				vtOut(key);
			}
		}
	}
	p_Computer->charEvent(event.GetKeyCode());
}

void Panel::vtOut(int value)
{
	if (keyEnd_ != keyStart_-1 ||(keyEnd_ ==25 && keyStart_ != 0))
	{
		keyBuffer_[keyEnd_++] = value;
		if (keyEnd_ == 26) keyEnd_ = 0;
		p_Vt100->dataAvailable();
		if (value == 27) p_Vt100->framingError(1);
	}
}

void Panel::onKeyDown(wxKeyEvent& event)
{
	int keycode;
	keycode = event.GetKeyCode();

	if (p_Vt100 != NULL)
	{
		if (keycode == lastKey_)
		{
			if (repeat_)
			{
				if (event.GetModifiers() != wxMOD_CONTROL || keycode != WXK_HOME || keycode != WXK_ESCAPE || keycode != WXK_SCROLL || keycode != WXK_TAB || keycode != WXK_RETURN)
				{
					lastKey_ = keycode;
					p_Vt100->keyDownPressed(event);
				}
			}
		}
		else
		{
			lastKey_ = keycode;
			p_Vt100->keyDownPressed(event);
		}
	}
	if (!p_Computer->keyDownPressed(keycode))
		event.Skip();
}

void Panel::onKeyUp(wxKeyEvent& event)
{
	if (p_Vt100 != NULL)
	{
		lastKey_ = 0;
		p_Vt100->keyUpPressed();
	}
	if (!p_Computer->keyUpReleased(event.GetKeyCode()))
		event.Skip();
}

Byte Panel::getKey(Byte vtOut)
{
	if (keyStart_ == keyEnd_)
		return vtOut;
	vtOut = keyBuffer_[keyStart_++];
	if (keyStart_ == 26) keyStart_ = 0;
	if (keyStart_ != keyEnd_)
		p_Vt100->dataAvailable();
	return vtOut;
}

void Panel::onMousePress(wxMouseEvent& WXUNUSED(event))
{
}

void Panel::onMouseRelease(wxMouseEvent& WXUNUSED(event))
{
}

void Panel::ledTimeout()
{
	wxClientDC dc(this);
	updateQLed(dc);
	updateResetLed(dc);
	updatePauseLed(dc);
	updateRunLed(dc);
	updateLoadLed(dc);
	for (int i=0; i<8; i++)
	{
		updateLed(dc, i);
		updateSeg(dc, i);
	}
	updateData(dc);
	updateDataTil313(dc);
	updateAddress(dc);
}

void Panel::setLedMs(long ms)
{
	ms_ = ms;
}

void Panel::setQLed(int status)
{
	if (qLedStatus != status)
	{
		qLedStatus = status;
		updateQLed_ = true;
		if (ms_ == 0)
		{
			wxClientDC dc(this);
			updateQLed(dc);
		}
	}
}

void Panel::updateQLed(wxDC& dc)
{
	if (updateQLed_)
	{
		qLedPointer->setStatus(dc, qLedStatus);
		updateQLed_ = false;
	}
}

void Panel::setResetLed(int status)
{
	if (resetLedStatus != status)
	{
		resetLedStatus = status;
		updateResetLed_ = true;
		if (ms_ == 0)
		{
			wxClientDC dc(this);
			updateResetLed(dc);
		}
	}
}

void Panel::updateResetLed(wxDC& dc)
{
	if (updateResetLed_)
	{
		resetLedPointer->setStatus(dc, resetLedStatus);
		updateResetLed_ = false;
	}
}

void Panel::setPauseLed(int status)
{
	if (pauseLedStatus != status)
	{
		pauseLedStatus = status;
		updatePauseLed_ = true;
		if (ms_ == 0)
		{
			wxClientDC dc(this);
			updatePauseLed(dc);
		}
	}
}

void Panel::updatePauseLed(wxDC& dc)
{
	if (updatePauseLed_)
	{
		pauseLedPointer->setStatus(dc, pauseLedStatus);
		updatePauseLed_ = false;
	}
}

void Panel::setRunLed(int status)
{
	if (runLedStatus != status)
	{
		runLedStatus = status;
		updateRunLed_ = true;
		if (ms_ == 0)
		{
			wxClientDC dc(this);
			updateRunLed(dc);
		}
	}
}

void Panel::updateRunLed(wxDC& dc)
{
	if (updateRunLed_)
	{
		runLedPointer->setStatus(dc, runLedStatus);
		updateRunLed_ = false;
	}
}

void Panel::setLoadLed(int status)
{
	if (loadLedStatus != status)
	{
		loadLedStatus = status;
		updateLoadLed_ = true;
		if (ms_ == 0)
		{
			wxClientDC dc(this);
			updateLoadLed(dc);
		}
	}
}

void Panel::updateLoadLed(wxDC& dc)
{
	if (updateLoadLed_)
	{
		loadLedPointer->setStatus(dc, loadLedStatus);
		updateLoadLed_ = false;
	}
}

void Panel::setLed(int i, int status)
{
	if (ledStatus[i] != status)
	{
		ledStatus[i] = status;
		updateLed_[i] = true;
		if (ms_ == 0)
		{
			wxClientDC dc(this);
			updateLed(dc, i);
		}
	}
}

void Panel::updateLed(wxDC& dc, int i)
{
	if (updateLed_[i])
	{
		ledPointer[i]->setStatus(dc, ledStatus[i]);
		updateLed_[i] = false;
	}
}

void Panel::showData(Byte value)
{
	if (dataStatus != value)
	{
		dataStatus = value;
		updateData_ = true;
		if (ms_ == 0)
		{
			wxClientDC dc(this);
			updateData(dc);
		}
	}
}

void Panel::updateData(wxDC& dc)
{
	if (updateData_)
	{
		dataPointer[0]->update(dc,(dataStatus>>4)&15);
		dataPointer[1]->update(dc, dataStatus&15);
		updateData_ = false;
	}
}

void Panel::showDataTil313(Byte value)
{
	if (dataTil313Status != value)
	{
		dataTil313Status = value;
		updateDataTil313_ = true;
		if (ms_ == 0)
		{
			wxClientDC dc(this);
			updateDataTil313(dc);
		}
	}
}

void Panel::updateDataTil313(wxDC& dc)
{
	if (updateDataTil313_)
	{
		dataTil313Pointer[0]->update(dc,(dataTil313Status>>4)&15);
		dataTil313Pointer[1]->update(dc, dataTil313Status&15);
		updateDataTil313_ = false;
	}
}

void Panel::showSeg(int number, Byte value)
{
	if (segStatus[number] != value)
	{
		segStatus[number] = value;
		updateSeg_[number] = true;
		if (ms_ == 0)
		{
			wxClientDC dc(this);
			updateSeg(dc, number);
		}
	}
}

void Panel::updateSeg(wxDC& dc, int number)
{
	if (updateSeg_[number])
	{
		segPointer[number]->update(dc, segStatus[number]);
		updateSeg_[number] = false;
	}
}

void Panel::showAddress(Word address)
{
	if (addressStatus != address)
	{
		addressStatus = address;
		updateAddress_ = true;
		if (ms_ == 0)
		{
			wxClientDC dc(this);
			updateAddress(dc);
		}
	}
}

void Panel::updateAddress(wxDC& dc)
{
	if (updateAddress_)
	{
		addressPointer[0]->update(dc, addressStatus>>12);
		addressPointer[1]->update(dc,(addressStatus>>8)&15);
		addressPointer[2]->update(dc,(addressStatus>>4)&15);
		addressPointer[3]->update(dc, addressStatus&15);
		updateAddress_ = false;
	}
}

void Panel::resetUp()
{
}

void Panel::resetDown()
{
}

void Panel::inUp()
{
}

void Panel::inDown()
{
}

void Panel::inSetState(bool state)
{
	wxClientDC dc(this);
	inSwitchButton->setState(dc, state);
}

void Panel::runUp()
{
#if wxCHECK_VERSION(2, 9, 0)
	runButtonPointer->SetBitmap(*upBitmapPointer);
#else
	runButtonPointer->SetBitmapLabel(*upBitmapPointer);
#endif
}

void Panel::runDown()
{
#if wxCHECK_VERSION(2, 9, 0)
	runButtonPointer->SetBitmap(*downBitmapPointer);
#else
	runButtonPointer->SetBitmapLabel(*downBitmapPointer);
#endif
}

void Panel::runSetState(bool state)
{
	wxClientDC dc(this);
	runSwitchButton->setState(dc, state);
}

void Panel::mpUp()
{
#if wxCHECK_VERSION(2, 9, 0)
	mpButtonPointer->SetBitmap(*upBitmapPointer);
#else
	mpButtonPointer->SetBitmapLabel(*upBitmapPointer);
#endif
}

void Panel::mpDown()
{
#if wxCHECK_VERSION(2, 9, 0)
	mpButtonPointer->SetBitmap(*downBitmapPointer);
#else
	mpButtonPointer->SetBitmapLabel(*downBitmapPointer);
#endif
}

void Panel::mpSetState(bool state)
{
	wxClientDC dc(this);
	mpSwitchButton->setState(dc, state);
}

void Panel::powerUp()
{
#if wxCHECK_VERSION(2, 9, 0)
	powerButtonPointer->SetBitmap(*upBitmapPointer);
#else
	powerButtonPointer->SetBitmapLabel(*upBitmapPointer);
#endif
}

void Panel::powerDown()
{
#if wxCHECK_VERSION(2, 9, 0)
	powerButtonPointer->SetBitmap(*downBitmapPointer);
#else
	powerButtonPointer->SetBitmapLabel(*downBitmapPointer);
#endif
}

void Panel::loadUp()
{
#if wxCHECK_VERSION(2, 9, 0)
	loadButtonPointer->SetBitmap(*upBitmapPointer);
#else
	loadButtonPointer->SetBitmapLabel(*upBitmapPointer);
#endif
}

void Panel::loadDown()
{
#if wxCHECK_VERSION(2, 9, 0)
	loadButtonPointer->SetBitmap(*downBitmapPointer);
#else
	loadButtonPointer->SetBitmapLabel(*downBitmapPointer);
#endif
}

void Panel::loadSetState(bool state)
{
	wxClientDC dc(this);
	loadSwitchButton->setState(dc, state);
}

void Panel::dataUp(int number)
{
#if wxCHECK_VERSION(2, 9, 0)
	dataSwitchPointer[number]->SetBitmap(*upBitmapPointer);
#else
	dataSwitchPointer[number]->SetBitmapLabel(*upBitmapPointer);
#endif
}

void Panel::dataDown(int number)
{
#if wxCHECK_VERSION(2, 9, 0)
	dataSwitchPointer[number]->SetBitmap(*downBitmapPointer);
#else
	dataSwitchPointer[number]->SetBitmapLabel(*downBitmapPointer);
#endif
}

void Panel::dataSetState(int number, bool state)
{
	wxClientDC dc(this);
	dataSwitchButton[number]->setState(dc, state);
}

void Panel::efUp(int number)
{
#if wxCHECK_VERSION(2, 9, 0)
	efSwitchPointer[number]->SetBitmap(*upBitmapPointer);
#else
	efSwitchPointer[number]->SetBitmapLabel(*upBitmapPointer);
#endif
}

void Panel::efDown(int number)
{
#if wxCHECK_VERSION(2, 9, 0)
	efSwitchPointer[number]->SetBitmap(*downBitmapPointer);
#else
	efSwitchPointer[number]->SetBitmapLabel(*downBitmapPointer);
#endif
}

Computer::Computer()
{
	memoryStart_ = 0;
	loadedProgram_ = NOPROGRAM;
	loadedOs_ = NOOS;
	lastTapeInput_ = 0;
	maxTapeInput_ = 0;
	gaugeValue_ = 0;
	sign_ = true;
	counter_ = 10;
	period_ = 24;
	basicExecAddress_[BASICADDR_KEY] = -1;
	basicExecAddress_[BASICADDR_READY] = -1;
	basicExecAddress_[BASICADDR_KEY_VT_RESTART] = -1;
	basicExecAddress_[BASICADDR_KEY_VT_INPUT] = -1;
	chip8baseVar_ = 0xef0;
	chip8mainLoop_ = 0x1b;
	chip8type_ = CHIP_NONE;
	for (int i=0; i<16; i++)
		chip8Register[i] = -1;

	threadPointer = new RunComputer();
	if ( threadPointer->Create() != wxTHREAD_NO_ERROR )
	{
		p_Main->message("Can't create thread");
	}
	threadPointer->SetPriority(WXTHREAD_MAX_PRIORITY);
}

bool Computer::isComputerRunning()
{
	return false;
}

void Computer::startComputerRun(bool WXUNUSED(load))
{
	p_Main->message("Illegal request to start Computer");
}

void Computer::onReset()
{
	p_Main->message("Illegal request to reuqest reset Computer");
}

void Computer::onRun()
{
	resetPressed_ = true;
}

void Computer::keyDown(int WXUNUSED(keycode))
{
}

bool Computer::keyDownExtended(int WXUNUSED(keycode), wxKeyEvent& WXUNUSED(event))
{
	return false;
}

bool Computer::keyDownPressed(int WXUNUSED(keycode))
{
	return false;
}

void Computer::keyUp(int WXUNUSED(keycode))
{
}

void Computer::keyUpExtended(int WXUNUSED(keycode), wxKeyEvent& WXUNUSED(event))
{
}

bool Computer::keyUpReleased(int WXUNUSED(keycode))
{
	return false;
}

void Computer::charEvent(int WXUNUSED(keycode))
{
}

void Computer::onButtonRelease(wxMouseEvent& WXUNUSED(event))
{
}

void Computer::onButtonPress(wxMouseEvent& WXUNUSED(event))
{
}

void Computer::cid1Bit8(bool WXUNUSED(set))
{
	p_Main->message("Illegal call to Cidelsa video bit set/reset");
}

int Computer::getComxExpansionType(int WXUNUSED(card))
{
	p_Main->message("Illegal call to fetch Comx expansion type");
	return 0;
}

void Computer::sleepComputer(long WXUNUSED(ms))
{
	p_Main->message("Illegal call to sleep computer");
}

void Computer::checkCaps()
{
}

void Computer::charFinished()
{
	p_Main->message("Illegal call that PECOM print is finished");
}

void Computer::finishStopTape()
{
	p_Main->message("Illegal call to stop PECOM/ETI tape");
}

void Computer::printOutPecom(int WXUNUSED(q))
{
	p_Main->message("Illegal call to send Q bit to PECOM printer");
}

void Computer::setElf2KDivider(Byte WXUNUSED(value))
{
	p_Main->message("Illegal call to set Elf 2000 divider value");
}

void Computer::removeElf2KSwitch()
{
	p_Main->message("Illegal call to stop Elf 2000 swicth panel");
}

void Computer::removeElfHex()
{
	p_Main->message("Illegal call to stop Elf hex panel");
}

void Computer::removeCosmicosHex()
{
	p_Main->message("Illegal call to stop Comsicos hex panel");
}

void Computer::removeElfLedModule()
{
	p_Main->message("Illegal call to stop Elf led panel");
}

void Computer::showData(Byte WXUNUSED(val))
{
	p_Main->message("Illegal call to display TIL311 data display");
}

void Computer::resetVideo()
{
	p_Main->message("Illegal call to reset video");
}

void Computer::resetComputer()
{
	p_Main->message("Illegal call to reset computer");
}

void Computer::clearBootstrap()
{
	p_Main->message("Illegal call to clear bootstrap");
}

void Computer::onInButtonRelease()
{
	p_Main->message("Illegal call to release Elf IN button");
}

void Computer::onInButtonPress()
{
	p_Main->message("Illegal call to press Elf IN button");
}

void Computer::onInButtonPress(Byte WXUNUSED(value))
{
	p_Main->message("Illegal call to press Elf IN button");
}

void Computer::cassette(short val)
{
	if (conversionTypeWav_ == 0)
	{
		if (val <= 0)
		{
			cassetteEf_ = tapePolarity_; // 0
			maxTapeInput_ = 0;
		}
		else
		{
			cassetteEf_ = !tapePolarity_; //1
			if (val > lastTapeInput_)
				maxTapeInput_ = val;
			else
				gaugeValue_ = maxTapeInput_ / 5;
		}
	}
	else
	{
		if (cassetteEf_ != tapePolarity_)
		{
			if (val > lastTapeInput_)
				maxTapeInput_ = val;
			else
			{
				gaugeValue_ = maxTapeInput_ / 5;
				cassetteEf_ = tapePolarity_; // 0
			}
		}
		else
		{
			if (val < lastTapeInput_)
				maxTapeInput_ = -val;
			else
			{
				gaugeValue_ = maxTapeInput_ / 5;
				cassetteEf_ = !tapePolarity_; //1
			}
		}
	}
	lastTapeInput_ = val;
}

void Computer::cassette(char val)
{
	if (conversionTypeWav_ == 0)
	{
		if (val < 0)
		{
/*			if (cassetteEf_ != tapePolarity_)
			{
//				if (period_ > 29)
//					p_Main->messageInt(period_);
				if (period_ < 23 || (period_ > 36 && period_ < 63))
				{
					period_++;
					lastTapeInput_ = val;
					return;
				}
				period_ = 0; // short 23-29 long 60-64
			}
			period_++;*/
			cassetteEf_ = tapePolarity_; // 0
			maxTapeInput_ = 0;
		}
		else
		{
/*			if (cassetteEf_ == tapePolarity_)
			{
//				if (period_ > 29)
//					p_Main->messageInt(period_);
				if (period_ < 23 || (period_ > 36 && period_ < 63))
				{
					period_++;
					lastTapeInput_ = val;
					return;
				}
				period_ = 0;
			}
			period_++;*/
			cassetteEf_ = !tapePolarity_; //1
			if (val > lastTapeInput_)
				maxTapeInput_ = val;
			else
				gaugeValue_ = maxTapeInput_ * 45;
		}
	}
	else
	{
		if (cassetteEf_ != tapePolarity_)
		{
			if (val > lastTapeInput_)
				maxTapeInput_ = val;
			else
			{
				gaugeValue_ = maxTapeInput_ * 45;
				cassetteEf_ = tapePolarity_; // 0
			}
		}
		else
		{
			if (val < lastTapeInput_)
				maxTapeInput_ = -val;
			else
			{
				gaugeValue_ = maxTapeInput_ * 45;
				cassetteEf_ = !tapePolarity_; //1
			}
		}
	}
	lastTapeInput_ = val;
}

void Computer::realCassette(short val)
{
	if (conversionType_ == 0)
	{
		if (val <= 0)
		{
			cassetteEf_ = tapePolarity_; // 0
			maxTapeInput_ = 0;
		}
		else
		{
			cassetteEf_ = !tapePolarity_; //1
			if (val > lastTapeInput_)
				maxTapeInput_ = val;
			else
				gaugeValue_ = maxTapeInput_;
		}
	}
	else
	{
		if (cassetteEf_ != tapePolarity_)
		{
			if (val > lastTapeInput_)
				maxTapeInput_ = val;
			else
			{
				gaugeValue_ = maxTapeInput_;
				cassetteEf_ = tapePolarity_; // 0
			}
		}
		else
		{
			if (val < lastTapeInput_)
				maxTapeInput_ = -val;
			else
			{
				gaugeValue_ = maxTapeInput_;
				cassetteEf_ = !tapePolarity_; //1
			}
		}
	}
	lastTapeInput_ = val;
}

void Computer::keyClear()
{
}

void Computer::startComputer()
{
}

void Computer::initComputer()
{
}

void Computer::configureComputer()
{
}

void Computer::onLoadButton()
{
}

void Computer::onMpButton()
{
}

void Computer::onRamButton()
{
}

void Computer::dataSwitch(int WXUNUSED(number))
{
}

void Computer::efSwitch(int WXUNUSED(number))
{
}

Byte Computer::getData()
{
	return 0;
}

void Computer::onHexDown(int WXUNUSED(hex))
{
}

void Computer::onHexKeyUp()
{
}

void Computer::reDefineInKey(int inKey)
{
	inKey_ = inKey;
}

void Computer::reDefineKeys()
{
}

int Computer::getRunState()
{
	return 0;
}

void Computer::checkLoadedSoftware()
{
}

void Computer::dataAvailable(bool WXUNUSED(data))
{
}

void Computer::thrStatus(bool WXUNUSED(data))
{
}

void Computer::setTempo(int WXUNUSED(tempo))
{
}

void Computer::switchQ(int WXUNUSED(value))
{
}

void Computer::reDefineKeysA(int* WXUNUSED(hexKeyDefB[]), int* WXUNUSED(keyDefGameValueB[]), int* WXUNUSED(keyDefGameHexB[]))
{
}

void Computer::reDefineKeysB(int* WXUNUSED(hexKeyDefB[]), int* WXUNUSED(keyDefGameValueB[]), int* WXUNUSED(keyDefGameHexB[]))
{
}

void Computer::onNumberKeyDown(int WXUNUSED(id))
{
}

void Computer::onNumberKeyUp()
{
}

void Computer::ledTimeout()
{
}

void Computer::setLedMs(long WXUNUSED(ms))
{
}

Byte Computer::getKey(Byte WXUNUSED(vtOut))
{
	return 0;
}

void Computer::activateMainWindow()
{
}

void Computer::showChip8Registers()
{
	int reg = chip8baseVar_;
	int newValue;

	for (int i=0; i<16; i++)
	{
		newValue = p_Computer->readMem(reg);
		if (newValue != chip8Register[i])
		{
			p_Main->showChip8Register(i, newValue);
			chip8Register[i] = newValue;
		}
		reg++;
	}
}