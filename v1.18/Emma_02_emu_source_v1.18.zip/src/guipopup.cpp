/*
 *******************************************************************
 *** This software is copyright 2008 by Marcel van Tongeren      ***
 *** You have permission to use, modify, copy, and distribute    ***
 *** this software so long as this copyright notice is retained. ***
 *** This software may not be used in commercial applications    ***
 *** without express written permission from the author.         ***
 *******************************************************************
*/

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#include "main.h"
#include "guipopup.h"

#include "wx/xrc/xmlres.h"             

BEGIN_EVENT_TABLE(PopupDialog, wxDialog)
	EVT_BUTTON(XRCID("Disk1Button"), PopupDialog::onComxDisk1)
	EVT_TEXT(XRCID("Disk1File"), PopupDialog::onComxDiskText1)
	EVT_BUTTON(XRCID("EjectDisk1"), PopupDialog::onComxDiskEject1)
	EVT_BUTTON(XRCID("Disk2Button"), PopupDialog::onComxDisk2)
	EVT_TEXT(XRCID("Disk2File"), PopupDialog::onComxDiskText2)
	EVT_BUTTON(XRCID("EjectDisk2"), PopupDialog::onComxDiskEject2)
	EVT_BUTTON(XRCID("CasButton"), PopupDialog::onCassette)
	EVT_TEXT(XRCID("WavFile"), PopupDialog::onCassetteText)
	EVT_BUTTON(XRCID("EjectCas"), PopupDialog::onCassetteEject)
	EVT_BUTTON(XRCID("RunButton"), PopupDialog::onLoadRunButton)
	EVT_BUTTON(XRCID("LoadButton"), PopupDialog::onLoadButton)
	EVT_BUTTON(XRCID("SaveButton"), PopupDialog::onSaveButton)
	EVT_BUTTON(XRCID("DsaveButton"), PopupDialog::onDataSaveButton)
	EVT_CHECKBOX(XRCID("UseLocation"), PopupDialog::onUseLocation)
	EVT_TEXT(XRCID("SaveStart"), PopupDialog::onSaveStart)
	EVT_TEXT(XRCID("SaveEnd"), PopupDialog::onSaveEnd)
	EVT_TEXT(XRCID("SaveExec"), PopupDialog::onSaveExec)

	EVT_CHECKBOX(XRCID("Elf2KControlWindowsPopup"), PopupDialog::onElf2KControlWindows)
	EVT_CHECKBOX(XRCID("Elf2KSwitchPopup"), PopupDialog::onElf2KSwitch)
	EVT_CHECKBOX(XRCID("Elf2KHexPopup"), PopupDialog::onElf2KHex)

	EVT_CHECKBOX(XRCID("ControlWindowsPopupCosmicos"), PopupDialog::onCosmicosControlWindows)
	EVT_CHECKBOX(XRCID("HexPopupCosmicos"), PopupDialog::onCosmicosHex)

	EVT_CHECKBOX(XRCID("ControlWindowsPopupElf"), PopupDialog::onElfControlWindows)

	EVT_CHECKBOX(XRCID("ControlWindowsPopupMembership"), PopupDialog::onMembershipControlWindows)

	EVT_SPINCTRL(XRCID("AdsChannelPopup"), PopupDialog::onTelmacAdsChannel)
	EVT_TEXT(XRCID("AdsChannelPopup"), PopupDialog::onTelmacAdsChannelText)
	EVT_SPINCTRL(XRCID("AdsVoltPopup"), PopupDialog::onTelmacAdsVolt)
	EVT_TEXT(XRCID("AdsVoltPopup"), PopupDialog::onTelmacAdsVoltText)
	EVT_SPINCTRL(XRCID("AdiChannelPopup"), PopupDialog::onTelmacAdiChannel)
	EVT_TEXT(XRCID("AdiChannelPopup"), PopupDialog::onTelmacAdiChannelText)
	EVT_SPINCTRL(XRCID("AdiVoltPopup"), PopupDialog::onTelmacAdiVolt)
	EVT_TEXT(XRCID("AdiVoltPopup"), PopupDialog::onTelmacAdiVoltText)

	EVT_BUTTON(XRCID("OK"), PopupDialog::onOk)
	EVT_ACTIVATE(PopupDialog::onFocus)
END_EVENT_TABLE()

PopupDialog::PopupDialog(wxWindow* parent)
{
	computerStr_ = p_Main->getRunningComputerStr();
	computer_ = p_Main->getRunningComputerId();

	tapeOnBitmap = wxBitmap(p_Main->getApplicationDir() + "images/tick.png", wxBITMAP_TYPE_PNG);
	tapeOffBitmap = wxBitmap(p_Main->getApplicationDir() + "images/minus.png", wxBITMAP_TYPE_PNG);

	loadingGui_ = true;
	if (computer_ == ELFII || computer_ == SUPERELF)
	{
		wxXmlResource::Get()->Load(p_Main->getApplicationDir()+p_Main->getPathSep()+"menuElf.xrc");
		wxXmlResource::Get()->LoadDialog(this, parent, wxT("PopupElf"));
		XRCCTRL(*this, "PopupElf", wxDialog)->SetLabel(p_Main->getSelectedComputerText()+" Menu");
	}
	else
	{
		if (computer_ == VIP || computer_ == TMC1800 || computer_ == TMC2000 || computer_ == NANO  || computer_ == ETI)
		{
			wxXmlResource::Get()->Load(p_Main->getApplicationDir()+p_Main->getPathSep()+"menu_Cas_Mem.xrc");
			wxXmlResource::Get()->LoadDialog(this, parent, wxT("Popup_Cas_Mem"));
			XRCCTRL(*this, "Popup_Cas_Mem", wxDialog)->SetLabel(p_Main->getSelectedComputerText()+" Menu");
		}
		else
		{
			wxXmlResource::Get()->Load(p_Main->getApplicationDir()+p_Main->getPathSep()+"menu"+computerStr_+".xrc");
			wxXmlResource::Get()->LoadDialog(this, parent, "Popup"+computerStr_);
			XRCCTRL(*this, "Popup"+computerStr_, wxDialog)->SetLabel(p_Main->getSelectedComputerText()+" Menu");
		}
	}
	loadingGui_ = false;
}

PopupDialog::~PopupDialog()
{
}

void PopupDialog::init()
{
	p_Main->setNoteBook();

	switch (computer_)
	{
		case COMX:
			XRCCTRL(*this, "Disk1File", wxTextCtrl)->SetValue(p_Main->getFloppyFile(0));
			XRCCTRL(*this, "Disk2File", wxTextCtrl)->SetValue(p_Main->getFloppyFile(1));
			XRCCTRL(*this, "WavFile", wxTextCtrl)->SetValue(p_Main->getWaveFile(computer_));
			setLocation(p_Main->getUseLoadLocation(computer_), p_Main->getSaveStartString(computer_), p_Main->getSaveEndString(computer_), p_Main->getSaveExecString(computer_));
		break;

		case ELF2K:
			XRCCTRL(*this, "Elf2KControlWindowsPopup", wxCheckBox)->SetValue(p_Main->getUseElfControlWindows(computer_));
			XRCCTRL(*this, "Elf2KSwitchPopup", wxCheckBox)->SetValue(p_Main->getUseSwitch(computer_));
			XRCCTRL(*this, "Elf2KHexPopup", wxCheckBox)->SetValue(p_Main->getUseHex(computer_));
			setStartLocation(p_Main->getSaveStartString(computer_));
			setEndLocation(p_Main->getSaveEndString(computer_));
		break;

		case VIP:
		case TMC1800:
		case TMC2000:
		case NANO:
		case ETI:
			XRCCTRL(*this, "WavFile", wxTextCtrl)->SetValue(p_Main->getWaveFile(computer_));
			setStartLocation(p_Main->getSaveStartString(computer_));
			setEndLocation(p_Main->getSaveEndString(computer_));
		break;

		case COSMICOS:
			XRCCTRL(*this, "WavFile", wxTextCtrl)->SetValue(p_Main->getWaveFile(computer_));
			XRCCTRL(*this, "ControlWindowsPopupCosmicos", wxCheckBox)->SetValue(p_Main->getUseElfControlWindows(computer_));
			XRCCTRL(*this, "HexPopupCosmicos", wxCheckBox)->SetValue(p_Main->getUseHex(computer_));
			setStartLocation(p_Main->getSaveStartString(computer_));
			setEndLocation(p_Main->getSaveEndString(computer_));
		break;

		case ELF:
		case ELFII:
		case SUPERELF:
			setTapeType(p_Main->getUseTape(computer_));
			enableMemAccessGui(true);
			XRCCTRL(*this, "WavFile", wxTextCtrl)->SetValue(p_Main->getWaveFile(computer_));
			XRCCTRL(*this, "ControlWindowsPopupElf", wxCheckBox)->SetValue(p_Main->getUseElfControlWindows(computer_));
			setLocation(p_Main->getUseLoadLocation(computer_), p_Main->getSaveStartString(computer_), p_Main->getSaveEndString(computer_), p_Main->getSaveExecString(computer_));
		break;

		case MEMBER:
			XRCCTRL(*this, "ControlWindowsPopupMembership", wxCheckBox)->SetValue(p_Main->getUseElfControlWindows(computer_));
			setStartLocation(p_Main->getSaveStartString(computer_));
			setEndLocation(p_Main->getSaveEndString(computer_));
		break;

		case TMC600:
			XRCCTRL(*this, "WavFile", wxTextCtrl)->SetValue(p_Main->getWaveFile(computer_));
			setLocation(p_Main->getUseLoadLocation(computer_), p_Main->getSaveStartString(computer_), p_Main->getSaveEndString(computer_), p_Main->getSaveExecString(computer_));
			if (p_Computer->getInType(3) == TELMACIN)
				enableIoGui();
		break;

		case PECOM:
			XRCCTRL(*this, "WavFile", wxTextCtrl)->SetValue(p_Main->getWaveFile(computer_));
			setLocation(p_Main->getUseLoadLocation(computer_), p_Main->getSaveStartString(computer_), p_Main->getSaveEndString(computer_), p_Main->getSaveExecString(computer_));
		break;

	}
}

void PopupDialog::setLocation(bool state, wxString saveStart, wxString saveEnd, wxString saveExec)
{
	wxString printBuffer;
	if (state)
	{
		XRCCTRL(*this,"SaveStart", wxTextCtrl)->SetValue(saveStart);
		XRCCTRL(*this,"SaveEnd", wxTextCtrl)->SetValue(saveEnd);
		XRCCTRL(*this,"SaveExec", wxTextCtrl)->SetValue(saveExec);
	}
	else
	{
		XRCCTRL(*this,"SaveStart", wxTextCtrl)->SetValue("");
		XRCCTRL(*this,"SaveEnd", wxTextCtrl)->SetValue("");
		XRCCTRL(*this,"SaveExec", wxTextCtrl)->SetValue("");
	}
	XRCCTRL(*this, "UseLocation", wxCheckBox)->SetValue(state);
	XRCCTRL(*this, "TextStart", wxStaticText)->Enable(state);
	XRCCTRL(*this, "TextEnd", wxStaticText)->Enable(state);
	XRCCTRL(*this, "TextExec", wxStaticText)->Enable(state);
	XRCCTRL(*this, "SaveStart", wxTextCtrl)->Enable(state);
	XRCCTRL(*this, "SaveEnd", wxTextCtrl)->Enable(state);
	XRCCTRL(*this, "SaveExec", wxTextCtrl)->Enable(state);
}

void PopupDialog::setStartLocation(wxString saveStart)
{
	XRCCTRL(*this,"SaveStart", wxTextCtrl)->SetValue(saveStart);
}

void PopupDialog::setEndLocation(wxString saveEnd)
{
	XRCCTRL(*this,"SaveEnd", wxTextCtrl)->SetValue(saveEnd);
}

void PopupDialog::setTapeType(bool useTape)
{
	XRCCTRL(*this, "CasButton", wxButton)->Enable(useTape);
	XRCCTRL(*this, "WavFile", wxTextCtrl)->Enable(useTape);
	XRCCTRL(*this, "EjectCas", wxButton)->Enable(useTape);
}

void PopupDialog::enableMemAccessGui(bool status)
{
	if ((p_Computer->getLoadedProgram()&0x1) == 0x1)
	{
		XRCCTRL(*this, "RunButton", wxButton)->Enable(status);
		XRCCTRL(*this, "UseLocation", wxCheckBox)->Enable(status);
		XRCCTRL(*this, "DsaveButton", wxButton)->Enable(status);
		XRCCTRL(*this, "TextStart", wxStaticText)->Enable(p_Main->getUseLoadLocation(computer_));
		XRCCTRL(*this, "TextEnd", wxStaticText)->Enable(p_Main->getUseLoadLocation(computer_));
		XRCCTRL(*this, "TextExec", wxStaticText)->Enable(p_Main->getUseLoadLocation(computer_));
		XRCCTRL(*this, "SaveStart", wxTextCtrl)->Enable(p_Main->getUseLoadLocation(computer_));
		XRCCTRL(*this, "SaveEnd", wxTextCtrl)->Enable(p_Main->getUseLoadLocation(computer_));
		XRCCTRL(*this, "SaveExec", wxTextCtrl)->Enable(p_Main->getUseLoadLocation(computer_));
	}
}

void PopupDialog::enableIoGui()
{
	XRCCTRL(*this,"AdiInputTextPopup", wxStaticText)->Enable(true);
	XRCCTRL(*this,"AdiChannelPopup", wxSpinCtrl)->Enable(true);
	XRCCTRL(*this,"AdiVoltPopup", wxSpinCtrl)->Enable(true);
	XRCCTRL(*this,"AdiVoltTextPopup", wxStaticText)->Enable(true);
	XRCCTRL(*this,"AdsInputTextPopup", wxStaticText)->Enable(true);
	XRCCTRL(*this,"AdsChannelPopup", wxSpinCtrl)->Enable(true);
	XRCCTRL(*this,"AdsVoltPopup", wxSpinCtrl)->Enable(true);
	XRCCTRL(*this,"AdsVoltTextPopup", wxStaticText)->Enable(true);
}

void PopupDialog::onOk(wxCommandEvent&WXUNUSED(event))
{
	Show(false);
}

void PopupDialog::onFocus(wxActivateEvent&WXUNUSED(event))
{
	p_Main->setNoteBook();
}

void PopupDialog::onComxDisk1(wxCommandEvent&event)
{
	p_Main->onComxDisk1(event);
	XRCCTRL(*this, "Disk1File", wxTextCtrl)->SetValue(p_Main->getFloppyFile(0));
}

void PopupDialog::onComxDiskText1(wxCommandEvent&event)
{
	p_Main->onComxDiskText1(event);
	if (p_Main->getGuiMode())
		p_Main->setTextCtrl("Disk1FileComx", p_Main->getFloppyFile(0));
}

void PopupDialog::onComxDiskEject1(wxCommandEvent&event)
{
	p_Main->onComxDiskEject1(event);
	XRCCTRL(*this, "Disk1File", wxTextCtrl)->SetValue(p_Main->getFloppyFile(0));
}

void PopupDialog::onComxDisk2(wxCommandEvent&event)
{
	p_Main->onComxDisk2(event);
	XRCCTRL(*this, "Disk2File", wxTextCtrl)->SetValue(p_Main->getFloppyFile(1));
}

void PopupDialog::onComxDiskText2(wxCommandEvent&event)
{
	p_Main->onComxDiskText2(event);
	if (p_Main->getGuiMode())
		p_Main->setTextCtrl("Disk2FileComx", p_Main->getFloppyFile(1));
}

void PopupDialog::onComxDiskEject2(wxCommandEvent&event)
{
	p_Main->onComxDiskEject2(event);
	XRCCTRL(*this, "Disk2File", wxTextCtrl)->SetValue(p_Main->getFloppyFile(1));
}

void PopupDialog::onElf2KControlWindows(wxCommandEvent&event)
{
 	p_Main->onElf2KControlWindows(event);
	if (p_Main->getGuiMode())
		p_Main->setCheckBox("Elf2KControlWindows", event.IsChecked());
}

void PopupDialog::onElf2KSwitch(wxCommandEvent&event)
{
 	p_Main->onElf2KSwitch(event);
	if (p_Main->getGuiMode())
	{
		if (event.IsChecked())
			XRCCTRL(*this, "Elf2KHexPopup", wxCheckBox)->SetValue(false);
		p_Main->setCheckBox("Elf2KSwitch", event.IsChecked());
	}
}

void PopupDialog::onElf2KHex(wxCommandEvent&event)
{
 	p_Main->onElf2KHex(event);
	if (p_Main->getGuiMode())
	{
		if (event.IsChecked())
			XRCCTRL(*this, "Elf2KSwitchPopup", wxCheckBox)->SetValue(false);
		p_Main->setCheckBox("Elf2KHex", event.IsChecked());
	}
}

void PopupDialog::onCosmicosControlWindows(wxCommandEvent&event)
{
 	p_Main->onCosmicosControlWindows(event);
	if (p_Main->getGuiMode())
		p_Main->setCheckBox("ControlWindowsCosmicos", event.IsChecked());
}

void PopupDialog::onCosmicosHex(wxCommandEvent&event)
{
 	p_Main->onCosmicosHex(event);
	if (p_Main->getGuiMode())
		p_Main->setCheckBox("HexCosmicos", event.IsChecked());
}

void PopupDialog::onElfControlWindows(wxCommandEvent&event)
{
 	p_Main->onElfControlWindows(event);
	if (p_Main->getGuiMode())
		p_Main->setCheckBox("ControlWindows"+computerStr_, event.IsChecked());
}

void PopupDialog::onMembershipControlWindows(wxCommandEvent&event)
{
 	p_Main->onMembershipControlWindows(event);
	if (p_Main->getGuiMode())
		p_Main->setCheckBox("ControlWindowsMembership", event.IsChecked());
}

void PopupDialog::onTelmacAdsChannel(wxSpinEvent&event)
{
	if (loadingGui_)  return;
	p_Main->onTelmacAdsChannel(event);
	XRCCTRL(*this, "AdsVoltPopup", wxSpinCtrl)->SetValue(p_Computer->getAds(event.GetPosition()));

	if (p_Main->getGuiMode())
		p_Main->setSpinCtrl("AdsChannel", event.GetPosition());
}

void PopupDialog::onTelmacAdsVolt(wxSpinEvent&event)
{
	if (loadingGui_)  return;
	p_Main->onTelmacAdsVolt(event);
	if (p_Main->getGuiMode())
		p_Main->setSpinCtrl("AdsVolt", event.GetPosition()); 
}

void PopupDialog::onTelmacAdsChannelText(wxCommandEvent&event)
{
	if (loadingGui_)  return;
	p_Main->onTelmacAdsChannelText(event);
	int adsChannel = XRCCTRL(*this, "AdsChannelPopup", wxSpinCtrl)->GetValue();
	int adsValue = p_Computer->getAds(adsChannel);
	XRCCTRL(*this, "AdsVoltPopup", wxSpinCtrl)->SetValue(adsValue);

	if (p_Main->getGuiMode())
	{
		p_Main->setSpinCtrl("AdsChannel", XRCCTRL(*this, "AdsChannelPopup", wxSpinCtrl)->GetValue());
		p_Main->setSpinCtrl("AdsVolt", adsValue);
	}
}

void PopupDialog::onTelmacAdsVoltText(wxCommandEvent&event)
{
	if (loadingGui_)  return;
	p_Main->onTelmacAdsVoltText(event);
	if (p_Main->getGuiMode())
		p_Main->setSpinCtrl("AdsVolt", XRCCTRL(*this, "AdsVoltPopup", wxSpinCtrl)->GetValue()); 
}

void PopupDialog::onTelmacAdiChannel(wxSpinEvent&event)
{
	if (loadingGui_)  return;
	p_Main->onTelmacAdiChannel(event);
	XRCCTRL(*this, "AdiVoltPopup", wxSpinCtrl)->SetValue(p_Computer->getAdi(event.GetPosition()));

	if (p_Main->getGuiMode())
		p_Main->setSpinCtrl("AdiChannel", event.GetPosition());
}

void PopupDialog::onTelmacAdiVolt(wxSpinEvent&event)
{
	if (loadingGui_)  return;
	p_Main->onTelmacAdiVolt(event);
	if (p_Main->getGuiMode())
		p_Main->setSpinCtrl("AdiVolt", event.GetPosition()); 
}

void PopupDialog::onTelmacAdiChannelText(wxCommandEvent&event)
{
	if (loadingGui_)  return;
	p_Main->onTelmacAdiChannelText(event);
	int adiChannel = XRCCTRL(*this, "AdiChannelPopup", wxSpinCtrl)->GetValue();
	int adiValue = p_Computer->getAdi(adiChannel);
	XRCCTRL(*this, "AdiVoltPopup", wxSpinCtrl)->SetValue(adiValue);

	if (p_Main->getGuiMode())
	{
		p_Main->setSpinCtrl("AdiChannel", XRCCTRL(*this, "AdiChannelPopup", wxSpinCtrl)->GetValue());
		p_Main->setSpinCtrl("AdiVolt", adiValue);
	}
}

void PopupDialog::onTelmacAdiVoltText(wxCommandEvent&event)
{
	if (loadingGui_)  return;
	p_Main->onTelmacAdiVoltText(event);
	if (p_Main->getGuiMode())
		p_Main->setSpinCtrl("AdiVolt", XRCCTRL(*this, "AdiVoltPopup", wxSpinCtrl)->GetValue()); 
}

void PopupDialog::onCassette(wxCommandEvent&event)
{
 	p_Main->onCassette(event);
	XRCCTRL(*this, "WavFile", wxTextCtrl)->SetValue(p_Main->getWaveFile(computer_));
}

void PopupDialog::onCassetteText(wxCommandEvent&event)
{
 	p_Main->onCassetteText(event);
	if (p_Main->getGuiMode())
		p_Main->setTextCtrl("WavFile"+computerStr_, p_Main->getWaveFile(computer_));
}

void PopupDialog::onCassetteEject(wxCommandEvent&event)
{
 	p_Main->onCassetteEject(event);
	XRCCTRL(*this, "WavFile", wxTextCtrl)->SetValue(p_Main->getWaveFile(computer_));
}

void PopupDialog::onLoadRunButton(wxCommandEvent&event)
{
 	p_Main->onLoadRunButton(event);
}

void PopupDialog::onLoadButton(wxCommandEvent&event)
{
 	p_Main->onLoadButton(event);
}

void PopupDialog::onSaveButton(wxCommandEvent&event)
{
 	p_Main->onSaveButton(event);
}

void PopupDialog::onDataSaveButton(wxCommandEvent&event)
{
 	p_Main->onDataSaveButton(event);
}

void PopupDialog::onSaveStart(wxCommandEvent& event)
{
 	p_Main->onSaveStart(event);
	p_Main->setTextCtrl("SaveStart"+computerStr_, event.GetString());
}

void PopupDialog::onSaveEnd(wxCommandEvent& event)
{
 	p_Main->onSaveEnd(event);
	p_Main->setTextCtrl("SaveEnd"+computerStr_, event.GetString());
}

void PopupDialog::onSaveExec(wxCommandEvent& event)
{
 	p_Main->onSaveExec(event);
	p_Main->setTextCtrl("SaveExec"+computerStr_, event.GetString());
}

void PopupDialog::onUseLocation(wxCommandEvent&event)
{
 	p_Main->onUseLocation(event);
	XRCCTRL(*this, "TextStart", wxStaticText)->Enable(event.IsChecked());
	XRCCTRL(*this, "TextEnd", wxStaticText)->Enable(event.IsChecked());
	XRCCTRL(*this, "TextExec", wxStaticText)->Enable(event.IsChecked());
	XRCCTRL(*this, "SaveStart", wxTextCtrl)->Enable(event.IsChecked());
	XRCCTRL(*this, "SaveEnd", wxTextCtrl)->Enable(event.IsChecked());
	XRCCTRL(*this, "SaveExec", wxTextCtrl)->Enable(event.IsChecked());
	if (p_Main->getGuiMode())
		p_Main->setCheckBox("UseLocation"+computerStr_, event.IsChecked());
}

