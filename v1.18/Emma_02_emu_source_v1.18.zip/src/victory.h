#ifndef VICTORY_H
#define VICTORY_H

#include "cdp1802.h"
#include "pixie.h"

class Victory : public Cdp1802, public Pixie
{
public:
	Victory(const wxString& title, const wxPoint& pos, const wxSize& size, double zoom, double zoomfactor, int computerType);
	~Victory();

	void configureComputer();
	void reDefineKeysA(int *, int *, int *);
	void reDefineKeysB(int *, int *, int *);
	void keyDown(int keycode);
	void keyUp(int keycode);

	Byte ef(int flag);
	Byte ef3();
	Byte ef4();
	Byte in(Byte port, Word address);
	void out(Byte port, Word address, Byte value);
	void outVictory(Byte value);
	void cycle(int type);

	void startComputer();
	Byte readMem(Word addr);
	void writeMem(Word addr, Byte value, bool writeRom);
	void cpuInstruction();
	void onReset();

private:
	int victoryKeyPort_;
	Byte victoryKeyState_[2][10];
	int colourMask_;

	int keyDefA_[16];
	int keyDefB_[16];
	KeyDef keyDefinition[512];

	int keyDefGameHexA_[5];
	int keyDefGameValueA_[5];
	int keyDefGameHexB_[5];
	int keyDefGameValueB_[5];
};

#endif  // VICTORY_H
